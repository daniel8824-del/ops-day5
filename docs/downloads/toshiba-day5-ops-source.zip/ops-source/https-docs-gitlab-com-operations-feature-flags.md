<!-- source: https://docs.gitlab.com/operations/feature_flags -->

/

* * *

# Feature flags

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

With feature flags, you can deploy your application’s new features to production in smaller batches.
You can toggle a feature on and off to subsets of users, helping you achieve Continuous Delivery.
Feature flags help reduce risk, allowing you to do controlled testing, and separate feature
delivery from customer launch.

A [complete list of feature flags](https://docs.gitlab.com/administration/feature_flags/list/) in GitLab is also available.

For an example of feature flags in action, see [Eliminating risk with feature flags](https://www.youtube.com/watch?v=U9WqoK9froI).

For a click-through demo, see [Feature Flags](https://tech-marketing.gitlab.io/static-demos/feature-flags/feature-flags-html.html).

## Using feature flags [Permalink](https://docs.gitlab.com/operations/feature_flags/\#using-feature-flags "Permalink")

GitLab offers an [Unleash](https://github.com/Unleash/unleash)-compatible API for feature flags.

By enabling or disabling a flag in GitLab, your application
can determine which features to enable or disable.

You can create feature flags in GitLab and use the API from your application
to get the list of feature flags and their statuses. The application must be configured to communicate
with GitLab, so it’s up to developers to use a compatible client library and
[integrate the feature flags in your app](https://docs.gitlab.com/operations/feature_flags/#integrate-feature-flags-with-your-application).

## Create a feature flag [Permalink](https://docs.gitlab.com/operations/feature_flags/\#create-a-feature-flag "Permalink")

To create and enable a feature flag:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Deploy** \> **Feature flags**.
3. Select **New feature flag**.
4. Enter a name that starts with a letter and contains only lowercase letters, digits, underscores (`_`),
or dashes (`-`), and does not end with a dash (`-`) or underscore (`_`).
5. Optional. Enter a description (255 characters maximum).
6. Add feature flag [**Strategies**](https://docs.gitlab.com/operations/feature_flags/#feature-flag-strategies) to define how the flag should be applied. For each strategy, include the **Type** (defaults to [**All users**](https://docs.gitlab.com/operations/feature_flags/#all-users))
and **Environments** (defaults to all environments).
7. Select **Create feature flag**.

To change these settings, select **Edit** (pencil)
next to any feature flag in the list.

## Maximum number of feature flags [Permalink](https://docs.gitlab.com/operations/feature_flags/\#maximum-number-of-feature-flags "Permalink")

The maximum number of feature flags per project on GitLab Self-Managed
is 200. For GitLab.com, the maximum number is determined by [tier](https://about.gitlab.com/pricing/):

| Tier | Feature flags per project (GitLab.com) | Feature flags per project (GitLab Self-Managed) |
| --- | --- | --- |
| Free | 50 | 200 |
| Premium | 150 | 200 |
| Ultimate | 200 | 200 |

## Feature flag strategies [Permalink](https://docs.gitlab.com/operations/feature_flags/\#feature-flag-strategies "Permalink")

You can apply a feature flag strategy across multiple environments, without defining
the strategy multiple times.

GitLab feature flags are based on [Unleash](https://docs.getunleash.io/). In Unleash, there are
[strategies](https://docs.getunleash.io/reference/activation-strategies) for granular feature
flag controls. GitLab feature flags can have multiple strategies, and the supported strategies are:

- [All users](https://docs.gitlab.com/operations/feature_flags/#all-users)
- [Percent of Users](https://docs.gitlab.com/operations/feature_flags/#percent-of-users)
- [User IDs](https://docs.gitlab.com/operations/feature_flags/#user-ids)
- [User List](https://docs.gitlab.com/operations/feature_flags/#user-list)

Strategies can be added to feature flags when [creating a feature flag](https://docs.gitlab.com/operations/feature_flags/#create-a-feature-flag),
or by editing an existing feature flag after creation by navigating to **Deploy** \> **Feature flags**
and selecting **Edit** (pencil).

### All users [Permalink](https://docs.gitlab.com/operations/feature_flags/\#all-users "Permalink")

Enables the feature for all users. It uses the Standard (`default`) Unleash activation [strategy](https://docs.getunleash.io/reference/activation-strategies#standard).

### Percent Rollout [Permalink](https://docs.gitlab.com/operations/feature_flags/\#percent-rollout "Permalink")

Enables the feature for a percentage of page views, with configurable consistency
of behavior. This consistency is also known as stickiness. It uses the
Gradual Rollout (`flexibleRollout`) Unleash activation [strategy](https://docs.getunleash.io/reference/activation-strategies#gradual-rollout).

You can configure the consistency to be based on:

- **User IDs**: Each user ID has a consistent behavior, ignoring session IDs.
- **Session IDs**: Each session ID has a consistent behavior, ignoring user IDs.
- **Random**: Consistent behavior is not guaranteed. The feature is enabled for the
selected percentage of page views randomly. User IDs and session IDs are ignored.
- **Available ID**: Consistent behavior is attempted based on the status of the user:
  - If the user is logged in, make behavior consistent based on user ID.
  - If the user is anonymous, make the behavior consistent based on the session ID.
  - If there is no user ID or session ID, then the feature is enabled for the selected
    percentage of page view randomly.

For example, set a value of 15% based on **Available ID** to enable the feature for 15% of page views. For
authenticated users this is based on their user ID. For anonymous users with a session ID it would be based on their
session ID instead as they do not have a user ID. Then if no session ID is provided, it falls back to random.

The rollout percentage can be from 0% to 100%.

Selecting a consistency based on User IDs functions the same as the [percent of Users](https://docs.gitlab.com/operations/feature_flags/#percent-of-users) rollout.

Selecting **Random** provides inconsistent application behavior for individual users.

### Percent of Users [Permalink](https://docs.gitlab.com/operations/feature_flags/\#percent-of-users "Permalink")

Enables the feature for a percentage of authenticated users. It uses the Unleash activation strategy
[`gradualRolloutUserId`](https://docs.getunleash.io/reference/activation-strategies#gradual-rollout).

For example, set a value of 15% to enable the feature for 15% of authenticated users.

The rollout percentage can be from 0% to 100%.

Stickiness (consistent application behavior for the same user) is guaranteed for authenticated users,
but not anonymous users.

[Percent rollout](https://docs.gitlab.com/operations/feature_flags/#percent-rollout) with a consistency based on **User IDs** has the same
behavior. You should use percent rollout because it’s more flexible than percent of users

If the percent of users strategy is selected, then the Unleash client **must** be given a user
ID for the feature to be enabled. See the [Ruby example](https://docs.gitlab.com/operations/feature_flags/#ruby-application-example) below.

### User IDs [Permalink](https://docs.gitlab.com/operations/feature_flags/\#user-ids "Permalink")

Enables the feature for a list of target users. It is implemented
using the Unleash UserIDs (`userWithId`) activation [strategy](https://docs.getunleash.io/reference/activation-strategies#userids).

Enter user IDs as a comma-separated list of values (for example,
`user@example.com, user2@example.com`, or `username1,username2,username3`, and so on).
User IDs are identifiers for your application users. They do not need to be GitLab users.

The Unleash client **must** be given a user ID for the feature to be enabled for
target users. See the [Ruby example](https://docs.gitlab.com/operations/feature_flags/#ruby-application-example) below.

### User List [Permalink](https://docs.gitlab.com/operations/feature_flags/\#user-list "Permalink")

Enables the feature for lists of users created [in the feature flags UI](https://docs.gitlab.com/operations/feature_flags/#create-a-user-list), or with the [feature flag user list API](https://docs.gitlab.com/api/feature_flag_user_lists/).
Similar to [User IDs](https://docs.gitlab.com/operations/feature_flags/#user-ids), it uses the Unleash UsersIDs (`userWithId`) activation [strategy](https://docs.getunleash.io/reference/activation-strategies#userids).

You can’t disable a specific feature for a user, but you can achieve similar results by enabling it for a user list.

For example:

- `Full-user-list` = `User1A, User1B, User2A, User2B, User3A, User3B, ...`
- `Full-user-list-excluding-B-users` = `User1A, User2A, User3A, ...`

#### Create a user list [Permalink](https://docs.gitlab.com/operations/feature_flags/\#create-a-user-list "Permalink")

To create a user list:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Deploy** \> **Feature flags**.
3. Select **View user lists**
4. Select **New user list**.
5. Enter a name for the list.
6. Select **Create**.

You can view a list’s User IDs by selecting **Edit** (pencil) next to it.
When viewing a list, you can rename it by selecting **Edit** (pencil).

#### Add users to a user list [Permalink](https://docs.gitlab.com/operations/feature_flags/\#add-users-to-a-user-list "Permalink")

To add users to a user list:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Deploy** \> **Feature flags**.
3. Select **Edit** (pencil) next to the list you want to add users to.
4. Select **Add Users**.
5. Enter the user IDs as a comma-separated list of values. For example,
`user@example.com, user2@example.com`, or `username1,username2,username3`, and so on.
6. Select **Add**.

#### Remove users from a user list [Permalink](https://docs.gitlab.com/operations/feature_flags/\#remove-users-from-a-user-list "Permalink")

To remove users from a user list:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Deploy** \> **Feature flags**.
3. Select **Edit** (pencil) next to the list you want to change.
4. Select **Remove** (remove) next to the ID you want to remove.

## Search for Code References [Permalink](https://docs.gitlab.com/operations/feature_flags/\#search-for-code-references "Permalink")

- Tier: Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

To remove the feature flag from the code during cleanup, find any project references to it.

To search for code references of a feature flag:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Deploy** \> **Feature flags**.
3. Edit the feature flag you want to remove.
4. Select **More actions** (ellipsis\_v).
5. Select **Search code references**.

## Disable a feature flag for a specific environment [Permalink](https://docs.gitlab.com/operations/feature_flags/\#disable-a-feature-flag-for-a-specific-environment "Permalink")

To disable a feature flag for a specific environment:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Deploy** \> **Feature flags**.
3. For the feature flag you want to disable, select **Edit** (pencil).
4. To disable the flag:
   - For each strategy it applies to, under **Environments**, delete the environment.
5. Select **Save changes**.

## Disable a feature flag for all environments [Permalink](https://docs.gitlab.com/operations/feature_flags/\#disable-a-feature-flag-for-all-environments "Permalink")

To disable a feature flag for all environments:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Deploy** \> **Feature flags**.
3. For the feature flag you want to disable, slide the Status toggle to **Disabled**.

The feature flag is displayed on the **Disabled** tab.

## Integrate feature flags with your application [Permalink](https://docs.gitlab.com/operations/feature_flags/\#integrate-feature-flags-with-your-application "Permalink")

To use feature flags with your application, get access credentials from GitLab.
Then prepare your application with a client library.

### Get access credentials [Permalink](https://docs.gitlab.com/operations/feature_flags/\#get-access-credentials "Permalink")

To get the access credentials that your application needs to communicate with GitLab:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Deploy** \> **Feature flags**.
3. Select **Configure** to view the following:
   - **API URL**: URL where the client (application) connects to get a list of feature flags.

   - **Instance ID**: Unique token that authorizes the retrieval of the feature flags.

   - **Application name**: The name of the environment the application runs in
     (not the name of the application itself).

     For example, if the application runs for a production server, the **Application name**
     could be `production` or similar. This value is used for the environment spec evaluation.

The meaning of these fields might change over time. For example, **Instance ID** might be a
single token or multiple tokens assigned to the **Environment**. Also,
**Application name** could describe the application version instead of the running environment.

### Choose a client library [Permalink](https://docs.gitlab.com/operations/feature_flags/\#choose-a-client-library "Permalink")

GitLab implements a single backend that is compatible with Unleash clients.

With the Unleash client, developers can define, in the application code, the default values for flags.
Each feature flag evaluation can express the desired outcome if the flag isn’t present in the
provided configuration file.

Unleash currently [offers many SDKs for various languages and frameworks](https://github.com/Unleash/unleash#unleash-sdks).

### Feature flags API information [Permalink](https://docs.gitlab.com/operations/feature_flags/\#feature-flags-api-information "Permalink")

For API content, see:

- [Feature flags API](https://docs.gitlab.com/api/feature_flags/)
- [Feature flag user lists API](https://docs.gitlab.com/api/feature_flag_user_lists/)

### Go application example [Permalink](https://docs.gitlab.com/operations/feature_flags/\#go-application-example "Permalink")

Here’s an example of how to integrate feature flags in a Go application:

go

```go
package main

import (
    "io"
    "log"
    "net/http"

    "github.com/Unleash/unleash-client-go/v3"
)

type metricsInterface struct {
}

func init() {
    unleash.Initialize(
        unleash.WithUrl("https://gitlab.com/api/v4/feature_flags/unleash/42"),
        unleash.WithInstanceId("29QmjsW6KngPR5JNPMWx"),
        unleash.WithAppName("production"), // Set to the running environment of your application
        unleash.WithListener(&metricsInterface{}),
    )
}

func helloServer(w http.ResponseWriter, req *http.Request) {
    if unleash.IsEnabled("my_feature_name") {
        io.WriteString(w, "Feature enabled\n")
    } else {
        io.WriteString(w, "hello, world!\n")
    }
}

func main() {
    http.HandleFunc("/", helloServer)
    log.Fatal(http.ListenAndServe(":8080", nil))
}
```

### Ruby application example [Permalink](https://docs.gitlab.com/operations/feature_flags/\#ruby-application-example "Permalink")

Here’s an example of how to integrate feature flags in a Ruby application.

The Unleash client is given a user ID for use with a **Percent rollout (logged in users)** rollout strategy or a list of **Target Users**.

ruby

```ruby
#!/usr/bin/env ruby

require 'unleash'
require 'unleash/context'

unleash = Unleash::Client.new({
  url: 'http://gitlab.com/api/v4/feature_flags/unleash/42',
  app_name: 'production', # Set to the running environment of your application
  instance_id: '29QmjsW6KngPR5JNPMWx'
})

unleash_context = Unleash::Context.new
# Replace "123" with the ID of an authenticated user.
# The context's user ID must be a string:
# https://unleash.github.io/docs/unleash_context
unleash_context.user_id = "123"

if unleash.is_enabled?("my_feature_name", unleash_context)
  puts "Feature enabled"
else
  puts "hello, world!"
end
```

### Unleash Proxy example [Permalink](https://docs.gitlab.com/operations/feature_flags/\#unleash-proxy-example "Permalink")

As of [Unleash Proxy](https://docs.getunleash.io/reference/unleash-proxy) version
0.2, the proxy is compatible with feature flags.

You should use Unleash Proxy for production on GitLab.com. See the [performance note](https://docs.gitlab.com/operations/feature_flags/#maximum-supported-clients-in-application-nodes) for details.

To run a Docker container to
connect to your project’s feature flags, run the following command:

shell

```shell
docker run \
  -e UNLEASH_PROXY_SECRETS=<secret> \
  -e UNLEASH_URL=<project feature flags URL> \
  -e UNLEASH_INSTANCE_ID=<project feature flags instance ID> \
  -e UNLEASH_APP_NAME=<project environment> \
  -e UNLEASH_API_TOKEN=<tokenNotUsed> \
  -p 3000:3000 \
  unleashorg/unleash-proxy
```

| Variable | Value |
| --- | --- |
| `UNLEASH_PROXY_SECRETS` | Shared secret used to configure an [Unleash Proxy client](https://docs.getunleash.io/reference/unleash-proxy#how-to-connect-to-the-proxy). |
| `UNLEASH_URL` | Your project’s API URL. For more details, read [Get access credentials](https://docs.gitlab.com/operations/feature_flags/#get-access-credentials). |
| `UNLEASH_INSTANCE_ID` | Your project’s Instance ID. For more details, read [Get access credentials](https://docs.gitlab.com/operations/feature_flags/#get-access-credentials). |
| `UNLEASH_APP_NAME` | The name of the environment the application runs in. For more details, read [Get access credentials](https://docs.gitlab.com/operations/feature_flags/#get-access-credentials). |
| `UNLEASH_API_TOKEN` | Required to start the Unleash Proxy, but not used to connect to GitLab. Can be set to any value. |

There is a limitation when using the Unleash Proxy where each proxy instance can request flags only for the environment named in `UNLEASH_APP_NAME`. The Proxy sends
this to GitLab on behalf of the client, which means the client can’t override it.

## Feature flag related issues [Permalink](https://docs.gitlab.com/operations/feature_flags/\#feature-flag-related-issues "Permalink")

- Tier: Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

You can link related issues to a feature flag. In the feature flag **Linked issues** section,
select the `+` button and input the issue reference number or the full URL of the issue.
The issues then appear in the related feature flag and the other way round.

This feature is similar to the [linked issues](https://docs.gitlab.com/user/project/issues/related_issues/) feature.

## Performance factors [Permalink](https://docs.gitlab.com/operations/feature_flags/\#performance-factors "Permalink")

GitLab feature flags can be used in any application. Large applications might require advance configuration.
This section explains the performance factors to help your organization to identify
what’s needed to be done before using the feature.
For more information, see [using feature flags](https://docs.gitlab.com/operations/feature_flags/#using-feature-flags).

### Maximum supported clients in application nodes [Permalink](https://docs.gitlab.com/operations/feature_flags/\#maximum-supported-clients-in-application-nodes "Permalink")

GitLab accepts as many client requests as possible until it hits the [rate limit](https://docs.gitlab.com/security/rate_limits/).
The feature flag API is considered **Unauthenticated traffic (from a given IP address)**. For GitLab.com, see the [GitLab.com specific limits](https://docs.gitlab.com/user/gitlab_com/).

The polling rate is configurable in SDKs. Provided that all clients are requesting from the same IP:

- At one request per minute, supports approximately 500 clients (8 RPS).
- At one request per 15 sec, supports approximately 125 clients.

For applications looking for more scalable solution, you should use [Unleash Proxy](https://docs.gitlab.com/operations/feature_flags/#unleash-proxy-example).
On GitLab.com, you should use Unleash Proxy to reduce the chance of being rate limited across endpoints.
This proxy server sits between the server and clients. It makes requests to the server on behalf of the client groups,
so the number of outbound requests can be greatly reduced. If you still get `429` responses, increase the `UNLEASH_FETCH_INTERVAL` value in the Unleash Proxy.

There is also an [issue](https://gitlab.com/gitlab-org/gitlab/-/issues/295472) to give more
capacity to the current rate limit.

### Recovering from network errors [Permalink](https://docs.gitlab.com/operations/feature_flags/\#recovering-from-network-errors "Permalink")

In general, [Unleash clients](https://github.com/Unleash/unleash#unleash-sdks) have
a fall-back mechanism when the server returns an error code.
For example, `unleash-ruby-client` reads flag data from the local backup so that
application can keep running in the current state.

Read the documentation in a SDK project for more information.

### GitLab Self-Managed [Permalink](https://docs.gitlab.com/operations/feature_flags/\#gitlab-self-managed "Permalink")

Functionality-wise, there are no differences. Both GitLab.com and GitLab Self-Managed behave the same.

In terms of scalability, it’s up to the spec of the GitLab instance.
GitLab.com uses a highly scaled architecture to handle many concurrent requests.

However, GitLab Self-Managed instances with insufficient capacity based on the [reference architectures](https://docs.gitlab.com/administration/reference_architectures/#additional-workloads)
won’t deliver comparable performance and can even be overloaded by feature flag traffic.
Consider the number of users of your deployed application _in addition_ to your GitLab users.

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**

| Tier | Feature flags per project (GitLab.com) | Feature flags per project (GitLab Self-Managed) |
| --- | --- | --- |

| Variable | Value |
| --- | --- |