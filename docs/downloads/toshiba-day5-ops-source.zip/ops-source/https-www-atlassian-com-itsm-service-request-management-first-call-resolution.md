<!-- source: https://www.atlassian.com/itsm/service-request-management/first-call-resolution -->

Get it free

Search

Sign in

Jira Service Management is now more powerful than ever as part of Service Collection. Unlock exceptional service experiences with Rovo, Assets, and our new Customer Service Management app.

[Try it now](https://www.atlassian.com/try/cloud/signup?bundle=service-collection&edition=premium)

# Why first call resolution matters

In this day and age of on-demand anything, customers tend to want swift, immediate help from their IT providers. Because speed of service delivery is closely linked to customer satisfaction, it’s helpful to keep track of how quickly customers’ issues are being resolved. That’s where first call resolution (or FCR) comes in.

[Get it free](https://www.atlassian.com/software/jira/service-management/free)

## What is first call resolution?

First call resolution is the ability of an IT team to meet a customer’s needs fully the first time they contact them. By measuring the rate of first call resolutions, IT teams can better understand how quickly they’re helping customers.

## Benefits and challenges of FCR

FCR is one of many [key IT metrics](https://www.atlassian.com/itsm/service-request-management/it-metrics-and-reporting) that help you track the effectiveness of your team and processes. More importantly, since customers appreciate quick resolutions to their problems, it’s a great way to stay focused on the customer experience.

In fact, call center company SQM Group reports that for every 1% improvement you make in FCR, you get a 1% improvement in customer satisfaction, too. They also found that on average, customer satisfaction drops by 15% every time a customer has to call back about the same issue.

Remember that FCR is just one measurement, though. It's neither a comprehensive indicator of customer satisfaction nor of IT effectiveness. Use it in combination with other measurements like time to first response and actual customer satisfaction (CSAT) scores to help you track trends and look for areas to improve.

Below are a few tips and tricks for measuring first call resolution that will help you ensure it’s truly an effective and helpful metric for your team.

## Best practices for measuring first call resolution

### Define what you’re measuring - and stay consistent

Is it still a first call if you escalate it to a higher support tier? Is it a second call if the customer is recontacted via a different mode of communication? What about if the customer contacts the wrong department?

You get to decide. The important thing is to clearly define what counts as FCR, and what does not, and stay consistent. We recommend keeping it simple enough to be easily measured, too. The more exceptions you create, the more confusion and complexity you introduce into your processes, training, and reporting.

We also recommend tracking overall customer satisfaction side by side with FCR to ensure that customers are still getting high quality service in addition to first call resolution. For example, it’s far better to call a customer back promptly than to leave them on hold for ten minutes, even if it means not resolving the issue on the very first point of contact. Keeping track of customer satisfaction will help give you an idea of how accurate your FCR measurement really is.

### Mark the issue as resolved only when the customer says it is

Unfortunately, [service desk](https://www.atlassian.com/itsm/service-request-management/how-to-build-a-service-desk) agents can sometimes feel pressured to close tickets prematurely to meet aggressive call-time and closure rate goals. As a result, they may mark a customer’s issue as resolved before it really is.

Though it may seem obvious, it’s important to remember that a ticket isn’t resolved until your customer says it is. Marking issues as resolved without confirming with the customer only creates frustrated customers and reopened tickets, which directly impact your first-call resolution rate.

### Track reopen rates for better FCR accuracy

A good way to make sure you’re getting a true measure of FCR is to track reopen rates as well. If you’re knocking your FCR goals out of the park, but getting a ton of new tickets or reopen requests from the same customers, you may not be truly resolving the issue on the first call.

Reopen rates are like a built in system of checks and balances for FCR. In fact, you may want to approach any FCR measurement that isn’t accompanied by a reopen rate with a healthy dose of skepticism.

Remember to set a reasonable measurement window for reopens and return calls, as well. We recommend allowing at least a 24-48 hour window from the initial call before including a resolved issue in your FCR percentage.

### Look at the full customer journey

One way to ensure speedy issue resolution is to offer self-service tools. For example, for a simple request like a password reset, the customer may never interact with an agent, since they’re able to help themselves from beginning to end. Occasionally that is not the case, however, and the customer ends up having to contact support through your full-service channels after having already tried the self-service method.

When that happens, it may be the first call to your support team – but it’s actually the second request for help from the customer.

It’s important to understand how many first calls to your support department are actually second interactions, where the customer requires further assistance since they weren’t able to effectively resolve their own needs using your self-help tools.

If you aren’t able to track performance across the entire customer journey, and identify where and how often self-help customers are turning into full-service support requests, your FCR rates may be artificially skewed. Plus, you’re missing the opportunity to look for key self-service improvements that could lower your cost to serve dramatically.

### Embrace a knowledge base to boost your FCR

By building a [knowledge base](https://www.atlassian.com/itsm/knowledge-management/what-is-a-knowledge-base) and encouraging your team to document and share their collective knowledge and experiences, you make repeat problems exponentially easier to resolve, and free up your agents’ time to focus on fixing and documenting more complex issues. Your IT team will be able to solve issues faster (and hopefully on the first call) when they have a knowledge base that they can easily refer to.

In fact, HDI states that organizations using knowledge centered support typically enjoy much better first-call and first-level resolution rates than those who do not – often by as much as 15%. Implementing a knowledge base is a no-brainer.

### Avoid setting conflicting performance goals

While there is nothing wrong with measuring both FCR and things like time to resolution, make sure that you aren’t setting goals for either that send mixed signals to your service desk agents.

For example, if you are striving to achieve an FCR of 85%, but agents are also expected to either resolve or escalate an issue within 5 minutes, they will have to choose between two goals you have set for them. Make sure they understand their priorities and are working together to achieve the same goals to support your business objectives.

Most importantly, first-call resolution should not be your main goal. Your primary goal is solving problems in the best way possible — even if that means escalating or calling the customer back.

## Summary

First call resolution is a great metric for keeping track of your team’s efficiency, but you should avoid taking it at face value. Think about how you’re measuring FCR and what other metrics you can track in addition to FCR — like reopen rates and customer satisfaction — to get to a more accurate measurement that will help you identify areas for improvement.

A comprehensive approach to first call resolution can ensure that your team is getting the full picture and tracking other key metrics that tell the story of your team's health and performance. The capability to build an accessible, dynamic [knowledge base](https://www.atlassian.com/itsm/knowledge-management/what-is-a-knowledge-base) for your employees and customers, as well as the ability to customize efficient workflows can make all the difference when it comes to FCR rates. Explore these game-changing features with Jira Service Management.

[Try Jira Service Management](https://www.atlassian.com/software/jira/service-management)

## Recommended for you

### Service desk vs help desk vs ITSM: What's the difference?

Get the best IT help desk and service desk service for efficient IT support. Learn about the difference between service desk, help desk, and ITSM.

[Read the article](https://www.atlassian.com/itsm/service-request-management/help-desk-vs-service-desk-vs-itsm)

WHITEPAPER

### Atlassian for ITSM

The basics you need to know about ITSM with Atlassian – across IT delivery, operations, and support, plus best practices and tips.

[Get the guide](https://www.atlassian.com/whitepapers/complete-guide-itsm)

### Learn more about ITSM

Find more ITSM guides and resources in this hub.

[Read this article](https://www.atlassian.com/itsm)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**