<!-- source: https://commerce.toshiba.com/wps/portal/marketing/mobile/tcx-m1/!ut/p/z1/tVTLdpswEP2WLLrU0UjIIJZAHHBcLOMCsdnkYBtstQYcl8ZJvr6Tpps4TekDa6HH0b13rkZzhmZ0TrM6v9ebvNVNne_wvMjM27EtnEB6MPUVH0AUCp5YaWT4I0FTmtFsv9JruigNSwpblISVZUGEFANi58wgxbLkebG018xcPaNXdbtvt3RR1OTb1w-wbaoC5_ywPuYH3FXNUu9wbVcPpGL0pstBhtfwznDgDX_qeBCZiT-VI88QqfmD_xv5F_6prDvjrgGA8H_hvzLYyc9OIG9f8IscvLbYlaSTEFKNhuhC-WPx8RLAFHSBr7BuRzbjMB6DUoF6BgyTdBhMOCLozb0ujjSpm0OFZfPpL6sigK4Ig_-M0CFv9SsvFTCUt9Mktkz8A7Nn9156hfKzMFUsRPdwXnl-XnnWi7zvOB5zgE_8OOYQWZduPEg9JkGc173Rc-VcuwKiRF154Moecn_d1V-ww-vPd3eZg425qdvioaXzP-vMyOSH0As3aChvt0TXZUPnLyA6_wnaV5U0HrXW5MsseHInxPeW8hiX1XvLo7HbOBcX3wEfNOlG -->

![logo](https://commerce.toshiba.com/wps/portal/marketing/mobile/tcx-m1/!ut/p/z1/tVVPf6IwEP0sPXjEDBAh7A2oBWsVdYUql_4Ag9IFYpFKu59-p-tetO2yfzQHEsh7b16G-U1ISBYkLKN9to7qTJRRju_LUHsYGtR0mQ0Tx1N6MB1RxdeDqeoMKAlISMJtkq3IMlV1Rg2aSnKacoky2pOMSFYlHqdKxGNjJWvJGzop6229IUteSs-7DmxEwfEZVasmqnBViDjLca6TF6mQyX2bgxC34ZNhwjv-xLRhqvnOhA1slQbaT_5v5A_8U1lrplgqAML_hX9ksJUfnkDen-CDHBxbbEvSSQjmDfrownOG9O4aQKNkiafQHwaGrMBwCJ7nem-Avh_03bGCCHK_z3hD_FJUBZbN17-sChfaIvT-M0KLvH5eeeaBjPJG4M91Df-Bdmb3dnCD8rNR4MkjdA-XlVcuKy-fRd4xTVs2QRk787kCU_3amvcCW2ZAL-tePXPl3FoUpr53Y4PFzpD727b-gh0-e3x6Ck1szKKs-UtNFn_WmZGpVCN7tEZDUb2RsjIVZHEAkcUvEMZf5yI-XCVmGasM4RVPecWr7nOFnzd1vd196UAHmqbproVY57ybiKIDH1E2YocGj5FkWxRMfc2yTPo2c79bY8mxY9bM0-Kz6VXNH3v5_s68uvoBu-BC1g!!/images/logo.png)X

Sign in to your Toshiba account

For optimum experience,
please log in on your desktop computer

UserName

Password

Sign In [Forgot password?](https://www.toshibacommerce.com/tgcs109/tsim/forgotpassword.do) [Enterprise Login](https://www.toshibacommerce.com/mga/sps/authsvc?PolicyId=urn:ibm:security:authentication:asf:externalIDPLogin&target=https%3A%2F%2Ftoshibacommerce.com%2Fwps%2Fmyportal)

Don't have an ID? [Request one here](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/faqs)

{"Z7\_I9120KK0OOHOE0QMEUVEHN2006":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OOHOE0QMEUVEHN2005":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OOHOE0QMEUVEHN2007":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8O010QM9VUT7600G6":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OOCVF0QMRMVO1M2000":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OOCVF0QMRMVO1M2002":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OOCVF0QMRMVO1M2001":{"windowState":"normal","portletMode":"view"},"Z7\_GAAC1A02NGTT20Q7DBT5VC1804":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OOCVF0QMRMVO1M2003":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8JB40QUOFC0B82002":{"windowState":"normal","portletMode":"view"}}

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

# TCx® M1

The TCx® M1 Mobile POS is a handheld device that allows associates to address long wait times by taking payments on the spot. Making checkout lines, curbside pickup, and remote areas of the store even more convenient

Meet the TCx® M1.

Select a Language for your download.EnglishDownload TCx® M1 Brochure

![product-img](https://commerce.toshiba.com/wps/wcm/connect/marketing/d64d0efc-358d-492e-b374-ce1fc28feb0a/T270009-image-01.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_GAAC1A02N8ABE0AVD86G7Q0421-d64d0efc-358d-492e-b374-ce1fc28feb0a-p4aoCDb)

![product-img](https://commerce.toshiba.com/wps/wcm/connect/marketing/800c39a4-b1d8-43c1-bf31-fe971f06cce2/T270040-image-02.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_GAAC1A02N8ABE0AVD86G7Q0421-800c39a4-b1d8-43c1-bf31-fe971f06cce2-p4aoCDb)

![product-img](https://commerce.toshiba.com/wps/wcm/connect/marketing/eaf492b7-000e-43f5-bb30-05904b734538/TCx-M1-image-03.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_GAAC1A02N8ABE0AVD86G7Q0421-eaf492b7-000e-43f5-bb30-05904b734538-p4aoCDb)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/a63b6ccb-c11f-44b0-90fc-4ccd276ecf00/M1+insert%2Ctap%2Cswipe+Graphics+2-02.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_GAAC1A02N8ABE0AVD86G7Q0421-a63b6ccb-c11f-44b0-90fc-4ccd276ecf00-p4aoCDb)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/5bf2364f-1f22-4ca4-8f90-9cec2e792d8b/M1+insert%2Ctap%2Cswipe+Graphics+3-03.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_GAAC1A02N8ABE0AVD86G7Q0421-5bf2364f-1f22-4ca4-8f90-9cec2e792d8b-p4aoCDb)

![](https://commerce.toshiba.com/wps/portal/marketing/mobile/tcx-m1/!ut/p/z1/tVVPf6IwEP0sPXjEDBAh7A2oBWsVdYUql_4Ag9IFYpFKu59-p-tetO2yfzQHEsh7b16G-U1ISBYkLKN9to7qTJRRju_LUHsYGtR0mQ0Tx1N6MB1RxdeDqeoMKAlISMJtkq3IMlV1Rg2aSnKacoky2pOMSFYlHqdKxGNjJWvJGzop6229IUteSs-7DmxEwfEZVasmqnBViDjLca6TF6mQyX2bgxC34ZNhwjv-xLRhqvnOhA1slQbaT_5v5A_8U1lrplgqAML_hX9ksJUfnkDen-CDHBxbbEvSSQjmDfrownOG9O4aQKNkiafQHwaGrMBwCJ7nem-Avh_03bGCCHK_z3hD_FJUBZbN17-sChfaIvT-M0KLvH5eeeaBjPJG4M91Df-Bdmb3dnCD8rNR4MkjdA-XlVcuKy-fRd4xTVs2QRk787kCU_3amvcCW2ZAL-tePXPl3FoUpr53Y4PFzpD727b-gh0-e3x6Ck1szKKs-UtNFn_WmZGpVCN7tEZDUb2RsjIVZHEAkcUvEMZf5yI-XCVmGasM4RVPecWr7nOFnzd1vd196UAHmqbproVY57ybiKIDH1E2YocGj5FkWxRMfc2yTPo2c79bY8mxY9bM0-Kz6VXNH3v5_s68uvoBu-BC1g!!/images/i_swiper-next-dark.svg)

![](https://commerce.toshiba.com/wps/portal/marketing/mobile/tcx-m1/!ut/p/z1/tVVPf6IwEP0sPXjEDBAh7A2oBWsVdYUql_4Ag9IFYpFKu59-p-tetO2yfzQHEsh7b16G-U1ISBYkLKN9to7qTJRRju_LUHsYGtR0mQ0Tx1N6MB1RxdeDqeoMKAlISMJtkq3IMlV1Rg2aSnKacoky2pOMSFYlHqdKxGNjJWvJGzop6229IUteSs-7DmxEwfEZVasmqnBViDjLca6TF6mQyX2bgxC34ZNhwjv-xLRhqvnOhA1slQbaT_5v5A_8U1lrplgqAML_hX9ksJUfnkDen-CDHBxbbEvSSQjmDfrownOG9O4aQKNkiafQHwaGrMBwCJ7nem-Avh_03bGCCHK_z3hD_FJUBZbN17-sChfaIvT-M0KLvH5eeeaBjPJG4M91Df-Bdmb3dnCD8rNR4MkjdA-XlVcuKy-fRd4xTVs2QRk787kCU_3amvcCW2ZAL-tePXPl3FoUpr53Y4PFzpD727b-gh0-e3x6Ck1szKKs-UtNFn_WmZGpVCN7tEZDUb2RsjIVZHEAkcUvEMZf5yI-XCVmGasM4RVPecWr7nOFnzd1vd196UAHmqbproVY57ybiKIDH1E2YocGj5FkWxRMfc2yTPo2c79bY8mxY9bM0-Kz6VXNH3v5_s68uvoBu-BC1g!!/images/i_swiper-prev-dark.svg)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

## Mobile Payments

### General Info

- Certified end-to-end mobile payments device (EMV, MSR, Contactless)
- Integrated barcode scanning
- Print to mobile & network printers
- PCI compliant
- Android OS


![purple gauge](https://commerce.toshiba.com/wps/wcm/connect/marketing/240dd1ec-1036-45e6-ba1c-399f67628cdd/1/gauge-max-sharp-solid-48x.png?MOD=AJPERES)

### **Fast & Efficient**

Faster checkout and reduction in store congestion while offering a quick, flexible payment option.

![](https://commerce.toshiba.com/wps/portal/marketing/mobile/tcx-m1/!ut/p/z1/tVVPf6IwEP0sPXjEDBAh7A2oBWsVdYUql_4Ag9IFYpFKu59-p-tetO2yfzQHEsh7b16G-U1ISBYkLKN9to7qTJRRju_LUHsYGtR0mQ0Tx1N6MB1RxdeDqeoMKAlISMJtkq3IMlV1Rg2aSnKacoky2pOMSFYlHqdKxGNjJWvJGzop6229IUteSs-7DmxEwfEZVasmqnBViDjLca6TF6mQyX2bgxC34ZNhwjv-xLRhqvnOhA1slQbaT_5v5A_8U1lrplgqAML_hX9ksJUfnkDen-CDHBxbbEvSSQjmDfrownOG9O4aQKNkiafQHwaGrMBwCJ7nem-Avh_03bGCCHK_z3hD_FJUBZbN17-sChfaIvT-M0KLvH5eeeaBjPJG4M91Df-Bdmb3dnCD8rNR4MkjdA-XlVcuKy-fRd4xTVs2QRk787kCU_3amvcCW2ZAL-tePXPl3FoUpr53Y4PFzpD727b-gh0-e3x6Ck1szKKs-UtNFn_WmZGpVCN7tEZDUb2RsjIVZHEAkcUvEMZf5yI-XCVmGasM4RVPecWr7nOFnzd1vd196UAHmqbproVY57ybiKIDH1E2YocGj5FkWxRMfc2yTPo2c79bY8mxY9bM0-Kz6VXNH3v5_s68uvoBu-BC1g!!/images/i_shield-check-solid.svg)

### Secured & Personal

Associates can scan & process payments (tap, swipe, insert) all on one device from any location within the store.

![yellow trophy star](https://commerce.toshiba.com/wps/wcm/connect/marketing/240dd1ec-1036-45e6-ba1c-399f67628cdd/2/trophy-star-sharp-solid-48x.png?MOD=AJPERES)

### Better Experience

Improved shopper experience by reducing checkout wait times while offering a quick payment option.

![](https://commerce.toshiba.com/wps/portal/marketing/mobile/tcx-m1/!ut/p/z1/tVVPf6IwEP0sPXjEDBAh7A2oBWsVdYUql_4Ag9IFYpFKu59-p-tetO2yfzQHEsh7b16G-U1ISBYkLKN9to7qTJRRju_LUHsYGtR0mQ0Tx1N6MB1RxdeDqeoMKAlISMJtkq3IMlV1Rg2aSnKacoky2pOMSFYlHqdKxGNjJWvJGzop6229IUteSs-7DmxEwfEZVasmqnBViDjLca6TF6mQyX2bgxC34ZNhwjv-xLRhqvnOhA1slQbaT_5v5A_8U1lrplgqAML_hX9ksJUfnkDen-CDHBxbbEvSSQjmDfrownOG9O4aQKNkiafQHwaGrMBwCJ7nem-Avh_03bGCCHK_z3hD_FJUBZbN17-sChfaIvT-M0KLvH5eeeaBjPJG4M91Df-Bdmb3dnCD8rNR4MkjdA-XlVcuKy-fRd4xTVs2QRk787kCU_3amvcCW2ZAL-tePXPl3FoUpr53Y4PFzpD727b-gh0-e3x6Ck1szKKs-UtNFn_WmZGpVCN7tEZDUb2RsjIVZHEAkcUvEMZf5yI-XCVmGasM4RVPecWr7nOFnzd1vd196UAHmqbproVY57ybiKIDH1E2YocGj5FkWxRMfc2yTPo2c79bY8mxY9bM0-Kz6VXNH3v5_s68uvoBu-BC1g!!/images/i_puzzle-piece-solid.svg)

### Complete Solution

Truly integrated mobile solution encompassing Toshiba branded Hardware, ELERA Software, and Toshiba Services.

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

## Complete mPOS Solution

The TCx®  M1 Mobile POS from Toshiba offers an end-to-end solution that reduces friction and improves engagement between the shopper and retailer all from the store associate’s hand – delivering a smooth customer experience from scanning, to loyalty cards, to payments.

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/1e185b41-388b-49d8-9502-9b6324d42735/tcx%2Bm1%2Byoutube%2Bcover%2Bimage.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_GAAC1A02N8ABE0AVD86G7Q0421-1e185b41-388b-49d8-9502-9b6324d42735-p49XVCg)\\
![](https://commerce.toshiba.com/wps/portal/marketing/mobile/tcx-m1/!ut/p/z1/tVVPf6IwEP0sPXjEDBAh7A2oBWsVdYUql_4Ag9IFYpFKu59-p-tetO2yfzQHEsh7b16G-U1ISBYkLKN9to7qTJRRju_LUHsYGtR0mQ0Tx1N6MB1RxdeDqeoMKAlISMJtkq3IMlV1Rg2aSnKacoky2pOMSFYlHqdKxGNjJWvJGzop6229IUteSs-7DmxEwfEZVasmqnBViDjLca6TF6mQyX2bgxC34ZNhwjv-xLRhqvnOhA1slQbaT_5v5A_8U1lrplgqAML_hX9ksJUfnkDen-CDHBxbbEvSSQjmDfrownOG9O4aQKNkiafQHwaGrMBwCJ7nem-Avh_03bGCCHK_z3hD_FJUBZbN17-sChfaIvT-M0KLvH5eeeaBjPJG4M91Df-Bdmb3dnCD8rNR4MkjdA-XlVcuKy-fRd4xTVs2QRk787kCU_3amvcCW2ZAL-tePXPl3FoUpr53Y4PFzpD727b-gh0-e3x6Ck1szKKs-UtNFn_WmZGpVCN7tEZDUb2RsjIVZHEAkcUvEMZf5yI-XCVmGasM4RVPecWr7nOFnzd1vd196UAHmqbproVY57ybiKIDH1E2YocGj5FkWxRMfc2yTPo2c79bY8mxY9bM0-Kz6VXNH3v5_s68uvoBu-BC1g!!/images/i_play-red.svg)](https://www.youtube.com/watch?v=EDKWDiXN8kU "")

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/7d624a1b-1094-4eaf-9a58-1b165b61ce9c/M1+insert%2Ctap%2Cswipe+Cover+v2-01+%281%29.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_GAAC1A02N8ABE0AVD86G7Q0421-7d624a1b-1094-4eaf-9a58-1b165b61ce9c-p5TvPsB)

### Faster Checkout

Today, retailers are looking at how best to eliminate in-store friction, reduce checkout time and the length of checkout lines, and improve customer service. The new Toshiba TCx M1 Associate Mobile Point-of-Sale Handheld addresses these issues and can enable faster checkout, reduce store congestion, and extend the point of sales beyond the front-end area of the store all in the store associate’s hand.

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![](https://commerce.toshiba.com/wps/portal/marketing/mobile/tcx-m1/!ut/p/z1/tVVPf6IwEP0sPXjEDBAh7A2oBWsVdYUql_4Ag9IFYpFKu59-p-tetO2yfzQHEsh7b16G-U1ISBYkLKN9to7qTJRRju_LUHsYGtR0mQ0Tx1N6MB1RxdeDqeoMKAlISMJtkq3IMlV1Rg2aSnKacoky2pOMSFYlHqdKxGNjJWvJGzop6229IUteSs-7DmxEwfEZVasmqnBViDjLca6TF6mQyX2bgxC34ZNhwjv-xLRhqvnOhA1slQbaT_5v5A_8U1lrplgqAML_hX9ksJUfnkDen-CDHBxbbEvSSQjmDfrownOG9O4aQKNkiafQHwaGrMBwCJ7nem-Avh_03bGCCHK_z3hD_FJUBZbN17-sChfaIvT-M0KLvH5eeeaBjPJG4M91Df-Bdmb3dnCD8rNR4MkjdA-XlVcuKy-fRd4xTVs2QRk787kCU_3amvcCW2ZAL-tePXPl3FoUpr53Y4PFzpD727b-gh0-e3x6Ck1szKKs-UtNFn_WmZGpVCN7tEZDUb2RsjIVZHEAkcUvEMZf5yI-XCVmGasM4RVPecWr7nOFnzd1vd196UAHmqbproVY57ybiKIDH1E2YocGj5FkWxRMfc2yTPo2c79bY8mxY9bM0-Kz6VXNH3v5_s68uvoBu-BC1g!!/images/g_cta-dark-left-squares.svg)

## Specifications

Specification Summary [Download Specifications](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/awzp/y2f0/~edisp/tcx_m1_technical_specification.pdf)

### Key prerequisites:

[View full Technical Specifications](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/awzp/y2f0/~edisp/tcx_m1_technical_specification.pdf)

![](https://commerce.toshiba.com/wps/portal/marketing/mobile/tcx-m1/!ut/p/z1/tVVPf6IwEP0sPXjEDBAh7A2oBWsVdYUql_4Ag9IFYpFKu59-p-tetO2yfzQHEsh7b16G-U1ISBYkLKN9to7qTJRRju_LUHsYGtR0mQ0Tx1N6MB1RxdeDqeoMKAlISMJtkq3IMlV1Rg2aSnKacoky2pOMSFYlHqdKxGNjJWvJGzop6229IUteSs-7DmxEwfEZVasmqnBViDjLca6TF6mQyX2bgxC34ZNhwjv-xLRhqvnOhA1slQbaT_5v5A_8U1lrplgqAML_hX9ksJUfnkDen-CDHBxbbEvSSQjmDfrownOG9O4aQKNkiafQHwaGrMBwCJ7nem-Avh_03bGCCHK_z3hD_FJUBZbN17-sChfaIvT-M0KLvH5eeeaBjPJG4M91Df-Bdmb3dnCD8rNR4MkjdA-XlVcuKy-fRd4xTVs2QRk787kCU_3amvcCW2ZAL-tePXPl3FoUpr53Y4PFzpD727b-gh0-e3x6Ck1szKKs-UtNFn_WmZGpVCN7tEZDUb2RsjIVZHEAkcUvEMZf5yI-XCVmGasM4RVPecWr7nOFnzd1vd196UAHmqbproVY57ybiKIDH1E2YocGj5FkWxRMfc2yTPo2c79bY8mxY9bM0-Kz6VXNH3v5_s68uvoBu-BC1g!!/images/g_cta-dark-right-sqares.svg)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

## Featured

### Related Solutions

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/b4097981-0367-4944-ae2d-99ca49fe4e62/WW2020-Cross-Promotion-Space-ELERA-Point-of-sale.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_GAAC1A02N8ABE0AVD86G7Q0421-b4097981-0367-4944-ae2d-99ca49fe4e62-oPr5Nl6)\\
\\
**ELERA® Point-of-Sale** \\
\\
ELERA Point-of-Sale offers next-generation unified commerce capabilities on top of existing store infrastructure, eliminating the need for disruptive rip-and-replace strategies and optimizing consumer engagement.\\
\\
Learn About ELERA® Point-of-Sale](https://commerce.toshiba.com/wps/portal/marketing/mobile/tcx-m1/!ut/p/z1/tVVPf6IwEP0sPXjEDBAh7A2oBWsVdYUql_4Ag9IFYpFKu59-p-tetO2yfzQHEsh7b16G-U1ISBYkLKN9to7qTJRRju_LUHsYGtR0mQ0Tx1N6MB1RxdeDqeoMKAlISMJtkq3IMlV1Rg2aSnKacoky2pOMSFYlHqdKxGNjJWvJGzop6229IUteSs-7DmxEwfEZVasmqnBViDjLca6TF6mQyX2bgxC34ZNhwjv-xLRhqvnOhA1slQbaT_5v5A_8U1lrplgqAML_hX9ksJUfnkDen-CDHBxbbEvSSQjmDfrownOG9O4aQKNkiafQHwaGrMBwCJ7nem-Avh_03bGCCHK_z3hD_FJUBZbN17-sChfaIvT-M0KLvH5eeeaBjPJG4M91Df-Bdmb3dnCD8rNR4MkjdA-XlVcuKy-fRd4xTVs2QRk787kCU_3amvcCW2ZAL-tePXPl3FoUpr53Y4PFzpD727b-gh0-e3x6Ck1szKKs-UtNFn_WmZGpVCN7tEZDUb2RsjIVZHEAkcUvEMZf5yI-XCVmGasM4RVPecWr7nOFnzd1vd196UAHmqbproVY57ybiKIDH1E2YocGj5FkWxRMfc2yTPo2c79bY8mxY9bM0-Kz6VXNH3v5_s68uvoBu-BC1g!!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fsoftware%2Fcommerce-suite%2Felera-pos?mapping=tgcs_new.portal.software)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/1a58e713-c31d-4457-b6c8-6d4ddba04af3/WW2020-Cross-Promotion-Space-ELERA.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_GAAC1A02N8ABE0AVD86G7Q0421-1a58e713-c31d-4457-b6c8-6d4ddba04af3-p8GrQ5A)\\
\\
**ELERA®** \\
\\
With the steady drive to improve the customer experience, be more agile, and scale continuously, you need a platform that can help you accelerate growth and evolve at your own speed.\\
\\
Learn About ELERA®](https://commerce.toshiba.com/wps/portal/marketing/mobile/tcx-m1/!ut/p/z1/tVVPf6IwEP0sPXjEDBAh7A2oBWsVdYUql_4Ag9IFYpFKu59-p-tetO2yfzQHEsh7b16G-U1ISBYkLKN9to7qTJRRju_LUHsYGtR0mQ0Tx1N6MB1RxdeDqeoMKAlISMJtkq3IMlV1Rg2aSnKacoky2pOMSFYlHqdKxGNjJWvJGzop6229IUteSs-7DmxEwfEZVasmqnBViDjLca6TF6mQyX2bgxC34ZNhwjv-xLRhqvnOhA1slQbaT_5v5A_8U1lrplgqAML_hX9ksJUfnkDen-CDHBxbbEvSSQjmDfrownOG9O4aQKNkiafQHwaGrMBwCJ7nem-Avh_03bGCCHK_z3hD_FJUBZbN17-sChfaIvT-M0KLvH5eeeaBjPJG4M91Df-Bdmb3dnCD8rNR4MkjdA-XlVcuKy-fRd4xTVs2QRk787kCU_3amvcCW2ZAL-tePXPl3FoUpr53Y4PFzpD727b-gh0-e3x6Ck1szKKs-UtNFn_WmZGpVCN7tEZDUb2RsjIVZHEAkcUvEMZf5yI-XCVmGasM4RVPecWr7nOFnzd1vd196UAHmqbproVY57ybiKIDH1E2YocGj5FkWxRMfc2yTPo2c79bY8mxY9bM0-Kz6VXNH3v5_s68uvoBu-BC1g!!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fsoftware%2Fsolutions-platform%2Felera?mapping=tgcs_new.portal.hardware)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/26cdb024-5ebb-4845-9e70-fe071488612d/WW2020-Product-Page-THUMB-LARGE-ELERA-Pay.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_GAAC1A02N8ABE0AVD86G7Q0421-26cdb024-5ebb-4845-9e70-fe071488612d-paqHzda)\\
\\
**ELERA® Pay** \\
\\
ELERA® Pay simplifies the retailer environment by utilizing a cloud-based payment platform providing transaction routing, central configurations, and reporting interfaces offering flexibility and adaptability.\\
\\
Learn About ELERA® Pay](https://commerce.toshiba.com/wps/portal/marketing/mobile/tcx-m1/!ut/p/z1/tVVPf6IwEP0sPXjEDBAh7A2oBWsVdYUql_4Ag9IFYpFKu59-p-tetO2yfzQHEsh7b16G-U1ISBYkLKN9to7qTJRRju_LUHsYGtR0mQ0Tx1N6MB1RxdeDqeoMKAlISMJtkq3IMlV1Rg2aSnKacoky2pOMSFYlHqdKxGNjJWvJGzop6229IUteSs-7DmxEwfEZVasmqnBViDjLca6TF6mQyX2bgxC34ZNhwjv-xLRhqvnOhA1slQbaT_5v5A_8U1lrplgqAML_hX9ksJUfnkDen-CDHBxbbEvSSQjmDfrownOG9O4aQKNkiafQHwaGrMBwCJ7nem-Avh_03bGCCHK_z3hD_FJUBZbN17-sChfaIvT-M0KLvH5eeeaBjPJG4M91Df-Bdmb3dnCD8rNR4MkjdA-XlVcuKy-fRd4xTVs2QRk787kCU_3amvcCW2ZAL-tePXPl3FoUpr53Y4PFzpD727b-gh0-e3x6Ck1szKKs-UtNFn_WmZGpVCN7tEZDUb2RsjIVZHEAkcUvEMZf5yI-XCVmGasM4RVPecWr7nOFnzd1vd196UAHmqbproVY57ybiKIDH1E2YocGj5FkWxRMfc2yTPo2c79bY8mxY9bM0-Kz6VXNH3v5_s68uvoBu-BC1g!!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fsoftware%2Fpayments-suite%2Felera-pay)

![](https://commerce.toshiba.com/wps/portal/marketing/mobile/tcx-m1/!ut/p/z1/tVVPf6IwEP0sPXjEDBAh7A2oBWsVdYUql_4Ag9IFYpFKu59-p-tetO2yfzQHEsh7b16G-U1ISBYkLKN9to7qTJRRju_LUHsYGtR0mQ0Tx1N6MB1RxdeDqeoMKAlISMJtkq3IMlV1Rg2aSnKacoky2pOMSFYlHqdKxGNjJWvJGzop6229IUteSs-7DmxEwfEZVasmqnBViDjLca6TF6mQyX2bgxC34ZNhwjv-xLRhqvnOhA1slQbaT_5v5A_8U1lrplgqAML_hX9ksJUfnkDen-CDHBxbbEvSSQjmDfrownOG9O4aQKNkiafQHwaGrMBwCJ7nem-Avh_03bGCCHK_z3hD_FJUBZbN17-sChfaIvT-M0KLvH5eeeaBjPJG4M91Df-Bdmb3dnCD8rNR4MkjdA-XlVcuKy-fRd4xTVs2QRk787kCU_3amvcCW2ZAL-tePXPl3FoUpr53Y4PFzpD727b-gh0-e3x6Ck1szKKs-UtNFn_WmZGpVCN7tEZDUb2RsjIVZHEAkcUvEMZf5yI-XCVmGasM4RVPecWr7nOFnzd1vd196UAHmqbproVY57ybiKIDH1E2YocGj5FkWxRMfc2yTPo2c79bY8mxY9bM0-Kz6VXNH3v5_s68uvoBu-BC1g!!/assets/images/i_swiper-next-dark.svg)

![](https://commerce.toshiba.com/wps/portal/marketing/mobile/tcx-m1/!ut/p/z1/tVVPf6IwEP0sPXjEDBAh7A2oBWsVdYUql_4Ag9IFYpFKu59-p-tetO2yfzQHEsh7b16G-U1ISBYkLKN9to7qTJRRju_LUHsYGtR0mQ0Tx1N6MB1RxdeDqeoMKAlISMJtkq3IMlV1Rg2aSnKacoky2pOMSFYlHqdKxGNjJWvJGzop6229IUteSs-7DmxEwfEZVasmqnBViDjLca6TF6mQyX2bgxC34ZNhwjv-xLRhqvnOhA1slQbaT_5v5A_8U1lrplgqAML_hX9ksJUfnkDen-CDHBxbbEvSSQjmDfrownOG9O4aQKNkiafQHwaGrMBwCJ7nem-Avh_03bGCCHK_z3hD_FJUBZbN17-sChfaIvT-M0KLvH5eeeaBjPJG4M91Df-Bdmb3dnCD8rNR4MkjdA-XlVcuKy-fRd4xTVs2QRk787kCU_3amvcCW2ZAL-tePXPl3FoUpr53Y4PFzpD727b-gh0-e3x6Ck1szKKs-UtNFn_WmZGpVCN7tEZDUb2RsjIVZHEAkcUvEMZf5yI-XCVmGasM4RVPecWr7nOFnzd1vd196UAHmqbproVY57ybiKIDH1E2YocGj5FkWxRMfc2yTPo2c79bY8mxY9bM0-Kz6VXNH3v5_s68uvoBu-BC1g!!/assets/images/i_swiper-prev-dark.svg)

Start a conversation

First name

Last name

Email

Company

Country

Phone

I am a

Business PartnerOtherPress / AnalystRetailerSupplierToshiba Employee

- Business Partner

- Other

- Press / Analyst

- Retailer

- Supplier

- Toshiba Employee


My Retail Segment

Fashion & ApparelFood ServiceGas & ConvenienceGroceryMass MerchandiseOtherPharmacy / Drug StoreSpecialty

- Fashion & Apparel

- Food Service

- Gas & Convenience

- Grocery

- Mass Merchandise

- Other

- Pharmacy / Drug Store

- Specialty


I am interested in learning more about

Add me to Toshiba Global Commerce Solutions' email marketing list

I am allowing Toshiba to contact me in regards to the information on this form

Comments

By submitting this form I agree that Toshiba Global Commerce Solutions, Inc. and its affiliates, including all subsidiaries and branches, may process my data as indicated above and as described in the [Toshiba Global Commerce Solutions Privacy Declaration.](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/common-content/general-content/privacy-policy&mapping=tgcs_new.portal.generaldetails)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**

reCAPTCHA is changing its terms of service. [Take action.](https://google.com/recaptcha/admin/migrate)

![success](https://commerce.toshiba.com/wps/portal/marketing/mobile/tcx-m1/!ut/p/z1/tVVPf6IwEP0sPXjEDBAh7A2oBWsVdYUql_4Ag9IFYpFKu59-p-tetO2yfzQHEsh7b16G-U1ISBYkLKN9to7qTJRRju_LUHsYGtR0mQ0Tx1N6MB1RxdeDqeoMKAlISMJtkq3IMlV1Rg2aSnKacoky2pOMSFYlHqdKxGNjJWvJGzop6229IUteSs-7DmxEwfEZVasmqnBViDjLca6TF6mQyX2bgxC34ZNhwjv-xLRhqvnOhA1slQbaT_5v5A_8U1lrplgqAML_hX9ksJUfnkDen-CDHBxbbEvSSQjmDfrownOG9O4aQKNkiafQHwaGrMBwCJ7nem-Avh_03bGCCHK_z3hD_FJUBZbN17-sChfaIvT-M0KLvH5eeeaBjPJG4M91Df-Bdmb3dnCD8rNR4MkjdA-XlVcuKy-fRd4xTVs2QRk787kCU_3amvcCW2ZAL-tePXPl3FoUpr53Y4PFzpD727b-gh0-e3x6Ck1szKKs-UtNFn_WmZGpVCN7tEZDUb2RsjIVZHEAkcUvEMZf5yI-XCVmGasM4RVPecWr7nOFnzd1vd196UAHmqbproVY57ybiKIDH1E2YocGj5FkWxRMfc2yTPo2c79bY8mxY9bM0-Kz6VXNH3v5_s68uvoBu-BC1g!!/images/tgcs/success.svg)

## Success!

Thank you for reaching out. One of our team members will be in contact soon. We hope you have a great day.

Close

Complementary
Content [Deferred Modules](https://commerce.toshiba.com/wps/contenthandler/marketing/!ut/p/digest!M6zrA0PEiotCbddBEGnoVg/mashup/ra:collection?themeID=ZJ_JQGEHK01N0LM806KGPAKPA0UO0&locale=en&mime-type=text%2Fjavascript&lm=1778793196000&entry=st_skin__0.0%3Aconfig_js&entry=wp_liveobject_framework_core__0.0%3Aconfig_js&entry=wp_portal_ui_utils__0.0%3Aconfig_js&entry=wp_contextmenu_js__0.0%3Aconfig_js&entry=wp_skin_cam__0.0%3Aconfig_js&entry=wp_contextmenu_config_lof__0.0%3Aconfig_js&entry=wp_federated_documents_picker__0.0%3Aconfig_js&entry=wp_dnd_main__0.0%3Aconfig_js&entry=wp_movecontrols__0.0%3Aconfig_js&entry=wp_toolbar_controlactions__0.0%3Aconfig_js&entry=wp_content_targeting_cam__0.0%3Aconfig_js&deferred=true)

- ${title}${badge}

${loading}

[Deferred Modules](https://commerce.toshiba.com/wps/contenthandler/marketing/!ut/p/digest!SpZvrtUURDcRHYzcbiqg-Q/mashup/ra:collection?themeID=ZJ_JQGEHK01N0LM806KGPAKPA0UO0&locale=en&mime-type=text%2Fplain&entry=wp_contextmenu_templates__0.0%3Aconfig_markup&entry=wp_skin_cam__0.0%3Aconfig_markup&entry=wp_dnd_main__0.0%3Aconfig_markup&deferred=true)

reCAPTCHA

Select all images with **bicycles** Click verify once there are none left

|     |     |     |
| --- | --- | --- |
| ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7zRmbCk6at_0oolaB22b6LakuqoLiZxXWWmosoJP__YGSo2sU7Cb9rwz-a5NvhhXdAmNMNHuPJNBL4bcXlX2e5Wu6pJ-Snd3jnUqSN1jIMiRWjg_xsgdlmd6qaUqGv5k9s9midW3-j2l207IhR_GTYUAA8coCdvxp0pfN7q-tMQLhAxBM3iiEnAqK9SmXajLWCpWt8&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7zRmbCk6at_0oolaB22b6LakuqoLiZxXWWmosoJP__YGSo2sU7Cb9rwz-a5NvhhXdAmNMNHuPJNBL4bcXlX2e5Wu6pJ-Snd3jnUqSN1jIMiRWjg_xsgdlmd6qaUqGv5k9s9midW3-j2l207IhR_GTYUAA8coCdvxp0pfN7q-tMQLhAxBM3iiEnAqK9SmXajLWCpWt8&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7zRmbCk6at_0oolaB22b6LakuqoLiZxXWWmosoJP__YGSo2sU7Cb9rwz-a5NvhhXdAmNMNHuPJNBL4bcXlX2e5Wu6pJ-Snd3jnUqSN1jIMiRWjg_xsgdlmd6qaUqGv5k9s9midW3-j2l207IhR_GTYUAA8coCdvxp0pfN7q-tMQLhAxBM3iiEnAqK9SmXajLWCpWt8&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) |
| ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7zRmbCk6at_0oolaB22b6LakuqoLiZxXWWmosoJP__YGSo2sU7Cb9rwz-a5NvhhXdAmNMNHuPJNBL4bcXlX2e5Wu6pJ-Snd3jnUqSN1jIMiRWjg_xsgdlmd6qaUqGv5k9s9midW3-j2l207IhR_GTYUAA8coCdvxp0pfN7q-tMQLhAxBM3iiEnAqK9SmXajLWCpWt8&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7zRmbCk6at_0oolaB22b6LakuqoLiZxXWWmosoJP__YGSo2sU7Cb9rwz-a5NvhhXdAmNMNHuPJNBL4bcXlX2e5Wu6pJ-Snd3jnUqSN1jIMiRWjg_xsgdlmd6qaUqGv5k9s9midW3-j2l207IhR_GTYUAA8coCdvxp0pfN7q-tMQLhAxBM3iiEnAqK9SmXajLWCpWt8&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7zRmbCk6at_0oolaB22b6LakuqoLiZxXWWmosoJP__YGSo2sU7Cb9rwz-a5NvhhXdAmNMNHuPJNBL4bcXlX2e5Wu6pJ-Snd3jnUqSN1jIMiRWjg_xsgdlmd6qaUqGv5k9s9midW3-j2l207IhR_GTYUAA8coCdvxp0pfN7q-tMQLhAxBM3iiEnAqK9SmXajLWCpWt8&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) |
| ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7zRmbCk6at_0oolaB22b6LakuqoLiZxXWWmosoJP__YGSo2sU7Cb9rwz-a5NvhhXdAmNMNHuPJNBL4bcXlX2e5Wu6pJ-Snd3jnUqSN1jIMiRWjg_xsgdlmd6qaUqGv5k9s9midW3-j2l207IhR_GTYUAA8coCdvxp0pfN7q-tMQLhAxBM3iiEnAqK9SmXajLWCpWt8&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7zRmbCk6at_0oolaB22b6LakuqoLiZxXWWmosoJP__YGSo2sU7Cb9rwz-a5NvhhXdAmNMNHuPJNBL4bcXlX2e5Wu6pJ-Snd3jnUqSN1jIMiRWjg_xsgdlmd6qaUqGv5k9s9midW3-j2l207IhR_GTYUAA8coCdvxp0pfN7q-tMQLhAxBM3iiEnAqK9SmXajLWCpWt8&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7zRmbCk6at_0oolaB22b6LakuqoLiZxXWWmosoJP__YGSo2sU7Cb9rwz-a5NvhhXdAmNMNHuPJNBL4bcXlX2e5Wu6pJ-Snd3jnUqSN1jIMiRWjg_xsgdlmd6qaUqGv5k9s9midW3-j2l207IhR_GTYUAA8coCdvxp0pfN7q-tMQLhAxBM3iiEnAqK9SmXajLWCpWt8&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) |

Please try again.

Please select all matching images.

Please also check the new images.

Please select around the object, or reload if there are none.

Verify