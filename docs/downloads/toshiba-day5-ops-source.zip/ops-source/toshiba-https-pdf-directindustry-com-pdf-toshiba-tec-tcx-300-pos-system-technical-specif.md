<!-- source: https://pdf.directindustry.com/pdf/toshiba-tec/tcx-300-pos-system-technical-specifications/18429-946797.html -->

Exhibit with us

EUR - €

\*mydirectindustry

English

[![The B2B marketplace for industrial equipment](https://img.directindustry.com/media/ps/images/di/header/header-logo.svg)](https://www.directindustry.com/)

Frequent searches

- crushers
- compact crushers
- jaw crushers
- mobile crushers
- building material crushers
- pumps
- remote controls
- wireless remote controls
- industrial remote controls
- valves

- [Products](https://www.directindustry.com/)
- [Catalogs](https://pdf.directindustry.com/)
- RFQ
- [News & Trends](https://trends.directindustry.com/)
- E-MAGAZINE

![Di_54043-SECO S.p.A.-60583](https://img.directindustry.com/images_di/bnr/54043/hd/60583v1.jpg)

![Di_13796-Schleuniger-59868](https://img.directindustry.com/images_di/bnr/13796/hd/59868v2.jpg)

![Di_16025-SIKO GmbH-59701](https://img.directindustry.com/images_di/bnr/16025/hd/59701v1.jpg)

1. [Catalogs](https://pdf.directindustry.com/)
2. [Toshiba TEC](https://pdf.directindustry.com/pdf/toshiba-tec-18429.html)
3. TCx™ 300 POS System Technical Specifications

![Toshiba TEC - logo](https://img.directindustry.com/images_di/logo-p/L18429.gif)
![video corpo](https://img.directindustry.com/media/ps/images/common/stand/video-icon.gif)

Catalogs

- [Products](https://www.directindustry.com/prod/toshiba-tec-18429.html)
- [Catalogs](https://pdf.directindustry.com/pdf/toshiba-tec-18429.html)
- News & Trends
- Exhibitions

# TCx™ 300 POS System Technical Specifications  1 /2Pages

![TCx™ 300 POS System Technical Specifications](https://img.directindustry.com/pdf/repository_di/18429/tcx-300-pos-system-technical-specifications-946797_1mg.jpg)

# TCx™ 300 POS System Technical Specifications  1 /2Pages

Are you interested in the products in this catalog?

[See contact information](https://www.directindustry.com/request/form.html?token=esuxxcymxN7jeoEcaLCtV3jLnPpJEQKAy1DEjKjpelPgLw3r9bvOXdoPQ2Uj6WZv9UfDcTuP5Kl6UiTAyBIuwaKrPiTChLPn8wM9b0n6sVOVjBHxS0uSORVRCNzLPwrKLAbs0Dkh1kp7V1do1M9WSXLCO9QOnnvoo2QrDwLm1RCz0G2eKxUrvOXJskWwl1KPkEkhufLxy0wPJP9CA16V4PsRQFHp0b7EI7YeczXFFB6jO3)

Free quotation

Contact distributor

TOSHIBA TEC Europe Retail Information Systems S. A.

Neuss, Germany

## Catalog excerpts

![TCx™ 300 POS System Technical Specifications-1](https://img.directindustry.com/pdf/repository_di/18429/tcx-300-pos-system-technical-specifications-946797_1m.jpg)

TCx™ 300 POS System Technical Specifications HARDWARE Product Name
Hardware Models
1 TB available 128 GB, 256 GB or 512 GB SSD, optional (Dual 128 GB or 256 GB available)
Microphone, line-out (back)
(2) [Display](https://www.directindustry.com/industrial-manufacturer/display-68195.html) Ports (1) VGA standard, 2nd VGA optional
128KB located on riser card
\- (2) PC USB 2.0 (back) - (1) PC USB 2.0 (front) - (2) PC USB 3.1 Gen 1 (back) - (2) USB-C \[USB 3.1 Gen 1 + PD\] (back) - (2) USB 2.0 Pin Headers - (2) RS-232 ports (back) - (1) 9-pin powered RS232 \[port C\] (back) - SDL cashdrawer (3A)
Power Consumption
80 + Gold Efficient power supply, 60 W typical/200 W maximum
Power Management§
Deep sleep automation, ACPI
OPTIONAL PERIPHERALS Displays
\- Toshiba TCx™ Display Solution - Toshiba SurePoint™ solution - Distributed 11-character display (AP Only), - Distributed 40-character displays - All Points Addressable
\- Toshiba TCx™ Printers - Toshiba SureMark™ printers - Fiscal printers
Modular [USB Keyboards](https://www.directindustry.com/industrial-manufacturer/usb-keyboard-131925.html): ANPOS, CANPOS, 67-Key and 67-Key with LCD
Cash drawers
\- Compact - Wide - Flip-top
SOFTWARE System management
SMBIOS, Wake on LAN, PXE, Wired for Management, Trusted Platform Management
Power Management§
Deep sleep automation ACPI
Management tools
Toshiba Remote Management Agent
Drivers supported
UPOS 1.14.5 or higher (includes O

Open the catalog to page 1

![TCx™ 300 POS System Technical Specifications-2](https://img.directindustry.com/pdf/repository_di/18429/tcx-300-pos-system-technical-specifications-946797_2m.jpg)

OPERATING SYSTEMS ‡
Windows 10 IoT Enterprise LTSB 2016 (x64)
Windows 10 IoT Enterprise LTSC 2019 (x64)
SERVICES Limited warranty\*\*
One-year onsite service. Extended service available through TCx™ Care.
One and two years are available through TCx™ Care
Service life
Up to seven years after withdrawal from market
Technical support††
Web based service request
Memory supports both system and video. Accessible system memory will be the installed memory size less the amount defined for video. Not all peripherals are available in all countries. Please contact your local Toshiba representative for details....

Open the catalog to page 2

## All Toshiba TEC catalogs and technical brochures

01. ![TCx™ Dual Station Printer](https://img.directindustry.com/pdf/repository_di/18429/tcx-dual-station-printer-1068553_1mg.jpg)



    TCx™ Dual Station Printer

    2  Pages

02. ![e TCx™ Display](https://img.directindustry.com/pdf/repository_di/18429/e-tcx-display-1068552_1mg.jpg)



    e TCx™ Display

    2  Pages

03. ![TCx™ Single Station Printer](https://img.directindustry.com/pdf/repository_di/18429/tcx-single-station-printer-1068551_1mg.jpg)



    TCx™ Single Station Printer

    2  Pages

04. ![Toshiba Self Checkout System 7](https://img.directindustry.com/pdf/repository_di/18429/toshiba-self-checkout-system-7-1068550_1mg.jpg)



    Toshiba Self Checkout System 7

    4  Pages

05. ![TCx® 900](https://img.directindustry.com/pdf/repository_di/18429/tcx-900-1068549_1mg.jpg)



    TCx® 900

    2  Pages

06. ![TCx™ Displays Technical Specifications](https://img.directindustry.com/pdf/repository_di/18429/tcx-displays-technical-specifications-946800_1mg.jpg)



    TCx™ Displays Technical Specifications

    4  Pages

07. ![CF3/CF3R](https://img.directindustry.com/pdf/repository_di/18429/cf3-cf3r-946799_1mg.jpg)



    CF3/CF3R

    2  Pages

08. ![TCx 700 Technical Specifications](https://img.directindustry.com/pdf/repository_di/18429/tcx-700-technical-specifications-946794_1mg.jpg)



    TCx 700 Technical Specifications

    2  Pages

09. ![TCx™ 700](https://img.directindustry.com/pdf/repository_di/18429/tcx-700-894193_1mg.jpg)



    TCx™ 700

    2  Pages

10. ![TCxWave](https://img.directindustry.com/pdf/repository_di/18429/tcxwave-894181_1mg.jpg)



    TCxWave

    6  Pages

11. ![TCx™ 800](https://img.directindustry.com/pdf/repository_di/18429/tcx-800-894159_1mg.jpg)



    TCx™ 800

    2  Pages

12. ![CORPORATE PROFILE TOSHIBA TEC CORPORATION](https://img.directindustry.com/pdf/repository_di/18429/corporate-profile-toshiba-tec-corporation-773383_1mg.jpg)



    CORPORATE PROFILE TOSHIBA TEC CORPORATION

    20  Pages

13. ![SurePOS 775](https://img.directindustry.com/pdf/repository_di/18429/surepos-775-602759_1mg.jpg)



    SurePOS 775

    6  Pages

14. ![SurePOS 300 Series](https://img.directindustry.com/pdf/repository_di/18429/surepos-300-series-602756_1mg.jpg)



    SurePOS 300 Series

    4  Pages

15. ![SurePOS 500 POS](https://img.directindustry.com/pdf/repository_di/18429/surepos-500-pos-602755_1mg.jpg)



    SurePOS 500 POS

    6  Pages

16. ![SurePOS 700 Series](https://img.directindustry.com/pdf/repository_di/18429/surepos-700-series-602751_1mg.jpg)



    SurePOS 700 Series

    8  Pages

17. ![TCxFlight](https://img.directindustry.com/pdf/repository_di/18429/tcxflight-602749_1mg.jpg)



    TCxFlight

    8  Pages

18. ![CK1 & CK1L](https://img.directindustry.com/pdf/repository_di/18429/ck1-ck1l-568310_1mg.jpg)



    CK1 & CK1L

    2  Pages

19. ![Line-up](https://img.directindustry.com/pdf/repository_di/18429/line-up-511499_1mg.jpg)



    Line-up

    2  Pages

20. ![TRST-A10](https://img.directindustry.com/pdf/repository_di/18429/trst-a10-511487_1mg.jpg)



    TRST-A10

    2  Pages

21. ![TOSHIBA WILLPOS M30](https://img.directindustry.com/pdf/repository_di/18429/toshiba-willpos-m30-511485_1mg.jpg)



    TOSHIBA WILLPOS M30

    2  Pages

22. ![TOSHIBA WILLPOS B20](https://img.directindustry.com/pdf/repository_di/18429/toshiba-willpos-b20-511483_1mg.jpg)



    TOSHIBA WILLPOS B20

    2  Pages

23. ![TOSHIBA WILLPOS C10](https://img.directindustry.com/pdf/repository_di/18429/toshiba-willpos-c10-511481_1mg.jpg)



    TOSHIBA WILLPOS C10

    2  Pages

24. ![TOSHIBA WILLPOS A10](https://img.directindustry.com/pdf/repository_di/18429/toshiba-willpos-a10-511479_1mg.jpg)



    TOSHIBA WILLPOS A10

    2  Pages

25. ![TOSHIBA WILLPOS A20](https://img.directindustry.com/pdf/repository_di/18429/toshiba-willpos-a20-511477_1mg.jpg)



    TOSHIBA WILLPOS A20

    2  Pages

26. ![inkjet head CB1](https://img.directindustry.com/pdf/repository_di/18429/inkjet-head-cb1-376453_1mg.jpg)



    inkjet head CB1

    2  Pages

27. ![inkjet head CA4](https://img.directindustry.com/pdf/repository_di/18429/inkjet-head-ca4-376451_1mg.jpg)



    inkjet head CA4

    2  Pages

28. ![TOSHIBA B-EP Series](https://img.directindustry.com/pdf/repository_di/18429/toshiba-b-ep-series-280455_1mg.jpg)



    TOSHIBA B-EP Series

    2  Pages

29. ![inkjet head CA3](https://img.directindustry.com/pdf/repository_di/18429/inkjet-head-ca3-280469_1mg.jpg)



    inkjet head CA3

    2  Pages

30. ![inkjet head CA5](https://img.directindustry.com/pdf/repository_di/18429/inkjet-head-ca5-280467_1mg.jpg)



    inkjet head CA5

    2  Pages

31. ![inkjet head CE2](https://img.directindustry.com/pdf/repository_di/18429/inkjet-head-ce2-280465_1mg.jpg)



    inkjet head CE2

    2  Pages

32. ![MD-480I](https://img.directindustry.com/pdf/repository_di/18429/md-480i-280459_1mg.jpg)



    MD-480I

    2  Pages

33. ![TOSHIBA B-SP2D](https://img.directindustry.com/pdf/repository_di/18429/toshiba-b-sp2d-280451_1mg.jpg)



    TOSHIBA B-SP2D

    2  Pages

34. ![TRST-A series](https://img.directindustry.com/pdf/repository_di/18429/trst-a-series-253613_1mg.jpg)



    TRST-A series

    2  Pages

35. ![TOSHIBA DB-EA4D](https://img.directindustry.com/pdf/repository_di/18429/toshiba-db-ea4d-253611_1mg.jpg)



    TOSHIBA DB-EA4D

    2  Pages

36. ![TOSHIBA B-852-R](https://img.directindustry.com/pdf/repository_di/18429/toshiba-b-852-r-253609_1mg.jpg)



    TOSHIBA B-852-R

    2  Pages

37. ![B-452-HS](https://img.directindustry.com/pdf/repository_di/18429/b-452-hs-253607_1mg.jpg)



    B-452-HS

    2  Pages

38. ![TOSHIBA B-SV4D](https://img.directindustry.com/pdf/repository_di/18429/toshiba-b-sv4d-253605_1mg.jpg)



    TOSHIBA B-SV4D

    2  Pages

39. ![TOSHIBA B-SV4 series](https://img.directindustry.com/pdf/repository_di/18429/toshiba-b-sv4-series-253603_1mg.jpg)



    TOSHIBA B-SV4 series

    2  Pages

40. ![TOSHIBA EV4 Series](https://img.directindustry.com/pdf/repository_di/18429/toshiba-ev4-series-253601_1mg.jpg)



    TOSHIBA EV4 Series

    2  Pages

41. ![TOSHIBA B-452](https://img.directindustry.com/pdf/repository_di/18429/toshiba-b-452-253599_1mg.jpg)



    TOSHIBA B-452

    2  Pages

42. ![B-SA4](https://img.directindustry.com/pdf/repository_di/18429/b-sa4-253597_1mg.jpg)



    B-SA4

    2  Pages

43. ![TOSHIBA B-SX4 & B-SX5](https://img.directindustry.com/pdf/repository_di/18429/toshiba-b-sx4-b-sx5-253595_1mg.jpg)



    TOSHIBA B-SX4 & B-SX5

    2  Pages

44. ![TOSHIBA B-EX4T2](https://img.directindustry.com/pdf/repository_di/18429/toshiba-b-ex4t2-253593_1mg.jpg)



    TOSHIBA B-EX4T2

    2  Pages

45. ![TOSHIBA B-EX4T1](https://img.directindustry.com/pdf/repository_di/18429/toshiba-b-ex4t1-253591_1mg.jpg)



    TOSHIBA B-EX4T1

    2  Pages


## Archived catalogs

1. ![Barcode Printer](https://img.directindustry.com/pdf/repository_di/18429/barcode-printer-57120_1mg.jpg)



Barcode Printer

2  Pages

2. ![POS Systems](https://img.directindustry.com/pdf/repository_di/18429/pos-systems-57119_1mg.jpg)



POS Systems

2  Pages

3. ![Silent Fan-less Touch Screen POS Terminal](https://img.directindustry.com/pdf/repository_di/18429/silent-fan-less-touch-screen-pos-terminal-57121_1mg.jpg)



Silent Fan-less Touch Screen POS Terminal

2  Pages


Related Searches

- [LCD display panel](https://www.directindustry.com/industrial-manufacturer/lcd-display-142416.html)
- [LCD screen](https://www.directindustry.com/industrial-manufacturer/lcd-monitor-75830.html)
- [Monitor with touchscreen](https://www.directindustry.com/industrial-manufacturer/touch-screen-monitor-72506.html)
- [Intel® Core™ PC](https://www.directindustry.com/industrial-manufacturer/intel-core-pc-160437.html)
- [Embedded PC](https://www.directindustry.com/industrial-manufacturer/embedded-pc-277820.html)
- [RS-232 PC](https://www.directindustry.com/industrial-manufacturer/rs-232-pc-219736.html)
- [Windows PC](https://www.directindustry.com/industrial-manufacturer/windows-pc-218517.html)
- [USB PC](https://www.directindustry.com/industrial-manufacturer/usb-pc-161341.html)
- [Linux PC](https://www.directindustry.com/industrial-manufacturer/linux-pc-218516.html)
- [LED monitor](https://www.directindustry.com/industrial-manufacturer/led-monitor-125628.html)
- [Keyboard with mechanical keys](https://www.directindustry.com/industrial-manufacturer/keyboard-mechanical-keys-116031.html)
- [USB 3.0 PC](https://www.directindustry.com/industrial-manufacturer/usb-30-pc-219954.html)
- [LED backlight monitor](https://www.directindustry.com/industrial-manufacturer/led-backlight-monitor-144809.html)
- [Compact PC](https://www.directindustry.com/industrial-manufacturer/compact-pc-83778.html)
- [RJ45 PC](https://www.directindustry.com/industrial-manufacturer/rj45-pc-219837.html)
- [WiFi PC](https://www.directindustry.com/industrial-manufacturer/wifi-pc-225812.html)
- [PS2 keyboard](https://www.directindustry.com/industrial-manufacturer/ps2-keyboard-131917.html)
- [Windows 10 PC](https://www.directindustry.com/industrial-manufacturer/windows-10-pc-187785.html)

\*Prices are pre-tax. They exclude delivery charges and customs duties and do not include additional charges for installation or activation options. Prices are indicative only and may vary by country, with changes to the cost of raw materials and exchange rates.

![FLEXCO](https://img.directindustry.com/images_di/logo-pp/L14800.gif)

![Showa Sokki Corporation](https://img.directindustry.com/images_di/logo-pp/L4613027.gif)

![Sketch CO., LTD.](https://img.directindustry.com/images_di/logo-pp/L4613033.gif)

![SANY](https://img.directindustry.com/images_di/logo-pp/L52887.gif)

![KOHJIN Film & Chemicals Co., Ltd.](https://img.directindustry.com/images_di/logo-pp/L4613032.gif)

![ViewOhre Imaging Co., Ltd.](https://img.directindustry.com/images_di/logo-pp/L4600885.gif)

![XCMG](https://img.directindustry.com/images_di/logo-pp/L50713.gif)

![Trotec Laser GmbH](https://img.directindustry.com/images_di/logo-pp/L13984.gif)

![Mitsuya Co. Ltd.](https://img.directindustry.com/images_di/logo-pp/L4612988.gif)

![Siemens Low-voltage – Power distribution](https://img.directindustry.com/images_di/logo-pp/L25580.gif)

![Leica Microsystems GmbH](https://img.directindustry.com/images_di/logo-pp/L182601.gif)

![Smalley](https://img.directindustry.com/images_di/logo-pp/L11812.gif)

![Seiken Co., Ltd.](https://img.directindustry.com/images_di/logo-pp/L4600884.gif)

![NIHON DENGYO KOSAKU Co., Ltd.](https://img.directindustry.com/images_di/logo-pp/L4613034.gif)

![AGENCY ASSIST INC.](https://img.directindustry.com/images_di/logo-pp/L4606488.gif)

![SAB BROECKSKES GMBH & Co. KG](https://img.directindustry.com/images_di/logo-pp/L31139.gif)

![Imao Corporation](https://img.directindustry.com/images_di/logo-pp/L182419.gif)

![TURCK](https://img.directindustry.com/images_di/logo-pp/L4959.gif)

![TAISEI GIKEN CO.,LTD](https://img.directindustry.com/images_di/logo-pp/L4600883.gif)

![THERMO FISHER SCIENTIFIC - MATERIALS SCIENCE](https://img.directindustry.com/images_di/logo-pp/L123345.gif)

![Henkel LOCTITE](https://img.directindustry.com/images_di/logo-pp/L5610.gif)

![SIKO GmbH](https://img.directindustry.com/images_di/logo-pp/L16025.gif)

![EVIDENT – Inspection Technologies](https://img.directindustry.com/images_di/logo-pp/L4613096.gif)

![Prevost](https://img.directindustry.com/images_di/logo-pp/L7518.gif)

![RICOS](https://img.directindustry.com/images_di/logo-pp/L4613035.gif)

![TBM Co., Ltd](https://img.directindustry.com/images_di/logo-pp/L4594505.gif)

![TOPSOLID SAS](https://img.directindustry.com/images_di/logo-pp/L21412.gif)

![Stäubli Fluid Connectors](https://img.directindustry.com/images_di/logo-pp/L7527.gif)

![C.I. Takiron](https://img.directindustry.com/images_di/logo-pp/L4613166.gif)

![BD|SENSORS GmbH](https://img.directindustry.com/images_di/logo-pp/L14047.gif)

![Schubert & Salzer Control Systems GmbH](https://img.directindustry.com/images_di/logo-pp/L9316.gif)

![Line Seiki](https://img.directindustry.com/images_di/logo-pp/L23163.gif)

![FAULHABER Drive Systems](https://img.directindustry.com/images_di/logo-pp/L7023.gif)

![TECDIA Co., Ltd.](https://img.directindustry.com/images_di/logo-pp/L4612948.gif)

![ifm electronic](https://img.directindustry.com/images_di/logo-pp/L544.gif)

![AnchorZ Inc.](https://img.directindustry.com/images_di/logo-pp/L4600881.gif)

![IBS INC.](https://img.directindustry.com/images_di/logo-pp/L4613038.gif)

![BOGE](https://img.directindustry.com/images_di/logo-pp/L14276.gif)