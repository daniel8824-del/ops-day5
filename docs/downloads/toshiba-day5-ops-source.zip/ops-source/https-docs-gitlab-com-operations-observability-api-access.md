<!-- source: https://docs.gitlab.com/operations/observability/api_access -->

/

* * *

# Access the Observability API

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed
- Status: Experiment

Use the GitLab Observability API to query traces, metrics, and logs,
and to manage dashboards and alerts programmatically.

## Prerequisites [Permalink](https://docs.gitlab.com/operations/observability/api_access/\#prerequisites "Permalink")

- Observability must be enabled for your group.
For setup instructions, see
[Set up Observability on GitLab.com](https://docs.gitlab.com/operations/observability/setup_gitlab_com/) or
[Set up Observability on GitLab Self-Managed](https://docs.gitlab.com/operations/observability/setup_self_managed/).
- You must have the Developer, Maintainer, or Owner role for the group.

## Get your API key [Permalink](https://docs.gitlab.com/operations/observability/api_access/\#get-your-api-key "Permalink")

1. In the top bar, select **Search or go to** and find your group.
2. In the left sidebar, select **Observability** \> **API Keys**.
3. Copy your API key.

Use this key in the `SIGNOZ-API-KEY` header when you make API requests.

## API endpoint [Permalink](https://docs.gitlab.com/operations/observability/api_access/\#api-endpoint "Permalink")

The API endpoint depends on your GitLab offering.

### GitLab.com [Permalink](https://docs.gitlab.com/operations/observability/api_access/\#gitlabcom "Permalink")

Your API base URL follows this pattern:

```plaintext
https://<group_id>.gitlab-o11y.com
```

Replace `<group_id>` with your GitLab group ID.

### GitLab Self-Managed [Permalink](https://docs.gitlab.com/operations/observability/api_access/\#gitlab-self-managed "Permalink")

Your API base URL is the same URL you configured as the
`o11y_service_url` for your group. For example:

```plaintext
http://<your-instance-ip>:8080
```

## Make API requests [Permalink](https://docs.gitlab.com/operations/observability/api_access/\#make-api-requests "Permalink")

Include your API key in the `SIGNOZ-API-KEY` header with every request.

The following example queries the health endpoint:

shell

```shell
curl --header "SIGNOZ-API-KEY: <your_api_key>" \
  https://<group_id>.gitlab-o11y.com/api/v1/health
```

Replace `<your_api_key>` with the key from the **API Keys** page, and
`<group_id>` with your GitLab group ID (or your self-managed instance URL).

## Available API endpoints [Permalink](https://docs.gitlab.com/operations/observability/api_access/\#available-api-endpoints "Permalink")

GitLab Observability uses the SigNoz API.
For the complete list of available endpoints, request and response formats,
and usage examples, see the
[SigNoz API reference](https://signoz.io/api-reference/).

## Related topics [Permalink](https://docs.gitlab.com/operations/observability/api_access/\#related-topics "Permalink")

- [Send telemetry data to GitLab Observability](https://docs.gitlab.com/operations/observability/send/)
- [Troubleshooting Observability](https://docs.gitlab.com/operations/observability/troubleshooting/)

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**