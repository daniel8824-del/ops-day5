<!-- source: https://www.atlassian.com/itsm/service-request-management -->

Get it free

Search

Sign in

Jira Service Management is now more powerful than ever as part of Service Collection. Unlock exceptional service experiences with Rovo, Assets, and our new Customer Service Management app.

[Try it now](https://www.atlassian.com/try/cloud/signup?bundle=service-collection&edition=premium)

# What is a service request?

**Key Takeaways:** Service request management is the process for handling everyday employee and customer requests, including access, equipment, and information.

- What it is: Standardized workflows for how requests are submitted, triaged, fulfilled, and communicated.

- Why it matters: A well-designed SRM practice improves user satisfaction, reduces wait times, and gives teams clearer demand signals.

- How Jira Service Management helps: Provides configurable request types, portals, and automations so teams can handle high volumes of requests efficiently and transparently.


IT teams receive a wide variety of customer requests. Whether incoming inquiries are asking for access to applications, software licenses, password resets, or new hardware, the Information Technology Infrastructure Library ( [ITIL](https://www.atlassian.com/itsm/change-management)) classifies these as service requests. Service requests are often recurring, so efficient IT teams follow a repeatable procedure to handle them.

[Get it free](https://www.atlassian.com/software/jira/service-management/free)

Service request management is related to, but distinct from other service management practices, including incident, problem, and change management. Service request management uniquely involves a user submitting their request for something new --whether that’s access to a service, a new phone, or information.

[ITIL specifies](https://www.axelos.com/corporate/media/files/glossaries/itil_2011_glossary_gb-v1-0.pdf) that, along with the service desk, service requests are managed by the request fulfilment process.

## What is request fulfillment?

Request fulfillment is the process of resolving a customer’s service request and refers to managing the entire lifecycle of all service requests. The service desk team is dedicated to responding to and fulfilling requests while delivering the highest level of service support quality to the customer.

Request fulfillment is about enabling employees by providing access to the IT services they need to be productive. It should help users see available services, understand how to request them, and set expectations for how long requests will take to be addressed.

In organizations that generate large numbers of service requests, it’s smart to handle service requests as a separate work stream – and to record and manage them as a separate record type. This should be a distinct process from your other IT processes.

## Service request management vs incident management

A common question that comes up about service request management is how it relates to core IT practices including incident, problem, and change management. It’s worth briefly covering certain key terms before getting into distinctions.

- **Service request** \- A formal user request for something new to be provided. Example: “I need a new Macbook.”

- [**Incident**](https://www.atlassian.com/incident-management) \- An unplanned event that disrupts or reduces the quality of a service and requires an emergency response. Example: “The website is down!”

- [**Problem**](https://www.atlassian.com/itsm/problem-management)\- The underlying cause of recurring or preventable incidents. Example: “That application issue strikes again!”

- [**Change**](https://www.atlassian.com/itsm/change-management) \- Adding, modifying, or removing something that could affect IT services. This can be tied to a service request. Example: “I need to upgrade the database!”


Service requests should be handled as a distinct workstream to help IT teams focus on delivering more valuable work and better enabling the rest of the organization. Service requests are quite often low risk, and can be expedited or even automated. For instance, if a new employee submits a service request for access to a software application, that request can be pre-approved and automatically granted.

All of this means that the IT team can reduce stress, save time, and avoid overly complicated workflows. Considering the variety of incoming change, incident, and service requests you have to handle, separate workstreams and records will allow your team to figure out how best to allocate your resources.

## Service request process

While there are some variations in the way a service request can be captured and fulfilled, it’s important to focus on driving standardization to improve overall service quality and efficiency. The following process represents a simple request fulfillment process based on ITIL recommendations. This can be used as a starting point for adapting existing ITIL processes or defining new ones.

![Diagram showing a service request flow](https://dam-cdn.atl.orangelogic.com/AssetLink/55l0t5fh0276w3n4qd528i8a55l8u28d.png)

Service request fulfillment process, in brief:

1. A customer requests help from your service portal or via email.

2. The IT service team assesses the request alongside pre-defined approval and qualification processes. If needed, they send the request for financial or business approval.

3. A service desk agent works to fulfill the service request, or forwards the request to someone who can.

4. After resolving the request, the agent closes the ticket and consults the customer to make sure they are satisfied.


## Service request management priorities

![](https://dam-cdn.atl.orangelogic.com/AssetLink/dyxc544bhv36x3282yhx7a67y8yw4lj8.png)

A strong service request management practice is customer focused, knowledge centric, and streamlined with automation. By applying these principles across your efforts, your organization can strengthen the IT support team, make it easy for customers to ask for help and get answers, and use tech to keep pace with changing organizational needs.

Here are recommendations of what IT service teams should prioritize to get closer to the customer and deliver the best service possible.

### Support the support team

The unsung heroes of any organization, support teams understandably get burnt out by the sheer volume of tickets they handle. Requests for services often exceed the supply of available time and resources. IT service teams in large corporations are constantly responding to requests from the business, often falling into the mode of reacting first to the customers who make the most noise. Meanwhile, customers complain that IT is difficult to work with, unresponsive, and takes too long to fulfill the requests they need to do their job. IT shouldn’t be thought of as a bottleneck.

To deliver better customer service, it’s important to focus on the well-being and development of frontline support teams. Typical tiered support teams are highly structured and manage requests via escalations. We recommend a more collaborative approach to service request management. In this approach, every member of the support team can get closer to the customer and answer questions. When IT teams swarm issues in tools like Slack, they also gain an opportunity for everyone to learn from the process of resolving the request.

By adding regular retros, the team gets a moment to step back and review everything that happened, on an ideally weekly basis. This provides a chance to ask questions, pinpoint areas for improvement, and make sure requests are routed to the appropriate teams. Becoming a learning focused team and embracing [continuous improvement](https://www.atlassian.com/agile/project-management/continuous-improvement) means the IT support team can be better customer advocates.

Working in IT can be a difficult and thankless job. At Atlassian, we recommend support teams regularly [conduct health monitors](https://www.atlassian.com/team-playbook/health-monitor) to assess and take action to improve the team.

### Shift left

To move out of a chaotic service request mess, one popular recommendation is to “shift left.” So, what does “shift left “mean? It’s moving request fulfillment as close to the front line – and customer – as possible. This improves the customer experience by speeding up time to resolution, simplifying support activity, and reducing the overall cost of request fulfillment.

For instance, a knowledge base with searchable articles can work wonders in deflecting tickets. Or, customizing your request intake forms to gather relevant information can reduce long back-and-forth conversations.

![Diagram showing value of shifting left in IT support](https://dam-cdn.atl.orangelogic.com/AssetLink/ru68e28v2825cmn25124b33x872rvq57.png)

Customers want a single place to go for help. Centralize the help seeker experience and make it as easy to access and use as possible.  Many organizations have created a self-service portal only for it to gather (metaphorical) dust. Learn from their mistakes, and create something based around the unique culture of your organization. Remember, that even if you build the most powerful self-service system, it’s worthless if customers can’t easily find it.

### Leverage automation

When you incorporate automation into your self service capability you reduce the overall workload for your IT team by removing common repetitive tasks.  For example, use automation to speed up the follow-up communications your agents complete manually today, improve the way you communicate with customers, and keep stakeholders updated on estimated resolution time. Canned responses for certain requests provide useful information to the customer and reduce the workload for the agent.  Customers often don’t know where to seek help from, and automation can also be used to route service requests to the appropriate team for expedited resolution.

### Be ready to scale up

As your organization grows, delivering service becomes increasingly complex.  More teams are involved in managing queues of requests. With more need to delegate responsibilities, and pass work between teams, context is often lost. We hear stories from customers that acquire new business units or companies, and face a daunting process to onboard them into their systems.

A service catalog provides information about the live IT services that are available for deployment. The ability to quickly deploy a service catalog, without a developer can enable you to adapt to changing business needs.

## Best practices for service requests

So what does it take to create an efficient service request management process? Here are 8 tips to consider:

1. Begin with the most common, simple, and easily fulfilled requests. Defining them provides immediate value to customers and allows the IT team to learn as they build out future phases of the request workstream.

2. Document all your requirements for your service requests-- question fields, approval process, fulfillment procedures, fulfillment team, process owner, SLAs, reporting, etc. This will allow the IT team to best manage the request offering over time. This step is very important for more complex request offerings that will evolve over time.

3. Capture the data needed to start the request process upon intake, but don’t overload the customer with too many questions.

4. Standardize and automate the approval process where possible. For example, all requests for new monitors are considered pre-approved (and automatically fulfilled if possible) and all software requests need to be approved by the customer’s manager.

5. Review the request fulfillment process and procedures to identify which support teams are responsible for completing the request, and if any special requirements exist. Streamline with automation if possible.

6. Identify what information should be available in the [knowledge base](https://www.atlassian.com/itsm/knowledge-management/what-is-a-knowledge-base) when a request offering is released. The overall goal of self-service is to give your customers what they want faster and to deflect requests where possible, so if you can answer a question in a common FAQ, include this knowledge as a part of the plan when creating the service request offering.

7. Review Service Level Agreements (SLAs) to ensure you have the proper measurements and notifications in place so that requests are fulfilled in a timely manner.

8. Identify what reporting and metrics are needed to properly manage the lifecycle of a service request. Start tracking with metrics like CSAT (customer satisfaction), time to response, time to resolution, and time to close.


## Summary

Getting service request management right means you’ll enable your IT team to focus on what’s most important to the broader organization, all while promoting a better customer experience. A flexible software tool like Jira Service Management can help your team cut through the chaos and configure workflows that fit your team's needs.

[Try Jira Service Management](https://www.atlassian.com/software/jira/service-management/free)

## Recommended for you

WHITEPAPER

### Atlassian for ITSM

The basics you need to know about ITSM with Atlassian – across IT delivery, operations, and support, plus best practices and tips.

[Get the guide](https://www.atlassian.com/whitepapers/complete-guide-itsm)

### IT Asset Management: Complete ITAM Guide & Best Practices

IT Asset Management (ITAM) is crucial for tracking and justifying IT spend. Learn more about the process, its importance, and choosing the right software.

[Read this article](https://www.atlassian.com/itsm/it-asset-management)

### Learn more about ITSM

Find more ITSM guides and resources in this hub.

[Read this article](https://www.atlassian.com/itsm)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**