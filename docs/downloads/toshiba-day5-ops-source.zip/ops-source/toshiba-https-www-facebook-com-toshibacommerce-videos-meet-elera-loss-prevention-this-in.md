<!-- source: https://www.facebook.com/ToshibaCommerce/videos/meet-elera-loss-prevention-this-integrated-self-checkout-loss-prevention-solutio/1505560226889567/ -->

Facebook

[Log in](https://www.facebook.com/login/device-based/regular/login/?login_attempt=1&next=https%3A%2F%2Fwww.facebook.com%2FToshibaCommerce%2Fvideos%2Fmeet-elera-loss-prevention-this-integrated-self-checkout-loss-prevention-solutio%2F1505560226889567%2F)

Log in

[Forgotten account?](https://www.facebook.com/recover/initiate?ars=royal_blue_bar)

[**Video**](https://www.facebook.com/watch/)

[Home](https://www.facebook.com/watch/)

[Live](https://www.facebook.com/watch/live/?ref=watch)

[Reels](https://www.facebook.com/reel/?s=bookmark)

[Explore](https://www.facebook.com/watch/topic/)

More

[Home](https://www.facebook.com/watch/)

[Live](https://www.facebook.com/watch/live/?ref=watch)

[Reels](https://www.facebook.com/reel/?s=bookmark)

[Explore](https://www.facebook.com/watch/topic/)

![](https://scontent-lga3-1.xx.fbcdn.net/v/t15.5256-10/411046126_783093456925340_1393938050871641819_n.jpg?stp=dst-jpg_s960x960_tt6&_nc_cat=110&ccb=1-7&_nc_sid=be8305&_nc_ohc=tttTtyeLA78Q7kNvwHZQNDK&_nc_oc=AdpOy8umY8XBBbLtxtiP1AxxxAo27P70q02yYwmINRS5DVvaPR_ki2whmxvwqUwmXdU&_nc_zt=23&_nc_ht=scontent-lga3-1.xx&_nc_gid=Dsxt2lnEjb1IjfgqLb0a4w&_nc_ss=7b289&oh=00_Af7HiiJaQdzHvZ-joaaSc3Zi8s7KhgeDVjdLtDxvumNfDg&oe=6A141F56)

Sorry, we're having trouble with playing this video.

[Learn more](https://www.facebook.com/help/396404120401278/list?__cft__[0]=AZaSARI54JpIyBbrrp5stcNMLZP9XcV61kXK5JHk_SZ2EQpBGxUpSjeP_rDlOoGKFTxW1grFZVZ9mzIRWZX6nf4aRE5X2AaLBVhGUPPmQLqEqXzRfoOUtttOyvpftTxJvKB_9Psa9NKVR4-T0brbjNgSNlMwRHJrvAdMvsHRz7Dw1w)

Meet ELERA® Loss Prevention!

This integrated self checkout loss prevention solution uses our state of the art TCx® EDGEcam+ mounted on SCO hardware and demonstrates the power of moving smart devices to the edge and enhancing them with A.I. capabilities.

https://bit.ly/3Rkf5w3

Like

Comment

Share

![](data:image/svg+xml,%3Csvg fill='none' xmlns='http://www.w3.org/2000/svg' viewBox='0 0 16 16'%3E%3Cpath d='M16.0001 7.9996c0 4.418-3.5815 7.9996-7.9995 7.9996S.001 12.4176.001 7.9996 3.5825 0 8.0006 0C12.4186 0 16 3.5815 16 7.9996Z' fill='url(%23paint0_linear_15251_63610)'/%3E%3Cpath d='M16.0001 7.9996c0 4.418-3.5815 7.9996-7.9995 7.9996S.001 12.4176.001 7.9996 3.5825 0 8.0006 0C12.4186 0 16 3.5815 16 7.9996Z' fill='url(%23paint1_radial_15251_63610)'/%3E%3Cpath d='M16.0001 7.9996c0 4.418-3.5815 7.9996-7.9995 7.9996S.001 12.4176.001 7.9996 3.5825 0 8.0006 0C12.4186 0 16 3.5815 16 7.9996Z' fill='url(%23paint2_radial_15251_63610)' fill-opacity='.5'/%3E%3Cpath d='M7.3014 3.8662a.6974.6974 0 0 1 .6974-.6977c.6742 0 1.2207.5465 1.2207 1.2206v1.7464a.101.101 0 0 0 .101.101h1.7953c.992 0 1.7232.9273 1.4917 1.892l-.4572 1.9047a2.301 2.301 0 0 1-2.2374 1.764H6.9185a.5752.5752 0 0 1-.5752-.5752V7.7384c0-.4168.097-.8278.2834-1.2005l.2856-.5712a3.6878 3.6878 0 0 0 .3893-1.6509l-.0002-.4496ZM4.367 7a.767.767 0 0 0-.7669.767v3.2598a.767.767 0 0 0 .767.767h.767a.3835.3835 0 0 0 .3835-.3835V7.3835A.3835.3835 0 0 0 5.134 7h-.767Z' fill='%23fff'/%3E%3Cdefs%3E%3CradialGradient id='paint1_radial_15251_63610' cx='0' cy='0' r='1' gradientUnits='userSpaceOnUse' gradientTransform='rotate(90 .0005 8) scale(7.99958)'%3E%3Cstop offset='.5618' stop-color='%230866FF' stop-opacity='0'/%3E%3Cstop offset='1' stop-color='%230866FF' stop-opacity='.1'/%3E%3C/radialGradient%3E%3CradialGradient id='paint2_radial_15251_63610' cx='0' cy='0' r='1' gradientUnits='userSpaceOnUse' gradientTransform='rotate(45 -4.5257 10.9237) scale(10.1818)'%3E%3Cstop offset='.3143' stop-color='%2302ADFC'/%3E%3Cstop offset='1' stop-color='%2302ADFC' stop-opacity='0'/%3E%3C/radialGradient%3E%3ClinearGradient id='paint0_linear_15251_63610' x1='2.3989' y1='2.3999' x2='13.5983' y2='13.5993' gradientUnits='userSpaceOnUse'%3E%3Cstop stop-color='%2302ADFC'/%3E%3Cstop offset='.5' stop-color='%230866FF'/%3E%3Cstop offset='1' stop-color='%232B7EFF'/%3E%3C/linearGradient%3E%3C/defs%3E%3C/svg%3E)

9

·

112 views

[Toshiba Global Commerce Solutions](https://www.facebook.com/ToshibaCommerce?__tn__=%3C%3C)

## [**Toshiba Global Commerce Solutions**](https://www.facebook.com/ToshibaCommerce?__tn__=-UC)

[13 December 2023](https://www.facebook.com/ToshibaCommerce/videos/1505560226889567/?__tn__=%2CO) · Shared with Public

Follow

Meet ELERA® Loss Prevention! …

See more

## Comments

## Related reels

[![](https://scontent-lga3-3.xx.fbcdn.net/v/t39.30808-10/457100476_18279081121230509_6232171245304065366_n.jpg?stp=dst-jpg_s960x960_tt6&_nc_cat=104&ccb=1-7&_nc_sid=3e895a&_nc_ohc=u4GWvWOt_bgQ7kNvwESyZIU&_nc_oc=Adr7QJnUdkp7Da21ji9nmvVhTZrChkySlB6YidizFS8s3MmPcrpq3z3_LYeE5dmaRv0&_nc_zt=23&_nc_ht=scontent-lga3-3.xx&_nc_gid=Dsxt2lnEjb1IjfgqLb0a4w&_nc_ss=7b289&oh=00_Af6zE2bpdNDkTiM4gLmLrNtR6IeTSVwQ4ewjKwvpY1pBrg&oe=6A141A1E)\\
\\
Toshiba Global Commerce Solutions\\
\\
963](https://www.facebook.com/reel/369740756230255/?s=ifu)

[![](https://scontent-lga3-3.xx.fbcdn.net/v/t51.29350-10/419327132_929141315234395_8384073129654464377_n.jpg?stp=dst-jpg_s960x960_tt6&_nc_cat=104&ccb=1-7&_nc_sid=2b839e&_nc_ohc=Jm5SMBEfgP8Q7kNvwHB7u0A&_nc_oc=AdoaQ_yRDVs0se_GypqdAt2trHPf3y8-KBDfbzgqzjAstxaAkMo7sWSODqJBW1ygm9M&_nc_zt=23&_nc_ht=scontent-lga3-3.xx&_nc_gid=Dsxt2lnEjb1IjfgqLb0a4w&_nc_ss=7b289&oh=00_Af4DNHB7hhunLkZI5yoS_XsXKaGQDc_0DSA8K6BkBQi-Cg&oe=6A142937)\\
\\
Toshiba Global Commerce Solutions\\
\\
1K](https://www.facebook.com/reel/2113351039018054/?s=ifu)

[![](https://scontent-lga3-1.xx.fbcdn.net/v/t51.29350-10/418757301_668666378680140_8456136726568734618_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=2b839e&_nc_ohc=TyPyRcq_S8sQ7kNvwHexy3F&_nc_oc=AdoCHJPJvIy46tdTsFC8KPqq93qVn_GA22kfGZR3HkUFeHiiUgt-cunlOCF5ZdoF_is&_nc_zt=23&_nc_ht=scontent-lga3-1.xx&_nc_gid=Dsxt2lnEjb1IjfgqLb0a4w&_nc_ss=7b289&oh=00_Af5AOdNRN2xIcR3nkNzJec6IHk6_nRK9m4J744921-sbig&oe=6A1434CA)\\
\\
Toshiba Global Commerce Solutions\\
\\
1K](https://www.facebook.com/reel/396621556158852/?s=ifu)

[![](https://scontent-lga3-1.xx.fbcdn.net/v/t51.36329-10/363308189_265063809567272_4097102740222727763_n.jpg?stp=dst-jpg_s960x960_tt6&_nc_cat=103&ccb=1-7&_nc_sid=2b839e&_nc_ohc=RL_4umAsoz4Q7kNvwGCd00_&_nc_oc=AdovrYip0QKajHzPXlb3V1fPeIE9oSHXNKmRnIVQDDEub49vvAuJdAmS5Q08M6H8kNA&_nc_zt=23&_nc_ht=scontent-lga3-1.xx&_nc_gid=Dsxt2lnEjb1IjfgqLb0a4w&_nc_ss=7b289&oh=00_Af7fmwERuju11NxvwuQ0wj6vrQ3AslUuSk12p8rRkAy84Q&oe=6A14191C)\\
\\
Toshiba Global Commerce Solutions\\
\\
1.4K](https://www.facebook.com/reel/1350797312456359/?s=ifu)

## Related videos

[![Video thumbnail](https://scontent-lga3-3.xx.fbcdn.net/v/t15.5256-10/518718032_24235320149398014_7952077537774587007_n.jpg?stp=dst-jpg_p206x206_tt6&_nc_cat=102&ccb=1-7&_nc_sid=d2b52d&_nc_ohc=FZXlkcBWMMsQ7kNvwGz4cHL&_nc_oc=AdplDTcicRA603pDgdguyZvqqLUYi31I99FQqPSQ7jVC9pZXUDFAYJcVBeO0yGbgqFE&_nc_zt=23&_nc_ht=scontent-lga3-3.xx&_nc_gid=_gkRJ3My4wND3RSMxtF5Vg&_nc_ss=7b289&oh=00_Af4tzhyC60BYrJRONZspr5VUiqb_zasaGpDEYhmYZdeD_A&oe=6A144169)\\
\\
1:10](https://www.facebook.com/100027924505315/videos/4230123193927713/?__so__=permalink&__cft__[0]=AZZ5uK_PkesGJej10egkuUBdbBYNsfgsrPmSG1bYENS5q4XSQn1PSuUCIzHW2tZTIHaVCyVl8K5T-nXzvdYQYobwrLyGqJn2pIMK9zVSbddUeCbmZ76LV2WolD0Mvbys8ROdHqyTW_aWWRLaz9V1HWSlGoSCu8m10d_UXKP0bWV_qA)

[Link to profile](https://www.facebook.com/watch/100027924505315/?__cft__[0]=AZZ5uK_PkesGJej10egkuUBdbBYNsfgsrPmSG1bYENS5q4XSQn1PSuUCIzHW2tZTIHaVCyVl8K5T-nXzvdYQYobwrLyGqJn2pIMK9zVSbddUeCbmZ76LV2WolD0Mvbys8ROdHqyTW_aWWRLaz9V1HWSlGoSCu8m10d_UXKP0bWV_qA)

[👟Try to keep up with Julianna Vigil, as she shares her fast-paced ‘Day in the Life’ as an Intern in Paid Media and Email Marketing at Toshiba HQ\\
\\
A great place to work, learn, and thrive + ☕ we have a great cafeteria 😁\\
\\
Learn more about career and internship opportunities - \\
https://careers.commerce.toshiba.com/](https://www.facebook.com/100027924505315/videos/4230123193927713/?__so__=permalink&__cft__[0]=AZZ5uK_PkesGJej10egkuUBdbBYNsfgsrPmSG1bYENS5q4XSQn1PSuUCIzHW2tZTIHaVCyVl8K5T-nXzvdYQYobwrLyGqJn2pIMK9zVSbddUeCbmZ76LV2WolD0Mvbys8ROdHqyTW_aWWRLaz9V1HWSlGoSCu8m10d_UXKP0bWV_qA)

[Toshiba Global Commerce Solutions](https://www.facebook.com/watch/100027924505315/?__cft__[0]=AZZ5uK_PkesGJej10egkuUBdbBYNsfgsrPmSG1bYENS5q4XSQn1PSuUCIzHW2tZTIHaVCyVl8K5T-nXzvdYQYobwrLyGqJn2pIMK9zVSbddUeCbmZ76LV2WolD0Mvbys8ROdHqyTW_aWWRLaz9V1HWSlGoSCu8m10d_UXKP0bWV_qA&__cft__[1]=AZZ5uK_PkesGJej10egkuUBdbBYNsfgsrPmSG1bYENS5q4XSQn1PSuUCIzHW2tZTIHaVCyVl8K5T-nXzvdYQYobwrLyGqJn2pIMK9zVSbddUeCbmZ76LV2WolD0Mvbys8ROdHqyTW_aWWRLaz9V1HWSlGoSCu8m10d_UXKP0bWV_qA)

1.5K views

·

11 July 2025

[![Video thumbnail](https://scontent-lga3-3.xx.fbcdn.net/v/t15.5256-10/516252342_759474290350122_5565095456479270323_n.jpg?stp=dst-jpg_p206x206_tt6&_nc_cat=102&ccb=1-7&_nc_sid=d2b52d&_nc_ohc=-AA0L6S7jPMQ7kNvwHXZ2ht&_nc_oc=AdopXKqzvgD2yao7a7SWxeh28FSa3jPCk7bZKxEnYVkv2hcxjcaqxg4bVzZGkKMSMFw&_nc_zt=23&_nc_ht=scontent-lga3-3.xx&_nc_gid=_gkRJ3My4wND3RSMxtF5Vg&_nc_ss=7b289&oh=00_Af5g1TOAyRvVjf_MKviL_Kbk04zPqw_UfTo28Uby3M1FNw&oe=6A14398D)\\
\\
0:08](https://www.facebook.com/100027924505315/videos/1461860804969083/?__so__=permalink&__cft__[0]=AZZuED9ft1_tQDFtzB-lsx-W8Eb9bqUMVLCk2R1oL_cYBDGqNHBdRE4gn5EOxP1oCubJ_zAqaCbtOPfZ7bz5VVsCSi8su15Rc80ZTuy_kU5MkUAoWBfgH1qQ5QiYoZD9ICL7Ei0el7kktlRNo7GbJUULca3mdNvo_87h_EiTtabEkg)

[Link to profile](https://www.facebook.com/watch/100027924505315/?__cft__[0]=AZZuED9ft1_tQDFtzB-lsx-W8Eb9bqUMVLCk2R1oL_cYBDGqNHBdRE4gn5EOxP1oCubJ_zAqaCbtOPfZ7bz5VVsCSi8su15Rc80ZTuy_kU5MkUAoWBfgH1qQ5QiYoZD9ICL7Ei0el7kktlRNo7GbJUULca3mdNvo_87h_EiTtabEkg)

[Summer intern vibes at our Frisco, TX office. \\
\\
Thanks to the "New Interns" Diana Chubb, Hrishitha Kakarla, Roei Ben Porat and Ahmet Koc for putting up with the "Old Interns" Dean Greenberg and Peter Yin.](https://www.facebook.com/100027924505315/videos/1461860804969083/?__so__=permalink&__cft__[0]=AZZuED9ft1_tQDFtzB-lsx-W8Eb9bqUMVLCk2R1oL_cYBDGqNHBdRE4gn5EOxP1oCubJ_zAqaCbtOPfZ7bz5VVsCSi8su15Rc80ZTuy_kU5MkUAoWBfgH1qQ5QiYoZD9ICL7Ei0el7kktlRNo7GbJUULca3mdNvo_87h_EiTtabEkg)

[Toshiba Global Commerce Solutions](https://www.facebook.com/watch/100027924505315/?__cft__[0]=AZZuED9ft1_tQDFtzB-lsx-W8Eb9bqUMVLCk2R1oL_cYBDGqNHBdRE4gn5EOxP1oCubJ_zAqaCbtOPfZ7bz5VVsCSi8su15Rc80ZTuy_kU5MkUAoWBfgH1qQ5QiYoZD9ICL7Ei0el7kktlRNo7GbJUULca3mdNvo_87h_EiTtabEkg&__cft__[1]=AZZuED9ft1_tQDFtzB-lsx-W8Eb9bqUMVLCk2R1oL_cYBDGqNHBdRE4gn5EOxP1oCubJ_zAqaCbtOPfZ7bz5VVsCSi8su15Rc80ZTuy_kU5MkUAoWBfgH1qQ5QiYoZD9ICL7Ei0el7kktlRNo7GbJUULca3mdNvo_87h_EiTtabEkg)

1.7K views

·

8 July 2025

[![Video thumbnail](https://scontent-lga3-2.xx.fbcdn.net/v/t15.5256-10/482820708_4059263250994799_4567659159044255856_n.jpg?stp=dst-jpg_p370x247_tt6&_nc_cat=107&ccb=1-7&_nc_sid=d2b52d&_nc_ohc=rYUSb_MDhyQQ7kNvwF19MgR&_nc_oc=Adr2Y2dyW9vrQv_PruCoxqOa7rFPPqFkcxAQoHbjreDhGp9nI6xDcucf9UPZY6Wo5Vc&_nc_zt=23&_nc_ht=scontent-lga3-2.xx&_nc_gid=_gkRJ3My4wND3RSMxtF5Vg&_nc_ss=7b289&oh=00_Af4QsouMclfbgVZSIXwKt4HYyaIv69JLDYnSjCTnFeGhxg&oe=6A141656)\\
\\
1:31](https://www.facebook.com/100027924505315/videos/1304353577293394/?__so__=permalink&__cft__[0]=AZYblAUTHLVs8EPZaHm0bGQvosaKvv-IMKFXlZVrwhrMLTvS6DqYXc9mkIx3YlNmkMJUbaANCLWL9IFjjRknIr9Z2KPLs0H76SzxecWah9S8Suc8DXt_ff6Ju51qukd9yv-ZbKL0Xtv69cXMVjO-VTGl6EOzzB6e_c2OO84Ms3xpTg)

[Link to profile](https://www.facebook.com/watch/100027924505315/?__cft__[0]=AZYblAUTHLVs8EPZaHm0bGQvosaKvv-IMKFXlZVrwhrMLTvS6DqYXc9mkIx3YlNmkMJUbaANCLWL9IFjjRknIr9Z2KPLs0H76SzxecWah9S8Suc8DXt_ff6Ju51qukd9yv-ZbKL0Xtv69cXMVjO-VTGl6EOzzB6e_c2OO84Ms3xpTg)

[In celebration of International Women's Day, we're proud to spotlight the amazing women at Toshiba Global Commerce Solutions who inspire us daily. Women across our organization are integral to our success through leading teams, innovating and creating the future of retail.\\
\\
This year, we’re highlighting 19 extraordinary women who were nominated by their colleagues throughout our Americas offices for showing accelerated action and an outstanding commitment to innovation, inclusion, and leadership.\\
\\
Thank you to all the women at Toshiba for your hard work, resilience, and unwavering commitment to excellence.\\
\\
#IWD2025 #AccerlateAction #WeAreRETAIL #WomensHistoryMonth](https://www.facebook.com/100027924505315/videos/1304353577293394/?__so__=permalink&__cft__[0]=AZYblAUTHLVs8EPZaHm0bGQvosaKvv-IMKFXlZVrwhrMLTvS6DqYXc9mkIx3YlNmkMJUbaANCLWL9IFjjRknIr9Z2KPLs0H76SzxecWah9S8Suc8DXt_ff6Ju51qukd9yv-ZbKL0Xtv69cXMVjO-VTGl6EOzzB6e_c2OO84Ms3xpTg)

[Toshiba Global Commerce Solutions](https://www.facebook.com/watch/100027924505315/?__cft__[0]=AZYblAUTHLVs8EPZaHm0bGQvosaKvv-IMKFXlZVrwhrMLTvS6DqYXc9mkIx3YlNmkMJUbaANCLWL9IFjjRknIr9Z2KPLs0H76SzxecWah9S8Suc8DXt_ff6Ju51qukd9yv-ZbKL0Xtv69cXMVjO-VTGl6EOzzB6e_c2OO84Ms3xpTg&__cft__[1]=AZYblAUTHLVs8EPZaHm0bGQvosaKvv-IMKFXlZVrwhrMLTvS6DqYXc9mkIx3YlNmkMJUbaANCLWL9IFjjRknIr9Z2KPLs0H76SzxecWah9S8Suc8DXt_ff6Ju51qukd9yv-ZbKL0Xtv69cXMVjO-VTGl6EOzzB6e_c2OO84Ms3xpTg)

1.4K views

·

7 March 2025

[![Video thumbnail](https://scontent-lga3-3.xx.fbcdn.net/v/t15.5256-10/482437978_667541622369701_4085195471343310595_n.jpg?stp=dst-jpg_p206x206_tt6&_nc_cat=102&ccb=1-7&_nc_sid=d2b52d&_nc_ohc=QaXcmuptmXMQ7kNvwG4XQ8o&_nc_oc=AdrWQ0QfbHyjV8JCO1XvCPdEfxV-c7IPk2DkLygwxdxXu099D37whsBqE2qoQDfUR48&_nc_zt=23&_nc_ht=scontent-lga3-3.xx&_nc_gid=_gkRJ3My4wND3RSMxtF5Vg&_nc_ss=7b289&oh=00_Af4qhiCbHEAA2xWXnUoIcbbYm_98YUURsc60dvhuLk_yNg&oe=6A142559)\\
\\
0:31](https://www.facebook.com/100027924505315/videos/662743313098132/?__so__=permalink&__cft__[0]=AZYxSXXTlNERnuyG27vSP8tu8GMtj7tPNM8_tnY5_fWMmPbxEE4U68T49c9joldjj5EFm8CCVE2OsaSzGeArS3ICoajUqFjmvS1KOPReVpbdi1MDnb17dY82BMjNXdJdOeUVJMCcCBqwolxjVWCk_0Rx9voaM4GHqLcedKHdYHyhmw)

[Link to profile](https://www.facebook.com/watch/100027924505315/?__cft__[0]=AZYxSXXTlNERnuyG27vSP8tu8GMtj7tPNM8_tnY5_fWMmPbxEE4U68T49c9joldjj5EFm8CCVE2OsaSzGeArS3ICoajUqFjmvS1KOPReVpbdi1MDnb17dY82BMjNXdJdOeUVJMCcCBqwolxjVWCk_0Rx9voaM4GHqLcedKHdYHyhmw)

[Intern thoughts: We put our own spin on the viral "Of Course" trend, showcasing what it’s like to be an intern at Toshiba Global Commerce Solutions! From content creation to business development, each of us brings something unique to the team—because, of course, that’s what interns do best. Watch as we highlight our different roles and a little bit of that intern magic that keeps things running smoothly.\\
\\
Pro tip: We're hiring for summer 2025 interns. Get all the details on https://careers.commerce.toshiba.com](https://www.facebook.com/100027924505315/videos/662743313098132/?__so__=permalink&__cft__[0]=AZYxSXXTlNERnuyG27vSP8tu8GMtj7tPNM8_tnY5_fWMmPbxEE4U68T49c9joldjj5EFm8CCVE2OsaSzGeArS3ICoajUqFjmvS1KOPReVpbdi1MDnb17dY82BMjNXdJdOeUVJMCcCBqwolxjVWCk_0Rx9voaM4GHqLcedKHdYHyhmw)

[Toshiba Global Commerce Solutions](https://www.facebook.com/watch/100027924505315/?__cft__[0]=AZYxSXXTlNERnuyG27vSP8tu8GMtj7tPNM8_tnY5_fWMmPbxEE4U68T49c9joldjj5EFm8CCVE2OsaSzGeArS3ICoajUqFjmvS1KOPReVpbdi1MDnb17dY82BMjNXdJdOeUVJMCcCBqwolxjVWCk_0Rx9voaM4GHqLcedKHdYHyhmw&__cft__[1]=AZYxSXXTlNERnuyG27vSP8tu8GMtj7tPNM8_tnY5_fWMmPbxEE4U68T49c9joldjj5EFm8CCVE2OsaSzGeArS3ICoajUqFjmvS1KOPReVpbdi1MDnb17dY82BMjNXdJdOeUVJMCcCBqwolxjVWCk_0Rx9voaM4GHqLcedKHdYHyhmw)

1.3K views

·

3 March 2025

[![Video thumbnail](https://scontent-lga3-2.xx.fbcdn.net/v/t15.5256-10/465095628_994938855769548_2375307021422746036_n.jpg?stp=dst-jpg_s640x640_tt6&_nc_cat=105&ccb=1-7&_nc_sid=d2b52d&_nc_ohc=gwu2pN__fsQQ7kNvwFIgR6I&_nc_oc=AdrNGX32xf7ndRyhle8gw4x1jhgUkTyLEkmpH2AkIYyAoTolmzmXiAF0ACc8sDiV4ng&_nc_zt=23&_nc_ht=scontent-lga3-2.xx&_nc_gid=_gkRJ3My4wND3RSMxtF5Vg&_nc_ss=7b289&oh=00_Af5nFq_GM2HV7w9ewdS27DObszP3l-6dhZNruE8JGySo6A&oe=6A143E9C)\\
\\
1:01](https://www.facebook.com/100027924505315/videos/795208832660942/?__so__=permalink&__cft__[0]=AZZ0Omd-WtZoISnAZv4OVODAr6siJT4C4SV18XOTp_JoBEyZe6OD5A4kr7CLTx0FK4wTlljHFfHBw586jJvTfhavGj8TO35p4zk_2A6zJV6cjKWbxEpnRyxZUJs8MdENoqPWIf9GQrRp8EaVwqd5RzcHxNNt_G6TxNOV5UHlTGXwcQ)

[Link to profile](https://www.facebook.com/watch/100027924505315/?__cft__[0]=AZZ0Omd-WtZoISnAZv4OVODAr6siJT4C4SV18XOTp_JoBEyZe6OD5A4kr7CLTx0FK4wTlljHFfHBw586jJvTfhavGj8TO35p4zk_2A6zJV6cjKWbxEpnRyxZUJs8MdENoqPWIf9GQrRp8EaVwqd5RzcHxNNt_G6TxNOV5UHlTGXwcQ)

[🎃 Happy Halloween! Lookin' good #TeamToshiba \\
👻 Tag your costume and share with your friends.](https://www.facebook.com/100027924505315/videos/795208832660942/?__so__=permalink&__cft__[0]=AZZ0Omd-WtZoISnAZv4OVODAr6siJT4C4SV18XOTp_JoBEyZe6OD5A4kr7CLTx0FK4wTlljHFfHBw586jJvTfhavGj8TO35p4zk_2A6zJV6cjKWbxEpnRyxZUJs8MdENoqPWIf9GQrRp8EaVwqd5RzcHxNNt_G6TxNOV5UHlTGXwcQ)

[Toshiba Global Commerce Solutions](https://www.facebook.com/watch/100027924505315/?__cft__[0]=AZZ0Omd-WtZoISnAZv4OVODAr6siJT4C4SV18XOTp_JoBEyZe6OD5A4kr7CLTx0FK4wTlljHFfHBw586jJvTfhavGj8TO35p4zk_2A6zJV6cjKWbxEpnRyxZUJs8MdENoqPWIf9GQrRp8EaVwqd5RzcHxNNt_G6TxNOV5UHlTGXwcQ&__cft__[1]=AZZ0Omd-WtZoISnAZv4OVODAr6siJT4C4SV18XOTp_JoBEyZe6OD5A4kr7CLTx0FK4wTlljHFfHBw586jJvTfhavGj8TO35p4zk_2A6zJV6cjKWbxEpnRyxZUJs8MdENoqPWIf9GQrRp8EaVwqd5RzcHxNNt_G6TxNOV5UHlTGXwcQ)

743 views

·

30 October 2024

[![Video thumbnail](https://scontent-lga3-1.xx.fbcdn.net/v/t15.5256-10/464986695_849320067066592_5480474040699144726_n.jpg?stp=dst-jpg_p206x206_tt6&_nc_cat=103&ccb=1-7&_nc_sid=d2b52d&_nc_ohc=ny72i4WsrfgQ7kNvwHyg7xF&_nc_oc=Adrka6xdj1tyDYzXy2mJUXIu9Atdy0fiFCdJgLHZjCpuPM7Okm78NLFmzdB8K37E2s8&_nc_zt=23&_nc_ht=scontent-lga3-1.xx&_nc_gid=Dsxt2lnEjb1IjfgqLb0a4w&_nc_ss=7b289&oh=00_Af563pWD88K8Z5Z6ekfwOCA-WVdiKr7pTjBhcfEHnWcRdw&oe=6A142E5A)\\
\\
0:56](https://www.facebook.com/100027924505315/videos/568152899052879/?__so__=permalink&__cft__[0]=AZaZkWrBeCnO9XGR3gGrOJVQ0JcXmbr9Q5_Y1YVPlDmrLqN6nQ37FE1E5avG_RuwqHBTSA9peUqJkq86A6cC_-U_Tx0xgZgNu_5VUgmAXp_kjO0lIa7XYlJh-dTcTdOP1y_LaEJkEBW-Ju6KtEpCuQaLwLDWp9RYxk8HzSA3pguTrQ)

[Link to profile](https://www.facebook.com/watch/100027924505315/?__cft__[0]=AZaZkWrBeCnO9XGR3gGrOJVQ0JcXmbr9Q5_Y1YVPlDmrLqN6nQ37FE1E5avG_RuwqHBTSA9peUqJkq86A6cC_-U_Tx0xgZgNu_5VUgmAXp_kjO0lIa7XYlJh-dTcTdOP1y_LaEJkEBW-Ju6KtEpCuQaLwLDWp9RYxk8HzSA3pguTrQ)

[Never a dull day around HQ. Thank you to our amazing interns Joey and Kayla for the office reviews. 🤣 \\
\\
BTW, spring internship applications are LIVE at https://careers.commerce.toshiba.com/en/openings/internship](https://www.facebook.com/100027924505315/videos/568152899052879/?__so__=permalink&__cft__[0]=AZaZkWrBeCnO9XGR3gGrOJVQ0JcXmbr9Q5_Y1YVPlDmrLqN6nQ37FE1E5avG_RuwqHBTSA9peUqJkq86A6cC_-U_Tx0xgZgNu_5VUgmAXp_kjO0lIa7XYlJh-dTcTdOP1y_LaEJkEBW-Ju6KtEpCuQaLwLDWp9RYxk8HzSA3pguTrQ)

[Toshiba Global Commerce Solutions](https://www.facebook.com/watch/100027924505315/?__cft__[0]=AZaZkWrBeCnO9XGR3gGrOJVQ0JcXmbr9Q5_Y1YVPlDmrLqN6nQ37FE1E5avG_RuwqHBTSA9peUqJkq86A6cC_-U_Tx0xgZgNu_5VUgmAXp_kjO0lIa7XYlJh-dTcTdOP1y_LaEJkEBW-Ju6KtEpCuQaLwLDWp9RYxk8HzSA3pguTrQ&__cft__[1]=AZaZkWrBeCnO9XGR3gGrOJVQ0JcXmbr9Q5_Y1YVPlDmrLqN6nQ37FE1E5avG_RuwqHBTSA9peUqJkq86A6cC_-U_Tx0xgZgNu_5VUgmAXp_kjO0lIa7XYlJh-dTcTdOP1y_LaEJkEBW-Ju6KtEpCuQaLwLDWp9RYxk8HzSA3pguTrQ)

821 views

·

28 October 2024

[![Video thumbnail](https://scontent-lga3-3.xx.fbcdn.net/v/t39.30808-10/457100476_18279081121230509_6232171245304065366_n.jpg?stp=dst-jpg_p206x206_tt6&_nc_cat=104&ccb=1-7&_nc_sid=3e895a&_nc_ohc=u4GWvWOt_bgQ7kNvwESyZIU&_nc_oc=Adr7QJnUdkp7Da21ji9nmvVhTZrChkySlB6YidizFS8s3MmPcrpq3z3_LYeE5dmaRv0&_nc_zt=23&_nc_ht=scontent-lga3-3.xx&_nc_gid=Dsxt2lnEjb1IjfgqLb0a4w&_nc_ss=7b289&oh=00_Af7xaCPikPnLqqP8P-xBoItTFpGopXAi1VTV2ZbMsLC16w&oe=6A141A1E)\\
\\
0:31](https://www.facebook.com/100027924505315/videos/369740756230255/?__so__=permalink&__cft__[0]=AZZr-A8V-tP_3yAAztIATvCK-PQHJQs-VrUJULZ5GOfSzVbht2m4fpBVfukQo0n9yO4-mlPfiKocZt-GBwftHYk2cII7IlL-S-bus9D7YmVoxz_qqr8P40SJqByPF8JTWfNt8YCW8rIomkWNS-btS4OmaXayEqEcDt1NVoE4Is84yA)

[Link to profile](https://www.facebook.com/watch/100027924505315/?__cft__[0]=AZZr-A8V-tP_3yAAztIATvCK-PQHJQs-VrUJULZ5GOfSzVbht2m4fpBVfukQo0n9yO4-mlPfiKocZt-GBwftHYk2cII7IlL-S-bus9D7YmVoxz_qqr8P40SJqByPF8JTWfNt8YCW8rIomkWNS-btS4OmaXayEqEcDt1NVoE4Is84yA)

[🍦🎉 We treated HQ employees to something sweet. Thank you to our Activities and Outreach Committee for the delicious @tworoosters and @jeremiahsice #TeamToshiba](https://www.facebook.com/100027924505315/videos/369740756230255/?__so__=permalink&__cft__[0]=AZZr-A8V-tP_3yAAztIATvCK-PQHJQs-VrUJULZ5GOfSzVbht2m4fpBVfukQo0n9yO4-mlPfiKocZt-GBwftHYk2cII7IlL-S-bus9D7YmVoxz_qqr8P40SJqByPF8JTWfNt8YCW8rIomkWNS-btS4OmaXayEqEcDt1NVoE4Is84yA)

[Toshiba Global Commerce Solutions](https://www.facebook.com/watch/100027924505315/?__cft__[0]=AZZr-A8V-tP_3yAAztIATvCK-PQHJQs-VrUJULZ5GOfSzVbht2m4fpBVfukQo0n9yO4-mlPfiKocZt-GBwftHYk2cII7IlL-S-bus9D7YmVoxz_qqr8P40SJqByPF8JTWfNt8YCW8rIomkWNS-btS4OmaXayEqEcDt1NVoE4Is84yA&__cft__[1]=AZZr-A8V-tP_3yAAztIATvCK-PQHJQs-VrUJULZ5GOfSzVbht2m4fpBVfukQo0n9yO4-mlPfiKocZt-GBwftHYk2cII7IlL-S-bus9D7YmVoxz_qqr8P40SJqByPF8JTWfNt8YCW8rIomkWNS-btS4OmaXayEqEcDt1NVoE4Is84yA)

963 views

·

29 August 2024

[![Video thumbnail](https://scontent-lga3-2.xx.fbcdn.net/v/t15.5256-10/429296677_919228583232362_3342615967069984493_n.jpg?stp=dst-jpg_s640x640_tt6&_nc_cat=105&ccb=1-7&_nc_sid=d2b52d&_nc_ohc=-aKqfc154m4Q7kNvwFfYNY9&_nc_oc=AdpY-QzRtnTLcwk2_adsV4a_VebFJecox7Wg8P-NdJkczuiCu9JnEsw1u6HHDtqRXiA&_nc_zt=23&_nc_ht=scontent-lga3-2.xx&_nc_gid=Dsxt2lnEjb1IjfgqLb0a4w&_nc_ss=7b289&oh=00_Af77hib0S5gNicBG98HVctVakPzRemDL4OnjE4kVFy_nIQ&oe=6A142B82)\\
\\
0:10](https://www.facebook.com/100027924505315/videos/819638796640213/?__so__=permalink&__cft__[0]=AZbcvq3THPlPM3_yjlX3Iicks9kte4rIXOfLnC4WdcF4iCGIz4TZxrzifI0xxDQq7x8OxkFPIi8kcK7KSLgOWiiJ_HYp-fFlhYCov2OO81Ydcxo963kwXmco4UeNnsl_MkOB3IqNdZFhGY7ibSyPGIy-mnsDHthSaUUHGJX4q0QNcQ)

[Link to profile](https://www.facebook.com/watch/100027924505315/?__cft__[0]=AZbcvq3THPlPM3_yjlX3Iicks9kte4rIXOfLnC4WdcF4iCGIz4TZxrzifI0xxDQq7x8OxkFPIi8kcK7KSLgOWiiJ_HYp-fFlhYCov2OO81Ydcxo963kwXmco4UeNnsl_MkOB3IqNdZFhGY7ibSyPGIy-mnsDHthSaUUHGJX4q0QNcQ)

[ELERA® Self Service empowers retailers to self-enable and self-innovate at their own pace allowing them to speed up the customer checkout process and improve front-end efficiency. \\
\\
Learn more and download our datasheet: https://bit.ly/40m7iSz](https://www.facebook.com/100027924505315/videos/819638796640213/?__so__=permalink&__cft__[0]=AZbcvq3THPlPM3_yjlX3Iicks9kte4rIXOfLnC4WdcF4iCGIz4TZxrzifI0xxDQq7x8OxkFPIi8kcK7KSLgOWiiJ_HYp-fFlhYCov2OO81Ydcxo963kwXmco4UeNnsl_MkOB3IqNdZFhGY7ibSyPGIy-mnsDHthSaUUHGJX4q0QNcQ)

[Toshiba Global Commerce Solutions](https://www.facebook.com/watch/100027924505315/?__cft__[0]=AZbcvq3THPlPM3_yjlX3Iicks9kte4rIXOfLnC4WdcF4iCGIz4TZxrzifI0xxDQq7x8OxkFPIi8kcK7KSLgOWiiJ_HYp-fFlhYCov2OO81Ydcxo963kwXmco4UeNnsl_MkOB3IqNdZFhGY7ibSyPGIy-mnsDHthSaUUHGJX4q0QNcQ&__cft__[1]=AZbcvq3THPlPM3_yjlX3Iicks9kte4rIXOfLnC4WdcF4iCGIz4TZxrzifI0xxDQq7x8OxkFPIi8kcK7KSLgOWiiJ_HYp-fFlhYCov2OO81Ydcxo963kwXmco4UeNnsl_MkOB3IqNdZFhGY7ibSyPGIy-mnsDHthSaUUHGJX4q0QNcQ)

631 views

·

18 March 2024

[![Video thumbnail](https://scontent-lga3-2.xx.fbcdn.net/v/t15.5256-10/428859587_1770474913429250_7632496482296640436_n.jpg?stp=dst-jpg_s640x640_tt6&_nc_cat=101&ccb=1-7&_nc_sid=d2b52d&_nc_ohc=Z7-l8MpDaUAQ7kNvwHKeH7N&_nc_oc=AdrPdpsQUJZGAE4IHVQYxCsc1-HRuMvK_I7uslMfyPR9cIjab_wHdCaRN0e_IDhliZ8&_nc_zt=23&_nc_ht=scontent-lga3-2.xx&_nc_gid=Dsxt2lnEjb1IjfgqLb0a4w&_nc_ss=7b289&oh=00_Af6ee3k-7chzMXEp7QqyTEYim32BcNvjzvlV_3KD1S-4fw&oe=6A1434B4)\\
\\
0:10](https://www.facebook.com/100027924505315/videos/423114580282474/?__so__=permalink&__cft__[0]=AZZVfoxNrXRGAB_Iu-pQmAxsHjq2zp4F2l2nqLnFytbqui57Y2J0ZDgR0PhODlT5SyKLhBaTFRDELVJCGh0f99HO22Fexd5ySHGoEr6vkdPNlVePsf4BMNmYlYpe5yZnaCJwvw0b-tWFpI57YqOlFbw7gpViI0JXtqAI3Rhufavn_w)

[Link to profile](https://www.facebook.com/watch/100027924505315/?__cft__[0]=AZZVfoxNrXRGAB_Iu-pQmAxsHjq2zp4F2l2nqLnFytbqui57Y2J0ZDgR0PhODlT5SyKLhBaTFRDELVJCGh0f99HO22Fexd5ySHGoEr6vkdPNlVePsf4BMNmYlYpe5yZnaCJwvw0b-tWFpI57YqOlFbw7gpViI0JXtqAI3Rhufavn_w)

[ELERA Self Service](https://www.facebook.com/100027924505315/videos/423114580282474/?__so__=permalink&__cft__[0]=AZZVfoxNrXRGAB_Iu-pQmAxsHjq2zp4F2l2nqLnFytbqui57Y2J0ZDgR0PhODlT5SyKLhBaTFRDELVJCGh0f99HO22Fexd5ySHGoEr6vkdPNlVePsf4BMNmYlYpe5yZnaCJwvw0b-tWFpI57YqOlFbw7gpViI0JXtqAI3Rhufavn_w)

[Toshiba Global Commerce Solutions](https://www.facebook.com/watch/100027924505315/?__cft__[0]=AZZVfoxNrXRGAB_Iu-pQmAxsHjq2zp4F2l2nqLnFytbqui57Y2J0ZDgR0PhODlT5SyKLhBaTFRDELVJCGh0f99HO22Fexd5ySHGoEr6vkdPNlVePsf4BMNmYlYpe5yZnaCJwvw0b-tWFpI57YqOlFbw7gpViI0JXtqAI3Rhufavn_w&__cft__[1]=AZZVfoxNrXRGAB_Iu-pQmAxsHjq2zp4F2l2nqLnFytbqui57Y2J0ZDgR0PhODlT5SyKLhBaTFRDELVJCGh0f99HO22Fexd5ySHGoEr6vkdPNlVePsf4BMNmYlYpe5yZnaCJwvw0b-tWFpI57YqOlFbw7gpViI0JXtqAI3Rhufavn_w)

114 views

·

4 March 2024

[Pages](https://www.facebook.com/pages/category/)

[Businesses](https://www.facebook.com/pages/category/all-businesses/)

[Science, technology and engineering](https://www.facebook.com/pages/category/science-engineering/)

[Toshiba Global Commerce Solutions](https://www.facebook.com/ToshibaCommerce/)

[Videos](https://www.facebook.com/ToshibaCommerce/videos/)

[Home](https://www.facebook.com/watch/)

[Live](https://www.facebook.com/watch/live/?ref=watch)

[Explore](https://www.facebook.com/watch/topic/)

Log in or sign up for Facebook to connect with friends, family and people you know.

[Log in](https://www.facebook.com/login/?next=%2FToshibaCommerce%2Fvideos%2Fmeet-elera-loss-prevention-this-integrated-self-checkout-loss-prevention-solutio%2F1505560226889567%2F)

or

[Create new account](https://www.facebook.com/reg/?next=%2FToshibaCommerce%2Fvideos%2Fmeet-elera-loss-prevention-this-integrated-self-checkout-loss-prevention-solutio%2F1505560226889567%2F)