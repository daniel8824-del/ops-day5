<!-- source: https://www.atlassian.com/itsm/change-management/types -->

Get it free

Sign in

Jira Service Management is now more powerful than ever as part of Service Collection. Unlock exceptional service experiences with Rovo, Assets, and our new Customer Service Management app.

[Try it now](https://www.atlassian.com/try/cloud/signup?bundle=service-collection&edition=premium)

# Types of change management for ITSM teams

Change management is an IT practice designed to minimize disruptions to IT services while making changes to critical systems and services. A [change](https://www.atlassian.com/itsm/change-management) is defined as adding, modifying, or removing anything that could have a direct or indirect effect on services.

[Get it free](https://www.atlassian.com/software/jira/service-management/free)

![Types of change visual](https://dam-cdn.atl.orangelogic.com/AssetLink/172vy4452145r3053447p5f7mpl6rro7.png)

## Standard changes

Standard changes are low-risk, commonly repeated, and pre-approved. They’re performed frequently and follow a documented, approved process.

These changes are common and follow a well-defined process. Because that process has already gone through the risk assessment and approval process, it doesn’t need to go through the process again every time there’s another instance of that activity.

These standard changes can be a great candidate for automation, freeing up teams to focus on normal and emergency changes. Some companies even report that as many as 70% of standard changes can be automated.

### Examples of standard changes

- Adding memory or storage

- Replacing a failing router with an identical working router

- Creating a new instance of a database


## Normal changes

Normal changes are non-emergency changes without a defined, pre-approved process.

Some normal changes—like a data center switch—are still high-risk and may require risk assessment and approval from a change advisory board. Others may be low-risk and can be approved quickly by a designated change authority or through automated checks and peer review.

### Examples of normal changes

- Upgrading to a new content management system

- Migrating to a new data center

- Performance improvements


## Emergency changes

These changes arise from an unexpected error or threat and need to be addressed immediately—usually to restore service for customers or employees or secure systems against a threat.

The urgency of emergency changes means they need to be handled on a much tighter timeline because the risk of a lengthy review process is higher than the risks involved with resolving the issue quickly.

How you categorize your changes depends on factors including your organization, processes, and risk tolerance. We advocate dropping the "one size fits all" approach, and treating each change differently based on risk assessment. As your organization learns more about previous incidents, particular systems, and incorporates other relevant data, it should be possible to designate a higher share of changes as standard and pre-approve them. Modern [change management](https://www.atlassian.com/itsm/change-management/best-practices) should make change requests as simple and streamlined as possible.

### Examples of emergency changes

- Implementing a security patch

- Dealing with a server outage

- Resolving a major incident


## How should you categorize changes?

These categories are a useful framework, but we recommend teams use them as guardrails for evolving change practices that meet their own needs. How your team categorizes changes depends on factors including your organization, processes, and risk tolerance. At Atlassian, we advocate for dropping the "one size fits all" approach, and treating each change individually based on risk assessment. As your organization learns more about previous incidents, particular systems, and incorporates other relevant data, it should be possible to designate a higher share of changes as standard and pre-approve them. Modern change management should make change requests as simple and streamlined as possible.

## Better change management with Jira Service Management

[Jira Service Management’s](https://www.atlassian.com/software/jira/service-management) new change management features empower teams with richer contextual information from software development tools so they can make better decisions and minimize risk. You can understand changes and innovate faster with integrations into modern software workflows.

[Learn more](https://www.atlassian.com/software/jira/service-management/features/itsm#change-management)

## Recommended for you

WHITEPAPER

### Atlassian's guide to agile ways of working with ITIL 4

ITIL 4 is here—and it’s more agile than ever. Learn tips to bring agility and collaboration into ITSM with Atlassian.

[Read the whitepaper](https://www.atlassian.com/whitepapers/itil4)

### What Is Knowledge Management?

Knowledge management processes create, curate, share, use, and manage knowledge across an organization and even across industries. Learn more here.

[Read the article](https://www.atlassian.com/itsm/knowledge-management)

### Learn more about ITSM

Find more ITSM guides and resources in this hub.

[Read this article](https://www.atlassian.com/itsm)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**