<!-- source: https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/software/iot-suite/elera-security-suite -->

![logo](https://commerce.toshiba.com/wps/portal/marketing/iot-suite/elera-security-suite/!ut/p/z1/tVRNc5swFPwtPXCU9ZAwlnvDTOIkrgdwgz-4eGQiQCkgB-QQ99dXSTrtJHWbaVN00de-fTs78xYneI2Tmt_LnGupal6a-yZxt7Ox410wH8JpQIYQzR0Sj5YRndoEL3GCk30qb_CGZMMsszlFIzLmyOEjini644i4trghQ3fnCnhEp7Xe6wJvRI0OrQWFqoQFrcp0xxtzkkqj9iC1OYpSNBy1Ij00Uh-fX_HqLUmJ-YbfLA9MffIE-ckQej5EbjwN2aVPnaX7HfC6crIgEwpgGp4EvGiyMSJH28uxTWA2gyCYndsQnQWLEGIaXoONV_dSdDiuVVMZmz__pYsXb3ag7-zwZ_op9EtP-qW3-6Xv13vWr_fsP3vPriYORHFw7sOEETMd76S_ejW8v4y_iSzSzP15bmi5LpCsM4XXP1IFr0-miqmSt3d3iWfySdVaPGgD_LeAMgrzUu2e09Ord5QZKY3IRCOawaExz4XW-_ajBRZ0XTfIlcpLMUhVZcGpkkK1RsxLJN5XFaNH9GXBuuusyKvt_IwOT27l7ZF-_SRW3odvQaq1iA!!/images/logo.png)X

Sign in to your Toshiba account

For optimum experience,
please log in on your desktop computer

UserName

Password

Sign In [Forgot password?](https://www.toshibacommerce.com/tgcs109/tsim/forgotpassword.do) [Enterprise Login](https://www.toshibacommerce.com/mga/sps/authsvc?PolicyId=urn:ibm:security:authentication:asf:externalIDPLogin&target=https%3A%2F%2Ftoshibacommerce.com%2Fwps%2Fmyportal)

Don't have an ID? [Request one here](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/faqs)

{"Z7\_I9120KK0OOKF10QEORP0U3PT01":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OOKF10QEORP0U3PT03":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OOKF10QEORP0U3PTG0":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OOKF10QEORP0U3PTG2":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OOKF10QEORP0U3PTG1":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OOKF10QEORP0U3PTG3":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OOKF10QEORP0U3PT80":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OOKF10QEORP0U3PT82":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8JB40QUOFC0B82000":{"windowState":"normal","portletMode":"view"}}

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

IOT Suite

# ELERA® Security Suite

ELERA® Security Suite is an end-to-end edge computing solution that helps retailers analyze customer behavior to improve checkout experiences, provide actionable insights to mitigate risks, improve customer throughput, while reducing shrink

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/acd634be-b540-424f-900f-9fea0877d229/g_herosecuirty-suite.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_GAAC1A02N8ABE0AVD86G7Q0421-acd634be-b540-424f-900f-9fea0877d229-pOhu6UA)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/cdc36357-3e3f-44fd-b3b4-7f47c3813498/g_yellow-loss-protection.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_GAAC1A02N8ABE0AVD86G7Q0421-cdc36357-3e3f-44fd-b3b4-7f47c3813498-oNwc8rO)

### ELERA® Loss Prevention

The ELERA® Loss Prevention solution is an integrated self-checkout loss prevention solution that uses TCx® EDGEcam cameras mounted on SCO hardware and reduces the need for the store associates to monitor shopper behavior – freeing associates to help more customers while reducing shrink at SCO lanes.

[ELERA® Loss Prevention](https://commerce.toshiba.com/wps/portal/marketing/iot-suite/elera-security-suite/!ut/p/z1/tVRNc5swFPwtPXCU9ZAwlnvDTOIkrgdwgz-4eGQiQCkgB-QQ99dXSTrtJHWbaVN00de-fTs78xYneI2Tmt_LnGupal6a-yZxt7Ox410wH8JpQIYQzR0Sj5YRndoEL3GCk30qb_CGZMMsszlFIzLmyOEjini644i4trghQ3fnCnhEp7Xe6wJvRI0OrQWFqoQFrcp0xxtzkkqj9iC1OYpSNBy1Ij00Uh-fX_HqLUmJ-YbfLA9MffIE-ckQej5EbjwN2aVPnaX7HfC6crIgEwpgGp4EvGiyMSJH28uxTWA2gyCYndsQnQWLEGIaXoONV_dSdDiuVVMZmz__pYsXb3ag7-zwZ_op9EtP-qW3-6Xv13vWr_fsP3vPriYORHFw7sOEETMd76S_ejW8v4y_iSzSzP15bmi5LpCsM4XXP1IFr0-miqmSt3d3iWfySdVaPGgD_LeAMgrzUu2e09Ord5QZKY3IRCOawaExz4XW-_ajBRZ0XTfIlcpLMUhVZcGpkkK1RsxLJN5XFaNH9GXBuuusyKvt_IwOT27l7ZF-_SRW3odvQaq1iA!!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fsoftware%2Fiot-suite%2Floss-prevention)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/9217cebb-39af-423d-857c-ddc75608a65f/g_teal-produce-recog.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_GAAC1A02N8ABE0AVD86G7Q0421-9217cebb-39af-423d-857c-ddc75608a65f-oNwcaoc)

### ELERA® Produce Recognition

The ELERA® Produce Recognition solution uses artificial intelligence (A.I.) to increase scanning accuracy and reduce the need for manual input of codes and intervention – making checkout a faster, friendlier, and smarter experience for customers.

[ELERA® Produce Recognition](https://commerce.toshiba.com/wps/portal/marketing/iot-suite/elera-security-suite/!ut/p/z1/tVRNc5swFPwtPXCU9ZAwlnvDTOIkrgdwgz-4eGQiQCkgB-QQ99dXSTrtJHWbaVN00de-fTs78xYneI2Tmt_LnGupal6a-yZxt7Ox410wH8JpQIYQzR0Sj5YRndoEL3GCk30qb_CGZMMsszlFIzLmyOEjini644i4trghQ3fnCnhEp7Xe6wJvRI0OrQWFqoQFrcp0xxtzkkqj9iC1OYpSNBy1Ij00Uh-fX_HqLUmJ-YbfLA9MffIE-ckQej5EbjwN2aVPnaX7HfC6crIgEwpgGp4EvGiyMSJH28uxTWA2gyCYndsQnQWLEGIaXoONV_dSdDiuVVMZmz__pYsXb3ag7-zwZ_op9EtP-qW3-6Xv13vWr_fsP3vPriYORHFw7sOEETMd76S_ejW8v4y_iSzSzP15bmi5LpCsM4XXP1IFr0-miqmSt3d3iWfySdVaPGgD_LeAMgrzUu2e09Ord5QZKY3IRCOawaExz4XW-_ajBRZ0XTfIlcpLMUhVZcGpkkK1RsxLJN5XFaNH9GXBuuusyKvt_IwOT27l7ZF-_SRW3odvQaq1iA!!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fsoftware%2Fiot-suite%2Fproduce-recognition)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/aa2d65a8-6590-4e5d-ac61-6b42306e1c01/g_purple-ai-camera.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_GAAC1A02N8ABE0AVD86G7Q0421-aa2d65a8-6590-4e5d-ac61-6b42306e1c01-oNwcdzr)

### Advanced A.I. Camera

Computer Vision cameras powered by the Qualcomm® QRB5165 System-on-Chip (SoC) are some of the best A.I. edge processing platforms on the market. The system uses the TCx® EDGEcam+ and multiple sensors to monitor customer behavior – without servers or processing lag – in real-time, adding enhanced security throughout the checkout area. The versatility of the TCx EDGEcam+ technology gives retailers the resources they need to enhance profit protection and improve the shopping experience.

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

Start a conversation

First name

Last name

Email

Company

Country

Phone

I am a

Business PartnerOtherPress / AnalystRetailerSupplierToshiba Employee

- Business Partner

- Other

- Press / Analyst

- Retailer

- Supplier

- Toshiba Employee


My Retail Segment

Fashion & ApparelFood ServiceGas & ConvenienceGroceryMass MerchandiseOtherPharmacy / Drug StoreSpecialty

- Fashion & Apparel

- Food Service

- Gas & Convenience

- Grocery

- Mass Merchandise

- Other

- Pharmacy / Drug Store

- Specialty


I am interested in learning more about

Add me to Toshiba Global Commerce Solutions' email marketing list

I am allowing Toshiba to contact me in regards to the information on this form

Comments

By submitting this form I agree that Toshiba Global Commerce Solutions, Inc. and its affiliates, including all subsidiaries and branches, may process my data as indicated above and as described in the [Toshiba Global Commerce Solutions Privacy Declaration.](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/common-content/general-content/privacy-policy&mapping=tgcs_new.portal.generaldetails)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**

reCAPTCHA is changing its terms of service. [Take action.](https://google.com/recaptcha/admin/migrate)

![success](https://commerce.toshiba.com/wps/portal/marketing/iot-suite/elera-security-suite/!ut/p/z1/tVRNc5swFPwtPXCU9ZAwlnvDTOIkrgdwgz-4eGQiQCkgB-QQ99dXSTrtJHWbaVN00de-fTs78xYneI2Tmt_LnGupal6a-yZxt7Ox410wH8JpQIYQzR0Sj5YRndoEL3GCk30qb_CGZMMsszlFIzLmyOEjini644i4trghQ3fnCnhEp7Xe6wJvRI0OrQWFqoQFrcp0xxtzkkqj9iC1OYpSNBy1Ij00Uh-fX_HqLUmJ-YbfLA9MffIE-ckQej5EbjwN2aVPnaX7HfC6crIgEwpgGp4EvGiyMSJH28uxTWA2gyCYndsQnQWLEGIaXoONV_dSdDiuVVMZmz__pYsXb3ag7-zwZ_op9EtP-qW3-6Xv13vWr_fsP3vPriYORHFw7sOEETMd76S_ejW8v4y_iSzSzP15bmi5LpCsM4XXP1IFr0-miqmSt3d3iWfySdVaPGgD_LeAMgrzUu2e09Ord5QZKY3IRCOawaExz4XW-_ajBRZ0XTfIlcpLMUhVZcGpkkK1RsxLJN5XFaNH9GXBuuusyKvt_IwOT27l7ZF-_SRW3odvQaq1iA!!/images/tgcs/success.svg)

## Success!

Thank you for reaching out. One of our team members will be in contact soon. We hope you have a great day.

Close

Complementary
Content [Deferred Modules](https://commerce.toshiba.com/wps/contenthandler/marketing/!ut/p/digest!M6zrA0PEiotCbddBEGnoVg/mashup/ra:collection?themeID=ZJ_JQGEHK01N0LM806KGPAKPA0UO0&locale=en&mime-type=text%2Fjavascript&lm=1778793196000&entry=st_skin__0.0%3Aconfig_js&entry=wp_liveobject_framework_core__0.0%3Aconfig_js&entry=wp_portal_ui_utils__0.0%3Aconfig_js&entry=wp_contextmenu_js__0.0%3Aconfig_js&entry=wp_skin_cam__0.0%3Aconfig_js&entry=wp_contextmenu_config_lof__0.0%3Aconfig_js&entry=wp_federated_documents_picker__0.0%3Aconfig_js&entry=wp_dnd_main__0.0%3Aconfig_js&entry=wp_movecontrols__0.0%3Aconfig_js&entry=wp_toolbar_controlactions__0.0%3Aconfig_js&entry=wp_content_targeting_cam__0.0%3Aconfig_js&deferred=true)

- ${title}${badge}

${loading}

[Deferred Modules](https://commerce.toshiba.com/wps/contenthandler/marketing/!ut/p/digest!SpZvrtUURDcRHYzcbiqg-Q/mashup/ra:collection?themeID=ZJ_JQGEHK01N0LM806KGPAKPA0UO0&locale=en&mime-type=text%2Fplain&entry=wp_contextmenu_templates__0.0%3Aconfig_markup&entry=wp_skin_cam__0.0%3Aconfig_markup&entry=wp_dnd_main__0.0%3Aconfig_markup&deferred=true)

reCAPTCHA