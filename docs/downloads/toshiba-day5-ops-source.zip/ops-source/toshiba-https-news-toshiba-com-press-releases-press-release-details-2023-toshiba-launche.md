<!-- source: https://news.toshiba.com/press-releases/press-release-details/2023/Toshiba-Launches-New-ELERASecurity-Suite-to-Address-the-Industrys-Challenges-Around-Shrink/default.aspx -->

[Skip to main content](https://news.toshiba.com/press-releases/press-release-details/2023/Toshiba-Launches-New-ELERASecurity-Suite-to-Address-the-Industrys-Challenges-Around-Shrink/default.aspx#maincontent)

[![Toshiba Logo](https://s25.q4cdn.com/239686007/files/design/logos/logo_toshiba.gif)Link to company website](http://www.toshiba.com/tai/)![United States](https://s25.q4cdn.com/239686007/files/design/logos/site_id_us.gif)

- [Americas](http://www.toshiba.com/tai/americas/index.jsp)
- [Worldwide](http://www.toshiba.co.jp/worldwide/index.html)

- [Americas](http://www.toshiba.com/tai/americas/index.jsp)
- [Worldwide](http://www.toshiba.co.jp/worldwide/index.html)

Close

## Site Search

_Newsroom Menu_

# Press Release Details

_Newsroom Menu_

[View all news](https://news.toshiba.com/press-releases/default.aspx)

### Toshiba Launches New ELERA™Security Suite to Address the Industry’s Challenges Around Shrink

09/12/2023

Download this Press ReleasePDF Format (opens in new window)

_Toshiba’s A.I.-powered solution empowers retailers across the globe to better manage loss prevention and protect profits_

RESEARCH TRIANGLE PARK, N.C.--(BUSINESS WIRE)--
The new [ELERA](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fcommerce.toshiba.com%2Fwps%2Fportal%2Fmarketing%2F%3Furile%3Dwcm%3Apath%3A%2Fen-us%2Fhome%2Fsoftware%2Fcommerce-platforms%2Felera&esheet=53551293&newsitemid=20230912900113&lan=en-US&anchor=ELERA&index=1&md5=1c0787db30db451e18f6323901e430f1) ™ Security Suite from [Toshiba Global Commerce Solutions](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fcommerce.toshiba.com%2Fwps%2Fportal%2Fmarketing%2F%3Furile%3Dwcm%3Apath%3A%2Fen-us%2Fhome&esheet=53551293&newsitemid=20230912900113&lan=en-US&anchor=Toshiba+Global+Commerce+Solutions&index=2&md5=87ab6a14839e32f8c77878fed640e211) empowers retailers to minimize shrink while providing consumers with enhanced checkout experiences and reduced friction. According to the latest data from the National Retail Federation, retail shrink accounted for [$94.5 billion in losses in 2021](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fnrf.com%2Fmedia-center%2Fpress-releases%2Fnrf-reports-retail-shrink-nearly-100b-problem%23%3A%7E%3Atext%3DWASHINGTON%2520%25E2%2580%2593%2520Retail%2520shrink%252C%2520when%2520taken%2Cby%2520the%2520National%2520Retail%2520Federation.&esheet=53551293&newsitemid=20230912900113&lan=en-US&anchor=%2494.5+billion+in+losses+in+2021&index=3&md5=11ec2f0d285e4100724b0b678d28daf5) in the U.S. and continues to be a critical challenge for retailers. Available later this year, the ELERA™ Security Suite offers retailers a comprehensive solution to protect their bottom line and combat multiple forms of shrink.

![The A.I.-powered ELERA™ Security Suite offers retailers a comprehensive solution to minimize shrink while providing consumers with enhanced checkout experiences. (Photo: Business Wire)](https://mms.businesswire.com/media/20230912900113/en/1885220/4/Produce_Recognition_-_Scanning.jpg)

The A.I.-powered ELERA™ Security Suite offers retailers a comprehensive solution to minimize shrink while providing consumers with enhanced checkout experiences. (Photo: Business Wire)

“In a world where every second and every cent counts, ELERA™ Security Suite is not just a tool but a strategy—turning data into decisions and losses into profits,” said Yevgeni Tsirulnik, SVP of Innovation and Incubation at Toshiba Global Commerce Solutions. “As global leaders in retail solutions, our Toshiba team and partners came together to envision and develop the A.I.-powered ELERA™ Security Suite to enhance their loss prevention measures that have a direct and positive impact on retailer profits while also improving the shopper experience.”

The ELERA™ Security Suite end-to-end solution deployed as-a-service through Toshiba’s IoT platform, fully orchestrates computer vision cameras with advanced edge A.I., to enhance profit protections and shopper experiences through:

- **Monitoring consumer behavior in real-time** – without servers or processing lag – via TCx® EDGEcam+ and multiple sensors, which adds enhanced security throughout the checkout area

- **Responding to incidents as they occur** for more impactful and timely resolutions with leading A.I.-powered computer vision

- **Notifying shoppers of potential errors** through proactive alerts and allowing them to correct the issue themselves – minimizing employee intervention and improving the checkout experience

- **Differentiating customer’s items vs. store items they’re purchasing**, improving recognition accuracy, and reducing incorrect warnings


The modular ELERA™ Security Suite system empowers retailers with versatility and opportunities to leverage the latest technology to meet their business needs. The ELERA™ Security Suite can be part of the overall ELERA™ solution, or it can be attached to other Toshiba or third-party POS systems.

“We are excited to expand our collaboration with Toshiba Global Commerce Solutions by integrating the [Qualcomm®](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fwww.qualcomm.com%2F&esheet=53551293&newsitemid=20230912900113&lan=en-US&anchor=Qualcomm%26%23174%3B&index=4&md5=3bf3378c80bfc394a508aee5ac0f326b) QRB5165 System-on-Chip (SoC) for IoT into Toshiba’s TCx EDGEcam+ to provide one of the best A.I. edge processing platforms in the market,” stated Art Miller, Vice President, Business Development and Head of Retail and Payments, Qualcomm Technologies, Inc. “Qualcomm QRB5165 SoC brings distributed A.I. and compute capabilities to the edge eliminating the need for expensive and power-intensive servers in the back of the store.”

This A.I.-driven solution presents benefits to both retailers and consumers across multiple touchpoints. ELERA™ Security Suite expands on the previously available [ELERA™ Produce Recognition](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fcommerce.toshiba.com%2Fwps%2Fportal%2Fmarketing%2F%3Furile%3Dwcm%3Apath%3A%2Fen-us%2Fhome%2Fsoftware%2Felera-solutions%2Fproduce-recognition&esheet=53551293&newsitemid=20230912900113&lan=en-US&anchor=ELERA%26%238482%3B+Produce+Recognition&index=5&md5=8e774cb0405451f3525525ce2224c889) that leverages A.I. and computer vision to accurately and efficiently identify produce and eliminate the need to input produce codes at checkout manually. Retailers are already benefiting from the produce recognition innovation through improved inventory accuracy and throughput in the self-service experience enabling a more seamless checkout and positive consumer experience. Based on recent retailer data, Toshiba has found that shoppers save as much as [five seconds per produce item](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fwww.youtube.com%2Fwatch%3Fv%3DBC_Q9zKRLNw&esheet=53551293&newsitemid=20230912900113&lan=en-US&anchor=five+seconds+per+produce+item&index=6&md5=9af6a11b40b6e06e178d49e173b0d1db) lookup during checkout.

Retailers that invest in the ELERA™ Security Suite can see strong returns on their investment in this new technology suite through increased inventory accuracy, decreased store staff intervention, and increased adoption of their self-checkout lanes. Given Toshiba’s focus on retailers and consumer privacy, we also offer peace of mind by meeting the requirements of applicable data privacy laws, including all federal, state, regional, territorial, national, and local laws, regulations, and rules by any government agency or authority that relate to the processing or the security of personal data.

Toshiba experts will be at [GroceryShop 2023](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fgroceryshop.com%2F&esheet=53551293&newsitemid=20230912900113&lan=en-US&anchor=GroceryShop+2023&index=7&md5=759faf917930b318bc30d137383aef48) in Las Vegas from September 19-21 to showcase the ELERA™ Security Suite and a portfolio of other retail solutions that enable retailers to re-imagine, accelerate, and differentiate their shopping experiences ( [booth #1050](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fcommerce.toshiba.com%2Fwps%2Fportal%2Fmarketing%3Furile%3Dwcm%3Apath%253A%252Fen-us%252Fhome%252Fcompany%252Fevents%252Fgrocery-shop-2023%26mapping%3Dtgcs_new.portal.company.eventdetails&esheet=53551293&newsitemid=20230912900113&lan=en-US&anchor=booth+%231050&index=8&md5=96ef844668fbabd16eb9f965227321f6)).

**About Toshiba Global Commerce Solutions**

Toshiba Global Commerce Solutions empowers retail to thrive and prosper through a dynamic ecosystem of smarter, more agile solutions and services that enable retailers to resiliently evolve with generations of consumers and adapt to market conditions. Supported by a global organization of devoted employees and partners, retailers gain more visibility and control over operations while enjoying the flexibility to build, scale, and transform retail experiences that anticipate and fulfill consumers’ ever-changing needs. Visit [commerce.toshiba.com](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fcommerce.toshiba.com%2F&esheet=53551293&newsitemid=20230912900113&lan=en-US&anchor=commerce.toshiba.com&index=9&md5=55c7b3cda3512eee39d065b77740a73d) and engage with us on [X, formerly known as Twitter](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Ftwitter.com%2FToshibaCommerce&esheet=53551293&newsitemid=20230912900113&lan=en-US&anchor=X%2C+formerly+known+as+Twitter&index=10&md5=22413c9e72fab621f5d714d6ada8eaaf), [Facebook](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fwww.facebook.com%2FToshibaCommerce%2F&esheet=53551293&newsitemid=20230912900113&lan=en-US&anchor=Facebook&index=11&md5=40ebc5ab4e85aedb8379b1b0f85d5060), [LinkedIn](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fwww.linkedin.com%2Fcompany%2Ftoshibacommerce&esheet=53551293&newsitemid=20230912900113&lan=en-US&anchor=LinkedIn&index=12&md5=6d1f7d8bfb792e7a85cf81e915a77e51), [Instagram](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fwww.instagram.com%2Ftoshibacommerce%2F&esheet=53551293&newsitemid=20230912900113&lan=en-US&anchor=Instagram&index=13&md5=bf851e9983477eabb1d0540a4277607b), and [YouTube](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fwww.youtube.com%2Ftoshibacommerce&esheet=53551293&newsitemid=20230912900113&lan=en-US&anchor=YouTube&index=14&md5=ee2cea430a0d6566ddadc4a42d6b3dbb), to learn more.

_Toshiba Global Commerce Solutions is a wholly owned subsidiary of Toshiba Tec Corporation, which is traded on the Tokyo Stock Exchange._

**Qualcomm**

_Qualcomm is a trademark or registered trademark of Qualcomm incorporated. Qualcomm branded products are products of Qualcomm Technologies, Inc. and/or its subsidiaries. Qualcomm patented technologies are licensed by Qualcomm Incorporated._

![](https://cts.businesswire.com/ct/CT?id=bwnews&sty=20230912900113r1&sid=q4-prod&distro=nx&lang=en)

Toshiba Global Commerce Solutions

Elizabeth Romero

Director, Corporate Communications

[elizabeth.romero@toshibagcs.com](mailto:elizabeth.romero@toshibagcs.com)

Source: Toshiba

**Multimedia Files:**

[![](https://s25.q4cdn.com/239686007/files/doc_multimedia/Produce_Recognition_-_Scanning@thumbnail.png)](https://s25.q4cdn.com/239686007/files/doc_multimedia/Produce_Recognition_-_Scanning.jpg)

The A.I.-powered ELERA™ Security Suite offers retailers a comprehensive solution to minimize shrink while providing consumers with enhanced checkout experiences. (Photo: Business Wire)1920 x 1080jpg865 KB

Download:

[Download originaljpg865 KB1920 x 1080](https://s25.q4cdn.com/239686007/files/doc_multimedia/Produce_Recognition_-_Scanning.jpg)

[Download thumbnailpng52 KB200 x 113](https://s25.q4cdn.com/239686007/files/doc_multimedia/Produce_Recognition_-_Scanning@thumbnail.png)

[Download lowrespng239 KB480 x 270](https://s25.q4cdn.com/239686007/files/doc_multimedia/Produce_Recognition_-_Scanning@lowres.png)

[Download squarepng122 KB250 x 250](https://s25.q4cdn.com/239686007/files/doc_multimedia/Produce_Recognition_-_Scanning@square.png)

[![](https://s25.q4cdn.com/239686007/files/doc_multimedia/Toshiba_RGB@thumbnail.png)](https://s25.q4cdn.com/239686007/files/doc_multimedia/Toshiba_RGB.jpg)

1182 x 181jpg54 KB

Download:

[Download originaljpg54 KB1182 x 181](https://s25.q4cdn.com/239686007/files/doc_multimedia/Toshiba_RGB.jpg)

[Download thumbnailpng5 KB200 x 31](https://s25.q4cdn.com/239686007/files/doc_multimedia/Toshiba_RGB@thumbnail.png)

[Download lowrespng17 KB480 x 74](https://s25.q4cdn.com/239686007/files/doc_multimedia/Toshiba_RGB@lowres.png)

[Download squarepng8 KB250 x 250](https://s25.q4cdn.com/239686007/files/doc_multimedia/Toshiba_RGB@square.png)

[View all news](https://news.toshiba.com/press-releases/default.aspx)

## Media Contact

For media and press inquiries please email us at:

[TAI-MediaInquiries@toshiba.com](mailto:TAI-MediaInquiries@toshiba.com)

## Newsroom Alerts

To opt-in for email alerts, please enter your email address in the field below and select at least one alert option. After submitting your request, you will receive an activation email to the requested email address. You must click the activation link in order to complete your subscription. You can sign up for additional alert options at any time.

At Toshiba, we promise to treat your data with respect and will not share your information with any third party. You can unsubscribe to any of the email alerts you are subscribed to by visiting the ‘unsubscribe’ section below. If you experience any issues with this process, please contact us for further assistance.

**By providing your email address below, you are providing consent to Toshiba to send you the requested Email Alert updates.**

\\* Required

|     |
| --- |
| Email Address\* |

|     |
| --- |
| Email Alert Options\* |
| |     |
| --- |
| Press Release |
| Presentations |
| Blog | |

|     |
| --- |
|  |
| ![Captcha](https://news.toshiba.com/q4api/v4/captcha?clientId=_ctrl0_ctl45_UCCaptcha) |
| **Enter the code shown above.** |
| \* |

Submit

Sign Up

[Unsubscribe](https://news.toshiba.com/email-alerts/default.aspx)

## Email Alert Sign Up Confirmation

- [Site Map](https://news.toshiba.com/site-map/default.aspx)
- [Terms of Use](http://www.toshiba.com/tai/terms.jsp)
- [Privacy Policy](http://www.toshiba.com/tai/privacy_policy.jsp)

© 2026 Toshiba All Rights Reserved.


[Powered By Q4 Inc.5.179.1.3(opens in new window)](https://www.q4inc.com/Powered-by-Q4/)

×

This website collects your IP address and uses cookies to deliver you content, personalize your experience, and analyze your activity on our website. By selecting “Accept,” closing this notice, or continuing to use our website, you agree to such collection and use. For additional information, visit our [Privacy Policy](https://www.toshiba.com/tai/privacy_policy.jsp).

Accept

Redirecting to Studio

Redirecting to Studio