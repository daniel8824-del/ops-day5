<!-- source: https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVXLdpswEP2WLrLU0SCEkJaYuBg7fpCGJGaTI8vCoQngYJo0_frKeZzEbmzSumgjhGbuaO6MrnCCL3FSyPtsIeusLOStWU8TdhUKi8BgAGM-DBxgdNKPeDgiUQD4HCc4WapsjqdCuITAzEZKWRJRCQpJOtco1alwUzbTksm1tSrqZX2Np7pAP1ZHcF3m-ghyWd3oenkrlcYXT0EHHniWB2QE3ZEHjHkWOesMrDGnOFlvC-r1uA8TPg67EA3HwYCeHIM53av_boPkfU4QU99sn0biTHAS9-DFf0_Sa3_YMTzYjh9MPBOAxcGEh75Nz9nn4m_Ddk5JxwYIxuRf_DcO-Hf5_2mQ7KfnYl3lBgY-4HAzxSaSk6YumJos3CtCBn5PmC4KRvYxsMjyeRzHQD0XX9xn-gHHRVnlptO_vTWytl2lLUWRmIGFqJCAZtosHaa1lNR1pCWwoWF_hIgeGKEBnrUL7xwI33-uz-5LbKQl-353l3hGEcqi1j9rfLkhCarMl7J4PIJCP6xyPc_k86fZSUtUl_M5qvRC365mulro6iWhXX1JYHdCn1KuBnjSLrzVLrzdKnzYLvdhu9yH7XIfHsp9v0mPG2_a-8d367Db4r9HFiSxiCSEIUUUR1SrFHGQLnIFceYaUqYstwnebRVe0P8LHzgBQNQlrhV-tW3gcCB8v-llNpUk1dAfLgysrK9RVqQlvnxXPrSUVV3oatVc9FfLjfK_-S_znNuP2dNAN6e9X50RCvwZfzhLczM92usf0_79x9NJOuzaziK_ep1qZ-p9-Q1XHKhE -->

![logo](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/images/logo.png)X

Sign in to your Toshiba account

For optimum experience,
please log in on your desktop computer

UserName

Password

Sign In [Forgot password?](https://www.toshibacommerce.com/tgcs109/tsim/forgotpassword.do) [Enterprise Login](https://www.toshibacommerce.com/mga/sps/authsvc?PolicyId=urn:ibm:security:authentication:asf:externalIDPLogin&target=https%3A%2F%2Ftoshibacommerce.com%2Fwps%2Fmyportal)

Don't have an ID? [Request one here](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/faqs)

{"Z7\_22KCH902NGN3D06Q1C8UUU04A7":{"windowState":"normal","portletMode":"view"},"Z7\_22KCH902NGN3D06Q1C8UUU04Q4":{"windowState":"normal","portletMode":"view"},"Z7\_22KCH902NGN3D06Q1C8UUU04Q6":{"windowState":"normal","portletMode":"view"},"Z7\_22KCH902NGN3D06Q1C8UUU04Q5":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2Q20":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2Q22":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2Q21":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2Q23":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2QI0":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2QI2":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2QI1":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2QI3":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O0U4C0QMRQ9T982UH5":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O0U4C0QMRQ9T982UH7":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O0U4C0QMRQ9T982U94":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OG5G00QE271IF33080":{"windowState":"normal","portletMode":"view"}}

![start portlet menu bar](<Base64-Image-Removed>)

## Commerce Marketplace \| Toshiba Commerce

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

# Toshiba Commerce Marketplace

Whether you are a small boutique or a large chain, our network of partners can give you the competitive edge you need for sustainable growth in today's market. ​

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/f2a88b7b-feb1-43e1-a547-6137499c8bb5/Marketplace-Main-Banner-Wider.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-f2a88b7b-feb1-43e1-a547-6137499c8bb5-p8Kqyrm)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/a8a4b32f-1388-4b3e-b79f-3584e1ea6100/Marketplace-Iso-Metric-Image.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-a8a4b32f-1388-4b3e-b79f-3584e1ea6100-pnkH69r)

## What is the

### Toshiba Commerce Marketplace

Connect with top providers through a marketplace that offers convenience, confidence, and choice to meet your business needs.

[Learn More](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Faboutthemarketplace)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/cb1aadaa-a5f7-4e77-b831-614c9d2d65cc/marketing-01-700.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-cb1aadaa-a5f7-4e77-b831-614c9d2d65cc-pnkBw46)

## Commerce Platform

### ELERA®

Empowers retailers of all sizes to address industry challenges through continuous innovation by providing a more agile and scalable solution that leads to a path of frictionless commerce.

[Learn More](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fsoftware%2Fsolutions-platform%2Felera)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/57757efe-ca1f-4a71-aab9-5b19baaa704e/Northstar-Marketplace-Main-Rotating-Promo-Banner-Square-image-Template-700x700-091924a.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-57757efe-ca1f-4a71-aab9-5b19baaa704e-pnkBptR)

## Featured Solution

### CBS NorthStar

NorthStar is a flexible cloud-based POS for restaurants that refuse to settle. Table service, kiosks, online orders—whatever mode you need. Freedom, flexibility, and power to level up your service.

[Learn More](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fcbs-northstar)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/c19741d2-7cb2-4eff-9bc6-67f32d19db98/BRdata-Marketplace-Main-Rotating-Promo-Banner-Square-image-Template-700x700-091924a.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-c19741d2-7cb2-4eff-9bc6-67f32d19db98-pfgDOwE)

## Featured Solution

### BRdata

Enterprise and store item, receiving, ordering, and inventory management. Actionable Analytics with 70 pre-defined reports and dashboards accessible via all modern browsers, iOS, and Android devices

[Learn More](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fbrdata)

About The MarketplaceELERA®CBS NorthStarBRdata

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

Select SolutionSolution(All)ELERAACE/CHECVisualstoreInnovationSoftwareHardwareServiceRetail Segment(All)Grocery / General MerchandiseHospitality / Entertainment​SpecialtyConvenience / FuelSelect an Industry.Category(All)CommerceFiltered Spend ProgramsMarketingOperationsPartner HardwarePaymentsPOS SoftwareRegion(All)North America​Latin America​EuropeAsia / PacificReset Filters

## There are no results matching your filter criteria. Please try again.

/en-us/home/marketplace/adyen/001a-adyen;Adyen

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/66302106-0e9d-4527-aec3-755ae88c8593/Adyan-Marketplace-Green-1152x765-premier.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-66302106-0e9d-4527-aec3-755ae88c8593-pNTN8r2)\\
\\
Adyen \\
\\
**Global Payments Platform** \\
\\
Payments\\
\\
Adyen's global platform powers unified commerce payments for enterprise retailers.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fadyen)

/en-us/home/marketplace/aptos/001b-aptos;Aptos

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/7783e06e-18a3-4f02-bf9d-6ce4f2a99881/Aptos-Marketplace-1152x765-Select.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-7783e06e-18a3-4f02-bf9d-6ce4f2a99881-pNYcIPu)\\
\\
Aptos \\
\\
**Aptos ONE** \\
\\
POS Software\\
\\
Aptos provides software to power Unified Commerce for Specialty Retailers. Aptos' comprehensive suite is led by Aptos ONE driving engagement with your clients](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Faptos)

/en-us/home/marketplace/brdata/002a-brdata;BRdata

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/5c7a0a45-94e5-4405-bfae-99a19329f7a2/BRdata1152x765.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-5c7a0a45-94e5-4405-bfae-99a19329f7a2-pNTNQsU)\\
\\
BRdata \\
\\
**Back-office enterprise solutions** \\
\\
Operations\\
\\
Enterprise and store item, receiving, ordering, and inventory management. Actionable Analytics with 70 pre-defined reports and dashboards accessible via all modern browsers, iOS, and Android devices](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fbrdata)

/en-us/home/marketplace/cbs-northstar/003a-cbs+northstar;CBS NorthStar

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/182f7149-62f1-4989-9527-2dee6ef1a651/NorthStar-Marketplace-1152x765-Premier.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-182f7149-62f1-4989-9527-2dee6ef1a651-pNTO5l.)\\
\\
CBS NorthStar \\
\\
**NorthStar** \\
\\
Commerce\\
\\
NorthStar is a flexible cloud-based POS for restaurants that refuse to settle. Table service, kiosks, online orders - whatever mode you need. Freedom, flexibility, and power to level up your service.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fcbs-northstar)

/en-us/home/marketplace/citcon/004a-citcon;Citcon

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/5bdc5ef0-29a6-4bf5-b090-f1da26c0009a/Citcon-Marketplace-1152x765-Premier.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-5bdc5ef0-29a6-4bf5-b090-f1da26c0009a-pNTOg6S)\\
\\
Citcon \\
\\
**Global Payments Platform** \\
\\
Payments\\
\\
Equipping merchants with the ability to accept alternative payments methods (e-wallets, Buy Now Pay Later, and others) via Toshiba Elera and ACE platforms](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fcitcon)

/en-us/home/marketplace/coupon-bureau/005a-coupon+bureau;The Coupon Bureau

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/296df91a-b969-4fb7-8b42-5cafb5c34007/The-Coupon-Bureau-Marketplace-1152x765-Premier.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-296df91a-b969-4fb7-8b42-5cafb5c34007-pNYcV-P)\\
\\
The Coupon Bureau \\
\\
**Universal Coupons** \\
\\
Marketing\\
\\
Enable acceptance of the new Universal Coupon/ AI (8112) standard to drive shoppers to your stores, improve your shopper’s experience, and enjoy operational efficiencies.1](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fcoupon-bureau)

/en-us/home/marketplace/datalogic/005b-datalogic;Datalogic

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/336acc47-ffa8-410f-8aeb-f50e915a7a8d/Datalogic-Marketplace-1152x765-Premier.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-336acc47-ffa8-410f-8aeb-f50e915a7a8d-pNTQ5ko)\\
\\
Datalogic \\
\\
**Data Capture, Barcode scanning and Mobile Solutions** \\
\\
Partner Hardware\\
\\
Datalogic is a global technology leader in the automatic data capture and factory automation markets, specialized in the designing and production of bar code readers, mobile computers and RFID.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fdatalogic)

/en-us/home/marketplace/ecrebo/006a-ecrebo;Ecrebo

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/c116021c-35ce-4e5d-bd01-ec2710de5c2d/Ecrebo-Marketplace-1152x765-elite.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-c116021c-35ce-4e5d-bd01-ec2710de5c2d-pNTQdIQ)\\
\\
Ecrebo, Inc. \\
\\
**Total Receipt Marketing SaaS solution** \\
\\
Marketing\\
\\
Ecrebo's Total Receipt Marketing SaaS solution enables retailers conclude every shopping trip with personalized graphical messages issued on paper and digital receipts in realtime.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fecrebo)

/en-us/home/marketplace/fis/006a-fis;FIS

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/b38f4aed-abbc-48b2-9a11-423bc4ef856b/FiS-Marketplace-1152x765-Elite2.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-b38f4aed-abbc-48b2-9a11-423bc4ef856b-pNTQS9k)\\
\\
FIS \\
\\
**FIS Filtered Spend** \\
\\
Filtered Spend Programs\\
\\
Filtered Spend improves access and control of benefit and wellness programs through optimized reporting and plan incentives and increased control over basket spend from a single multiple prepaid card.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Ffis)

/en-us/home/marketplace/gft-ewards/007a-gft+rewards;GFT Rewards

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/9c0489da-3284-4c43-a992-ef93ce2e7a54/GFT-Rewardsr-Marketplace-1152x765-Premier.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-9c0489da-3284-4c43-a992-ef93ce2e7a54-pNTR37a)\\
\\
GFT Rewards, LLC \\
\\
**GFT Rewards** \\
\\
Marketing\\
\\
GFT Rewards is a "Rewards as a Service" (RaaS) software company which enables retailers, brands and intellectual property owners to distribute, redeem and reconcile rewards and promotions.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fgft-ewards)

/en-us/home/marketplace/accuvia-software-group/007b-accuvia+software+group;Accuvia Software Group

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/9fcc3bf9-7178-40ff-81b3-7bd4cc627ad3/AccuviaSoftwareGroupSelect.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-9fcc3bf9-7178-40ff-81b3-7bd4cc627ad3-pNYfrtA)\\
\\
Accuvia Software Group \\
\\
**Accuvia Software Group** \\
\\
POS Software\\
\\
ASG delivers advanced POS and analytics solutions for Specialty, Department, and Discount retail, helping major chains optimize operations, harness data, and innovate in real time.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Faccuvia-software-group)

/en-us/home/marketplace/veras-retail/007b-accuvia+software+group;Veras Retail

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/06a09f05-1f14-47b0-af40-a80ca6e13b20/VerasRetailSelect.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-06a09f05-1f14-47b0-af40-a80ca6e13b20-pNYc5A6)\\
\\
Veras Retail \\
\\
**Veras Retail** \\
\\
POS Software\\
\\
Veras Retail delivers proven, flexible retail software—including Veras Checkout POS—backed by decades of expertise to help retailers drive efficiency, sales, and customer engagement.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fveras-retail)

/en-us/home/marketplace/altaine-inc-/007b-altaine+inc;Altaine Inc

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/80beeafe-3405-46fb-9916-4a5d54027164/Altaine-Marketplace+Card+Banner+Image+Builder+1152x765-091724a.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-80beeafe-3405-46fb-9916-4a5d54027164-pNTNslA)\\
\\
Altaine Inc \\
\\
**Altaine Inc** \\
\\
Commerce\\
\\
Omni-channel commerce platform for convenience and QSR sectors.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Faltaine-inc-)

/en-us/home/marketplace/catch/007b-catch;Catch

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/e5f8bc19-bf02-4d68-933f-389ff3a3cb62/CATCH+Marketplace+Partner+Card+Banner1152x765.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-e5f8bc19-bf02-4d68-933f-389ff3a3cb62-pSoqK9O)\\
\\
Catch \\
\\
**Catch** \\
\\
Marketing\\
\\
Catch is a Physical AI platform powering in-store retail media, turning stores into real-time environments that understand shopper behavior and intent across all touchpoints.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fcatch)

/en-us/home/marketplace/evermore/007b-evermore;Evermore

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/5a67d54f-c9ac-4f63-b225-d355080f22f1/Evermore_ELITE_TGCS_Marketplace.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-5a67d54f-c9ac-4f63-b225-d355080f22f1-pNTQqdc)\\
\\
Evermore \\
\\
**Evermore** \\
\\
Filtered Spend Programs\\
\\
Evermore is a leading health benefits card with over $1B in benefit spend across OTC, food, and general merchandise. The Evermore integration into Toshiba ACE 8.5.1 enables retailers to accept the "&more" benefit cards at checkout, unlocking incremental revenue across categories.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fevermore)

/en-us/home/marketplace/honeywell/007b-honeywell;Honeywell

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/4918d4f4-ea3c-462a-b7ca-54f51446b636/Honeywell-Marketplace-1152x765-select.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-4918d4f4-ea3c-462a-b7ca-54f51446b636-pNTRi0C)\\
\\
Honeywell \\
\\
**Strategic Channel Business Manager** \\
\\
Partner Hardware\\
\\
Honeywell’s PSS business creates mobile computers, printers, and data capture devices that improve worker productivity in companies around the world across all industries improving efficiency.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fhoneywell)

/en-us/home/marketplace/magstar/007b-magstar;Magstar

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/ef2c2128-72d6-4d0e-90bd-9365cd0ce15a/Magstar-Marketplace-1152x765-Select.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-ef2c2128-72d6-4d0e-90bd-9365cd0ce15a-pNTS7qw)\\
\\
Magstar \\
\\
**Unified Retail Management** \\
\\
Commerce\\
\\
Magstar powers specialty retailers with unified retail management - ERP, POS, inventory, CRM, analytics & mobile—driving growth, efficiency & seamless experiences across stores & online.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fmagstar)

/en-us/home/marketplace/market-pay-and-toshiba/007b-market+pay;Market Pay

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/55f94164-ab03-42ad-bf0e-7a7f3589f5ec/MarketPay_Toshiba_ELITE_box.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-55f94164-ab03-42ad-bf0e-7a7f3589f5ec-pU9a5Og)\\
\\
Market Pay \\
\\
**Omnichannel Unified Payment Platform** \\
\\
Payments\\
\\
Market Pay combines an omnichannel payment platform covering in-store POS, mobile and unified commerce with a premium PAX Android pinpads and terminals, ensuring fast, secure and seamless transactions.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2FMarket-Pay-and-toshiba)

/en-us/home/marketplace/worldline-and-toshiba/007b-worldline;Worldline

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/b6304229-0e2a-4ab5-b8de-b9ec522fd6e2/Worldline_Toshiba_PREMIER_box.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-b6304229-0e2a-4ab5-b8de-b9ec522fd6e2-pNYqANU)\\
\\
Worldline \\
\\
**One Commerce** \\
\\
Payments\\
\\
One payments partner. One back office. Infinite sales channels.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fworldline-and-toshiba)

/en-us/home/marketplace/ingenico/007c-ingenico;Ingenico

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/66ea7877-2138-4f3c-b2c4-352b0b5f651b/Ingenico-Marketplace-1152x765-Select.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-66ea7877-2138-4f3c-b2c4-352b0b5f651b-pNTRCKW)\\
\\
Ingenico \\
\\
**Retail Payment Solutions** \\
\\
Partner Hardware\\
\\
Moving Commerce Forward in Retail Ingenico is enhancing the commerce experience, with payment solutions that are smarter, more connected, and tailored to drive your success.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fingenico)

/en-us/home/marketplace/loc/007d-loc+software;LOC Software

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/a280598f-64de-479e-b818-a149c7edc8d7/LOC-Software--Marketplace-1152x765-Elite.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-a280598f-64de-479e-b818-a149c7edc8d7-pNTRX88)\\
\\
LOC Software \\
\\
**ThriVersA** \\
\\
POS Software\\
\\
LOC’s ThriVersA suite empowers independent merchants to optimize retail. For 35 years, we've led in POS, back office, host, and loyalty, offering flexible solutions for unique business needs.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Floc)

/en-us/home/marketplace/nationsbenefits/009a-nationsbenefits;NationsBenefits

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/e7fa601b-7694-49ff-913d-9f188f4c4343/NationsBenefits-Marketplace-1152x765-Elite.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-e7fa601b-7694-49ff-913d-9f188f4c4343-pNTTzfL)\\
\\
NationsBenefits \\
\\
**Health Spending Card** \\
\\
Filtered Spend Programs\\
\\
NationsBenefits offers a health benefits program that allows members to purchase approved over-the-counter (OTC) items, healthy food items, and services through participating merchants.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fnationsbenefits)

/en-us/home/marketplace/partron-esl/009b-partron+esl;Partron ESL

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/fcdd41a4-bf07-429a-9f84-736a8df0e88f/Partron-ESL-Marketplace-1152x765-select.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-fcdd41a4-bf07-429a-9f84-736a8df0e88f-pNTTLJd)\\
\\
Partron ESL \\
\\
**Partron ESL** \\
\\
Partner Hardware\\
\\
IoT solution provider, specializing in full-graphic Electronic Shelf Label, Digital Signage, and Smart Shelf Solutions](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fpartron-esl)

/en-us/home/marketplace/popid/010a-popid;PopID

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/b04e736e-58eb-45f9-9a63-b2b1f2584f19/PopID-Marketplace-1152x765-Premier.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-b04e736e-58eb-45f9-9a63-b2b1f2584f19-pNYbHvt)\\
\\
PopID, Inc. \\
\\
**Loyalty and Payment Solution** \\
\\
Payments\\
\\
PopID aims to be the universal gateway for verifying an individual’s identity based on face or palm for applications such as loyalty and payment.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fpopid)

/en-us/home/marketplace/qualcomm/010a-qualcomm;Qualcomm

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/e7f12db2-460b-4ea2-b27b-13ec9143364d/Qualcomm-Marketplace-1152x765-Premier.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-e7f12db2-460b-4ea2-b27b-13ec9143364d-pNYbPZn)\\
\\
Qualcomm Technologies Inc. \\
\\
**Qualcomm** \\
\\
Commerce\\
\\
A suite of connected, EDGE AI-capable IoT products empowers retailers with real-time insights, assisting store digitization in the Gen AI era.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fqualcomm)

/en-us/home/marketplace/toshiba-business/010b-toshiba+america+business+solutions;Toshiba America Business Solutions

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/f9576b2a-b7aa-4259-b3e2-8df1e76ddc14/Toshiba--Marketplace-1152x765-select.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-f9576b2a-b7aa-4259-b3e2-8df1e76ddc14-pNYb.Ov)\\
\\
Toshiba America Business Solutions \\
\\
**Thermal Print Solutions** \\
\\
Partner Hardware\\
\\
Toshiba provides high-performance POS and thermal label printers for large retail clients. Our scalable solutions ensure seamless store operations, improving efficiency and reliability.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Ftoshiba-business)

/en-us/home/marketplace/verifone/010c-verifone;Verifone

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/41b20167-54df-4684-b23d-484e9625d4bf/Verifone-Marketplace-1152x765-select.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-41b20167-54df-4684-b23d-484e9625d4bf-pNYcemz)\\
\\
Verifone \\
\\
**Omnichannel Payments Platform** \\
\\
Partner Hardware\\
\\
Verifone's omnichannel platform offers seamless, secure payments across in-store and online with flexible processing, powerful and secure payment devices, and insights to enhance customer experiences.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fverifone)

/en-us/home/marketplace/vertex/011a-vertex;Vertex

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/3f7e0f80-b931-4a9c-8288-e8b7e747b2f9/Vertex-Marketplace-1152x765-Premier.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-3f7e0f80-b931-4a9c-8288-e8b7e747b2f9-pNYck5L)\\
\\
Vertex, Inc. \\
\\
**Vertex** \\
\\
Commerce\\
\\
Vertex, Inc. is a leading global provider of indirect tax solutions. The Company’s mission is to deliver the most trusted tax technology enabling global businesses to transact, comply and grow with confidence.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fvertex)

/en-us/home/marketplace/xenia/013a-xenia+retail;Xenia Retail

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/97b830b1-5157-42d0-a33f-b2aa4ebd119f/Xenia-Retail--Marketplace-1152x765-select.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-97b830b1-5157-42d0-a33f-b2aa4ebd119f-pfhBqTu)\\
\\
Xenia Retail \\
\\
**Unified Commerce Platform for Brick & Mortar Retail** \\
\\
POS Software\\
\\
True Speed-to-Market with a Microservices-based, Cloud-Native Unified Commerce Platform: POS, mPOS, SCO and Mobile Consumer Shopping - full integrations and chain-wide deployment in under 12 months](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fxenia)

/en-us/home/marketplace/zebra/033a+zebra+technologies;Zebra Technologies

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/16cd89e3-6048-41c1-8e9f-f28ce6c2bcb1/Zebra-Technologies-Marketplace-1152x765-select.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-16cd89e3-6048-41c1-8e9f-f28ce6c2bcb1-pNYcwRT)\\
\\
Zebra Technologies \\
\\
**Zebra Retail Solutions** \\
\\
Partner Hardware\\
\\
Zebra empowers retailers by making every front-line worker & asset visible, connected & fully optimized with an award-winning portfolio of hardware, software, services & solutions.](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace%2Fzebra)

/en-us/home/marketplace/coupon-bureau/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/citcon/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/datalogic/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/honeywell/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/cbs-northstar/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/toshiba-business/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/vertex/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/aptos/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/gft-ewards/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/zebra/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/adyen/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/ingenico/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/xenia/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/verifone/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/ecrebo/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/nationsbenefits/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/popid/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/brdata/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/partron-esl/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/loc/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/fis/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/qualcomm/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/magstar/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/evermore/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/accuvia-software-group/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/veras-retail/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/altaine-inc-/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/market-pay-and-toshiba/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/worldline-and-toshiba/learn-more-marketplace;learn-more-marketplace

/en-us/home/marketplace/catch/learn-more-marketplace;learn-more-marketplace

Load More

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

## For more information about the Marketplace,   see the Toshiba Partner Alliance Program Guide.

View Program Guide

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![](https://commerce.toshiba.com/wps/contenthandler/dav/fs-type1/themes/TGCSMarketingThemeV2/images/g_cta-dark-left-squares.svg)

## Interested in listing your product on the   Toshiba Commerce Marketplace?

[Learn More](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fpartners%2Fmarketplace-partners)![](https://commerce.toshiba.com/wps/contenthandler/dav/fs-type1/themes/TGCSMarketingThemeV2/images/g_cta-dark-right-sqares.svg)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

Start a conversation

First name

Last name

Email

Company

Country

Phone

I am a

Business PartnerOtherPress / AnalystRetailerSupplierToshiba Employee

- Business Partner

- Other

- Press / Analyst

- Retailer

- Supplier

- Toshiba Employee


My Retail Segment

Fashion & ApparelFood ServiceGas & ConvenienceGroceryMass MerchandiseOtherPharmacy / Drug StoreSpecialty

- Fashion & Apparel

- Food Service

- Gas & Convenience

- Grocery

- Mass Merchandise

- Other

- Pharmacy / Drug Store

- Specialty


I am interested in learning more about

Add me to Toshiba Global Commerce Solutions' email marketing list

I am allowing Toshiba to contact me in regards to the information on this form

Comments

By submitting this form I agree that Toshiba Global Commerce Solutions, Inc. and its affiliates, including all subsidiaries and branches, may process my data as indicated above and as described in the [Toshiba Global Commerce Solutions Privacy Declaration.](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/common-content/general-content/privacy-policy&mapping=tgcs_new.portal.generaldetails)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**

reCAPTCHA is changing its terms of service. [Take action.](https://google.com/recaptcha/admin/migrate)

![success](https://commerce.toshiba.com/wps/portal/marketing/!ut/p/z1/tVbLdpswEP2WLrxUNAjx6g4TF2PHD9KQxGxyBBaYxjyKid306yvHyUlwbZNTF20Eku6dmTujAezje-xnbJ3ErEryjC3F-8xXHxxDIjAcwkQf2QqodDpwdWdMXBvwLfaxX4TJHM8MQyMEAhmFocQQZRAiRuccRTwytEgNOFPZ9nSYVUW1wDOeoadVBxZ5yjuQsvKRV8WShRzfvRgdmmBKJpAx9MYmqKopkZvuUJroFPvbbYOafd2CqT5xeuCOJvaQXl2C8O4Nf_yA_zEm8Kgltq9d48bQideHV_yJoLd4ODJM2LdvT01hQPXsqe5YMr1V6_b_pt_h92m716QrA9gT8i_4moOfwp8QqBHv11N0QIEDGtZDbBLZb6qCmYhCeyBkaPUNUUX2WL4E1ZUs3fM8oKaG79YJ32Avy8tUVPr390LmshZyKaTICEBC1GCAAi5eFZVzxqimMMnAQobTFlx6poUGerVdeuVM-sEuP8cvsWgtyY-fP31TdIQ8q_ivCt_XWkKYpwXLnjuQ8c0q5fOE7R7FTpSjKp_PUcljvlwFvIx5-RrQsbokcDygT3WuBnrSLr3ULr3cKr3TrvZOu9o77WrvnKv9oKkfN960jx_fPWf3m_-JtsCIRBghKgpJqCPKwwjpwDSkGUSZc4jUUNKa6LVW6Q36f-ltxQZwe0STnG-yDDqcST9o-jMRmSTlyBrFgpZVC5RkUY7vP6QPFaysMl6umpP-drKW_ne88CVe5sHuH9DMAlkXRkse8ZKXF0-lWF5UVbH62oEObDabizjP4yW_EE27A4cgi3wlPKifxEWa6vJz8jLQ43X_d3eMbCvQNzdRKqZnebswG6wPT1fRqCcrcfrwNlVKoCzXV-aXP4tQ_Nc!/images/tgcs/success.svg)

## Success!

Thank you for reaching out. One of our team members will be in contact soon. We hope you have a great day.

Close

Complementary
Content [Deferred Modules](https://commerce.toshiba.com/wps/contenthandler/marketing/!ut/p/digest!M6zrA0PEiotCbddBEGnoVg/mashup/ra:collection?themeID=ZJ_JQGEHK01N0LM806KGPAKPA0UO0&locale=en&mime-type=text%2Fjavascript&lm=1778876784000&entry=st_skin__0.0%3Aconfig_js&entry=wp_liveobject_framework_core__0.0%3Aconfig_js&entry=wp_portal_ui_utils__0.0%3Aconfig_js&entry=wp_contextmenu_js__0.0%3Aconfig_js&entry=wp_skin_cam__0.0%3Aconfig_js&entry=wp_contextmenu_config_lof__0.0%3Aconfig_js&entry=wp_federated_documents_picker__0.0%3Aconfig_js&entry=wp_dnd_main__0.0%3Aconfig_js&entry=wp_movecontrols__0.0%3Aconfig_js&entry=wp_toolbar_controlactions__0.0%3Aconfig_js&entry=wp_content_targeting_cam__0.0%3Aconfig_js&deferred=true)

- ${title}${badge}

${loading}

[Deferred Modules](https://commerce.toshiba.com/wps/contenthandler/marketing/!ut/p/digest!SpZvrtUURDcRHYzcbiqg-Q/mashup/ra:collection?themeID=ZJ_JQGEHK01N0LM806KGPAKPA0UO0&locale=en&mime-type=text%2Fplain&entry=wp_contextmenu_templates__0.0%3Aconfig_markup&entry=wp_skin_cam__0.0%3Aconfig_markup&entry=wp_dnd_main__0.0%3Aconfig_markup&deferred=true)

reCAPTCHA