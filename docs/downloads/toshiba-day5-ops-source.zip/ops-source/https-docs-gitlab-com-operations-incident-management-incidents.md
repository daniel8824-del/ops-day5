<!-- source: https://docs.gitlab.com/operations/incident_management/incidents -->

/

* * *

# Incidents

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

An incident is a service disruption or outage that needs to be restored urgently.
Incidents are critical in incident management workflows.
Use GitLab to triage, respond, and remediate incidents.

## Incidents list [Permalink](https://docs.gitlab.com/operations/incident_management/incidents/\#incidents-list "Permalink")

When you [view the incidents list](https://docs.gitlab.com/operations/incident_management/manage_incidents/#view-a-list-of-incidents), it contains the following:

- **State**: To filter incidents by their state, select **Open**, **Closed**,
or **All** above the incident list.

- **Search**: Search for incident titles and descriptions or [filter the list](https://docs.gitlab.com/operations/incident_management/incidents/#filter-the-incidents-list).

- **Severity**: Severity of a particular incident, which can be one of the following
values:

  - severity-criticalCritical - S1
  - severity-highHigh - S2
  - severity-mediumMedium - S3
  - severity-lowLow - S4
  - severity-unknownUnknown
- **Incident**: The title of the incident, which attempts to capture the
most meaningful information.

- **Status**: The status of the incident, which can be one of the following values:


  - Triggered
  - Acknowledged
  - Resolved

In the Premium or Ultimate tier, this field is also linked to [on-call escalation](https://docs.gitlab.com/operations/incident_management/paging/#escalating-an-incident) for the incident.

- **Date created**: How long ago the incident was created. This field uses the
standard GitLab pattern of `X time ago`. Hover over this value to see the exact date and time formatted according to your locale.

- **Assignees**: The user assigned to the incident.

- **Published**: Whether the incident is published to a [status page](https://docs.gitlab.com/operations/incident_management/status_page/).


![Incidents List](https://docs.gitlab.com/operations/incident_management/img/incident_list_v15_6.png)

For an example of the incident list in action, see this
[demo project](https://gitlab.com/gitlab-org/monitor/monitor-sandbox/-/incidents).

### Sort the incident list [Permalink](https://docs.gitlab.com/operations/incident_management/incidents/\#sort-the-incident-list "Permalink")

The incident list shows incidents sorted by incident created date, showing the newest first.

To sort by another column, or to change the sorting order, select the column.

The columns you can sort by:

- Severity
- Status
- Time to SLA
- Published

### Filter the incidents list [Permalink](https://docs.gitlab.com/operations/incident_management/incidents/\#filter-the-incidents-list "Permalink")

To filter the incident list by author or assignee, enter these values in the search box.

## Incident details [Permalink](https://docs.gitlab.com/operations/incident_management/incidents/\#incident-details "Permalink")

### Summary [Permalink](https://docs.gitlab.com/operations/incident_management/incidents/\#summary "Permalink")

The summary section for incidents provides critical details about the
incident and the contents of the issue template (if [selected](https://docs.gitlab.com/operations/incident_management/alerts/#trigger-actions-from-alerts)). The highlighted
bar at the top of the incident displays from left to right:

- The link to the original alert.
- The alert start time.
- The event count.

Below the highlight bar, a summary includes the following fields:

- Start time
- Severity
- `full_query`
- Monitoring tool

The incident summary can be further customized using
[GitLab Flavored Markdown](https://docs.gitlab.com/user/markdown/).

If an incident is [created from an alert](https://docs.gitlab.com/operations/incident_management/alerts/#trigger-actions-from-alerts)
that provided Markdown for the incident, then the Markdown is appended to the summary.
If an incident template is configured for the project, then the template content is appended at the end.

Comments are displayed in threads, but can be displayed chronologically
[by toggling on the recent updates view](https://docs.gitlab.com/operations/incident_management/incidents/#recent-updates-view).

When you make changes to an incident, GitLab creates [system notes](https://docs.gitlab.com/user/project/system_notes/) and
displays them below the summary.

### Metrics [Permalink](https://docs.gitlab.com/operations/incident_management/incidents/\#metrics "Permalink")

- Tier: Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

In many cases, incidents are associated to metrics. You can upload screenshots of metric
charts in the **Metrics** tab:

![Incident Metrics tab](https://docs.gitlab.com/operations/incident_management/img/incident_metrics_tab_v13_8.png)

When you upload an image, you can associate the image with text or a link to the original graph.

![Text link modal](https://docs.gitlab.com/operations/incident_management/img/incident_metrics_tab_text_link_modal_v14_9.png)

If you add a link, you can access the original graph by selecting the hyperlink above the uploaded image.

### Alert details [Permalink](https://docs.gitlab.com/operations/incident_management/incidents/\#alert-details "Permalink")

Incidents show the details of linked alerts in a separate tab. To populate this
tab, the incident must have been created with a linked alert. Incidents
created automatically from alerts have this
field populated.

![Incident alert details](https://docs.gitlab.com/operations/incident_management/img/incident_alert_details_v13_4.png)

### Timeline events [Permalink](https://docs.gitlab.com/operations/incident_management/incidents/\#timeline-events "Permalink")

Incident timelines give a high-level overview of what happened
during an incident, and the steps that were taken for it to be resolved.

Read more about [timeline events](https://docs.gitlab.com/operations/incident_management/incident_timeline_events/) and how to enable this feature.

### Recent updates view [Permalink](https://docs.gitlab.com/operations/incident_management/incidents/\#recent-updates-view "Permalink")

- Tier: Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

To see the latest updates on an incident, select
**Turn recent updates view on** (history) on the comment bar. Comments display
un-threaded and chronologically, newest to oldest.

### Service Level Agreement countdown timer [Permalink](https://docs.gitlab.com/operations/incident_management/incidents/\#service-level-agreement-countdown-timer "Permalink")

- Tier: Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

You can enable the Service Level Agreement Countdown timer on incidents to track
the Service Level Agreements (SLA) you hold with your customers. The timer is
automatically started when the incident is created, and shows the time
remaining before the SLA period expires. The timer is also dynamically updated
every 15 minutes so you do not have to refresh the page to see the time remaining.

Prerequisites:

- You must have the Maintainer or Owner role for the project.

To configure the timer:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Settings** \> **Monitor**.
3. Expand the **Incidents** section, then select the **Incident settings** tab.
4. Select **Activate “time to SLA” countdown timer**.
5. Set a time limit in increments of 15 minutes.
6. Select **Save changes**.

After you enable the SLA countdown timer, the **Time to SLA** column is available in the
incidents list and as a field on new incidents. If
the incident isn’t closed before the SLA period ends, GitLab adds a `missed::SLA`
label to the incident.

## Related topics [Permalink](https://docs.gitlab.com/operations/incident_management/incidents/\#related-topics "Permalink")

- [Create an incident](https://docs.gitlab.com/operations/incident_management/manage_incidents/#create-an-incident)
- [Create an incident automatically](https://docs.gitlab.com/operations/incident_management/alerts/#trigger-actions-from-alerts)
whenever an alert is triggered
- [View incidents list](https://docs.gitlab.com/operations/incident_management/manage_incidents/#view-a-list-of-incidents)
- [Assign to a user](https://docs.gitlab.com/operations/incident_management/manage_incidents/#assign-to-a-user)
- [Change incident severity](https://docs.gitlab.com/operations/incident_management/manage_incidents/#change-severity)
- [Change incident status](https://docs.gitlab.com/operations/incident_management/manage_incidents/#change-status)
- [Change escalation policy](https://docs.gitlab.com/operations/incident_management/manage_incidents/#change-escalation-policy)
- [Close an incident](https://docs.gitlab.com/operations/incident_management/manage_incidents/#close-an-incident)
- [Automatically close incidents via recovery alerts](https://docs.gitlab.com/operations/incident_management/manage_incidents/#automatically-close-incidents-via-recovery-alerts)
- [Add a to-do item](https://docs.gitlab.com/user/todos/#create-a-to-do-item)
- [Add labels](https://docs.gitlab.com/user/project/labels/)
- [Assign a milestone](https://docs.gitlab.com/user/project/milestones/)
- [Make an incident confidential](https://docs.gitlab.com/user/project/issues/confidential_issues/)
- [Set a due date](https://docs.gitlab.com/user/project/issues/due_dates/)
- [Toggle notifications](https://docs.gitlab.com/user/profile/notifications/#subscribe-to-notifications-for-a-specific-issue-merge-request-or-epic)
- [Track spent time](https://docs.gitlab.com/user/project/time_tracking/)
- [Add a Zoom meeting to an incident](https://docs.gitlab.com/user/project/issues/associate_zoom_meeting/) the same
way you add it to an issue
- [Linked resources in incidents](https://docs.gitlab.com/operations/incident_management/linked_resources/)
- Create incidents and receive incident notifications [directly from Slack](https://docs.gitlab.com/operations/incident_management/slack/)
- Use the [Issues API](https://docs.gitlab.com/api/issues/) to interact with incidents

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**