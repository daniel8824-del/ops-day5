<!-- source: https://www.bluestarinc.com/hubfs/00_BlueStar%20Microsite%20Files/Toshiba_Retail/pdf/TCx_Single_Station_Printer_Brochure.pdf?hsLang=en-us -->

™
\[Image: Im0\]
TCx Single
Station Printer

Single Station Printer Model (6145 - 1TN)

Achieving Brilliant Commerce with Printing Solutions
Designed for Retail
Toshiba Global Commerce Solutions is a leader in printing

Toshiba Global Commerce Solutions is a leader in printing
solutions so we understand that point-of-sale printers are
an essential part of any high-performance point-of-sale
(POS) system. Our extensive expertise in developing printing
solutions designed for retail brings systems management,
efficiency, and reliability to a variety of retail environments.
Retailers are increasingly focused on enhanced functionality
that provides personalized experiences for their customers,
including offering discount vouchers with printed receipts and
enabling loyalty programs for customers.

Designed for Performance

The TCx Single Station printer is the perfect choice for any
business when looking for optimized printer performance. It's a
compact, low-profile printing solution that is easy to configure,
install and manage with the most popular and industry
standard POS operating systems available today (including
4690 and TCx™ Sky).

• Print head design is superior to our previous printers to
deliver the highest speed, print quality, and longevity
• Fastest Receipt Print Speed - 406 mm/sec (125 lps at 8 lpi)

• Fastest Receipt Print Speed - 406 mm/sec (125 lps at 8 lpi)

• 30+ % paper reduction cost savings (over normal printing
mode)

• Triple network connectivity – Built-in USB and Powered USB,
and optional Ethernet, WiFi, or RS232

* * *

Retailers
Printing with ease

Printing with ease
and efficiency while
providing power and
paper-reduction cost

Associates
A reliable, easy to set up

Customers
Reduces customer wait

A reliable, easy to set up
receipt printer that minimizes
downtime with simple, rapid
paper roll replacement and
faster service.

Reduces customer wait
times and keeps the
line moving with quick
shopping interactions.

Built for Reliability

The TCx Single Station printer design uses the highest quality
materials available to meet the rigors of retail environments
for lasting performance in harsh surroundings. With its
retail-hardened durability protecting your investment, that
means continued uptime, fewer service calls, saving valuable
employee time, and minimized lifecycle costs.
• Steel Frame construction to endure high frequency usage and

• Sturdy latching features to minimize chance of breakage

• Paper sensor design that is immune to debris

• Easy in-house serviceability to change components to
reducing support calls

Built-in Manageability
Retail operations require accessible, dependable printing to

Retail operations require accessible, dependable printing to
deliver a truly seamless experience for your customers. That
means your receipt printer has to continue to perform at its
best. The TCx Single Station printer helps retailers better
manage the performance and efficiency of their printer
with proactive monitoring of the entire POS system to avoid
problems that can cause unexpected downtime. By having
easier visibility to the life of your printer, you are able to
continue providing quick and reliable service to keep checkout
traffic flowing and your customers coming back.
• Thermal Print Head Health Sensor - accurate, programmable

• Thermal Print Head Health Sensor - accurate, programmable
sensor system monitors printer head health.

• Usage statistics – number of cuts, lines printed, etc.

• Remote monitoring – provides visibility to the status of your
printer and address issues before they occur

• Integrated remote management technology – manage the
inventory data, defined events, firmware and configuration
updates across all devices at an enterprise level
• Industry-leading advanced exchange warranty (1 year)

TOSHIBA

• Industry-leading advanced exchange warranty (1 year)

Toshiba and the Toshiba logo are trademarks or registered trademarks of Toshiba in the
United States, other countries, or both. All other trademarks and logos are the property of
their respective owners. Information in this document is subject to change without notice.

TCD15036-USEN-02