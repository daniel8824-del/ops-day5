<!-- source: https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcx-amplify/!ut/p/z1/tVRJT8JAFP4tHjhO5nW6TY9tw27TFimUXkit3ZQuwAj03zsaEwVRoti5zEzet7x8yXs4wD4OynCXpyHLqzJc8f8iUJZjTdIH1ASnbxMZXEsinjpzxb5A8AwHOKij_AEvZDHRiBIRlKhShCQ1TpCmgIAkei9DpMpJLEev6KhkNcvwIi7R87YDWVXEHdhWCduHG_5axWkYNWjbbFlc8DqLDigs6lWeNHh-qZ2Al-GbowPnB2-QDwVHN8FVvL5Dh6YozZR3wCnTmBBDBOCGZwFHJgvepLocagKB8Rhse9wTwO3aEwc80ZmCgOe7PN5jr6w2BY_47pcJDi46iFc6_Czfh3blSbvyQrvy7WZP282e_nP2dGRI4Hp2zwSDEj4dV8qPTob3y_jzdZU_rteBzrdMVbL4wLD_hzXDZcjGMq2UdxeyDOVlUmH_mIH9z4y6KKjYoKcJ3U-TLC2WVleUz16r3a2u37wAAGn6vA!! -->

![logo](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcx-amplify/!ut/p/z1/tVXLdpswFPyWLlhiXd5ydkAT7FAXcIJt2ORgKh4tIAJKiPv1VZpN7bjhNCna6HVn7miOdIVitENxkzyWecJK2iQVn0exfufOVXOBbfAdT9YgWKlyaGwCxZFktEExitu0_IYiTcnmsp7KYmaoqagaJBPnOkiiivcapIaWES19jk4b1rICRaQRH3oBCloTAXqasSHp-KgieZIexP7QM1LzfZY-iUndVmV2QNsxOTHfhr80E17hfdOGQA8dHy9tRd3ov_Fv0L_gT2mttWwpADz8PfgjgaP4-CTk9QnOeHAsccykkxTYW15yFZ7jql8-A-gqivgpjLvlXJLBdcHz3CsJgktv7UOo-Lcgoe1jSQYUNrSr-R26-ccrsoCxDMoHM7xN78C09PK09NK09NN6j6f1Hv9n7_G1pUIQelc2WFjmz-eD9NdjBYDX4_L7_X1s8jJKG0aeGNq9o45yGrlb2aucq0tYIZZNRtHuGIF2fyK4sryi-5cvwWz2CubYjmSkI93soePLBWNtfyGAAMMwzHJK84rMUloLcA5S0J5LP45EbV1j5VCWpfhjvfhpfRUde4-H26w-221xn62YFpmffgFKrMP6/images/logo.png)X

Sign in to your Toshiba account

For optimum experience,
please log in on your desktop computer

UserName

Password

Sign In [Forgot password?](https://www.toshibacommerce.com/tgcs109/tsim/forgotpassword.do) [Enterprise Login](https://www.toshibacommerce.com/mga/sps/authsvc?PolicyId=urn:ibm:security:authentication:asf:externalIDPLogin&target=https%3A%2F%2Ftoshibacommerce.com%2Fwps%2Fmyportal)

Don't have an ID? [Request one here](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/faqs)

{"Z7\_I9120KK0OOKF10QEORP0U3PT01":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OOKF10QEORP0U3PT03":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OOKF10QEORP0U3PTG0":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OOKF10QEORP0U3PTG2":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OOKF10QEORP0U3PTG1":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OOKF10QEORP0U3PTG3":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OOKF10QEORP0U3PT80":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OOKF10QEORP0U3PT82":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8JB40QUOFC0B82000":{"windowState":"normal","portletMode":"view"}}

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

# TCx® Amplify

Transform the way your customers shop. Create an engaging experience and empower your customers to take charge of their shopping journey.

Meet TCx® Amplify.

Select a Language for your download.EnglishDownload TCx® Amplify Brochure

![product-img](https://commerce.toshiba.com/wps/wcm/connect/marketing/badc435b-e540-4937-9ac8-99d1a569eefd/TCx-Amplify-01.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_GAAC1A02N8ABE0AVD86G7Q0421-badc435b-e540-4937-9ac8-99d1a569eefd-pOrryLo)

![product-img](https://commerce.toshiba.com/wps/wcm/connect/marketing/7f5c7015-96fb-4217-bbf5-db42960725a7/TCx-Amplify-02.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_GAAC1A02N8ABE0AVD86G7Q0421-7f5c7015-96fb-4217-bbf5-db42960725a7-pOrryLo)

![product-img](https://commerce.toshiba.com/wps/wcm/connect/marketing/9be8138d-1e81-4950-8e2c-d24f8ff2dcb0/TCx-Amplify-03.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_GAAC1A02N8ABE0AVD86G7Q0421-9be8138d-1e81-4950-8e2c-d24f8ff2dcb0-pOrryLo)

![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcx-amplify/!ut/p/z1/tVXLdpswFPyWLlhiXd5ydkAT7FAXcIJt2ORgKh4tIAJKiPv1VZpN7bjhNCna6HVn7miOdIVitENxkzyWecJK2iQVn0exfufOVXOBbfAdT9YgWKlyaGwCxZFktEExitu0_IYiTcnmsp7KYmaoqagaJBPnOkiiivcapIaWES19jk4b1rICRaQRH3oBCloTAXqasSHp-KgieZIexP7QM1LzfZY-iUndVmV2QNsxOTHfhr80E17hfdOGQA8dHy9tRd3ov_Fv0L_gT2mttWwpADz8PfgjgaP4-CTk9QnOeHAsccykkxTYW15yFZ7jql8-A-gqivgpjLvlXJLBdcHz3CsJgktv7UOo-Lcgoe1jSQYUNrSr-R26-ccrsoCxDMoHM7xN78C09PK09NK09NN6j6f1Hv9n7_G1pUIQelc2WFjmz-eD9NdjBYDX4_L7_X1s8jJKG0aeGNq9o45yGrlb2aucq0tYIZZNRtHuGIF2fyK4sryi-5cvwWz2CubYjmSkI93soePLBWNtfyGAAMMwzHJK84rMUloLcA5S0J5LP45EbV1j5VCWpfhjvfhpfRUde4-H26w-221xn62YFpmffgFKrMP6/images/i_swiper-next-dark.svg)

![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcx-amplify/!ut/p/z1/tVXLdpswFPyWLlhiXd5ydkAT7FAXcIJt2ORgKh4tIAJKiPv1VZpN7bjhNCna6HVn7miOdIVitENxkzyWecJK2iQVn0exfufOVXOBbfAdT9YgWKlyaGwCxZFktEExitu0_IYiTcnmsp7KYmaoqagaJBPnOkiiivcapIaWES19jk4b1rICRaQRH3oBCloTAXqasSHp-KgieZIexP7QM1LzfZY-iUndVmV2QNsxOTHfhr80E17hfdOGQA8dHy9tRd3ov_Fv0L_gT2mttWwpADz8PfgjgaP4-CTk9QnOeHAsccykkxTYW15yFZ7jql8-A-gqivgpjLvlXJLBdcHz3CsJgktv7UOo-Lcgoe1jSQYUNrSr-R26-ccrsoCxDMoHM7xN78C09PK09NK09NN6j6f1Hv9n7_G1pUIQelc2WFjmz-eD9NdjBYDX4_L7_X1s8jJKG0aeGNq9o45yGrlb2aucq0tYIZZNRtHuGIF2fyK4sryi-5cvwWz2CubYjmSkI93soePLBWNtfyGAAMMwzHJK84rMUloLcA5S0J5LP45EbV1j5VCWpfhjvfhpfRUde4-H26w-221xn62YFpmffgFKrMP6/images/i_swiper-prev-dark.svg)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

## About This Item

### General Info

- Personalized end-to-end mobile shopping experience for consumers
- In-store alerts help advertise new products, services and more
- Self-scanning feature creates more options for checkout
- A faster, convenient checkout option for mobile shoppers
- Store reporting so retailers can track solution utilization aligned to your budget

![IMPLEMENT](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcx-amplify/!ut/p/z1/tVXLdpswFPyWLlhiXd5ydkAT7FAXcIJt2ORgKh4tIAJKiPv1VZpN7bjhNCna6HVn7miOdIVitENxkzyWecJK2iQVn0exfufOVXOBbfAdT9YgWKlyaGwCxZFktEExitu0_IYiTcnmsp7KYmaoqagaJBPnOkiiivcapIaWES19jk4b1rICRaQRH3oBCloTAXqasSHp-KgieZIexP7QM1LzfZY-iUndVmV2QNsxOTHfhr80E17hfdOGQA8dHy9tRd3ov_Fv0L_gT2mttWwpADz8PfgjgaP4-CTk9QnOeHAsccykkxTYW15yFZ7jql8-A-gqivgpjLvlXJLBdcHz3CsJgktv7UOo-Lcgoe1jSQYUNrSr-R26-ccrsoCxDMoHM7xN78C09PK09NK09NN6j6f1Hv9n7_G1pUIQelc2WFjmz-eD9NdjBYDX4_L7_X1s8jJKG0aeGNq9o45yGrlb2aucq0tYIZZNRtHuGIF2fyK4sryi-5cvwWz2CubYjmSkI93soePLBWNtfyGAAMMwzHJK84rMUloLcA5S0J5LP45EbV1j5VCWpfhjvfhpfRUde4-H26w-221xn62YFpmffgFKrMP6/images/i_shield-check-solid.svg)

### **MOBILITY**

Mobile session and WiFi offline recovery for better customer service and increased associate productivity

![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcx-amplify/!ut/p/z1/tVXLdpswFPyWLlhiXd5ydkAT7FAXcIJt2ORgKh4tIAJKiPv1VZpN7bjhNCna6HVn7miOdIVitENxkzyWecJK2iQVn0exfufOVXOBbfAdT9YgWKlyaGwCxZFktEExitu0_IYiTcnmsp7KYmaoqagaJBPnOkiiivcapIaWES19jk4b1rICRaQRH3oBCloTAXqasSHp-KgieZIexP7QM1LzfZY-iUndVmV2QNsxOTHfhr80E17hfdOGQA8dHy9tRd3ov_Fv0L_gT2mttWwpADz8PfgjgaP4-CTk9QnOeHAsccykkxTYW15yFZ7jql8-A-gqivgpjLvlXJLBdcHz3CsJgktv7UOo-Lcgoe1jSQYUNrSr-R26-ccrsoCxDMoHM7xN78C09PK09NK09NN6j6f1Hv9n7_G1pUIQelc2WFjmz-eD9NdjBYDX4_L7_X1s8jJKG0aeGNq9o45yGrlb2aucq0tYIZZNRtHuGIF2fyK4sryi-5cvwWz2CubYjmSkI93soePLBWNtfyGAAMMwzHJK84rMUloLcA5S0J5LP45EbV1j5VCWpfhjvfhpfRUde4-H26w-221xn62YFpmffgFKrMP6/images/i_puzzle-piece-solid.svg)

### PROMOTIONS

Seamlessly promote up-sell and cross-sell items, and send personalized content while the customer is shopping

![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcx-amplify/!ut/p/z1/tVXLdpswFPyWLlhiXd5ydkAT7FAXcIJt2ORgKh4tIAJKiPv1VZpN7bjhNCna6HVn7miOdIVitENxkzyWecJK2iQVn0exfufOVXOBbfAdT9YgWKlyaGwCxZFktEExitu0_IYiTcnmsp7KYmaoqagaJBPnOkiiivcapIaWES19jk4b1rICRaQRH3oBCloTAXqasSHp-KgieZIexP7QM1LzfZY-iUndVmV2QNsxOTHfhr80E17hfdOGQA8dHy9tRd3ov_Fv0L_gT2mttWwpADz8PfgjgaP4-CTk9QnOeHAsccykkxTYW15yFZ7jql8-A-gqivgpjLvlXJLBdcHz3CsJgktv7UOo-Lcgoe1jSQYUNrSr-R26-ccrsoCxDMoHM7xN78C09PK09NK09NN6j6f1Hv9n7_G1pUIQelc2WFjmz-eD9NdjBYDX4_L7_X1s8jJKG0aeGNq9o45yGrlb2aucq0tYIZZNRtHuGIF2fyK4sryi-5cvwWz2CubYjmSkI93soePLBWNtfyGAAMMwzHJK84rMUloLcA5S0J5LP45EbV1j5VCWpfhjvfhpfRUde4-H26w-221xn62YFpmffgFKrMP6/images/i_object-intersect-solid.svg)

### REPORTING

Daily reporting helps retailers track and optimize usage

![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcx-amplify/!ut/p/z1/tVXLdpswFPyWLlhiXd5ydkAT7FAXcIJt2ORgKh4tIAJKiPv1VZpN7bjhNCna6HVn7miOdIVitENxkzyWecJK2iQVn0exfufOVXOBbfAdT9YgWKlyaGwCxZFktEExitu0_IYiTcnmsp7KYmaoqagaJBPnOkiiivcapIaWES19jk4b1rICRaQRH3oBCloTAXqasSHp-KgieZIexP7QM1LzfZY-iUndVmV2QNsxOTHfhr80E17hfdOGQA8dHy9tRd3ov_Fv0L_gT2mttWwpADz8PfgjgaP4-CTk9QnOeHAsccykkxTYW15yFZ7jql8-A-gqivgpjLvlXJLBdcHz3CsJgktv7UOo-Lcgoe1jSQYUNrSr-R26-ccrsoCxDMoHM7xN78C09PK09NK09NN6j6f1Hv9n7_G1pUIQelc2WFjmz-eD9NdjBYDX4_L7_X1s8jJKG0aeGNq9o45yGrlb2aucq0tYIZZNRtHuGIF2fyK4sryi-5cvwWz2CubYjmSkI93soePLBWNtfyGAAMMwzHJK84rMUloLcA5S0J5LP45EbV1j5VCWpfhjvfhpfRUde4-H26w-221xn62YFpmffgFKrMP6/images/i_gears-solid.svg)

### ALERTS & MESSAGES

Send personalized content to the shopper during their in-store experience

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

## Designed for You

Give customers a more engaging, personalized shopping experience

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/b66c62e6-e67a-41f3-9ef6-497d98f8970b/2019-12-29+23_40_39-Toshiba+TCx%E2%84%A2Amplify+-+Using+Mobility+to+Enhance+the+In-Store+Shopping+Experience.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_GAAC1A02N8ABE0AVD86G7Q0421-b66c62e6-e67a-41f3-9ef6-497d98f8970b-o.ap3dl)\\
![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcx-amplify/!ut/p/z1/tVXLdpswFPyWLlhiXd5ydkAT7FAXcIJt2ORgKh4tIAJKiPv1VZpN7bjhNCna6HVn7miOdIVitENxkzyWecJK2iQVn0exfufOVXOBbfAdT9YgWKlyaGwCxZFktEExitu0_IYiTcnmsp7KYmaoqagaJBPnOkiiivcapIaWES19jk4b1rICRaQRH3oBCloTAXqasSHp-KgieZIexP7QM1LzfZY-iUndVmV2QNsxOTHfhr80E17hfdOGQA8dHy9tRd3ov_Fv0L_gT2mttWwpADz8PfgjgaP4-CTk9QnOeHAsccykkxTYW15yFZ7jql8-A-gqivgpjLvlXJLBdcHz3CsJgktv7UOo-Lcgoe1jSQYUNrSr-R26-ccrsoCxDMoHM7xN78C09PK09NK09NN6j6f1Hv9n7_G1pUIQelc2WFjmz-eD9NdjBYDX4_L7_X1s8jJKG0aeGNq9o45yGrlb2aucq0tYIZZNRtHuGIF2fyK4sryi-5cvwWz2CubYjmSkI93soePLBWNtfyGAAMMwzHJK84rMUloLcA5S0J5LP45EbV1j5VCWpfhjvfhpfRUde4-H26w-221xn62YFpmffgFKrMP6/images/i_play-red.svg)](https://youtu.be/1A3aL0txeL8 "")

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/ac7a90c0-9a9a-4d06-840f-09089b50aa99/One%2Bsolution%2Bfits%2Ball.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_GAAC1A02N8ABE0AVD86G7Q0421-ac7a90c0-9a9a-4d06-840f-09089b50aa99-o.appKY)

### Mobile shopping

Today's consumers expect to use mobile devices while shopping as mobility continues to dominate retail and influence shopper behaviors. Mobile shopping empowers you to engage shoppers throughout the shopping journey—creating new differentiating features while building brand value and loyalty.

With TCx Amplify, you can use mobile technology to meet customers where they are - on their own mobile phones or retailer-owned consumer devices – at time of decision. From self-scan in-store to personalized alerts, and from cross-channel transactions to loyalty discounts, TCx Amplify gives customers the power of choice, allowing them to shop at their own pace and convenience.

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcx-amplify/!ut/p/z1/tVXLdpswFPyWLlhiXd5ydkAT7FAXcIJt2ORgKh4tIAJKiPv1VZpN7bjhNCna6HVn7miOdIVitENxkzyWecJK2iQVn0exfufOVXOBbfAdT9YgWKlyaGwCxZFktEExitu0_IYiTcnmsp7KYmaoqagaJBPnOkiiivcapIaWES19jk4b1rICRaQRH3oBCloTAXqasSHp-KgieZIexP7QM1LzfZY-iUndVmV2QNsxOTHfhr80E17hfdOGQA8dHy9tRd3ov_Fv0L_gT2mttWwpADz8PfgjgaP4-CTk9QnOeHAsccykkxTYW15yFZ7jql8-A-gqivgpjLvlXJLBdcHz3CsJgktv7UOo-Lcgoe1jSQYUNrSr-R26-ccrsoCxDMoHM7xN78C09PK09NK09NN6j6f1Hv9n7_G1pUIQelc2WFjmz-eD9NdjBYDX4_L7_X1s8jJKG0aeGNq9o45yGrlb2aucq0tYIZZNRtHuGIF2fyK4sryi-5cvwWz2CubYjmSkI93soePLBWNtfyGAAMMwzHJK84rMUloLcA5S0J5LP45EbV1j5VCWpfhjvfhpfRUde4-H26w-221xn62YFpmffgFKrMP6/images/g_cta-dark-left-squares.svg)

## Specifications

Specification Summary [Download Specifications](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/cgvj/c191/~edisp/tcx_amplify_tech_specs_usen.pdf)

## **Software features** **:**

| Feature | Benefits |
| --- | --- |
| Retailer-branded smart phone shopping | Thin-client mobile shopping app for Android or iOS. Optionally integrated with existing retailer mobile applications. |
| In-aisle promotions | Architected to allow for up-sell and cross-selling of items while the customer is shopping—optionally using the POS Integration Hub which is based on Toshiba DIF software. |
| In-store alerts and messages to shoppers | Extensible capability to send personalized content to the shopper during their store experience—e.g. “fresh bread available in the bakery”, “your prescription is ready”, “see our daily specials”, etc. |
| State-of-the-art scanning capability with Honeywell Swift Decoder | This high-performance barcode scanning software provides consumer smart phones with fast and accurate scanning of barcodes from any direction on a product and reduces costly errors by eliminating misreads. |
| Sub-second response times | TCx Amplify is a store-optimized, high-performance solution, designed for the demanding high-volume retail store environment. |
| “My price” and “My total”—shoppers see their personalized, loyalty-based, discounted prices and totals during shopping | The solution is architected to leverage a single version of business logic for all touch points in the store (e.g. POS registers, self-checkout, and mobile) with respect to loyalty, pricing, discounts, and payments. TCx Amplify is not a “stand beside” solution—it’s tightly integrated with the POS system in the store. |
| Exception framework | Minimizes shopper interruptions during shopping, but protects the retailer by ensuring that any POS exceptions (e.g. age verification) are handled during checkout at the self-service pay station or other front-end POS register. |
| Trust Level Management | Makes auditing smarter by incorporating shopper history and other factors. TCx Amplify provides a configurable Trust Management Service. For retailers with an existing solution, it's also possible to leverage a retailer-provided trust service. |
| Wi-Fi offline capability | Shoppers can continue scanning items if a wi-fi disruption occurs; the solution will automatically “catch up” when wi-fi is restored. |
| Failover support for virtual sessions | If a controller that is maintaining a shopper’s transaction fails, the Mobile Engine will connect to backup controllers and replay the shopper’s transaction. This eliminates the need for the shopper to rescan their transaction. |
| Mobile session recovery on another phone | If a phone becomes disabled for some reason in the middle of a shopping trip, the shopper’s session can be recovered on another phone or a retailer-provided smart device using the shopper’s loyalty ID. |
| Price check | Shoppers can quickly check the price of any item before deciding to purchase. If implemented by the retailer, the price will be the shopper’s loyalty price. |
| Fast and easy check out—at any front-end register or a self-service pay station | The solution is pre-integrated with Toshiba checkout options, including standard POS registers (with SI GUI or VisualStore) and Toshiba Self-Checkout (with CHEC) or a mobile-optimized self-service pay station (also using CHEC). |
| Self-service scale | TCx Amplify provides a complete self-service scale capability that allows shoppers to easily self-weigh their fresh produce, then synchronize automatically to their smart phone label. (The self-service scale can optionally be configured to also print price-embedded barcode labels.) Combined with supported hardware components from Toshiba and 3rd-party scale manufacturers, this provides retailers a complete weights and measures certified solution for self-service weighing of produce items—ideal for the fresh foods area of the store. |
| Support for retailer owned consumer devices | Yet another way for retailers to let their customers shop the way they want to. TCx Amplify V1.4.1 provides support for:<br>Datalogic 9800i Models<br>Zebra MC18 Android<br>Datalogic Joya A6<br>Other devices can be supported through professional services |
| **Extensions for CHEC (self-checkout) and SI GUI (conventional POS register)** | Extensions are provided to allow any front-end register (whether self-checkout using CHEC or whether a conventional register using SI GUI) to be able to complete a mobile transaction. These extensions include the capability to handle exceptions (for example, age verification, audit required, and so on) as a seamless part of the front-end checkout process. |
| **Support for Mobile Payments** | TCx Amplify V.1.4.1 provides support for Mobile Payments (which encompass mobile wallets and mobile money transfers) and are an increasingly attractive way to pay because they’re secure, fast, and convenient. |
| Reporting | Daily reporting for statistics and utilization history—enables retailers to track usage and better understand how to optimize the solution operationally. |
| Associate line/queue busting solution for greater throughput and versatility during peak shopping periods | Retailers can better manage peak operating periods by deploying additional store associates to the front-end. Combined with supported retail-hardened smart devices and supported wireless printers, Toshiba TCx Amplify enables store associates to scan a customer's order while they wait in line, then print a suspend/retrieve label so they can complete their payment when they get to the register. This not only makes the line go faster, it also results in a net increase in total store throughput during the busiest shopping periods of the year. |
| Works with a variety of POS solutions | Works with Toshiba POS solutions including 4690 OS-based solutions (e.g. SurePOS ACE, SA, GSA, CDSA,SI V4R1, CHEC 7.1)  and VisualStore. Plus, it's architected as a highly-extensible solution that can integrate with additional or 3rd party POS systems. |
| Support for Apple Applications Certification | Retail built Apple applications now have the ability of demo mode to provide access to their actual app rather than a video of their app for certification. This demo mode does not access their core controller/system. |

[View full Technical Specifications](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/cgvj/c191/~edisp/tcx_amplify_tech_specs_usen.pdf)

![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcx-amplify/!ut/p/z1/tVXLdpswFPyWLlhiXd5ydkAT7FAXcIJt2ORgKh4tIAJKiPv1VZpN7bjhNCna6HVn7miOdIVitENxkzyWecJK2iQVn0exfufOVXOBbfAdT9YgWKlyaGwCxZFktEExitu0_IYiTcnmsp7KYmaoqagaJBPnOkiiivcapIaWES19jk4b1rICRaQRH3oBCloTAXqasSHp-KgieZIexP7QM1LzfZY-iUndVmV2QNsxOTHfhr80E17hfdOGQA8dHy9tRd3ov_Fv0L_gT2mttWwpADz8PfgjgaP4-CTk9QnOeHAsccykkxTYW15yFZ7jql8-A-gqivgpjLvlXJLBdcHz3CsJgktv7UOo-Lcgoe1jSQYUNrSr-R26-ccrsoCxDMoHM7xN78C09PK09NK09NN6j6f1Hv9n7_G1pUIQelc2WFjmz-eD9NdjBYDX4_L7_X1s8jJKG0aeGNq9o45yGrlb2aucq0tYIZZNRtHuGIF2fyK4sryi-5cvwWz2CubYjmSkI93soePLBWNtfyGAAMMwzHJK84rMUloLcA5S0J5LP45EbV1j5VCWpfhjvfhpfRUde4-H26w-221xn62YFpmffgFKrMP6/images/g_cta-dark-right-sqares.svg)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcx-amplify/!ut/p/z1/tVXLdpswFPyWLlhiXd5ydkAT7FAXcIJt2ORgKh4tIAJKiPv1VZpN7bjhNCna6HVn7miOdIVitENxkzyWecJK2iQVn0exfufOVXOBbfAdT9YgWKlyaGwCxZFktEExitu0_IYiTcnmsp7KYmaoqagaJBPnOkiiivcapIaWES19jk4b1rICRaQRH3oBCloTAXqasSHp-KgieZIexP7QM1LzfZY-iUndVmV2QNsxOTHfhr80E17hfdOGQA8dHy9tRd3ov_Fv0L_gT2mttWwpADz8PfgjgaP4-CTk9QnOeHAsccykkxTYW15yFZ7jql8-A-gqivgpjLvlXJLBdcHz3CsJgktv7UOo-Lcgoe1jSQYUNrSr-R26-ccrsoCxDMoHM7xN78C09PK09NK09NN6j6f1Hv9n7_G1pUIQelc2WFjmz-eD9NdjBYDX4_L7_X1s8jJKG0aeGNq9o45yGrlb2aucq0tYIZZNRtHuGIF2fyK4sryi-5cvwWz2CubYjmSkI93soePLBWNtfyGAAMMwzHJK84rMUloLcA5S0J5LP45EbV1j5VCWpfhjvfhpfRUde4-H26w-221xn62YFpmffgFKrMP6/images/g_cta-block-support-left.svg)![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcx-amplify/!ut/p/z1/tVXLdpswFPyWLlhiXd5ydkAT7FAXcIJt2ORgKh4tIAJKiPv1VZpN7bjhNCna6HVn7miOdIVitENxkzyWecJK2iQVn0exfufOVXOBbfAdT9YgWKlyaGwCxZFktEExitu0_IYiTcnmsp7KYmaoqagaJBPnOkiiivcapIaWES19jk4b1rICRaQRH3oBCloTAXqasSHp-KgieZIexP7QM1LzfZY-iUndVmV2QNsxOTHfhr80E17hfdOGQA8dHy9tRd3ov_Fv0L_gT2mttWwpADz8PfgjgaP4-CTk9QnOeHAsccykkxTYW15yFZ7jql8-A-gqivgpjLvlXJLBdcHz3CsJgktv7UOo-Lcgoe1jSQYUNrSr-R26-ccrsoCxDMoHM7xN78C09PK09NK09NN6j6f1Hv9n7_G1pUIQelc2WFjmz-eD9NdjBYDX4_L7_X1s8jJKG0aeGNq9o45yGrlb2aucq0tYIZZNRtHuGIF2fyK4sryi-5cvwWz2CubYjmSkI93soePLBWNtfyGAAMMwzHJK84rMUloLcA5S0J5LP45EbV1j5VCWpfhjvfhpfRUde4-H26w-221xn62YFpmffgFKrMP6/images/i_toolbox.svg)

## Product Support & Maintenance

Need help with your Toshiba product?

[Get Support](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcx-amplify/!ut/p/z1/tVXLdpswFPyWLlhiXd5ydkAT7FAXcIJt2ORgKh4tIAJKiPv1VZpN7bjhNCna6HVn7miOdIVitENxkzyWecJK2iQVn0exfufOVXOBbfAdT9YgWKlyaGwCxZFktEExitu0_IYiTcnmsp7KYmaoqagaJBPnOkiiivcapIaWES19jk4b1rICRaQRH3oBCloTAXqasSHp-KgieZIexP7QM1LzfZY-iUndVmV2QNsxOTHfhr80E17hfdOGQA8dHy9tRd3ov_Fv0L_gT2mttWwpADz8PfgjgaP4-CTk9QnOeHAsccykkxTYW15yFZ7jql8-A-gqivgpjLvlXJLBdcHz3CsJgktv7UOo-Lcgoe1jSQYUNrSr-R26-ccrsoCxDMoHM7xN78C09PK09NK09NN6j6f1Hv9n7_G1pUIQelc2WFjmz-eD9NdjBYDX4_L7_X1s8jJKG0aeGNq9o45yGrlb2aucq0tYIZZNRtHuGIF2fyK4sryi-5cvwWz2CubYjmSkI93soePLBWNtfyGAAMMwzHJK84rMUloLcA5S0J5LP45EbV1j5VCWpfhjvfhpfRUde4-H26w-221xn62YFpmffgFKrMP6/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fsupport)![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcx-amplify/!ut/p/z1/tVXLdpswFPyWLlhiXd5ydkAT7FAXcIJt2ORgKh4tIAJKiPv1VZpN7bjhNCna6HVn7miOdIVitENxkzyWecJK2iQVn0exfufOVXOBbfAdT9YgWKlyaGwCxZFktEExitu0_IYiTcnmsp7KYmaoqagaJBPnOkiiivcapIaWES19jk4b1rICRaQRH3oBCloTAXqasSHp-KgieZIexP7QM1LzfZY-iUndVmV2QNsxOTHfhr80E17hfdOGQA8dHy9tRd3ov_Fv0L_gT2mttWwpADz8PfgjgaP4-CTk9QnOeHAsccykkxTYW15yFZ7jql8-A-gqivgpjLvlXJLBdcHz3CsJgktv7UOo-Lcgoe1jSQYUNrSr-R26-ccrsoCxDMoHM7xN78C09PK09NK09NN6j6f1Hv9n7_G1pUIQelc2WFjmz-eD9NdjBYDX4_L7_X1s8jJKG0aeGNq9o45yGrlb2aucq0tYIZZNRtHuGIF2fyK4sryi-5cvwWz2CubYjmSkI93soePLBWNtfyGAAMMwzHJK84rMUloLcA5S0J5LP45EbV1j5VCWpfhjvfhpfRUde4-H26w-221xn62YFpmffgFKrMP6/images/g_cta-block-support-right.svg)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

## Featured

### Related Solutions

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/1a58e713-c31d-4457-b6c8-6d4ddba04af3/WW2020-Cross-Promotion-Space-ELERA.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_GAAC1A02N8ABE0AVD86G7Q0421-1a58e713-c31d-4457-b6c8-6d4ddba04af3-p8GrQ5A)\\
\\
**ELERA®**](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcx-amplify/!ut/p/z1/tVXLdpswFPyWLlhiXd5ydkAT7FAXcIJt2ORgKh4tIAJKiPv1VZpN7bjhNCna6HVn7miOdIVitENxkzyWecJK2iQVn0exfufOVXOBbfAdT9YgWKlyaGwCxZFktEExitu0_IYiTcnmsp7KYmaoqagaJBPnOkiiivcapIaWES19jk4b1rICRaQRH3oBCloTAXqasSHp-KgieZIexP7QM1LzfZY-iUndVmV2QNsxOTHfhr80E17hfdOGQA8dHy9tRd3ov_Fv0L_gT2mttWwpADz8PfgjgaP4-CTk9QnOeHAsccykkxTYW15yFZ7jql8-A-gqivgpjLvlXJLBdcHz3CsJgktv7UOo-Lcgoe1jSQYUNrSr-R26-ccrsoCxDMoHM7xN78C09PK09NK09NN6j6f1Hv9n7_G1pUIQelc2WFjmz-eD9NdjBYDX4_L7_X1s8jJKG0aeGNq9o45yGrlb2aucq0tYIZZNRtHuGIF2fyK4sryi-5cvwWz2CubYjmSkI93soePLBWNtfyGAAMMwzHJK84rMUloLcA5S0J5LP45EbV1j5VCWpfhjvfhpfRUde4-H26w-221xn62YFpmffgFKrMP6/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fsoftware%2Fsolutions-platform%2Felera?mapping=tgcs_new.portal.hardware)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/afa71f94-f30b-4ee6-b057-7184783cea31/WW2020-Cross-Promotion-Space-ACE.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_GAAC1A02N8ABE0AVD86G7Q0421-afa71f94-f30b-4ee6-b057-7184783cea31-p8Grz6Y)\\
\\
**SurePOS ACE**](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcx-amplify/!ut/p/z1/tVXLdpswFPyWLlhiXd5ydkAT7FAXcIJt2ORgKh4tIAJKiPv1VZpN7bjhNCna6HVn7miOdIVitENxkzyWecJK2iQVn0exfufOVXOBbfAdT9YgWKlyaGwCxZFktEExitu0_IYiTcnmsp7KYmaoqagaJBPnOkiiivcapIaWES19jk4b1rICRaQRH3oBCloTAXqasSHp-KgieZIexP7QM1LzfZY-iUndVmV2QNsxOTHfhr80E17hfdOGQA8dHy9tRd3ov_Fv0L_gT2mttWwpADz8PfgjgaP4-CTk9QnOeHAsccykkxTYW15yFZ7jql8-A-gqivgpjLvlXJLBdcHz3CsJgktv7UOo-Lcgoe1jSQYUNrSr-R26-ccrsoCxDMoHM7xN78C09PK09NK09NN6j6f1Hv9n7_G1pUIQelc2WFjmz-eD9NdjBYDX4_L7_X1s8jJKG0aeGNq9o45yGrlb2aucq0tYIZZNRtHuGIF2fyK4sryi-5cvwWz2CubYjmSkI93soePLBWNtfyGAAMMwzHJK84rMUloLcA5S0J5LP45EbV1j5VCWpfhjvfhpfRUde4-H26w-221xn62YFpmffgFKrMP6/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fsoftware%2Flegacy-systems%2Face?mapping=tgcs_new.portal.hardware)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/3cf13491-fd34-44dd-b8d9-6edf7f0bc58c/WW2020-Cross-Promotion-Space-Global-Services.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_GAAC1A02N8ABE0AVD86G7Q0421-3cf13491-fd34-44dd-b8d9-6edf7f0bc58c-p8GrwCA)\\
\\
**Professional Services**](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcx-amplify/!ut/p/z1/tVXLdpswFPyWLlhiXd5ydkAT7FAXcIJt2ORgKh4tIAJKiPv1VZpN7bjhNCna6HVn7miOdIVitENxkzyWecJK2iQVn0exfufOVXOBbfAdT9YgWKlyaGwCxZFktEExitu0_IYiTcnmsp7KYmaoqagaJBPnOkiiivcapIaWES19jk4b1rICRaQRH3oBCloTAXqasSHp-KgieZIexP7QM1LzfZY-iUndVmV2QNsxOTHfhr80E17hfdOGQA8dHy9tRd3ov_Fv0L_gT2mttWwpADz8PfgjgaP4-CTk9QnOeHAsccykkxTYW15yFZ7jql8-A-gqivgpjLvlXJLBdcHz3CsJgktv7UOo-Lcgoe1jSQYUNrSr-R26-ccrsoCxDMoHM7xN78C09PK09NK09NN6j6f1Hv9n7_G1pUIQelc2WFjmz-eD9NdjBYDX4_L7_X1s8jJKG0aeGNq9o45yGrlb2aucq0tYIZZNRtHuGIF2fyK4sryi-5cvwWz2CubYjmSkI93soePLBWNtfyGAAMMwzHJK84rMUloLcA5S0J5LP45EbV1j5VCWpfhjvfhpfRUde4-H26w-221xn62YFpmffgFKrMP6/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fservices%2Fimplement%2Fprofessional-services?mapping=tgcs_new.portal.hardware)

![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcx-amplify/!ut/p/z1/tVXLdpswFPyWLlhiXd5ydkAT7FAXcIJt2ORgKh4tIAJKiPv1VZpN7bjhNCna6HVn7miOdIVitENxkzyWecJK2iQVn0exfufOVXOBbfAdT9YgWKlyaGwCxZFktEExitu0_IYiTcnmsp7KYmaoqagaJBPnOkiiivcapIaWES19jk4b1rICRaQRH3oBCloTAXqasSHp-KgieZIexP7QM1LzfZY-iUndVmV2QNsxOTHfhr80E17hfdOGQA8dHy9tRd3ov_Fv0L_gT2mttWwpADz8PfgjgaP4-CTk9QnOeHAsccykkxTYW15yFZ7jql8-A-gqivgpjLvlXJLBdcHz3CsJgktv7UOo-Lcgoe1jSQYUNrSr-R26-ccrsoCxDMoHM7xN78C09PK09NK09NN6j6f1Hv9n7_G1pUIQelc2WFjmz-eD9NdjBYDX4_L7_X1s8jJKG0aeGNq9o45yGrlb2aucq0tYIZZNRtHuGIF2fyK4sryi-5cvwWz2CubYjmSkI93soePLBWNtfyGAAMMwzHJK84rMUloLcA5S0J5LP45EbV1j5VCWpfhjvfhpfRUde4-H26w-221xn62YFpmffgFKrMP6/images/i_swiper-next-dark.svg)

![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcx-amplify/!ut/p/z1/tVXLdpswFPyWLlhiXd5ydkAT7FAXcIJt2ORgKh4tIAJKiPv1VZpN7bjhNCna6HVn7miOdIVitENxkzyWecJK2iQVn0exfufOVXOBbfAdT9YgWKlyaGwCxZFktEExitu0_IYiTcnmsp7KYmaoqagaJBPnOkiiivcapIaWES19jk4b1rICRaQRH3oBCloTAXqasSHp-KgieZIexP7QM1LzfZY-iUndVmV2QNsxOTHfhr80E17hfdOGQA8dHy9tRd3ov_Fv0L_gT2mttWwpADz8PfgjgaP4-CTk9QnOeHAsccykkxTYW15yFZ7jql8-A-gqivgpjLvlXJLBdcHz3CsJgktv7UOo-Lcgoe1jSQYUNrSr-R26-ccrsoCxDMoHM7xN78C09PK09NK09NN6j6f1Hv9n7_G1pUIQelc2WFjmz-eD9NdjBYDX4_L7_X1s8jJKG0aeGNq9o45yGrlb2aucq0tYIZZNRtHuGIF2fyK4sryi-5cvwWz2CubYjmSkI93soePLBWNtfyGAAMMwzHJK84rMUloLcA5S0J5LP45EbV1j5VCWpfhjvfhpfRUde4-H26w-221xn62YFpmffgFKrMP6/images/i_swiper-prev-dark.svg)

Start a conversation

First name

Last name

Email

Company

Country

Phone

I am a

Business PartnerOtherPress / AnalystRetailerSupplierToshiba Employee

- Business Partner

- Other

- Press / Analyst

- Retailer

- Supplier

- Toshiba Employee


My Retail Segment

Fashion & ApparelFood ServiceGas & ConvenienceGroceryMass MerchandiseOtherPharmacy / Drug StoreSpecialty

- Fashion & Apparel

- Food Service

- Gas & Convenience

- Grocery

- Mass Merchandise

- Other

- Pharmacy / Drug Store

- Specialty


I am interested in learning more about

Add me to Toshiba Global Commerce Solutions' email marketing list

I am allowing Toshiba to contact me in regards to the information on this form

Comments

By submitting this form I agree that Toshiba Global Commerce Solutions, Inc. and its affiliates, including all subsidiaries and branches, may process my data as indicated above and as described in the [Toshiba Global Commerce Solutions Privacy Declaration.](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/common-content/general-content/privacy-policy&mapping=tgcs_new.portal.generaldetails)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**

reCAPTCHA is changing its terms of service. [Take action.](https://google.com/recaptcha/admin/migrate)

![success](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcx-amplify/!ut/p/z1/tVXLdpswFPyWLlhiXd5ydkAT7FAXcIJt2ORgKh4tIAJKiPv1VZpN7bjhNCna6HVn7miOdIVitENxkzyWecJK2iQVn0exfufOVXOBbfAdT9YgWKlyaGwCxZFktEExitu0_IYiTcnmsp7KYmaoqagaJBPnOkiiivcapIaWES19jk4b1rICRaQRH3oBCloTAXqasSHp-KgieZIexP7QM1LzfZY-iUndVmV2QNsxOTHfhr80E17hfdOGQA8dHy9tRd3ov_Fv0L_gT2mttWwpADz8PfgjgaP4-CTk9QnOeHAsccykkxTYW15yFZ7jql8-A-gqivgpjLvlXJLBdcHz3CsJgktv7UOo-Lcgoe1jSQYUNrSr-R26-ccrsoCxDMoHM7xN78C09PK09NK09NN6j6f1Hv9n7_G1pUIQelc2WFjmz-eD9NdjBYDX4_L7_X1s8jJKG0aeGNq9o45yGrlb2aucq0tYIZZNRtHuGIF2fyK4sryi-5cvwWz2CubYjmSkI93soePLBWNtfyGAAMMwzHJK84rMUloLcA5S0J5LP45EbV1j5VCWpfhjvfhpfRUde4-H26w-221xn62YFpmffgFKrMP6/images/tgcs/success.svg)

## Success!

Thank you for reaching out. One of our team members will be in contact soon. We hope you have a great day.

Close

Complementary
Content

[Deferred Modules](https://commerce.toshiba.com/wps/contenthandler/marketing/!ut/p/digest!M6zrA0PEiotCbddBEGnoVg/mashup/ra:collection?themeID=ZJ_JQGEHK01N0LM806KGPAKPA0UO0&locale=en&mime-type=text%2Fjavascript&lm=1778793196000&entry=st_skin__0.0%3Aconfig_js&entry=wp_liveobject_framework_core__0.0%3Aconfig_js&entry=wp_portal_ui_utils__0.0%3Aconfig_js&entry=wp_contextmenu_js__0.0%3Aconfig_js&entry=wp_skin_cam__0.0%3Aconfig_js&entry=wp_contextmenu_config_lof__0.0%3Aconfig_js&entry=wp_federated_documents_picker__0.0%3Aconfig_js&entry=wp_dnd_main__0.0%3Aconfig_js&entry=wp_movecontrols__0.0%3Aconfig_js&entry=wp_toolbar_controlactions__0.0%3Aconfig_js&entry=wp_content_targeting_cam__0.0%3Aconfig_js&deferred=true)

- ${title}${badge}

${loading}

[Deferred Modules](https://commerce.toshiba.com/wps/contenthandler/marketing/!ut/p/digest!SpZvrtUURDcRHYzcbiqg-Q/mashup/ra:collection?themeID=ZJ_JQGEHK01N0LM806KGPAKPA0UO0&locale=en&mime-type=text%2Fplain&entry=wp_contextmenu_templates__0.0%3Aconfig_markup&entry=wp_skin_cam__0.0%3Aconfig_markup&entry=wp_dnd_main__0.0%3Aconfig_markup&deferred=true)