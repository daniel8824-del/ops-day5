<!-- source: https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/marketplace/citcon/!ut/p/z1/tZFfb4IwFMU_yx58JL20BeojMlcZI-AWFXgxwEDr5I-u0-3bry4-OLPNLIa-NDc9-Z3Tc1GCIpTU6U4sUimaOl2rOU7Muden9og5ELLAHcLYD7hHH24BTIpmlwSJeoZfjg1oihKUtLl4RrFBMt3SaamZmBUaJX2qsYyZGjZKyExKmMXKgzqvZSuXKC5q7e21B8umKnpQpduXQrbrNFdDLmTe1Oj-y_yPbOp3eOs7_kJFSOVSE3XZoOgEhaIjSinFarNJbGXf1LJ4lyi66D87pD1NwEPbgbE54SFzHUKn5lFw3srgEQ8IAA_wj4JvBcZqAdbc7esYPA8CbnCA8RBbuntHFAPQbCeKPZrUzbZSC336Z9-jiw74SocLeL1bPOkUz6FbfLfd826759d231aTihFjvfogIMLKyZg_JMaimp9fe_vmE6-ocd0! -->

![logo](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/marketplace/citcon/!ut/p/z1/tVRNU4MwFPwtHjjSPAjQ1BtiTbF22uq0pVw6gOGjQoI0tvrvTdWD34zjkEsmyWZ3s29eUIgCFPJoX2SRLASPSrVeh85mPLDcEfFgRqb-EOaTKR1bV-cAjoVWbYBQHcMPwwW0RCEK66S4RWsbx0bfsFLdMQnTLTywdBITRzftFGLHwqRP0iM64bKWOVozrj_sNMhFxTSoouaOybqMErVICpkIji5fxH_xpl5nNhNvkikLkcz1gqcCBe-oUPBGpZDF9v4-dJW84JI9ShS06q-Obt87oDPXg7mzoDPie9haOm-Az6mcXZtnGIBOzW8BHwJcqwL0N_7AMGE8him1KcB8aPYN_wIrDkCrfcEOaMFFU6mC3vwx71GrgvlPhRZ6o1t63Ck9hW7pu82edps9_W_2qr-zUsSv35TLY0xUIzcsZQ1reg-N2s6lrHenGmhwOBx6mRBZyXqJqDT47koudqqtPyJRXS0qgu1y-4ShmFVeTCZDbGfV5utU7q_ck2cDATTJ/images/logo.png)X

Sign in to your Toshiba account

For optimum experience,
please log in on your desktop computer

UserName

Password

Sign In [Forgot password?](https://www.toshibacommerce.com/tgcs109/tsim/forgotpassword.do) [Enterprise Login](https://www.toshibacommerce.com/mga/sps/authsvc?PolicyId=urn:ibm:security:authentication:asf:externalIDPLogin&target=https%3A%2F%2Ftoshibacommerce.com%2Fwps%2Fmyportal)

Don't have an ID? [Request one here](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/faqs)

{"Z7\_I9120KK0OG5G00QE271IF33000":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OG5G00QE271IF33002":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OG5G00QE271IF33001":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OG5G00QE271IF33003":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OG5G00QE271IF330G0":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OG5G00QE271IF330G2":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OG5G00QE271IF330G1":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OG5G00QE271IF330G3":{"windowState":"normal","portletMode":"view"}}

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

# Global Payments Platform

## Citcon

Equipping merchants with the ability to accept alternative payments methods (e-wallets, Buy Now Pay Later, and others) via Toshiba Elera and ACE platforms

PARTNER LEVEL:Premier

CATEGORY:Payments

SOLUTION:ELERA, ACE / CHEC

RETAIL SEGMENT:grocery / general merchandise

REGION :north america​


[Learn More](https://citcon.com/)

![banner-image](https://commerce.toshiba.com/wps/wcm/connect/marketing/530c36c5-e15a-4ac6-8896-3c85fdfc9018/Citcon-Marketplace-Partner-Card-square-diamond-logo.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_GAAC1A02N8ABE0AVD86G7Q0421-530c36c5-e15a-4ac6-8896-3c85fdfc9018-pNTOg6S)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![](https://commerce.toshiba.com/wps/contenthandler/dav/fs-type1/themes/TGCSMarketingThemeV2/images/g_cta-dark-left-squares.svg)

## Interested in listing your product on the Toshiba Commerce Marketplace?

[Learn More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/marketplace/aboutthemarketplace) [Join Now](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/partners/together-commerce-alliance-program/#anchor-partner-program-guide)

![](https://commerce.toshiba.com/wps/contenthandler/dav/fs-type1/themes/TGCSMarketingThemeV2/images/g_cta-dark-right-sqares.svg)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

Start a conversation

First name

Last name

Email

Company

Country

Phone

I am a

Business PartnerOtherPress / AnalystRetailerSupplierToshiba Employee

- Business Partner

- Other

- Press / Analyst

- Retailer

- Supplier

- Toshiba Employee


My Retail Segment

Fashion & ApparelFood ServiceGas & ConvenienceGroceryMass MerchandiseOtherPharmacy / Drug StoreSpecialty

- Fashion & Apparel

- Food Service

- Gas & Convenience

- Grocery

- Mass Merchandise

- Other

- Pharmacy / Drug Store

- Specialty


I am interested in learning more about

Add me to Toshiba Global Commerce Solutions' email marketing list

I am allowing Toshiba to contact me in regards to the information on this form

Comments

By submitting this form I agree that Toshiba Global Commerce Solutions, Inc. and its affiliates, including all subsidiaries and branches, may process my data as indicated above and as described in the [Toshiba Global Commerce Solutions Privacy Declaration.](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/common-content/general-content/privacy-policy&mapping=tgcs_new.portal.generaldetails)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**

reCAPTCHA is changing its terms of service. [Take action.](https://google.com/recaptcha/admin/migrate)

![success](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/marketplace/citcon/!ut/p/z1/tVRNU4MwFPwtHjjSPAjQ1BtiTbF22uq0pVw6gOGjQoI0tvrvTdWD34zjkEsmyWZ3s29eUIgCFPJoX2SRLASPSrVeh85mPLDcEfFgRqb-EOaTKR1bV-cAjoVWbYBQHcMPwwW0RCEK66S4RWsbx0bfsFLdMQnTLTywdBITRzftFGLHwqRP0iM64bKWOVozrj_sNMhFxTSoouaOybqMErVICpkIji5fxH_xpl5nNhNvkikLkcz1gqcCBe-oUPBGpZDF9v4-dJW84JI9ShS06q-Obt87oDPXg7mzoDPie9haOm-Az6mcXZtnGIBOzW8BHwJcqwL0N_7AMGE8him1KcB8aPYN_wIrDkCrfcEOaMFFU6mC3vwx71GrgvlPhRZ6o1t63Ck9hW7pu82edps9_W_2qr-zUsSv35TLY0xUIzcsZQ1reg-N2s6lrHenGmhwOBx6mRBZyXqJqDT47koudqqtPyJRXS0qgu1y-4ShmFVeTCZDbGfV5utU7q_ck2cDATTJ/images/tgcs/success.svg)

## Success!

Thank you for reaching out. One of our team members will be in contact soon. We hope you have a great day.

Close

Complementary
Content

[Deferred Modules](https://commerce.toshiba.com/wps/contenthandler/marketing/!ut/p/digest!M6zrA0PEiotCbddBEGnoVg/mashup/ra:collection?themeID=ZJ_GAAC1A02N0K0706RHNLD121AS3&locale=en&mime-type=text%2Fjavascript&lm=1778793196000&entry=st_skin__0.0%3Aconfig_js&entry=wp_liveobject_framework_core__0.0%3Aconfig_js&entry=wp_portal_ui_utils__0.0%3Aconfig_js&entry=wp_contextmenu_js__0.0%3Aconfig_js&entry=wp_skin_cam__0.0%3Aconfig_js&entry=wp_contextmenu_config_lof__0.0%3Aconfig_js&entry=wp_federated_documents_picker__0.0%3Aconfig_js&entry=wp_dnd_main__0.0%3Aconfig_js&entry=wp_movecontrols__0.0%3Aconfig_js&entry=wp_toolbar_controlactions__0.0%3Aconfig_js&entry=wp_content_targeting_cam__0.0%3Aconfig_js&deferred=true)

- ${title}${badge}

${loading}

[Deferred Modules](https://commerce.toshiba.com/wps/contenthandler/marketing/!ut/p/digest!SpZvrtUURDcRHYzcbiqg-Q/mashup/ra:collection?themeID=ZJ_GAAC1A02N0K0706RHNLD121AS3&locale=en&mime-type=text%2Fplain&entry=wp_contextmenu_templates__0.0%3Aconfig_markup&entry=wp_skin_cam__0.0%3Aconfig_markup&entry=wp_dnd_main__0.0%3Aconfig_markup&deferred=true)

reCAPTCHA