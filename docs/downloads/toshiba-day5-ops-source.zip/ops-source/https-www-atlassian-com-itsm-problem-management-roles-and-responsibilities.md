<!-- source: https://www.atlassian.com/itsm/problem-management/roles-and-responsibilities -->

Get it free

Search

Sign in

Jira Service Management is now more powerful than ever as part of Service Collection. Unlock exceptional service experiences with Rovo, Assets, and our new Customer Service Management app.

[Try it now](https://www.atlassian.com/try/cloud/signup?bundle=service-collection&edition=premium)

# Problem management roles and responsibilities

[Problem management](https://www.atlassian.com/itsm/problem-management) is about more than just finding and fixing incidents. Real problem management lies in identifying and understanding the underlying causes of an incident as well as identifying the best method to eliminate that root cause.

[Get it free](https://www.atlassian.com/software/jira/service-management/free)

That’s why effective problem management efforts consist of teams operating under clear roles and responsibilities. Team members understand what the roles are, what each person is responsible for, and who is in each role during a problem investigation.

Here are a few of the most common problem management roles. It’s important to understand that not every team will operate with every role on this list. And these aren’t necessarily permanent roles. Instead, think of them as designations for a team that comes together to work on a particular problem.

## Problem manager

The problem owner manages the overall process for a specific problem. They coordinate and direct all facets of the problem management effort, including bringing the right teams, tools, and information together. The problem manager may also delegate subtasks to other team members as they see fit.

**Also called**: Problem owner, Major Incident Manager

## Process owner

The process owner is responsible for the overall health and success of the team’s problem management process. They oversee evolution and development of the process, as well as team member training and onboarding.

**Also called**: Process manager, process coordinator

## Service owner

The service owner is responsible for defining ongoing operations and health of the service. This can include measuring and reporting on the value of changes, enhancements, planned downtime, training, documentation, and more.

**Also called**: Service leader, product manager

## Service desk agent

Front-line support for your [service desk](https://www.atlassian.com/itsm/service-request-management/how-to-build-a-service-desk). The service desk agent is often the first to notice and report an incident or problem. The agent is often also the first person to notice that several unique incidents all relate to a greater problem.

**Also called**: Agent, Service agent, Support Agent, Help desk agent, Service desk analyst

## Tech lead

An individual familiar with the impacted service experiencing a problem or incident. Often a developer or engineer, the tech lead can dive into recent code changes to see what root causes may be contributing to the problem.

**Also called**: Technical lead, subject matter expert, on-call engineer, developer, software developer, Site Reliability Engineer (SRE)

## Stakeholders

Stakeholders can be whoever needs high-level info on the problem but isn’t directly involved in the problem management process. This can be anyone from adjacent teams, to customers, and organizational leaders.

**Also called**: Customers, executive teams, vendors, end users, business teams

[Free problem management template](https://www.atlassian.com/itsm/problem-management/template)

## Recommended for you

WHITEPAPER

### Atlassian's guide to agile ways of working with ITIL 4

ITIL 4 is here—and it’s more agile than ever. Learn tips to bring agility and collaboration into ITSM with Atlassian.

[Read the whitepaper](https://www.atlassian.com/whitepapers/itil4)

### IT Change Management: ITIL Framework & Best Practices

IT Change Management minimizes risk while making changes to systems and services. Learn about the change management process, its importance, best practices

[Read this article](https://www.atlassian.com/itsm/change-management)

### Learn more about ITSM

Find more ITSM guides and resources in this hub.

[Read this article](https://www.atlassian.com/itsm)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**