<!-- source: https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-tcx800-sitearea -->

![logo](https://commerce.toshiba.com/wps/portal/marketing/product-support/support-hardware/support-tcx800-sitearea/!ut/p/z1/tVTZcoIwFP0aHmOugBj6hsuAdRi1rRsvnQBhaYXQEKX9-8a208XpMh01Lwk35557ktwDDvAKByXd5SmVOS_pRn2vA-t2ZLd1GI9h4g68Icz8RW80bbugBl7gAAdVlMd4DZaVdHQ7RKQTJsgEAsiO7RhFYWQSSqgVUbpHR6WsZIbXrETbWoOMF0yDeltVXEgNKsHjbSTRe-BtgTIq4oaKDyyS0SMBQHUumYpTvPxLbKC24YfhgMoPXiBj23Q80oepO3X6MLPm7pSM-oa5sN4Ah5m9K71nALgT_VvAlyJrJbL7s8gOXu5y1uB5yUWhHuD6n_fr_Vmhe2SF3-ld87z01mnpJwNvALOhP18443Z73yNnpdePpL986a5fOlz5VRd-308VLZUZysuE49WBp_Dq0FMfkUNPKcL87uEhcJRveSnZo8o-uXHVsdIND1__N04ZGkTpFyxhgonWVqhwJmVVX2igQdM0rZTzdMNaES80-C4l47WS-RWJq6IgxhO6vyLNTZKlxa0_NDqfptrb7IolqZ8BTVQHjg!!/images/logo.png)X

Sign in to your Toshiba account

For optimum experience,
please log in on your desktop computer

UserName

Password

Sign In [Forgot password?](https://www.toshibacommerce.com/tgcs109/tsim/forgotpassword.do) [Enterprise Login](https://www.toshibacommerce.com/mga/sps/authsvc?PolicyId=urn:ibm:security:authentication:asf:externalIDPLogin&target=https%3A%2F%2Ftoshibacommerce.com%2Fwps%2Fmyportal)

Don't have an ID? [Request one here](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/faqs)

{"Z7\_I9120KK0OGDHE0QMVBIP1G0005":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OGDHE0QMVBIP1G0007":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OGDHE0QMVBIP1G00G4":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OGDHE0QMVBIP1G00G6":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OODHD0QEMUVAK11000":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OODHD0QEMUVAK11002":{"windowState":"normal","portletMode":"view"}}

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

# TCx® 800, TCx® 810 & 810E Support

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/ec875807-11ca-4bce-8bf5-e022c12ad1b7/1/img.png?MOD=AJPERES)

The downloads below are divided into 2 sections, files that are publicly accessible to anyone and files that are restricted to those with an Enterprise ID ([learn more](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/faqs ""))

* * *

###### Drivers & Information common to all products

There are multiple cross-platform packages available (including Diagnostics, UPOS Drivers, RMA, MUS, NWD and VSP) as well as system unit drivers that apply to multiple machine types (including touch screen & biometric drivers)

[View common packages & drivers](https://commerce.toshiba.com/wps/portal/marketing?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-commonpackages-sitearea "")

The document below shows which operating systems are supported across different processors and TGCS plaforms, to better enable viable operating system upgrade options for different POS terminal models.

[TGCS hardware & OS compatibility matrix](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/windows-compatibility)

If all you have is a 4-digit machine type or 7-digit machine-type/model number and you are not sure which product you have you can refer to the [Support by Machine Type](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-MTM-lookup) page.

Security and vulnerability issues can be reported via the [Product Security](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-security) page

Regulatory compliance documents can be found using the red Documentation & Publication icon at the bottom of the [Support home page](https://commerce.toshiba.com/support). These documents available include

- EU 617/2013 power consumption reports for system units
- Taiwan Bureau of Standards, Metrology and Inspection reports for Restriction of Hazardous Substance (RoHS)
- UN38.3 reports for shipping of lithium batteries
- Turkish EPREL reports

###### Machine type & Model information

Machine type & model information for TCx 800

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
| **Machine Type** | **Model** | **1st Digit** | **2nd Digit** | **3rd Digit** |
| 6200 | 1xx | 1=1st generation<br> E=Windows preload OS | 0=15” 4:3 ratio<br> 1=15.6” 16:9 ratio<br> 3=18.5” 16:9 ratio | C=Celeron CPU<br> 5=i5 CPU |

Machine type & model information for TCx 810

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
| **Machine Type** | **Model** | **1st Digit** | **2nd Digit** | **3rd Digit** |
| 6201 | 2xx | 2=2nd generation<br> E=Windows preload OS | 5=15” 4:3 ratio<br> 6=15.6” 16:9 ratio<br> 9=19.5” 16:9 ratio | C=Celeron CPU<br> 3=i3 CPU<br> 5=i5 CPU<br> 7=i7 CPU |

Machine type & model information for TCx 810E

|     |     |     |     |     |
| --- | --- | --- | --- | --- |
| **Machine Type** | **Model** | **1st Digit** | **2nd Digit** | **3rd Digit** |
| 4828 | 2xx | E=Windows preload OS<br> T=4818-T10 replacement | 2=2nd generation “AIO Lite” | C=Celeron CPU<br> 5=i5 CPU |

###### Public content (OS Drivers)

27.20.100.9171Content below is publicly available to anyone at no cost

**TCx 810E (4828-x2x)**

Linux requires a [4.19 kernel](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/windows-compatibility); additional drivers not shipped as part of the kernel distribution are listed below.

_Audio_

- Windows 10

[4828-x2x\_Audio\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/zglv/x3dp/~edisp/4828-x2x_audio_win10.zip) (6.0.9116.1, 22 November 2021)

_Bluetooth_

- Windows 10 & Windows 11

[4828-x2x\_BT\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/x2j0/x3dp/~edisp/4828-x2x_bt_win10.zip) (23.100.0, 22 May 2025)

_Chipset_

- Windows 10

[4828-x2x\_Chipset\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/c2v0/x3dp/~edisp/4828-x2x_chipset_win10.zip) (10.1.19502.8391, 11 April 2024)

_LAN_

- Windows 10

[4828-x2x\_LAN\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/bgfu/x3dp/~edisp/4828-x2x_lan_win10.zip) (30.0.0.0, 22 May 2025)

_Management Engine_

- Windows 10

[4828-x2x\_ME\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/x21l/x3dp/~edisp/4828-x2x_me_win10.zip) (2435.6.36.0, 22 May 2025)

_Rapid Storage Technology_

- Windows 10

[4828-x2x\_RST\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/cnn0/x3dp/~edisp/4828-x2x_rst_win10.zip) (2435.6.36.0, 27 May 2025) _for internet connected machines_

[4828-x2x\_RST(offline)\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/bmup/x3dp/~edisp/4828-x2x_rst(offline)_win10.zip) (17.9.1008.0, 23 November 2021) _for internet inaccessible machines_

_Serial (System Unit)_

- Windows 10

[4828-x2x\_Serial\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/awfs/x3dp/~edisp/4828-x2x_serial_win10.zip) (30.100.2020.7, 22 November 2021)

_Touchscreen_

Use the touch drivers from the [Common packages & drivers](https://commerce.toshiba.com/wps/portal/marketing?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-commonpackages-sitearea) page

_USB-RS232 Dongle_

- Linux

Driver source available at [https://github.com/WCHSoftGroup/ch343ser\_linux](https://github.com/WCHSoftGroup/ch343ser_linux)

_Video (Main Display)_

- Windows 10

[4828-x2x\_Video\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/zgvv/x3dp/~edisp/4828_x2x_video_win10.zip) (27.20.100.9168, 22 November 2021) _for internet connected machines_

[4828-x2x\_Video(offline)\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/bmup/x3dp/~edisp/4828-x2x_video(offline)_win10.zip) (1.100.3325.0, 22 November 2021) _for internet inaccessible machines_

_Video (10.1" Display)_

- Windows 10

[4828-x2x\_SecondaryVideo\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/zgvv/x3dp/~edisp/4828-x2x_secondaryvideo_win10.zip) (10.1.2762.0, 22 November 2021)

- Linux

[displaylink-driver-5.4.0-55.153.run](https://www.displaylink.com/) (via [https://www.displaylink.com/](https://www.displaylink.com/)) (22 November 2021)

_Wi-Fi_

- Windows 10 & Windows 11

[4828-x2x\_Wifi\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/awzp/x3dp/~edisp/4828-x2x_wifi_win10.zip) (23.110.0, 22 May 2025)

- Linux

[4828-x2x\_Wifi\_Lnx.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/awzp/x2xp/~edisp/4828-x2x_wifi_linux.zip) (34.618819.0, 23 November 2021)

**TCx 810 (6201-xxC/xx3/xx5/xx7)**

Linux requires a [5.8 kernel](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/windows-compatibility); additional drivers not shipped as part of the kernel distribution are listed below.

_Accelerometer_

- Windows 10

[6201-xxx\_Accelerometer\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/dgvy/x3dp/~edisp/6201-xxx_accelerometer_win10.zip) (3.10.100.4477, 9 October 2025)

_Audio_

- Windows 10

[6201-xxx\_Audio\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/zglv/x3dp/~edisp/6201-xxx_audio_win10.zip) (6.0.9116.1, 17 November 2021)

_Biometric_

Please refer to the [I/O Devices Support](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-peripheral) page

_Bluetooth_

- Windows 10

[6201-xxx\_BT\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/x2j0/x3dp/~edisp/6201-xxx_bt_win10.zip) (23.100.1, 9 October 2025)

_Chipset_

- Windows 10

[6201-xxx\_Chipset\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/c2v0/x3dp/~edisp/6201-xxx_chipset_win10.zip) (10.1.19913.8607, 9 October 2025)

_Network_

- Windows 10

[6201-xxx\_LAN\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/bgfu/x3dp/~edisp/6201-xxx_lan_win10.zip) (30.1.0.2, 9 October 2025)

_Management Engine_

- Windows 10

[6201-xxx\_ME\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/x21l/x3dp/~edisp/6201-xxx_me_win10.zip) (2233.3.26.0, 28 September 2023)

_Rapid Storage Technology_

- Windows 10

[6201-xxx\_RST\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/cnn0/x3dp/~edisp/6201-xxx_rst_win10.zip) (18.8.0.1007, 9 October 2025) _for internet connected machines_

[6201-xxx\_RST(offline)\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/bmup/x3dp/~edisp/6201-xxx_rst(offline)_win10.zip) (18.1.1041.0, 9 October 2025)  _for internet inaccessible machines_

_Serial (Base / Stand)_

- Windows 10

[6201-xxx\_BaseSerial\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/awfs/x3dp/~edisp/6201-xxx_baseserial_win10.zip) (6.7.6.2130, 17 November 2021)

- Linux

[6201-xxx\_BaseSerial\_Lnx.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/zxjp/ywxf/~edisp/6201-xxx_baseserial_lnx.zip) (3.x, 17 November 2021)

_Serial (System Unit)_

- Windows 10

[6201-xxx\_HeadSerial\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/awfs/x3dp/~edisp/6201-xxx_headserial_win10.zip) (30.100.2129.8, 9 October 2025)

_USB-RS232 Dongle_

- Linux

Driver source available at [https://github.com/WCHSoftGroup/ch343ser\_linux](https://github.com/WCHSoftGroup/ch343ser_linux)

_Touchscreen_

Use the touch drivers from the [Common packages & drivers](https://commerce.toshiba.com/wps/portal/marketing?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-commonpackages-sitearea) page

_Video (Main Display)_

- Windows 10

[6201-xxx\_Video\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/zgvv/x3dp/~edisp/6201-xxx_video_win10.zip) (32.0.101.5768, 3 November 2025)

[6201-xxx\_Video(Intel GCC)\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/y2mp/x3dp/~edisp/6201-xxx_video(igcc)_win10.zip) (1.100.5687.0, 3 November 2025)

_Video (10.1" Display)_

- Windows 10

[6201-xxx\_SecondaryVideo\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/zgvv/x3dp/~edisp/6201-xxx_secondaryvideo_win10.zip) (10.1.2762.0, 17 November 2021)

- Linux

[displaylink-driver-5.4.0-55.153.run](https://www.displaylink.com/) (via [https://www.displaylink.com/](https://www.displaylink.com/)) (17 November 2021)

_Wi-Fi_

- Windows 10

[6201-xxx\_Wifi\_Win10.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/awzp/x3dp/~edisp/6201-xxx_wifi_win10.zip) (23.110.0, 9 October 2025)

- Linux

[6201-xxx\_Wifi\_Lnx.zip](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/x3dp/zmlf/~edisp/6201-xxx_wifi_lnx.zip) (34.618819.0, 17 November 2021)

**TCx 800 (6200-xxC/xx3/xx5/xx7)**

Linux requires a [4.4 kernel](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/windows-compatibility); additional drivers not shipped as part of the kernel distribution are listed below.

_Accelerometer_

- Windows 10 LTSB 2016

[6200-1xx\_ACCELEROMETER\_W10.zip](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/bwv0/zxjf/~edisp/6200-1xx_accelerometer_w10.zip) (v4.22.0092, 14 November 2018)

- Windows 10 LTSC 2019

[6200-1xx\_ACCELEROMETER\_LTSC2019.zip](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/x2x0/c2my/~edisp/6200-1xx_accel_ltsc2019.zip) (v3.0.1.0, 21 June 2019)

_Audio_

- Windows 10

[6200-1xx\_AUDIO\_W10.zip](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/yxvk/aw9f/~edisp/6200-1xx_audio_w10.zip) (v6.0.9132.1, 3 June 2021)

_Biometric_

Please refer to the [I/O Devices Support](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-peripheral) page

_Chipset_

- Windows 10 (all versions)

[6200-1xx\_CHIPSET\_W10.zip](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/axbz/zxrf/~edisp/6200-1xx_chipset_w10.zip) (v10.1.19502.8391, 9 May 2024)

_DisplayLink_

- Windows 10

[6200-1xx\_DisplayLink\_W10.zip](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/ewxp/bmtf/~edisp/6200-1xx_displaylink_w10.zip) (v8.1.848.0, 30 July 2020)

- Linux

[displaylink-driver-5.3.1.34.run](https://www.displaylink.com/downloads/ubuntu) (via [https://www.displaylink.com/](https://www.displaylink.com/))  (30 July 2020)

_Management Engine_

- Windows 10 (all versions)

[6200-1xx\_ME\_WIN10.zip](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/x21l/x3dp/~edisp/6200-1xx_me_win10.zip) (v2344.5.41.0, 10 May 2024)

_Network_

- Windows 10 LTSB 2016

[6200-1xx\_LAN\_W10.zip](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/ef9s/yw5f/~edisp/6200-1xx_lan_w10.zip) (v12.17.8.7, 14 November 2018)

- Windows 10 LTSC 2019

[6200-1xx\_LAN\_LTSC2019.zip](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/x2x0/c2my/~edisp/6200-1xx_lan_ltsc2019.zip) (v12.19.2.60, 3 June 2025)

_Rapid Storage Technology_

- Windows 10 (all versions)

[6200-1xx\_RST\_W10.zip](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/ef9y/c3rf/~edisp/6200-1xx_rst_w10.zip) (v17.8.0.1065, 11 August 2020)

_Serial_

- Windows 10 LTSB 2016

[6200-1xx\_SERIAL\_WIN10.zip](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/awfs/x3dp/~edisp/6200-1xx_serial_win10.zip) (v30.100.1725.1, 19 November 2018)

- Windows 10 LTSC 2019

[6200-1xx\_SERIAL\_LTSC2019.zip](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/x2x0/c2my/~edisp/6200-1xx_serial_ltsc2019.zip) (v30.100.1841.2, 3 July 2019)

_Touchscreen_

Use the touch drivers from the [Common packages & drivers](https://commerce.toshiba.com/wps/portal/marketing?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-commonpackages-sitearea) page

_USB RS232 Dongle_

- Windows 10 (all versions)

[6200\_USB\_RS232\_DONGLE.zip](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/mzjf/zg9u/~edisp/6200_usb_rs232_dongle.zip) (v2.12.26, 14 November 2018)

_Video_

- Windows 10 (all versions)

[6200-1xx\_VIDEO\_W10.zip](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/dmlk/zw9f/~edisp/6200-1xx_video_w10.zip) (v31.0.101.2134, 3 June 2025)

###### Restricted content (security alerts, BIOS & publications)

Content below is only available to entitled customers with a TGCS enterprise ID ([learn more](https://www.toshibacommerce.com/wps/portal/!ut/p/a1/rZZdT8IwFIb_Cl5w2fT0Y213uRABEZgoRtiN2camU_chDBB_vdMYFQgMk7OLZj09ffL25PRNqUcn1Mv8VfLgl0me-S-fc0_d21cGui7wnmn3JDjGssdDrbnbgSph-jcB-gO7Sui0B6JtC1Bqe3_HtFrV8mAszvucXXJN76hHvTAri_KRTqOsCY95GjVhsSyKfF42oZjns2VYkp_A90-DNLJovfjcXYTJjE6ZhsgXKiJMmoBIK7aJif2AAFMyjgXnsTLfauHA50Cd2p3T7ifUVOvrtDX1-ko4JnGb4MpbBo7rdLXq9nl_pOm0EqkPiryw6M1v1ZQAYzHJiASrGsKIEd8ONGHcnhmwQ24xUQfUyECHYwMZNlAgA0eADcSu4Qi7bUbYbaMkNlD9G9g7wUCSp9dXz6lML8_K6K2kkz3X29W16yNb3XeS7x0HGsAGKmyghQ3UyEBXYgOxa-hit43EbhvJsYHs38DeCQ-e-htc_24p0tvUiE1Cnq8NCKtYvY_jNL0fDokf7AS84OhyFdiszz4AuVHpsQ!!/?1dmy&urile=wcm%3apath%3a%2Fen%2Fhome%2Fabout-us%2Fcontact-us%2Ffaqs))

[Pictorial guides to features](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=FLD_BROWSE&path=%2fPublications%2fPictorial%20Guides)

[TCx 800 Knowledgebase](https://www.toshibacommerce.com/wps/myportal/partner?urile=wcm:path:/partner_en/home/knowledgebase/hardware-kb/800)

**TCx 810 Essential (4828-x2x)**

Minimum linux kernel required is [4.19](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/windows-compatibility)

_BIOS (XHKT 2550) & BIOS settings utility (v1.1.12) (30 March 2026)_

[BIOS update for Windows](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS2496908&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1)

[BIOS update for linux](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS2496907&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1)

_Downloads_

For MSR configuration use the Modular Device Utility in the POS Keyboard section of the [POS Peripheral Firmware, Publications & Utilities](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-peripheral) page

_Firmware_

Firmware for POS devices, including the touch screen, can be found on the [POS Peripheral Firmware, Publications & Utilities](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-peripheral) page

_Publications_

[Getting Started Guide](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS2473732&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1)

[Planning, Install & Service Guide](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS2496885&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1)

[Chinese, Serbian, Russian, Ukraine](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS2496887&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1)

[OS Install Guide](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS2474750&RevisionSelectionMethod=LatestReleased&allowInterrupt=1)

[Linux Configuration Guide](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS2496883&RevisionSelectionMethod=LatestReleased&allowInterrupt=1)

[10.1" Monitor User Guide](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS2690416&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1)

[Guide to features](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS2469412&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1)

**TCx 810 (6201-xxC/xx3/xx5/xx7)**

Minimum linux kernel required is [5.8](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/windows-compatibility)

_BIOS (XGKT 2520) & BIOS settings utility (v1.1.15) (16 July 2025)_

[BIOS update for Windows](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS2473688&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1)

[BIOS update for linux](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS2473689&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1)

_Downloads_

For MSR configuration use the Modular Device Utility in the POS Keyboard section of the [POS Peripheral Firmware, Publications & Utilities](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-peripheral) page

_Firmware_

Firmware for POS devices, including the touch screen, can be found on the [POS Peripheral Firmware, Publications & Utilities](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-peripheral) page

_Publications_

[Getting Started Guide](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS2473686&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1)

[Planning, Install & Service Guide](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS2473687&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1)

[Chinese, Serbian, Spanish, Russian, Ukraine](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS2473685&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1)

[OS Install Guide](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS2474750&RevisionSelectionMethod=LatestReleased&allowInterrupt=1)

[Camera Module User Guide](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS2486772&RevisionSelectionMethod=LatestReleased&allowInterrupt=1)

[Scan Engine User Guide](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS2486773&RevisionSelectionMethod=LatestReleased&allowInterrupt=1)

[10.1" Monitor User Guide](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS2690416&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1)

[Guide to features](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS2469411&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1)

[TCx OS for Android 12402 - Install Guide](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS3361185&RevisionSelectionMethod=LatestReleased&allowInterrupt=1)

[TCx OS for Android 12.2402 - Release Notes](https://tgcs04.toshibacommerce.com/cs/groups/tgcsempcontsuppcustwservice/documents/document/b3mz/mzyx/~edisp/prod.tos3361185.pdf)

**TCx 800 (6200-xxC/xx3/xx5/xx7)**

Minimum linux kernel required is [4.4](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/windows-compatibility)

_BIOS (XFKT 320) & BIOS settings utility (v0.21) (3 June 2025)_

[BIOS update for Windows](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS2614516&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1)

[BIOS update for linux](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS2061360&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1)

_Downloads_

[MSR Configuration utility for Windows](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS1843287&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1) _(v.1.3.14) (18 April 2022)_

You can also use the Modular Device Utility in the POS Keyboard section of the [POS Peripheral Firmware, Publications & Utilities](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-peripheral) page

_Firmware_

Firmware for POS devices, including the touch screen, can be found on the [POS Peripheral Firmware, Publications & Utilities](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-peripheral) page

_Publications_

[OS Install Guide (v1.6)](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS1727939&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1)

[Getting Started Guide](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS1598955&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1)

[Installation & Service Guide](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS1699482&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1)

[Chinese, Serbian](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS1721298&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1)

[Linux Configuration Guide](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS1737958&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1)

[10.1" Monitor User Guide](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS2142507&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1)

[Guide to features](https://tgcs04.toshibacommerce.com/cs/idcplg?IdcService=GET_FILE&dDocName=PROD.TOS1671241&RevisionSelectionMethod=LatestReleased&allowInterrupt=1&noSaveAs=1)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/c5a376ee-ff6a-4af7-bf31-8e92fd840a87/POS-Diagnostics.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-c5a376ee-ff6a-4af7-bf31-8e92fd840a87-pFQ4h.o)

###### POS Diagnostics

[Read more](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-commonpackages-sitearea)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/06e31b56-6bd7-4325-95e1-a83165054fb4/Support-handbook.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-06e31b56-6bd7-4325-95e1-a83165054fb4-pFQ4cct)

###### Support Guides & Handbooks

[Read more](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/support-guides)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/ed7af18e-05c2-4b70-9886-377c3e303ec7/support-news.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-ed7af18e-05c2-4b70-9886-377c3e303ec7-pFQ4fqB)

###### Support News

[Read more](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/support-news)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

## Need help with your TCx® 800 or TCx® 810?

[Submit a Service Request](https://tgcs01.toshibacommerce.com/OA_HTML/xxtgc_ebslogin_isupport_tgcp2aa.html)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

Start a conversation

First name

Last name

Email

Company

Country

Phone

I am a

Business PartnerOtherPress / AnalystRetailerSupplierToshiba Employee

- Business Partner

- Other

- Press / Analyst

- Retailer

- Supplier

- Toshiba Employee


My Retail Segment

Fashion & ApparelFood ServiceGas & ConvenienceGroceryMass MerchandiseOtherPharmacy / Drug StoreSpecialty

- Fashion & Apparel

- Food Service

- Gas & Convenience

- Grocery

- Mass Merchandise

- Other

- Pharmacy / Drug Store

- Specialty


I am interested in learning more about

Add me to Toshiba Global Commerce Solutions' email marketing list

I am allowing Toshiba to contact me in regards to the information on this form

Comments

By submitting this form I agree that Toshiba Global Commerce Solutions, Inc. and its affiliates, including all subsidiaries and branches, may process my data as indicated above and as described in the [Toshiba Global Commerce Solutions Privacy Declaration.](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/common-content/general-content/privacy-policy&mapping=tgcs_new.portal.generaldetails)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**

reCAPTCHA is changing its terms of service. [Take action.](https://google.com/recaptcha/admin/migrate)

![success](https://commerce.toshiba.com/wps/portal/marketing/product-support/support-hardware/support-tcx800-sitearea/!ut/p/z1/tVTZcoIwFP0aHmOugBj6hsuAdRi1rRsvnQBhaYXQEKX9-8a208XpMh01Lwk35557ktwDDvAKByXd5SmVOS_pRn2vA-t2ZLd1GI9h4g68Icz8RW80bbugBl7gAAdVlMd4DZaVdHQ7RKQTJsgEAsiO7RhFYWQSSqgVUbpHR6WsZIbXrETbWoOMF0yDeltVXEgNKsHjbSTRe-BtgTIq4oaKDyyS0SMBQHUumYpTvPxLbKC24YfhgMoPXiBj23Q80oepO3X6MLPm7pSM-oa5sN4Ah5m9K71nALgT_VvAlyJrJbL7s8gOXu5y1uB5yUWhHuD6n_fr_Vmhe2SF3-ld87z01mnpJwNvALOhP18443Z73yNnpdePpL986a5fOlz5VRd-308VLZUZysuE49WBp_Dq0FMfkUNPKcL87uEhcJRveSnZo8o-uXHVsdIND1__N04ZGkTpFyxhgonWVqhwJmVVX2igQdM0rZTzdMNaES80-C4l47WS-RWJq6IgxhO6vyLNTZKlxa0_NDqfptrb7IolqZ8BTVQHjg!!/images/tgcs/success.svg)

## Success!

Thank you for reaching out. One of our team members will be in contact soon. We hope you have a great day.

Close

Complementary
Content

[Deferred Modules](https://commerce.toshiba.com/wps/contenthandler/marketing/!ut/p/digest!M6zrA0PEiotCbddBEGnoVg/mashup/ra:collection?themeID=ZJ_JQGEHK01N0LM806KGPAKPA0UO0&locale=en&mime-type=text%2Fjavascript&lm=1778876784000&entry=st_skin__0.0%3Aconfig_js&entry=wp_liveobject_framework_core__0.0%3Aconfig_js&entry=wp_portal_ui_utils__0.0%3Aconfig_js&entry=wp_contextmenu_js__0.0%3Aconfig_js&entry=wp_skin_cam__0.0%3Aconfig_js&entry=wp_contextmenu_config_lof__0.0%3Aconfig_js&entry=wp_federated_documents_picker__0.0%3Aconfig_js&entry=wp_dnd_main__0.0%3Aconfig_js&entry=wp_movecontrols__0.0%3Aconfig_js&entry=wp_toolbar_controlactions__0.0%3Aconfig_js&entry=wp_content_targeting_cam__0.0%3Aconfig_js&deferred=true)

- ${title}${badge}

${loading}

[Deferred Modules](https://commerce.toshiba.com/wps/contenthandler/marketing/!ut/p/digest!SpZvrtUURDcRHYzcbiqg-Q/mashup/ra:collection?themeID=ZJ_JQGEHK01N0LM806KGPAKPA0UO0&locale=en&mime-type=text%2Fplain&entry=wp_contextmenu_templates__0.0%3Aconfig_markup&entry=wp_skin_cam__0.0%3Aconfig_markup&entry=wp_dnd_main__0.0%3Aconfig_markup&deferred=true)

reCAPTCHA

Select all images with **bicycles** Click verify once there are none left

|     |     |     |
| --- | --- | --- |
| ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7Ol80BS8U9MDL1ksE1VbgXgzLYUwrryuuafHt1JDJIzhZ9HNCpY34kO_ZOVsdAxkt438upglpTVBMRHEZVyQa59MxotNZwFP2auUkMhtRHXjLN66kX4oQFsw3IPFwqYaExD0ZC8VzgDGg4lHghvQJmK6PY2VxFA9h0YZdkblsFwnORIIn6Xl1Uls3QOAN8GHwHfESY&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7Ol80BS8U9MDL1ksE1VbgXgzLYUwrryuuafHt1JDJIzhZ9HNCpY34kO_ZOVsdAxkt438upglpTVBMRHEZVyQa59MxotNZwFP2auUkMhtRHXjLN66kX4oQFsw3IPFwqYaExD0ZC8VzgDGg4lHghvQJmK6PY2VxFA9h0YZdkblsFwnORIIn6Xl1Uls3QOAN8GHwHfESY&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7Ol80BS8U9MDL1ksE1VbgXgzLYUwrryuuafHt1JDJIzhZ9HNCpY34kO_ZOVsdAxkt438upglpTVBMRHEZVyQa59MxotNZwFP2auUkMhtRHXjLN66kX4oQFsw3IPFwqYaExD0ZC8VzgDGg4lHghvQJmK6PY2VxFA9h0YZdkblsFwnORIIn6Xl1Uls3QOAN8GHwHfESY&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) |
| ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7Ol80BS8U9MDL1ksE1VbgXgzLYUwrryuuafHt1JDJIzhZ9HNCpY34kO_ZOVsdAxkt438upglpTVBMRHEZVyQa59MxotNZwFP2auUkMhtRHXjLN66kX4oQFsw3IPFwqYaExD0ZC8VzgDGg4lHghvQJmK6PY2VxFA9h0YZdkblsFwnORIIn6Xl1Uls3QOAN8GHwHfESY&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7Ol80BS8U9MDL1ksE1VbgXgzLYUwrryuuafHt1JDJIzhZ9HNCpY34kO_ZOVsdAxkt438upglpTVBMRHEZVyQa59MxotNZwFP2auUkMhtRHXjLN66kX4oQFsw3IPFwqYaExD0ZC8VzgDGg4lHghvQJmK6PY2VxFA9h0YZdkblsFwnORIIn6Xl1Uls3QOAN8GHwHfESY&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7Ol80BS8U9MDL1ksE1VbgXgzLYUwrryuuafHt1JDJIzhZ9HNCpY34kO_ZOVsdAxkt438upglpTVBMRHEZVyQa59MxotNZwFP2auUkMhtRHXjLN66kX4oQFsw3IPFwqYaExD0ZC8VzgDGg4lHghvQJmK6PY2VxFA9h0YZdkblsFwnORIIn6Xl1Uls3QOAN8GHwHfESY&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) |
| ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7Ol80BS8U9MDL1ksE1VbgXgzLYUwrryuuafHt1JDJIzhZ9HNCpY34kO_ZOVsdAxkt438upglpTVBMRHEZVyQa59MxotNZwFP2auUkMhtRHXjLN66kX4oQFsw3IPFwqYaExD0ZC8VzgDGg4lHghvQJmK6PY2VxFA9h0YZdkblsFwnORIIn6Xl1Uls3QOAN8GHwHfESY&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7Ol80BS8U9MDL1ksE1VbgXgzLYUwrryuuafHt1JDJIzhZ9HNCpY34kO_ZOVsdAxkt438upglpTVBMRHEZVyQa59MxotNZwFP2auUkMhtRHXjLN66kX4oQFsw3IPFwqYaExD0ZC8VzgDGg4lHghvQJmK6PY2VxFA9h0YZdkblsFwnORIIn6Xl1Uls3QOAN8GHwHfESY&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7Ol80BS8U9MDL1ksE1VbgXgzLYUwrryuuafHt1JDJIzhZ9HNCpY34kO_ZOVsdAxkt438upglpTVBMRHEZVyQa59MxotNZwFP2auUkMhtRHXjLN66kX4oQFsw3IPFwqYaExD0ZC8VzgDGg4lHghvQJmK6PY2VxFA9h0YZdkblsFwnORIIn6Xl1Uls3QOAN8GHwHfESY&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) |

Please try again.

Please select all matching images.

Please also check the new images.

Please select around the object, or reload if there are none.

Verify