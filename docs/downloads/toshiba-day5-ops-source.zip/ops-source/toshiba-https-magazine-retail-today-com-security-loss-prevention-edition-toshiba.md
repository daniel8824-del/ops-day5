<!-- source: https://magazine.retail-today.com/security_loss_prevention_edition/toshiba -->

![](https://magazine.retail-today.com/system/resources/images/h5mag_logo.png?m=1662632987)

The Path to Secure Retail

Achieving secure retail is a journey, not a sprint — and the path to safe shopping and minimal theft requires retailers to confront a variety of challenges. The good news is that these challenges can be overcome by deploying a variety of technologies, tactics, and resources.

Retailers can use this illustration to explore some of the possible solutions that can contribute to better loss prevention outcomes in your stores as you redefine your loss prevention program for our new world of retail. In it, you'll see:

- Solutions for deterring theft and organized retail crime
- Technologies you can use to create a sense of safety for shoppers
- Ways to prevent theft (intentional and otherwise) at self-checkouts
- And more!

[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/sensormatic/849214/sensormatic_logo_wtag-svg.320_0_1.png)](https://www.sensormatic.com/contact)[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/sensormatic/849208/thin_arrow_white.svg)](https://magazine.retail-today.com/security_loss_prevention_edition/toshiba#image-3)

![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/sensormatic/849211/1a.1440_0_1.jpg)![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/sensormatic/849212/2a.1440_0_1.jpg)

[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/sensormatic/849208/thin_arrow_white.svg)](https://magazine.retail-today.com/security_loss_prevention_edition/toshiba#image-5)

![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/sensormatic/849213/3a.1440_0_1.jpg)

Take a deeper dive into loss prevention with Sensormatic's latest white paper, [Secure Retail in the New World](https://www.sensormatic.com/resources/ig/2023/secure-retail-infographic), and get global, real-world insights you can use to improve your loss prevention program today.

[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/sensormatic/849210/RETAIL_TODAY_RED_WHITE_PNG.320_0_1.png)](https://magazine.retail-today.com/security_loss_prevention_edition/table_of_contents)

[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/sensormatic/849204/pngkey_com_twitter_logo_black_png_842567_150x150.1440_0_1.png)](https://twitter.com/intent/tweet?text=Sensormatic&url=https%3A%2F%2Fmagazine.retail-today.com%2Fsecurity_loss_prevention_edition%2Fsensormatic)[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/sensormatic/849205/pngkit_facebook_like_png_100309_150x150.1440_0_1.png)](https://www.facebook.com/sharer.php?u=https%3A%2F%2Fmagazine.retail-today.com%2Fsecurity_loss_prevention_edition%2Fsensormatic)[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/sensormatic/849206/PngItem_326086_150x150.1440_0_1.png)](https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fmagazine.retail-today.com%2Fsecurity_loss_prevention_edition%2Fsensormatic&title=Sensormatic&summary=Take%20a%20deeper%20dive%20into%20loss%20prevention%20with%20Sensormatic%27s%20latest%20white%20paper%2C%20Secure%20Retail%20in%20the%20New%20World%2C%20and%20get%20global%2C%20real-world%20insights%20you%20can%20use%20to%20improve%20your%20loss%20prevention%20program%20today.%20The%20Path%20to%20Secure%20Retail%20Achieving%20secure%20retail%20is%20a%20journey%2C%20not%20a%20sprint%20%E2%80%94%20and%20the%20path%20to%20safe%20shopping%20and%20minimal%20theft%20requires%20retailers%20to%20confront%20a%20variety%20of%20challenges.%20The%20good%20news%20is%20that%20these%20challenges%20can%20be%20overcome%20by%20deploying%20a%20variety%20of%20technologies%2C%20tactics%2C%20and%20resources.%20Reta)

MAY 2024

07/06/2024 03:26:14

From Reactive to Proactive: AI-Driven Solutions in Retail Loss Prevention

In the dynamic realm of retail, the perpetual need to balance profitability with the imperative of loss prevention propels an ongoing quest for innovative solutions. The intricacies of security and loss prevention form an intricate mosaic of myriad challenges: shoplifting and employee theft, technology and cybersecurity breaches, organized retail crime, fraudulent transactions, and the safeguarding of supply chains. It's a complex narrative with no panaceas or one-size-fits-all solutions, urging retailers to approach the issue strategically and tailoring responses to the unique contours of their business.

Amid this complexity, a notable shift has emerged, driving a move from reactive to proactive measures, particularly at the front end of the store, thanks to cutting-edge loss prevention technology. This evolution addresses security concerns and remains steadfast in enhancing the shopper’s experience.

**Loss prevention technology is no longer solely about combating theft; it also plays a pivotal role in enhancing the overall customer experience.** Traditional security measures, often conspicuous and intimidating, could make shoppers uncomfortable due to strict scrutiny. The latest advancements make surveillance systems more discreet, blending seamlessly into store designs. Furthermore, artificial intelligence (A.I.)-driven systems optimize store layouts and product placements based on customer behavior, resulting in a more enjoyable shopping experience and increased customer satisfaction.

With a focus on **shrink reduction**, **accuracy improvement**, **data-driven decision-making**, and **cost savings**, advanced security measures have become transformative forces within the retail industry. These innovations underscore a commitment to safeguarding assets while elevating the retail experience for every shopper who walks through the door.

The AI-powered ELERA® Security Suite enhances loss prevention measures that directly and positively impact retailer profits and improve the shopper experience.

**Reducing Shrink: A Proactive Approach**

**Improving Accuracy with Item Recognition**

![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/toshiba/849062/Loss_prevention.960_0_1.png)

Retailers have historically grappled with shrink by depending on visible security measures. However, the rise of A.I. and machine learning has ushered in a new era. A.I. is the new darling in the retail technology industry, and retailers are exploring the strategy to address challenges like loss prevention, payments, and promotions. Advanced surveillance systems equipped with A.I powered technologies can detect suspicious behavior patterns in real-time, enabling proactive loss prevention. This shift from reactive to proactive measures and initiating a corrective dialog with the consumer in real time marks a significant advancement in the fight against shrink.

Inaccurate stock-keeping unit (SKU) entries contribute significantly to shrink, affecting revenue and customer satisfaction. Advanced produce recognition software, leveraging integrated computer vision and A.I., ensures accurate product identification, weighing, and pricing. This protects the business from financial losses and creates a smoother, more customer-friendly checkout experience. For example, the practice of intentionally or accidentally misrepresenting or mislabeling items at checkout, scanning a lower-priced item like a banana, and passing it off as a higher-priced item like steak has been observed repeatedly in consumer behavior. But now, with innovative produce recognition solutions, a banana will always be scanned accurately as a banana, and the consumer will be prompted to self-correct, both deterring fraudulent activities and protecting the shopper experience when these types of errors are unintentional.

From Reactive to Proactive: AI-Driven Solutions in Retail Loss Prevention

By **Yevgeni Tsirulnik**, SVP of Innovation and Incubation,               Toshiba Global Commerce Solutions

The AI-powered ELERA® Security Suite enhances loss prevention measures that directly and positively impact retailer profits and improve the shopper experience.

- Yevgeni Tsirulnik, SVP of Innovation and Incubation,       Toshiba Global Commerce Solutions

![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/toshiba/849067/Yevgeni_preferred_for_media_1.400_0_1.jpg)[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/toshiba/849066/linkedin-icon-white.640_0_1.png)](https://www.linkedin.com/in/carol-leaman-22973b/?originalSubdomain=ca)

In the era of data dominance, loss prevention technology is a valuable source of insights. A.I.-equipped cameras analyze customer purchase behavior, providing data on preferences and purchasing patterns. Retailers can utilize this information to make informed decisions on inventory management, marketing strategies, and customer engagement. This data-driven approach helps identify trends and proactively address potential issues, such as relocating frequently stolen items or implementing enhanced security measures.

**Cost Savings: A Long-Term Investment**

**Data-Driven Decision Making**

**ELERA™ Security Suite: A Game-Changer**

![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/toshiba/849063/Elera_2.960_0_1.jpg)

While the initial investment in loss prevention technology may seem hefty, the long-term benefits and quick ROI far outweigh the price. Traditional security measures, such as large security staff and physical surveillance, are expensive and far less effective. Loss prevention technology automates many security tasks, reducing the need for extensive human intervention and/or reviewing the videos by the human eye after the fact. The cost of stolen inventory and losses due to inefficient inventory management surpasses the initial investment in technology, making it a financially sound decision for retailers.

The Toshiba Global Commerce Solutions team empowers **retailers to reimagine, build, and scale their operations to provide a smarter, highly personalized, and privacy-conscious experience for customers, associates, and the enterprise.** We are truly unique in our ability to provide end-to-end, modular, connected, and empowering solutions, coupling CV/AI technologies with deep customer interaction design to accelerate the future of retail. Inventory shrink is a pervasive issue in the retail industry, and frictionless technologies are increasingly significant in promoting retail security. The A.I.-powered ELERA® Security Suite enhances loss prevention measures that directly and positively impact retailer profits and improve the shopper experience. Retailers have seen strong returns on their investment through increased inventory accuracy, decreased staff intervention, and increased adoption of their self-checkout lanes.

The end-to-end ELERA® Security Suite solution, deployed through Toshiba’s IoT platform, harnesses the power of A.I., edge computer vision, and sensors to monitor consumer behavior in real time. Responding to incidents promptly and notifying shoppers of potential errors minimizes employee intervention and improves the overall checkout experience for everyone involved.

Retailers investing in the ELERA® Security Suite can see strong returns on their investment through increased inventory accuracy, decreased store staff intervention, and increased adoption of their self-checkout lanes.

The Self-Service Loss Prevention solution, a fundamental component of the ELERA® Security Suite, empowers retailers to monitor customer interactions through groundbreaking camera technology and algorithms, aiming to minimize losses and simultaneously streamline the entire self-checkout process. The decreased friction contributes to shrink reduction and simplifies the checkout process for the customers.

Along with the ELERA® Security Suite, Toshiba Global Commerce Solutions has updated the ELER® Produce Recognition solution that will now include front-end produce recognition in cashier lanes and self-checkout. To further enhance the self-checkout process, ELERA® Produce Recognition will also be able to scan and identify produce while it is still in a bag, which other competing systems do not offer.

**In Conclusion: Embracing the Future**

Loss prevention technology has transformed remarkably in a few short years. The advancements safeguard inventory, enhance consumer experiences, and provide valuable data-driven insights. As the industry evolves, retailers must view these advancements as necessary to prosper in a fiercely competitive business environment. By investing in the latest technologies, retailers can turn data into decisions and losses into profits, ensuring a seamless and secure shopping experience.

[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/toshiba/849064/thin_arrow_white.svg)](https://magazine.retail-today.com/security_loss_prevention_edition/toshiba#arrow_direction)

[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/toshiba/849053/pngkey_com_twitter_logo_black_png_842567_150x150.1440_0_1.png)](https://twitter.com/intent/tweet?text=Toshiba&url=https%3A%2F%2Fmagazine.retail-today.com%2Fsecurity_loss_prevention_edition%2Ftoshiba)[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/toshiba/849054/pngkit_facebook_like_png_100309_150x150.1440_0_1.png)](https://www.facebook.com/sharer.php?u=https%3A%2F%2Fmagazine.retail-today.com%2Fsecurity_loss_prevention_edition%2Ftoshiba)[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/toshiba/849055/PngItem_326086_150x150.1440_0_1.png)](https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fmagazine.retail-today.com%2Fsecurity_loss_prevention_edition%2Ftoshiba&title=Toshiba&summary=May%202024%20Yevgeni%20Tsirulnik%20SVP%20of%20Innovation%20and%20Incubation%2C%20Toshiba%20Global%20Commerce%20Solutions%20From%20Reactive%20to%20Proactive%3A%20AI-Driven%20Solutions%20in%20Retail%20Loss%20Prevention%20In%20the%20dynamic%20realm%20of%20retail%2C%20the%20perpetual%20need%20to%20balance%20profitability%20with%20the%20imperative%20of%20loss%20prevention%20propels%20an%20ongoing%20quest%20for%20innovative%20solutions.%20The%20intricacies%20of%20security%20and%20loss%20prevention%20form%20an%20intricate%20mosaic%20of%20myriad%20challenges%3A%20shoplifting%20and%20employee%20theft%2C%20technology%20and%20cybersecurity%20breaches%2C%20organized)

[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/toshiba/849061/RETAILTODAY_RED_WHITE_PNG.480_0_1.png)](https://magazine.retail-today.com/security_loss_prevention_edition/table_of_contents)

May 2024

![](<Base64-Image-Removed>)

Yevgeni Tsirulnik

SVP of Innovation and Incubation, Toshiba Global Commerce Solutions

![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/toshiba/849051/Bio_Ikon_1.1440_0_1.png)[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/toshiba/849050/linkedin_ikon.1440_0_1.png)](https://www.linkedin.com/in/yevgeni-tsirulnik-8ab2a54/)

[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/toshiba/849068/Toshiba_RGB.1024_0_1.jpg)](https://commerce.toshiba.com/)

[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/toshiba/849056/New_Project__2_.1440_0_1.png)](https://commerce.toshiba.com/)

[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/toshiba/849065/RETAIL_TODAY_RED_WHITE_PNG.320_0_1.png)](https://magazine.retail-today.com/edit-nrf_2024_part_2/table_of_contents_28643)

[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/toshiba/849053/pngkey_com_twitter_logo_black_png_842567_150x150.1440_0_1.png)](https://twitter.com/intent/tweet?text=Toshiba&url=https%3A%2F%2Fmagazine.retail-today.com%2Fsecurity_loss_prevention_edition%2Ftoshiba)[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/toshiba/849054/pngkit_facebook_like_png_100309_150x150.1440_0_1.png)](https://www.facebook.com/sharer.php?u=https%3A%2F%2Fmagazine.retail-today.com%2Fsecurity_loss_prevention_edition%2Ftoshiba)[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/toshiba/849055/PngItem_326086_150x150.1440_0_1.png)](https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fmagazine.retail-today.com%2Fsecurity_loss_prevention_edition%2Ftoshiba&title=Toshiba&summary=May%202024%20Yevgeni%20Tsirulnik%20SVP%20of%20Innovation%20and%20Incubation%2C%20Toshiba%20Global%20Commerce%20Solutions%20From%20Reactive%20to%20Proactive%3A%20AI-Driven%20Solutions%20in%20Retail%20Loss%20Prevention%20In%20the%20dynamic%20realm%20of%20retail%2C%20the%20perpetual%20need%20to%20balance%20profitability%20with%20the%20imperative%20of%20loss%20prevention%20propels%20an%20ongoing%20quest%20for%20innovative%20solutions.%20The%20intricacies%20of%20security%20and%20loss%20prevention%20form%20an%20intricate%20mosaic%20of%20myriad%20challenges%3A%20shoplifting%20and%20employee%20theft%2C%20technology%20and%20cybersecurity%20breaches%2C%20organized)

MAY 2024

07/05/2024 21:11:58

![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/elb_learning/848935/EBL_Learning.1440_0_1.jpg)

[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/elb_learning/848928/RETAIL_TODAY_RED_WHITE_PNG.320_0_1.png)](https://magazine.retail-today.com/security_loss_prevention_edition/table_of_contents)

[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/elb_learning/848925/pngkey_com_twitter_logo_black_png_842567_150x150.1440_0_1.png)](https://twitter.com/intent/tweet?text=ELB%20Learning&url=https%3A%2F%2Fmagazine.retail-today.com%2Fsecurity_loss_prevention_edition%2Felb_learning)[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/elb_learning/848926/pngkit_facebook_like_png_100309_150x150.1440_0_1.png)](https://www.facebook.com/sharer.php?u=https%3A%2F%2Fmagazine.retail-today.com%2Fsecurity_loss_prevention_edition%2Felb_learning)[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/elb_learning/848927/PngItem_326086_150x150.1440_0_1.png)](https://www.linkedin.com/shareArticle?mini=true&url=https%3A%2F%2Fmagazine.retail-today.com%2Fsecurity_loss_prevention_edition%2Felb_learning&title=ELB%20Learning&summary=How%20L%26D%20Helps%20Reduce%20Retail%20Theft%20Today%E2%80%99s%20retailers%20face%20a%20costly%20problem%20that%E2%80%99s%20only%20bound%20to%20get%20more%20expensive%E2%80%A6shoplifting.%C2%A0%20In%202023%2C%20stores%20lost%20%24121.6%20billion%20to%20retail%20theft%2C%20according%20to%20research%20from%20CapitalOne%20Shopping.%20This%20number%20is%20projected%20to%20rise%20to%20over%20%24150%20billion%20in%202026.%C2%A0%20The%20rise%20in%20retail%20theft%20left%20big%20retailers%20hurting%20%E2%80%93%20Target%20reported%20a%20%24400%20million%20hit%20to%20gross%20profit%20margin%20and%20Dick%E2%80%99s%20Sporting%20Goods%20dropped%20their%20profits%20by%2023%25%20in%20part%20to%20increased%20theft.%20The%20time%20to%20up%20security)

MAY2024

# How L&D Helps Reduce Retail Theft

Today’s retailers face a costly problem that’s only bound to get more expensive…shoplifting.

In 2023, stores lost $121.6 billion to retail theft, according to research from [CapitalOne Shopping](https://capitaloneshopping.com/research/shoplifting-statistics/). This number is projected to rise to over $150 billion in 2026.

The rise in retail theft left big retailers hurting – [Target](https://finance.yahoo.com/news/retail-theft-walmart-home-depot-target-detail-unacceptable-amount-of-crime-172928039.html?guccounter=1) reported a $400 million hit to gross profit margin and [Dick’s Sporting Goods](https://www.cnbc.com/2023/08/22/dicks-sporting-goods-dks-earnings-q2-2023.html?utm_campaign=mb&utm_medium=newsletter&utm_source=morning_brew) dropped their profits by 23% in part to increased theft. The time to up security measures is now.

But, where do you start? It’s not investing in state-of-the-art security cameras or bringing in a squad of security guards to stand near every entrance.

It’s training your employees.

Let’s take a closer look at how strengthening your learning and development (L&D) programs can stop shoplifting.

Picture this: A global retailer has hundreds of stores worldwide, and thousands of employees who speak many languages.

Now, think about how much it would cost to get each employee in the same place at the same time to come together and learn. That’s a lot of dollar signs and not very realistic.

It’s not just about geographical scale either. Attrition rates in the retail industry sit high at [around 60%](https://www.mckinsey.com/industries/retail/our-insights/how-retailers-can-attract-and-retain-frontline-talent-amid-the-great-attrition). Retailers need to account for high turnover with training that can easily get new employees up to speed as they come on board.

One PowerPoint or outdated employee handbook won’t cut it. Leveling up your training with different learning formats and technology can help you engage employees with training they want to participate in – and that actually sticks.

Your employees are critical to preventing theft. But what if they don’t know what to look for? How will they handle confrontation? That’s where training comes in.

It may not always be as obvious as someone trying to pull a security tag off a shirt or a customer sprinting for the exit and setting off alarms. It could be a fellow employee fudging the numbers on returns to pocket the difference or swapping the sale tags on full-price items.

Training content empowers employees to spot these red flags and shows them how to intervene in the moment. Technology provides delivery formats and channels that make training engaging and relevant no matter where you’re learning from.

When in-person training opportunities were out of the question due to the pandemic, the luxury brand [Fendi](https://www.elblearning.com/case-studies/fendis-immersive-mobile-learning-course-by-video-interact-using-lectora-cenariovr) needed a quick fix for arming employees against thieves. ELB Learning, and our partner, Video Interact, brought the stores to their homes. We used VR to create 360-degree videos for each store. When “walking” through the immersive environment, employees were tasked with identifying specific shoplifting and security risks – opened drawers, unattended fitting rooms, customers carrying suspiciously large bags, and more.

You should also consider formats that keep training “always on.” Microlearning, or content that’s delivered in “bite-sized” chunks, dials in on specific skills that fit the learner's schedules or just-in-time needs. Employees can complete focused modules during a slow period on the retail floor. If they notice something off, like someone lingering a little too long in the store without asking for help or trying anything on, they can tap into a course for a way forward.

Confrontation is tough, especially when it’s calling someone out for stealing. This is why soft skills training should be part of your mix. Soft skills training in theft prevention can include topics like improving problem-solving and critical thinking and knowing when it’s time to escalate a situation.

We’ve found that video-based practice helps build confidence in these sticky situations. Employees can submit their rehearsed responses to managers, get feedback, and continue this loop until people feel ready to turn learning into action.

![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/elb_learning/848933/Andrew_scivally.1440_0_1.jpg)

# **Andrew Scivally**

# Chief Executive Officer  ELB Learning

[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/elb_learning/848930/linkedin-icon-white.400_0_1.png)](https://www.linkedin.com/in/scivally/)

![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/elb_learning/848929/thin_arrow_white.svg)

# Thinking Through Scale

# Teaching Theft Prevention and Response

How do you know if your retail theft training is working? In Fendi’s case, after implementing the VR course across 1,800 employees worldwide, they saw a 55% decrease in thefts across stores with a 400% ROI. You can also look out for more reporting of suspicious activity, and fewer inventory discrepancies.

But sometimes success is less quantifiable than that. Once employees see their efforts contributing to the bigger picture, they are more likely to keep it up. This sparks a culture of improvement – staying personally proactive and encouraging others around them to do the same.

Employees are your greatest asset – invest in training that shows, not just tells, that. Giving them the tools and confidence to prevent shoplifting and respond in the moment keeps your business and employees safe.

[![](https://magazine.retail-today.com/retailtoday/security_loss_prevention_edition/elb_learning/848929/thin_arrow_white.svg)](https://magazine.retail-today.com/security_loss_prevention_edition/toshiba#arrow_direction)

# Measuring Success

07/06/2024 03:26:15

05/20/2024 00:00:00

[Go to article: Cover](https://magazine.retail-today.com/security_loss_prevention_edition/cover) [Go to article: Editorial](https://magazine.retail-today.com/security_loss_prevention_edition/editorial) [Go to article: Table of contents](https://magazine.retail-today.com/security_loss_prevention_edition/table_of_contents) [Go to article: Toshiba Ad](https://magazine.retail-today.com/security_loss_prevention_edition/toshiba_ad) [Go to article: Gatekeeper Systems](https://magazine.retail-today.com/security_loss_prevention_edition/gatekeeper_systems) [Go to article: Hughes](https://magazine.retail-today.com/security_loss_prevention_edition/hughes) [Go to article: Appriss Retail](https://magazine.retail-today.com/security_loss_prevention_edition/appriss_retail) [Go to article: Avery Dennison](https://magazine.retail-today.com/security_loss_prevention_edition/avery_dennison) [Go to article: DUST Identity](https://magazine.retail-today.com/security_loss_prevention_edition/dust_identity) [Go to article: parcelLab Ad](https://magazine.retail-today.com/security_loss_prevention_edition/parcellab_ad) [Go to article: Chargeback Gurus](https://magazine.retail-today.com/security_loss_prevention_edition/chargeback_gurus) [Go to article: Sensormatic](https://magazine.retail-today.com/security_loss_prevention_edition/sensormatic) [Go to article: Toshiba](https://magazine.retail-today.com/security_loss_prevention_edition/toshiba) [Go to article: ELB Learning](https://magazine.retail-today.com/security_loss_prevention_edition/elb_learning) [Go to article: Mercatus Ad](https://magazine.retail-today.com/security_loss_prevention_edition/mercatus_ad) [Go to article: Esri](https://magazine.retail-today.com/security_loss_prevention_edition/esri) [Go to article: Axonify](https://magazine.retail-today.com/security_loss_prevention_edition/axonify) [Go to article: Telesign](https://magazine.retail-today.com/security_loss_prevention_edition/telesign) [Go to article: Palo Alto Networks](https://magazine.retail-today.com/security_loss_prevention_edition/palo_alto_networks) [Go to article: ECAMSECURE](https://magazine.retail-today.com/security_loss_prevention_edition/ecamsecure) [Go to article: Zebra Technologies](https://magazine.retail-today.com/security_loss_prevention_edition/zebra_technologies) [Go to article: Hivery Ad](https://magazine.retail-today.com/security_loss_prevention_edition/hivery_ad)