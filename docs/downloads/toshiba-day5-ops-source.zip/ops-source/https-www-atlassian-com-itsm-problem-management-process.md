<!-- source: https://www.atlassian.com/itsm/problem-management/process -->

Get it free

Sign in

Jira Service Management is now more powerful than ever as part of Service Collection. Unlock exceptional service experiences with Rovo, Assets, and our new Customer Service Management app.

[Try it now](https://www.atlassian.com/try/cloud/signup?bundle=service-collection&edition=premium)

# Knowing the problem management process

A strong [problem management](https://www.atlassian.com/itsm/problem-management) process helps teams identify and manage the root causes of incidents on an IT service. Done well, a consistent problem management process can keep repeat incidents from happening and stop critical incidents from happening in the first place. It is a core component of ITSM frameworks.

[Get it free](https://www.atlassian.com/software/jira/service-management/free)

![video thumbnail](<Base64-Image-Removed>)

Problem management works alongside incident management and other ITIL practices to form an overall ITSM strategy.

At Atlassian, we advocate bringing the problem and incident management processes closer together.

When problem management is a heavy, siloed, and separate process, companies can end up creating a dumping ground of problems. This backlog is where problem issues go to die in some teams. It’s best to get problems in front of the teams that can handle and do valuable investigations.

[Jira Service Management](https://www.atlassian.com/software/jira/service-management/features/incident-management) enables teams to work with more transparency and context by equipping them with a repertoire of collaborative tools. As we mentioned, it’s best when incident management and problem management go hand in hand. Let’s walk through the problem management process to understand how this works best.

![Problem Management Process Diagram](https://dam-cdn.atl.orangelogic.com/AssetLink/vmu257q8268r03h3e86x5lk8t48ry6vr.png)

## What is the problem management process

1. **Problem detection** \- Proactively find problems so they can be fixed, or identify workarounds before future incidents happen.

2. **Categorization and prioritization** \- Track and assess known problems to keep teams organized and working on the most relevant and high-value problems.

3. **Investigation and diagnosis** \- Identify the underlying contributing causes of the problem and the best course of action for remediation.

4. **Create a known error record** \- In ITIL, a known error is “a problem that has a documented root cause and a workaround.” Recording this information leads to less downtime if the problem triggers an incident. This is typically stored in a document called a known error database.

5. **Create a workaround, if necessary** \- A workaround is a temporary solution for reducing the impact of problems and keeping them from becoming incidents. These aren’t ideal, but they can limit business impact and avoid a customer-facing incident if the problem can’t be easily identified and eliminated.

6. **Resolve and close the problem** \- A closed problem is one that has been eliminated and can no longer cause another incident.


## The role of the problem management process in ITIL

ITIL V3 is the most recent edition of the popular ITIL framework that includes Problem Management as a recommended process. The newest ITIL edition, V4, shifts the recommendations to suggested practices instead of processes. The new suggestions aim to empower organizations to define their own processes specific to their unique circumstances and needs.

Overall, however, an effective problem management process delivers valuable service improvements, while identifying and eliminating the driving forces behind incidents.

Learn more about how Jira Service Management can transform your problem management process.

[Try Jira Service Management](https://www.atlassian.com/software/jira/service-management)

## Recommended for you

WHITEPAPER

### Atlassian's guide to agile ways of working with ITIL 4

ITIL 4 is here—and it’s more agile than ever. Learn tips to bring agility and collaboration into ITSM with Atlassian.

[Read the whitepaper](https://www.atlassian.com/whitepapers/itil4)

### IT Change Management: ITIL Framework & Best Practices

IT Change Management minimizes risk while making changes to systems and services. Learn about the change management process, its importance, best practices

[Read this article](https://www.atlassian.com/itsm/change-management)

### Learn more about ITSM

Find more ITSM guides and resources in this hub.

[Read this article](https://www.atlassian.com/itsm)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**