<!-- source: https://docs.gitlab.com/operations/incident_management/status_page -->

/

* * *

# Status Page

- Tier: Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

With a GitLab Status Page, you can create and deploy a static website to communicate
efficiently to users during an incident. The Status Page landing page displays an
overview of recent incidents:

![Status Page landing page](https://docs.gitlab.com/operations/incident_management/img/status_page_incidents_v12_10.png)

Selecting an incident displays a detail page with more information about a particular incident:

![Status Page detail](https://docs.gitlab.com/operations/incident_management/img/status_page_detail_v12_10.png)

- Status on the incident, including when the incident was last updated.
- The incident title, including any emoji.
- The description of the incident, including emoji.
- Any file attachments provided in the incident description, or comments with a
valid image extension.
- A chronological ordered list of updates to the incident.

## Set up a Status Page [Permalink](https://docs.gitlab.com/operations/incident_management/status_page/\#set-up-a-status-page "Permalink")

To configure a GitLab Status Page you must:

1. [Configure GitLab](https://docs.gitlab.com/operations/incident_management/status_page/#configure-gitlab-with-cloud-provider-information) with your
cloud provider information.
2. [Configure your AWS account](https://docs.gitlab.com/operations/incident_management/status_page/#configure-your-aws-account).
3. [Create a Status Page project](https://docs.gitlab.com/operations/incident_management/status_page/#create-a-status-page-project) on GitLab.
4. [Sync incidents to the Status Page](https://docs.gitlab.com/operations/incident_management/status_page/#sync-incidents-to-the-status-page).

### Configure GitLab with cloud provider information [Permalink](https://docs.gitlab.com/operations/incident_management/status_page/\#configure-gitlab-with-cloud-provider-information "Permalink")

Only AWS S3 is supported as a deploy target.

Prerequisites:

- You must have the Maintainer or Owner role.

To provide GitLab with the AWS account information needed to push content to your Status Page:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Settings** \> **Monitor**.
3. Expand **Status page**.
4. Select the **Active** checkbox.
5. In the **Status Page URL** box, provide the URL for your external status page.
6. In the **S3 Bucket name** box, type the name of your S3 bucket. For more information, see
[Bucket configuration documentation](https://docs.aws.amazon.com/AmazonS3/latest/dev/HostingWebsiteOnS3Setup.html).
7. In the **AWS region** box, type the region for your bucket. For more information, see the
[AWS documentation](https://github.com/aws/aws-sdk-ruby#configuration).
8. Enter your **AWS access key ID** and **AWS Secret access key**.
9. Select **Save changes**.

### Configure your AWS account [Permalink](https://docs.gitlab.com/operations/incident_management/status_page/\#configure-your-aws-account "Permalink")

1. Within your AWS account, create two new IAM policies, using the following files
as examples:
   - [Create bucket](https://gitlab.com/gitlab-org/status-page/-/blob/master/deploy/etc/s3_create_policy.json).
   - [Update bucket contents](https://gitlab.com/gitlab-org/status-page/-/blob/master/deploy/etc/s3_update_bucket_policy.json) (Remember replace `S3_BUCKET_NAME` with your bucket name).
2. Create a new AWS access key with the permissions policies created in the first step.

### Create a status page project [Permalink](https://docs.gitlab.com/operations/incident_management/status_page/\#create-a-status-page-project "Permalink")

After configuring your AWS account, you must add the Status Page project and configure
the necessary CI/CD variables to deploy the Status Page to AWS S3:

1. Fork the [Status Page](https://gitlab.com/gitlab-org/status-page) project.
You can do this through [Repository Mirroring](https://gitlab.com/gitlab-org/status-page#repository-mirroring),
which ensures you get the up-to-date Status Page features.
2. In the left sidebar, select **Settings** \> **CI/CD**.
3. Expand **Variables**.
4. Add the following variables from your Amazon Console:
   - `S3_BUCKET_NAME` \- The name of the Amazon S3 bucket.
     If no bucket with the provided name exists, the first pipeline run creates
     one and configures it for
     [static website hosting](https://docs.aws.amazon.com/AmazonS3/latest/dev/HostingWebsiteOnS3Setup.html).

   - `AWS_DEFAULT_REGION` \- The AWS region.

   - `AWS_ACCESS_KEY_ID` \- The AWS access key ID.

   - `AWS_SECRET_ACCESS_KEY` \- The AWS secret.
5. In the left sidebar, select **Build** \> **Pipelines**.
6. To deploy the Status Page to S3, select **New pipeline**.

Consider limiting who can access issues in this project, as any user who can view
the incident can potentially [publish comments to your GitLab Status Page](https://docs.gitlab.com/operations/incident_management/status_page/#publish-comments-on-incidents).

### Sync incidents to the Status Page [Permalink](https://docs.gitlab.com/operations/incident_management/status_page/\#sync-incidents-to-the-status-page "Permalink")

After creating the CI/CD variables, configure the Project you want to use for
Incidents:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Settings** \> **Monitor**.
3. Expand **Status page**.
4. Fill in your cloud provider’s credentials and make sure to select the **Active** checkbox.
5. Select **Save changes**.

## How to use your GitLab Status Page [Permalink](https://docs.gitlab.com/operations/incident_management/status_page/\#how-to-use-your-gitlab-status-page "Permalink")

After configuring your GitLab instance, relevant updates trigger a background job
that pushes JSON-formatted data about the incident to your external cloud provider.
Your status page website periodically fetches this JSON-formatted data. It formats
and displays it to users, providing information about ongoing incidents without
extra effort from your team:

```
Understand your status pageHow GitLab fetches, formats, and displays incident dataStatus Page

Cloud Provider

GitLab Instance

trigger

saves data

fetches data

issue updates

Background job: JSON generation

Cloud Bucket stores JSON file

Static Site on CDN
```

### Publish an incident [Permalink](https://docs.gitlab.com/operations/incident_management/status_page/\#publish-an-incident "Permalink")

To publish an incident:

1. Create an incident in the project you enabled the GitLab Status Page settings in.
2. A [project or group owner](https://docs.gitlab.com/user/permissions/) must use the
[`/publish` quick action](https://docs.gitlab.com/user/project/quick_actions/#publish) to publish the
incident to the GitLab Status Page. [Confidential incidents](https://docs.gitlab.com/user/project/issues/confidential_issues/) can’t be published.

A background worker publishes the incident onto the Status Page using the credentials
you provided during setup. As part of publication, GitLab:

- Anonymizes user and group mentions with `Incident Responder`.
- Removes titles of non-public [GitLab references](https://docs.gitlab.com/user/markdown/#gitlab-specific-references).
- Publishes any files attached to incident descriptions, up to 5000 per incident.

After publication, you can access the incident’s details page by selecting the
**Published on status page** button displayed under the Incident’s title.

![Status Page detail link](https://docs.gitlab.com/operations/incident_management/img/status_page_detail_link_v13_1.png)

### Update an incident [Permalink](https://docs.gitlab.com/operations/incident_management/status_page/\#update-an-incident "Permalink")

To publish an update to the Incident, update the incident’s description.

When referenced incidents are changed (such as title or confidentiality) the incident
they were referenced in is not updated.

### Publish comments on incidents [Permalink](https://docs.gitlab.com/operations/incident_management/status_page/\#publish-comments-on-incidents "Permalink")

To publish comments to the Status Page Incident:

- Create a comment on the incident.
- When you’re ready to publish the comment, mark the comment for publication by
adding a microphone [emoji reaction](https://docs.gitlab.com/user/emoji_reactions/)
reaction (`:microphone:` 🎤) to the comment.
- Any files attached to the comment (up to 5000 per incident) are also published.

Anyone with access to view the incident can add an emoji reaction to a comment, so
consider limiting access to issues to team members only.

### Update the incident status [Permalink](https://docs.gitlab.com/operations/incident_management/status_page/\#update-the-incident-status "Permalink")

To change the incident status from `open` to `closed`, close the incident
within GitLab. Closing the incident triggers a background worker to update the
GitLab Status Page website.

If you
[make a published incident confidential](https://docs.gitlab.com/user/project/issues/confidential_issues/#make-an-issue-confidential),
GitLab unpublishes it from your GitLab Status Page website.

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**