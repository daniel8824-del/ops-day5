<!-- source: https://www.atlassian.com/itsm/esm/hr-automation-best-practices -->

Get it free

Search

Sign in

Jira Service Management is now more powerful than ever as part of Service Collection. Unlock exceptional service experiences with Rovo, Assets, and our new Customer Service Management app.

[Try it now](https://www.atlassian.com/try/cloud/signup?bundle=service-collection&edition=premium)

# HR Automation Best Practices

Many businesses delay rolling out automation until the later stages of their [ITSM](https://www.atlassian.com/itsm) implementation, as they are grappling with a multitude of challenges like growing their customer base and providing new products and services at break-neck speed. But, the instinct to postpone automation can be self-defeating because incorporating automation into Enterprise Service Management processes early can help break down team silos and better allocate scarce resources. Automation is key to IT optimization and digital transformation, and the extension to [ESM](https://www.atlassian.com/itsm/esm) is also beneficial. Modern, dynamic IT environments need to scale faster, and internal business teams desire the same.

[Get it free](https://www.atlassian.com/software/jira/service-management/free)

Imagine from day one of your ITSM tool roll-out, your Human Resources (HR) team has baked in automation to the service desk, so they can focus on projects that deliver value, instead of being stuck in the monotony of repetitive tasks. Onboarding new staff, getting them plugged into services, provisioning laptops, and granting access to all the right systems gets unwieldy and complex without a structured workflow. Without effective automation and collaboration between HR and IT teams, tasks can be forgotten and tensions arise, which leads to frustration and inefficiencies on both sides.

So how can automation help these two teams work in sync? These seven best practices are a good start:

## 1\. Take the best of ITSM to enable your HR teams

ITSM at its core is the belief that IT should be delivered as a service. [HR teams](https://www.atlassian.com/software/jira/service-management/hr) can benefit greatly from adopting this approach. However, HR can’t simply copy and paste what’s been done on the IT side and call it a day. Successful IT teams carefully think about what processes they can apply and adapt to other teams' environments. While IT shares some processes with a team like HR, their working environments, preferences, and style are likely completely different. When IT understands the HR team’s unique needs, it can better identify which processes should be automated and set up the automation - dramatically amplifying the HR team’s efficacy.

One common ITSM practice that is hugely beneficial for HR teams is [creating a centralized knowledge hub](https://www.atlassian.com/blog/it-service-management/stem-the-chaos-of-remote-work-with-these-itsm-best-practices). With a knowledge hub, HR teams can gather all of the common repetitive questions they get asked about payroll, holiday leave, ID cards, and more in one place to encourage self-service. When employees start to submit a ticket, recommended articles from the knowledge base appear with helpful information through a tool like Jira Service Management, deflecting tickets from ever reaching agents.

![Service request portal](https://dam-cdn.atl.orangelogic.com/AssetLink/hicgqj3u61b4yw846swfcm13784887q2.png)

HR is a team that interacts with almost everyone in the business, whether they’re coming in or going out. And with chat tools like Slack, email, phone calls - they’re always accessible. This makes them especially susceptible to a large influx of requests that can be challenging to manage across intake channels. IT teams can help HR automate some simple but time-sucking tasks like the closure of resolved tickets, or automatically creating sub-tasks for certain ticket types.

## 2\. Use Agile principles by starting small and iterating

Gartner: 3 Steps to [Agile](https://www.atlassian.com/agile) IT Service Management\* predicts that “by 2023, 80% of ITSM teams that have not adopted an agile approach will find their ITSM practices are ignored or bypassed as a result of more agile ways of working being adopted elsewhere in the organization.”

You wouldn’t decide to run a marathon and go from running 0 miles to 20 miles in a few days - instead you’d start small running a few miles a day and building your stamina up over time. The same applies to setting up automation for your service desk. Start and test with one business team and workflow like onboarding and continue to scale and build out the additional HR processes that need to be modernized. Understand where the bottlenecks are, what can be automated to alleviate those pain points, and start with a few systems. You’ll find other teams like legal, facilities, finance, and more will come knocking on your door, once you’ve proven a service management approach to be a success and “not just IT stuff.”

Starting small, testing, and iterating is an agile principle that you can lean into heavily. For example, we’ve seen teams do 30-day retros to identify what automation worked, and determine what automation to attempt next. Scaling sensibly ensures your service desk doesn’t become unmanageable and teams see the value first before you impose a new technology and process on them.

## 3\. Onboard new employees seamlessly with HR workflows

Manual onboarding is easy for the first few employees. The opportunity for human error escalates quickly when suddenly you’re onboarding 50 new employees weekly instead of three. The complexity of onboarding gets more involved, and automating this will ensure you have a consistent experience for new hires.

There are a dozen tiny steps and multiple departments required to get a new employee plugged into the work environment, physically and digitally. IT teams can help HR automate the entire process by setting up a series of triggers to help staff prepare for new arrivals. Once a ticket is initiated it can trigger the provisioning of a new laptop, installation of the required programs, creation of an email account, and notification of facilities to find them a desk. All of this can be done with Jira HR workflows, customized to suit your HR team’s needs.

![HR workflow](https://dam-cdn.atl.orangelogic.com/AssetLink/8s73nb40gs86dsb4qv6y5035gko013v3.png)

A smooth onboarding process enabled by automation sets a positive tone for a new employee and ensures they don’t feel like a burden or worse - forgotten about. With the entire process orchestrated, each team knows exactly what to contribute and when. Attracting and retaining talent is an expensive journey, and automated IT systems can help recoup some of the cost by ensuring new employees have a strong first impression.

## 4\. Remove the endless permission hoops

While on the topic of onboarding: one of the most frustrating experiences for a new employee is having to gain access to all the systems required to get started. If it’s day three and they still can’t get onto Slack to say hello to their team, they could be missing a team ritual they didn’t know about. Permission hoops cause new employees to sit idle, delaying their potential value.

IT has the opportunity to use automation to streamline this experience. They can provision laptops with pre-installed systems, or set up a chatbot to send to new employees all the links and Slack groups that will help them get started. Instead of jumping through several multiple permission steps, companies can switch to “open by default.” By setting up your systems with the mindset of ‘innocent until proven guilty’, teams can search and find their own answers without flooding IT’s service desk.

## 5\. Create a ‘help yourself’ attitude with a service catalog

'Can you send that in an email?’ Too often this is the default for fielding employee requests. In addition to automating permissions, IT can go one step further by providing a unified service catalog for all of their digital services, where employees can select what they need and IT can gain insight into service demand. It’s IT's job to minimize friction for workers when it comes to locating and accessing the information they need to get their job done.

As Forrester states in their report ‘Three Trends Are Transforming the Service Desk, October 2019’ _“most service management tools were once ticketing and workflow platforms, but today, they're facilitating end-to-end automation without human intervention and with capabilities on par with those of business process management (BPM) platforms.”_

Forrester also notes the importance of organizations investing time in automation to meet employees' expectations. Making options available where employees can self-serve end-to-end is quickly becoming the norm. Employees expect a rapid resolution, becoming weary of the two-week wait for IT’s response.

A large portion of request fulfillment can be automated through a service catalog and well-designed service request forms that can be created without needing to involve IT. In fact, one Atlassian customer recently automated 30% of their service catalog, much to the delight of their internal teams.

## 6\. Don’t forget about employee offboarding

Whether an employee is leaving voluntarily or not, [offboarding](https://kissflow.com/hr-process/employee-offboarding/best-practices-for-employee-offboarding/) is a sensitive process for HR teams. There’s a lot to remember to do, like notifying the team, collecting company property, following legal guidelines - and all within a short time window. Clunky offboarding invites unnecessary risk to a company with laptops and phones providing access to sensitive company data. Through automation, offboarding can become an easy win.

By using [asset management](https://www.atlassian.com/itsm/it-asset-management) tools integrated into your service desk, assets are accounted for and retrieved when the time comes. If you’re using a spreadsheet to do this, it might be time to incorporate automation and asset management into your workflows. IT can set up an offboarding flow that notifies a group of people and triggers sub-tasks. If you’re tracking assets, you can easily look up what property needs to be returned by a selected date, and have the ticket auto-resolve once the employee has exited the company. License subscriptions are another task that can easily be automated to avoid falling through the cracks.

![Employee offboarding request](https://dam-cdn.atl.orangelogic.com/AssetLink/53kd588786yab30si226ns8421bmrq83.jpg)

## 7\. Opt for low-code automation to realize value faster

While legacy vendors promise the dream through a smorgasbord of automation and Artificial Intelligence (AI) offerings, the sad reality is that this means a 50% increase in required with consulting hours and the accompanying price tag, not to mention the extra fees when you need to modify and maintain it down the track. The costs involved detract from the overall value of automation. To avoid this problem, we believe in platform-level automation through a low code approach, meaning non-technical teams can jump in and drag and drop their way to a workflow. By democratizing access to automation, teams can manage their own changes without IT being the bottleneck.

In a traditional ITSM implementation, one team usually defines the processes, which sadly end up meeting the building team’s administrative requirements and not the functional requirements of the team using the tool. A low-code platform encourages experimentation and a faster learning cycle. Jira Service Management offers any team the ability to customize their service portal, including a drag-and-drop form builder that lets each team request the exact data they need to do their job faster and provide high velocity support. An open and collaborative culture, and a democratized service desk, means more people get to use and see value in your ITSM tool.

Creating an enterprise-wide approach to automation lets you automate not only IT processes, but also entire technologies and teams. IT automation is changing the way companies manage their IT services in a digital-first business landscape. With an integrated ecosystem of products, you’ll have a comprehensive view of service across your organization. If you haven’t invested heavily already, you need to do so. Avoiding automation is bad for business.

_\*Gartner "3 Steps to Agile IT Service Management," Mark Cleary, 27 May 2020_

Want to learn more about how automation works in Jira Service Management?

[Get the guide](https://www.atlassian.com/software/jira/service-management/product-guide/tips-and-tricks/automation)

## Recommended for you

ARTICLE

### The complete guide to Enterprise Service Management (ESM)

What is Enterprise Service Management? Learn how to implement ESM for better service delivery in this guide.

[Read the article](https://www.atlassian.com/itsm/esm)

ARTICLE

### HR Service Delivery: Definition, Benefits & Best Practices

Discover what HR service delivery is, why it’s important, and how it can improve the employee experience and boost HR operations.

[Read the article](https://www.atlassian.com/itsm/esm/hr-service-management-and-delivery)

### Learn more about ITSM

Find more ITSM guides and resources in this hub.

[Read this article](https://www.atlassian.com/itsm)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**