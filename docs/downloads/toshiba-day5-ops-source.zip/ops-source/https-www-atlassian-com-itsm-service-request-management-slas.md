<!-- source: https://www.atlassian.com/itsm/service-request-management/slas -->

Get it free

Search

Sign in

Jira Service Management is now more powerful than ever as part of Service Collection. Unlock exceptional service experiences with Rovo, Assets, and our new Customer Service Management app.

[Try it now](https://www.atlassian.com/try/cloud/signup?bundle=service-collection&edition=premium)

# What is an SLA? Service level agreement explained

Get it free (Deliver value fast with Jira Service Management)

Deliver value fast with Jira Service Management

[Get it free](https://www.atlassian.com/itsm/service-request-management/slas#start-trial)

**Key Takeaway:** Service level agreements (SLAs) define the response and resolution times your team commits to, helping set clear expectations and measure performance.

- What it is: Time-based targets and rules for how quickly tickets should be acknowledged, updated, and resolved.

- Why it matters: Well-designed SLAs improve consistency, accountability, and user trust while exposing bottlenecks and capacity gaps.

- How Jira Service Management helps: Lets teams define, track, and automate SLAs with visual timers, alerts, and reports embedded in service projects.


If you’ve ever wondered about the SLA meaning or how these agreements work in practice, you’re not alone. Service level agreements shape how IT teams and service providers deliver support, but they’re often misunderstood or poorly implemented.

An SLA defines what customers can expect from a service provider and what happens when those expectations aren’t met. These agreements help IT teams prioritize work, manage customer relationships, and measure their own performance. Well-designed SLAs make everyone’s job easier by removing ambiguity about service expectations.

This guide covers what SLAs are, why they’re important, and how to create agreements that work for both service providers and customers.

[Try Service Collection Free](https://www.atlassian.com/software/jira/service-management/free)

Service Collection includes Jira Service Management to help teams streamline the process of creating and enforcing SLAs. The platform connects Dev, IT, and business teams on a single system to deliver high-velocity service.

## What is an SLA?

As a service provider, a service level agreement is a plain-language agreement between you and your customer (whether internal or external) that defines the services you will deliver, the responsiveness that can be expected, and how you will measure performance.

SLAs define contractually agreed-upon terms for services, including things like uptime and support responsiveness. For instance, promising customers 99.9% service uptime or a response from support within 24 hours. In addition to formalizing service expectations, SLAs set forth the terms for redress when requirements are breached.

An SLA is a foundational agreement between your IT team and customers that is important in building trust. They manage customer expectations and allow your team to know which issues you are responsible for resolving. With SLAs in place, there is a mutual understanding of service expectations. Implementing SLAs can benefit your IT team in numerous ways, including:

- Strengthening IT’s relationship with customers - SLAs ease the concern over risk, which improves trust between parties. By defining what happens in the event of a breach, they reduce uncertainty.

- Formalizing communication - Conversations with stakeholders about IT issues can be difficult. Nobody wants to be hearing from a customer ten times a day or, on the other hand, allowing a customer to quietly stew over their unspoken expectations for service performance. An SLA enables stakeholders to have structured conversations based on already agreed-upon terms.

- Improving productivity and morale - SLAs define the urgency of incoming requests. They focus IT teams on which incoming issues matter the most.


## What are the key components of an SLA?

Every effective SLA includes several core elements that work together to create clear expectations. Here are the main components:

- **Services provided:** This section spells out exactly what services are covered under the agreement. Whether it's [ITSM](https://www.atlassian.com/itsm) support, cloud hosting, or another service, specificity prevents confusion about what's included and what's not.

- **Performance metrics:** These are the measurable standards your team commits to meeting. Response times, resolution times, uptime percentages, and other quantifiable targets give everyone a clear benchmark for success.

- **Roles and responsibilities:** This clarifies who does what. It defines which tasks fall to the service provider, which belong to the customer, and where handoffs happen. Clear role definition prevents finger-pointing when issues arise.

- **Remedies and penalties:** This outlines what happens when SLA terms aren't met. Whether it's service credits, refunds, or other compensation, having predefined consequences creates accountability and gives customers recourse.


## Types of SLAs

SLAs can be structured in different ways depending on your business model and customer needs. The right structure depends on how you deliver your services and who you serve.

### Customer-based SLA

Customer-based SLAs are contracts between a service provider and an organization or customer. This type covers all the services that the customer receives, tailored to their specific requirements and priorities.

This approach works well when you have large enterprise clients with unique needs or when service delivery varies significantly between customers. A customer-based SLA allows you to customize performance targets, support hours, and other terms to match what that specific customer actually needs.

### Service-based SLA

A service-based SLA applies to one specific service across all customers who use it. Instead of customizing for each customer, you create a standard agreement for how that service will be delivered.

Cloud hosting providers often use this model, promising all customers the same uptime percentages and [service request](https://www.atlassian.com/itsm/service-request-management) response times. [IT support](https://www.atlassian.com/itsm/service-request-management/it-support) teams might create a service-based SLA for email support that applies equally to all departments. This standardization makes SLAs easier to manage at scale.

### Multi-level SLA

Multi-level SLAs combine corporate-level, customer-level, and service-level agreements into a hierarchical structure. This approach gives large organizations flexibility while maintaining consistency.

For example, a corporate-level SLA might set baseline standards for all services. Customer-level agreements then add specific terms for individual clients, and service-level agreements drill down into the details for each service offering. This structure helps companies with complex service portfolios manage hundreds of SLA terms without drowning in paperwork.

## SLA examples across industries

Looking at real SLA examples helps illustrate how these agreements work in practice across different sectors:

- **IT support services:** An internal IT team might promise to respond to [service desk](https://www.atlassian.com/itsm/service-request-management/how-to-build-a-service-desk) tickets within two hours during business hours and resolve critical issues within four hours. The SLA specifies that if response times exceed these targets, the IT director must explain the delay to affected department heads. Performance is measured through [IT metrics](https://www.atlassian.com/itsm/service-request-management/it-metrics-and-reporting) tracked in their ticketing system.

- **Cloud hosting:** A web hosting company guarantees 99.95% uptime for all customer websites. If monthly uptime falls below this threshold, customers receive a service credit for that month. The hosting provider tracks uptime through automated monitoring and publishes monthly reports.

- **Customer service:** A software company commits to [first call resolution](https://www.atlassian.com/itsm/service-request-management/first-call-resolution) for 70% of support calls and promises email responses within 24 hours. Calls that can't be resolved immediately are escalated to tier-2 support within one business day. Customers who experience repeated SLA breaches are offered premium support at no additional cost.


These examples show how SLAs translate abstract promises into concrete, measurable commitments with real consequences.

## What metrics should an SLA include?

The metrics you track determine whether your SLA is actually enforceable or just aspirational. Here are common metrics that appear in effective SLAs:

- **Uptime and availability:** This metric measures the percentage of time a service is operational and accessible. Most SLAs express this as a percentage, like 99.9% uptime.

- **Response time:** How quickly does your team acknowledge a service request or issue after it's reported? Response time SLAs typically vary by priority level.

- **Resolution time:** This tracks how long it takes to fully resolve an issue from initial report to final fix. Like response times, resolution targets usually differ based on issue severity.

- **Quality metrics:** Some SLAs include measures like [first call resolution](https://www.atlassian.com/itsm/service-request-management/first-call-resolution) rates or customer satisfaction scores to ensure speed doesn't come at the expense of quality.


Tracking these metrics is critical because you can't improve what you don't measure. [IT support solutions](https://www.atlassian.com/itsm/service-request-management/it-support-software) with built-in reporting make it easier to monitor performance and spot trends before they become problems

## How to set an SLA and measure your performance

Above, we talked about how SLAs can feel a bit arbitrary and like you’re not always measuring things that directly support your company’s bigger business objectives. To make sure you’re measuring the right things, and meeting the expectations that other parts of the business have of you, we recommend revisiting your SLAs regularly. Follow this process:

- Set a baseline. The best place to start is by looking at your current SLAs, and how you’re performing against them. Take an inventory of what you offer, and how it aligns to the business goals of your company and your customers.

- Ask how you’re doing. Talk directly with your customers and solicit constructive feedback. What are you doing well, and what could you do better? Are you offering the right services?

- Build a draft of new SLAs based on the results of the steps above. Get rid of the services you no longer need, and add the ones that will make customers even happier and bring more value to both the business and IT.

- Get support from management. To be successful, SLAs need the blessing of your IT leaders, and the leaders of your customer organizations, too. Start by getting your own management to buy in, and then ask them to help you negotiate with your customer’s management team.


If you've followed the above process, your SLAs should be in pretty good shape.

## What are best practices for creating an effective SLA?

Once you’ve brokered the best SLAs for your current business and customer needs, you’re ready to implement them. Here are some tips for taking SLAs to a whole new level of ease and effectiveness.

#### Create an SLA that stops tracking time to resolution while you’re waiting for a customer to reply

IT departments need to be able to measure their own response times effectively to provide the best possible service. Still, measuring SLAs gets complicated quickly as slow-responding customers and third-party escalations cause response times to look far worse than they may actually be. Make sure your measurement and reporting systems can accommodate exceptions like these, so the service desk team is tracked based on how they are actually performing.

You can also set up automation rules in Jira Service Management to automatically close tickets that have been inactive for a set period, which prevents stale issues from skewing your SLA metrics. [Service request management in Jira Service Management](https://www.atlassian.com/software/jira/service-management/product-guide/getting-started/service-request-management) provides built-in workflows for handling these types of scenarios.

#### Remember the agent experience

Use simple, clear naming conventions. Agents should be able to read the name of the SLA and quickly understand what they’re being measured on. It’s also important to resist the urge to create too many goals. Agents should be able to clearly understand what their goals are, without too many special situations. The more goals you create, and the more variables you introduce into each goal, the harder they become to understand and adhere to.

#### Break up large, complex SLAs

Rather than creating complex SLAs use a series of smaller ones, so you can measure and report on the individual pieces of your workflow, not just the entire pie. This also makes it easier to update your SLAs and keep them current.

#### Set different performance goals based on ticket priority levels

On an average day, your service desk team won’t consider a printer failure its highest priority ticket. But the CEO’s printer? That’s another story. In practice, IT teams prioritize tickets in a ton of different ways: from which parts of the business are being affected to who opened the ticket to even more complex combinations (like an outage of the sales booking system at the end of the quarter).

You need flexibility from your service desk software so you can create SLA performance goals based on just about any combination of parameters you define. It’s important to be able to change or edit them easily to keep your team’s priorities completely aligned with changing business needs.

Jira Service Management’s automation capabilities let you build rules that handle these complex priority combinations without manual intervention. You can change or edit them easily to keep your team’s priorities completely aligned with changing business needs.

#### Keep some SLAs running 24/7, and restrict others to normal business hours

If your service desk team works Monday to Friday during normal business hours, you can't provide true 24 x 7 support for every service you offer. Even with on-call service desk teams and customers that pay for priority support, you will still often have some services that warrant weekday responses, and some that warrant instant attention, no matter what time of day or night.

Configure your service desk to stop the clock from ticking on Saturdays and Sundays, and get even more complex if you want to create customized rules for things like company holidays. And, considering creating calendars to support teams based in different locations.

#### Automate routine SLA tasks

Jira Service Management includes automation features that can handle repetitive work without manual intervention. You can set up rules to automatically close support tickets after a certain period of inactivity or when customers confirm their issues are resolved. This keeps your SLA metrics accurate by preventing stale tickets from sitting in your queue and skewing your resolution times.

#### Use AI to speed up responses and resolution

Rovo agents can help streamline ticket routing and initial response, ensuring customers get answers faster and reducing the burden on your support team. AI work breakdown in Jira can help teams understand complex issues more quickly by breaking them into manageable pieces, which speeds up resolution times and helps you meet SLA targets more consistently.

## Ensure your SLA drives real results

SLAs only work if you actively monitor compliance and hold your team accountable. Set up regular reviews to check how you're performing against your targets and where you're falling short. Jira Service Management can help streamline the creation and enforcement of SLAs, making it easier to track performance and maintain consistency across your service delivery.

Remember that SLAs should evolve with your business. What worked six months ago might not serve your current needs. Schedule quarterly reviews to assess whether your SLAs still align with business priorities and customer expectations, then adjust your targets or retire outdated agreements as needed. When SLAs are designed thoughtfully and enforced consistently, they become a tool for building trust and improving service quality over time.

## Recommended for you

WHITEPAPER

### Atlassian for ITSM

The basics you need to know about ITSM with Atlassian – across IT delivery, operations, and support, plus best practices and tips.

[Get the guide](https://www.atlassian.com/whitepapers/complete-guide-itsm)

### IT Asset Management: Complete ITAM Guide & Best Practices

IT Asset Management (ITAM) is crucial for tracking and justifying IT spend. Learn more about the process, its importance, and choosing the right software.

[Read this article](https://www.atlassian.com/itsm/it-asset-management)

### Learn more about ITSM

Find more ITSM guides and resources in this hub.

[Read this article](https://www.atlassian.com/itsm)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**