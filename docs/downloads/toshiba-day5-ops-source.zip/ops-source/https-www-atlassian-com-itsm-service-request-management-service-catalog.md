<!-- source: https://www.atlassian.com/itsm/service-request-management/service-catalog -->

Get it free

Sign in

Jira Service Management is now more powerful than ever as part of Service Collection. Unlock exceptional service experiences with Rovo, Assets, and our new Customer Service Management app.

[Try it now](https://www.atlassian.com/try/cloud/signup?bundle=service-collection&edition=premium)

# Exploring IT Service Catalogs

**Key Takeaways:** A service catalog is an organized list of all the services your team offers, with clear request options and expectations.

- What it is: A structured menu of services (like access, equipment, and apps) with descriptions, eligibility, and SLAs.

- Why it matters: Makes it easy for users to know what’s available, reduces confusion, and standardizes how work enters the team.

- How Jira Service Management helps: Powers self-service portals where catalog items become guided request forms with routing, approvals, and automation built in.


It’s easy to fall behind when your team is working on a large number of [service requests](https://www.atlassian.com/itsm/service-request-management). Some of the most common derailments are requests that are out of scope for your specialty or meant for another team. Losing just a few minutes can put you behind for the rest of the day. So, how do you keep your service desk organized and clear of random requests?

[Get it free](https://www.atlassian.com/software/jira/service-management/free)

Implementing a service catalog is an efficient way to improve [service request management](https://www.atlassian.com/software/jira/service-management/product-guide/getting-started/service-request-management). A service catalog helps your customers understand what issues your team can solve, resulting in fewer off-base requests and clear expectations of how you can help. This article explores service catalogs, offers best management practices, and highlights potential integrations with the IT service desk.

## What is an IT service catalog?

A service catalog is a comprehensive list of a company’s services. These can include IT support and operations services and services offered by non-IT service teams like HR, marketing, and facilities.

A business service catalog acts as a “storefront” where end users can browse and request services, while a technical service catalog is intended for internal use by service providers. Customers select a service from your catalog and submit the required information to set the IT team up for success.

Service catalogs are a feature of service management software like [Jira Service Management](https://www.atlassian.com/software/jira/service-management). Modern service management clarifies what services are offered and how they will be delivered. Most teams that invest in a service catalog will increase quality and expedite request resolution.

Imagine your team specializes in setting up and supporting software solutions within your business. You’ve noticed increased hardware-related tickets that need to be routed to another team. Your team commits to a [service strategy](https://www.atlassian.com/itsm/itil/service-strategy) and arrives at four distinct services you can deliver. Customers now have clear descriptions to help them choose the right service, along with a helpful message guiding them if the service they need isn’t available.

![JSM Screenshot](https://dam-cdn.atl.orangelogic.com/AssetLink/o34rf7818a1x826mj0tjv4ef6p641828.png)

## Benefits of a service catalog

A service catalog provides managers with valuable data, enabling users to quickly request services and empowering teams to identify the most valuable and time-consuming tickets. It also guides customers to the right team, instilling confidence in their ability to find the right solution.

## Differences between a service catalog and a service portfolio

A service portfolio is the complete record of an IT organization's past, present, and future services. Referencing a service portfolio will help your team understand what has been worked on in the past and what you are offering today. Many teams will also add aspirational services to their service portfolio while developing the capabilities needed to provide them to future customers.

Many IT teams adjust their service offerings over time. When asked why you don't offer a service you used to, you should be able to find a ready answer within the service portfolio. Services are often discontinued due to various factors, which should be documented in your service portfolio. With a glance at your service portfolio, you can confidently answer that business leader's question.

## What is included in an IT service catalog?

An IT service catalog is a cornerstone of IT Service Management (ITSM), acting as a centralized repository of a company’s IT services. It provides a clear and organized view of available services, making it easier for users to find and request the services they need. Critical components of an IT service catalog include:

### Service offerings and options

Service offerings are the core services that a business provides to its customers. In an IT service catalog, these offerings represent the various self-serve and ITSM-supported solutions that users can access. For instance, a service offering might include software installation, password resets, or network access.

On the other hand, service options are customized versions of these offerings tailored to specific customer preferences. For example, a standard software installation might have options for different software versions or additional configurations. By clearly defining service offerings and options, an IT service catalog ensures that users can easily find and request the services that best meet their needs.

### Service relationships

Understanding the relationships between different services is crucial for effective service management. For example, a password change might require a user to log out of all devices and log back in, potentially triggering additional security measures.

By mapping out these relationships and clarifying them in the IT service catalog, IT teams can ensure a seamless user experience and avoid potential issues. This interconnected view of services is a crucial aspect of an ITIL 4 service catalog, helping to provide a comprehensive understanding of how different services interact and depend on each other.

## Service catalog management

### Roles and responsibilities for managing a service catalog

The teammates you need to execute your service catalog will vary based on the services you offer. Implementing an ITIL service catalog is crucial for establishing a standardized system for managing IT services. Best practices include prioritizing popular services, keeping stakeholders informed, leveraging AI and automation, ensuring a quality user experience, and continually measuring success to adapt to user needs and improve system efficacy.

Most IT teams are led by an IT manager, breaking out roles based on functional areas. Many IT organizations include procurement, infrastructure, architecture, operations, engineering, security, and business intelligence services. Some teams focus on having experts in each functional area, while others train generalists who can handle anything offered in your service catalog.

Modern businesses extend service management beyond IT, so teams like HR, facilities, and finance will collaborate with IT to implement their service offerings. Using data from a [service strategy](https://www.atlassian.com/itsm/itil/service-strategy), IT managers can allocate resources to the functions most in demand.

### Service catalog governance

IT governance decides a company’s future direction, resources, and goals. A service provider is crucial for defining and managing the service catalog, ensuring it meets the needs of different target audiences.

A current service catalog and an existing service portfolio are incredible assets for these future-forward conversations. Using these assets, IT managers can confidently point to which services create the most value today and look back at which services did not. Decisions made in governance could alter which services continue to be offered and which services need to be revisited or removed.

In a perfect world, governance would be up to you and your team, but that is not always true. A solid grasp of your service catalog will help decision-makers know what is at stake when changes need to be made.

### Performance metrics for service catalog management

Data on usage, SLA performance, and customer satisfaction are great starting points for measuring an IT organization's performance.

- Usage data tells IT teams what services are in demand based on the volume of tickets. This information is easily accessible by filtering your tickets by “issue type.”

- SLAs, or Service Level Agreements, dictate what the customer can expect and how long the issue should take to resolve. Your goal is to use SLAs to gauge your success in delivering service within the time allotted.

- Customer satisfaction is a valuable metric that keeps you focused on problems and the customers who experience them.


## Best practices for creating an IT service catalog

Creating an effective IT service catalog requires careful planning and execution. Here are some best practices to consider:

### Identify user needs

The first step in creating an IT service catalog is to identify the needs of your users and customers. This involves gathering input from end-users to understand their unique needs and expectations. Conduct surveys, interviews, and focus groups to gather this information. This will help you create a relevant service catalog that meets your users' needs effectively.

Additionally, consider the following best practices:

- **Clearly define the purpose and scope of the service catalog**: Ensure that everyone understands what it is for and what it will include.

- **Develop a structured and organized service catalog framework**. A well-structured framework makes it easier to manage and update the catalog.

- **Design and build the service catalog using a service management platform**: Utilize tools like Jira Service Management to create a flexible and scalable service catalog.

- **Integrate the service catalog with existing ITSM tools and systems**: Ensure that the service catalog works seamlessly with other ITSM processes and tools.

- **Test and refine the service catalog to ensure it is user-friendly and effective**: Gather user feedback and make necessary adjustments.

- **Continuously evaluate and improve the service catalog to ensure it remains relevant and effective**. Review and update the catalog regularly to align with changing user needs and organizational goals.


By following these best practices, you can create an IT Service Catalog that optimizes service delivery costs, improves user satisfaction, and enhances the overall efficiency of your IT department.

## How the service catalog supports ITSM processes

[IT Service Management (ITSM)](https://www.atlassian.com/itsm) is how IT teams manage the end-to-end delivery of IT services to customers. A self-service portal is crucial in facilitating user access to the service catalog, allowing users to view services, raise tickets, and make requests.

It’s tempting to think that your service catalog is just the beginning of your IT process, as it’s often the first thing a customer interacts with. However, your service catalog is one of the most essential components of ITSM, as it touches every stage of your IT service lifecycle.

When adding a new service to your catalog, ITSM fundamentals will inspire you to build repeatable processes that create efficiency.

### Service catalog and change management

Let's again focus on software provisioning as a service and imagine a customer who wants to spin up a new software solution for payroll. Given the complexity of change management, you've designed a [change management](https://www.atlassian.com/itsm/change-management) workflow that these service desk tickets follow step-by-step.

Modern change management workflows break down silos by notifying other teams, providing context and transparency in the ticket, avoiding bottlenecks, and minimizing risk. A service catalog and service desk can run workflows to make sure that services that need a high level of care get it every time.

### Service catalog and incident management

[Incident management](https://www.atlassian.com/incident-management) is the process used by development and IT operations teams to respond to an unplanned event or service interruption and restore the service to its operational state. Service catalog examples are crucial in illustrating best practices for setting up and managing the catalog.

A service catalog aids your incident management efforts by helping surface incidents earlier so teams can respond faster. Identifying a spike in request types can alert your team to an incident related to service. A service catalog that kicks off an Incident Management workflow helps ensure that your team doesn’t miss any steps along the way.

## Getting started with IT service catalogs

You're not alone when getting started with a service catalog. Thousands of teams have adopted a service strategy and have learned some incredible efficiencies along the way. Atlassian has collected service request management best practices that make a great foundation for your service catalog design. [Jira Service Management](https://www.atlassian.com/software/jira/service-management) offers a flexible service management solution so you can implement a service catalog that fits the unique needs of your business.

[Try Jira Service Management](https://www.atlassian.com/software/jira/service-management)

## Recommended for you

WHITEPAPER

### The Total Economic Impact™ Of Atlassian For ITSM

The Total Economic Impact™ of Atlassian Jira Service Management. The report includes cost savings and business benefits enabled by Jira Service Management.

[Read the whitepaper](https://www.atlassian.com/whitepapers/forrester-total-economic-impact-atlassian-for-itsm)

WHITEPAPER

### Atlassian's guide to agile ways of working with ITIL 4

ITIL 4 is here—and it’s more agile than ever. Learn tips to bring agility and collaboration into ITSM with Atlassian.

[Read the whitepaper](https://www.atlassian.com/whitepapers/itil4)

### Learn more about ITSM

Find more ITSM guides and resources in this hub.

[Read this article](https://www.atlassian.com/itsm)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**