<!-- source: https://docs.gitlab.com/operations/incident_management/manage_incidents -->

/

* * *

# Manage incidents

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

History

- Ability to add an [incident](https://docs.gitlab.com/operations/incident_management/) to an iteration [introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/347153) in GitLab 17.0.

This page collects instructions for all the things you can do with [incidents](https://docs.gitlab.com/operations/incident_management/incidents/) or in relation to them.

## Create an incident [Permalink](https://docs.gitlab.com/operations/incident_management/manage_incidents/\#create-an-incident "Permalink")

You can create an incident manually or automatically.

## Add an incident to an iteration [Permalink](https://docs.gitlab.com/operations/incident_management/manage_incidents/\#add-an-incident-to-an-iteration "Permalink")

- Tier: Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

To add an incident to an [iteration](https://docs.gitlab.com/user/group/iterations/):

1. In the top bar, select **Search or go to** and find your project.
2. Go to your incident:
   - For incidents in the issues list, select **Plan** \> **Work items**,
     then filter by **Type** = **Incident**.
   - For incidents in the monitor list, select **Monitor** \> **Incidents**.
3. Select your incident.
4. In the right sidebar, in the **Iteration** section, select **Edit**.
5. From the dropdown list, select the iteration to add this incident to.
6. Select any area outside the dropdown list.

Alternatively, you can use the [`/iteration` quick action](https://docs.gitlab.com/user/project/quick_actions/#iteration).

### From the Incidents page [Permalink](https://docs.gitlab.com/operations/incident_management/manage_incidents/\#from-the-incidents-page "Permalink")

Prerequisites:

- You must have the Reporter, Developer, Maintainer, or Owner role for the project.

To create an incident from the **Incidents** page:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Monitor** \> **Incidents**.
3. Select **Create incident**.

### From the Work items page [Permalink](https://docs.gitlab.com/operations/incident_management/manage_incidents/\#from-the-work-items-page "Permalink")

Prerequisites:

- You must have the Reporter, Developer, Maintainer, or Owner role for the project.

To create an incident from the **Work items** page:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Plan** \> **Work items**, and select **New item**.
3. From the **Type** dropdown list, select **Incident**. Only fields relevant to
incidents are available on the page.
4. Select **Create incident**.

### From an alert [Permalink](https://docs.gitlab.com/operations/incident_management/manage_incidents/\#from-an-alert "Permalink")

Create an incident issue when viewing an [alert](https://docs.gitlab.com/operations/incident_management/alerts/).
The incident description is populated from the alert.

Prerequisites:

- You must have the Developer, Maintainer, or Owner role for the project.

To create an incident from an alert:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Monitor** \> **Alerts**.
3. Select your desired alert.
4. Select **Create incident**.

After an incident is created, to view it from the alert, select **View incident**.

When you [close an incident](https://docs.gitlab.com/operations/incident_management/manage_incidents/#close-an-incident) linked to an alert, GitLab
[changes the alert’s status](https://docs.gitlab.com/operations/incident_management/alerts/#change-an-alerts-status) to **Resolved**.
You are then credited with the alert’s status change.

### Automatically, when an alert is triggered [Permalink](https://docs.gitlab.com/operations/incident_management/manage_incidents/\#automatically-when-an-alert-is-triggered "Permalink")

- Tier: Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

In the project settings, you can turn on [creating an incident automatically](https://docs.gitlab.com/operations/incident_management/alerts/#trigger-actions-from-alerts)
whenever an alert is triggered.

### Using the PagerDuty webhook [Permalink](https://docs.gitlab.com/operations/incident_management/manage_incidents/\#using-the-pagerduty-webhook "Permalink")

History

- [PagerDuty V3 Webhook](https://support.pagerduty.com/docs/webhooks) support [introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/383029) in GitLab 15.7.

You can set up a webhook with PagerDuty to automatically create a GitLab incident
for each PagerDuty incident. This configuration requires you to make changes
in both PagerDuty and GitLab.

Prerequisites:

- You must have the Maintainer or Owner role for the project.

To set up a webhook with PagerDuty:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Settings** \> **Monitor**
3. Expand **Incidents**.
4. Select the **PagerDuty integration** tab.
5. Turn on the **Active** toggle.
6. Select **Save integration**.
7. Copy the value of **Webhook URL** for use in a later step.
8. To add the webhook URL to a PagerDuty webhook integration, follow the steps described in the [PagerDuty documentation](https://support.pagerduty.com/docs/webhooks#manage-v3-webhook-subscriptions).

To confirm the integration is successful, trigger a test incident from PagerDuty to
check if a GitLab incident is created from the incident.

## View a list of incidents [Permalink](https://docs.gitlab.com/operations/incident_management/manage_incidents/\#view-a-list-of-incidents "Permalink")

To view a list of the [incidents](https://docs.gitlab.com/operations/incident_management/incidents/#incidents-list):

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Monitor** \> **Incidents**.

To view an incident’s [details page](https://docs.gitlab.com/operations/incident_management/incidents/#incident-details), select it from the list.

### Who can view an incident [Permalink](https://docs.gitlab.com/operations/incident_management/manage_incidents/\#who-can-view-an-incident "Permalink")

History

- [Changed](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/169256) the minimum user role from Reporter to Planner in GitLab 17.7.

Whether you can view an incident depends on the [project visibility level](https://docs.gitlab.com/user/public_access/) and
the incident’s confidentiality status:

- Public project and a non-confidential incident: Anyone can view the incident.
- Private project and non-confidential incident: You must have the Guest, Planner, Reporter, Developer, Maintainer, or Owner role for the project.
- Confidential incident (regardless of project visibility): You must have the Planner, Reporter, Developer, Maintainer, or Owner role for the project.

## Assign to a user [Permalink](https://docs.gitlab.com/operations/incident_management/manage_incidents/\#assign-to-a-user "Permalink")

Assign incidents to users that are actively responding.

Prerequisites:

- You must have the Reporter, Developer, Maintainer, or Owner role for the project.

To assign a user:

1. In an incident, in the right sidebar, next to **Assignees**, select **Edit**.
2. From the dropdown list, select one or [multiple users](https://docs.gitlab.com/user/project/issues/multiple_assignees_for_issues/) to add as **assignees**.
3. Select any area outside the dropdown list.

## Change severity [Permalink](https://docs.gitlab.com/operations/incident_management/manage_incidents/\#change-severity "Permalink")

See the [incidents list](https://docs.gitlab.com/operations/incident_management/incidents/#incidents-list) topic for a full description of the severity levels available.

Prerequisites:

- You must have the Reporter, Developer, Maintainer, or Owner role for the project.

To change an incident’s severity:

1. In an incident, in the right sidebar, next to **Severity**, select **Edit**.
2. From the dropdown list, select the new severity.

You can also change the severity using the [`/severity` quick action](https://docs.gitlab.com/user/project/quick_actions/#severity).

## Change status [Permalink](https://docs.gitlab.com/operations/incident_management/manage_incidents/\#change-status "Permalink")

History

- [Introduced](https://gitlab.com/groups/gitlab-org/-/epics/5716) in GitLab 14.9 [with a flag](https://docs.gitlab.com/administration/feature_flags/) named `incident_escalations`. Disabled by default.
- [Enabled on GitLab.com and GitLab Self-Managed](https://gitlab.com/gitlab-org/gitlab/-/issues/345769) in GitLab 14.10.
- [Feature flag `incident_escalations`](https://gitlab.com/gitlab-org/gitlab/-/issues/345769) removed in GitLab 15.1.

Prerequisites:

- You must have the Developer, Maintainer, or Owner role for the project.

To change the status of an incident:

1. In an incident, in the right sidebar, next to **Status**, select **Edit**.
2. From the dropdown list, select the new severity.

**Triggered** is the default status for new incidents.

### As an on-call responder [Permalink](https://docs.gitlab.com/operations/incident_management/manage_incidents/\#as-an-on-call-responder "Permalink")

- Tier: Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

On-call responders can respond to [incident pages](https://docs.gitlab.com/operations/incident_management/paging/#escalating-an-incident)
by changing the status.

Changing the status has the following effects:

- To **Acknowledged**: limits on-call pages based on the project’s [escalation policy](https://docs.gitlab.com/operations/incident_management/escalation_policies/).
- To **Resolved**: silences all on-call pages for the incident.
- From **Resolved** to **Triggered**: restarts the incident escalating.

In GitLab 15.1 and earlier, changing the status of an [incident created from an alert](https://docs.gitlab.com/operations/incident_management/manage_incidents/#from-an-alert)
also changes the alert status. In [GitLab 15.2 and later](https://gitlab.com/gitlab-org/gitlab/-/issues/356057),
the alert status is independent and does not change when the incident status changes.

## Change escalation policy [Permalink](https://docs.gitlab.com/operations/incident_management/manage_incidents/\#change-escalation-policy "Permalink")

- Tier: Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

Prerequisites:

- You must have the Developer, Maintainer, or Owner role for the project.

To change the escalation policy of an incident:

1. In an incident, in the right sidebar, next to **Escalation policy**, select **Edit**.
2. From the dropdown list, select the escalation policy.

By default, new incidents do not have an escalation policy selected.

Selecting an escalation policy [changes the incident status](https://docs.gitlab.com/operations/incident_management/manage_incidents/#change-status) to **Triggered** and begins
[escalating the incident to on-call responders](https://docs.gitlab.com/operations/incident_management/paging/#escalating-an-incident).

In GitLab 15.1 and earlier, the escalation policy for [incidents created from alerts](https://docs.gitlab.com/operations/incident_management/manage_incidents/#from-an-alert)
reflects the alert’s escalation policy and cannot be changed. In [GitLab 15.2 and later](https://gitlab.com/gitlab-org/gitlab/-/issues/356057),
the incident escalation policy is independent and can be changed.

## Close an incident [Permalink](https://docs.gitlab.com/operations/incident_management/manage_incidents/\#close-an-incident "Permalink")

Prerequisites:

- You must have the Reporter, Developer, Maintainer, or Owner role for the project.

To close an incident, in the upper-right corner, select **Incident actions** (ellipsis\_v) and then **Close incident**.

When you close an incident that is linked to an [alert](https://docs.gitlab.com/operations/incident_management/alerts/),
the linked alert’s status changes to **Resolved**.
You are then credited with the alert’s status change.

### Automatically close incidents via recovery alerts [Permalink](https://docs.gitlab.com/operations/incident_management/manage_incidents/\#automatically-close-incidents-via-recovery-alerts "Permalink")

Turn on closing an incident automatically when GitLab receives a recovery alert
from an HTTP or Prometheus webhook.

Prerequisites:

- You must have the Maintainer or Owner role for the project.

To configure the setting:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Settings** \> **Monitor**.
3. Expand the **Incidents** section.
4. Select the **Automatically close associated incident** checkbox.
5. Select **Save changes**.

When GitLab receives a [recovery alert](https://docs.gitlab.com/operations/incident_management/integrations/#recovery-alerts), it closes the associated incident.
This action is recorded as a system note on the incident indicating that it
was closed automatically by the GitLab Alert bot.

## Delete an incident [Permalink](https://docs.gitlab.com/operations/incident_management/manage_incidents/\#delete-an-incident "Permalink")

Prerequisites:

- You must have the Owner role for a project.

To delete an incident:

1. In an incident, select **Incident actions** (ellipsis\_v).
2. Select **Delete incident**.

Alternatively:

1. In an incident, select **Edit**.
2. Select **Delete incident**.

## Other actions [Permalink](https://docs.gitlab.com/operations/incident_management/manage_incidents/\#other-actions "Permalink")

Because incidents in GitLab are built on top of [issues](https://docs.gitlab.com/user/project/issues/),
they have the following actions in common:

- [Add a to-do item](https://docs.gitlab.com/user/todos/#create-a-to-do-item)
- [Add labels](https://docs.gitlab.com/user/project/labels/#assign-and-unassign-labels)
- [Assign a milestone](https://docs.gitlab.com/user/project/milestones/#assign-a-milestone-to-an-item)
- [Make an incident confidential](https://docs.gitlab.com/user/project/issues/confidential_issues/)
- [Set a due date](https://docs.gitlab.com/user/project/issues/due_dates/)
- [Toggle notifications](https://docs.gitlab.com/user/profile/notifications/#subscribe-to-notifications-for-a-specific-issue-merge-request-or-epic)
- [Track time spent](https://docs.gitlab.com/user/project/time_tracking/)

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**