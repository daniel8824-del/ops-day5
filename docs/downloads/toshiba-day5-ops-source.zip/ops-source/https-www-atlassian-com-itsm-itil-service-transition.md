<!-- source: https://www.atlassian.com/itsm/itil/service-transition -->

Get it free

Sign in

Jira Service Management is now more powerful than ever as part of Service Collection. Unlock exceptional service experiences with Rovo, Assets, and our new Customer Service Management app.

[Try it now](https://www.atlassian.com/try/cloud/signup?bundle=service-collection&edition=premium)

# ITIL service transition: principles, benefits, and processes

Service transition is the process of moving services from development into the production environment. Without careful planning, new and updated services can potentially disrupt business processes. Collaboration across IT and the business is necessary, including preparing users and support staff for the change.

[Get it free](https://www.atlassian.com/software/jira/service-management/free)

Service transition is the third stage of the [ITIL service lifecycle](https://www.atlassian.com/itsm/itil/service-strategy). It applies to new services, existing services that are changing, and retiring legacy services. [ITIL](https://www.atlassian.com/itsm/itil) service transition employs best practices to shift services to production effectively, safely, and efficiently.

This guide will review the benefits and key principles of ITIL service transition, as well as roles and processes that ensure success.

## What is ITIL service transition?

During ITIL service transition, IT teams move new or updated services from the development environment to production. It uses the service [knowledge management](https://www.atlassian.com/itsm/knowledge-management) system to ensure the changes provide value to the business. It deploys prioritized changes that improve efficiency and mitigate risks.

## Key principles of service transition

Formalizing the ITIL service transition process reduces the risks inherent in making changes. It also ensures that [IT teams](https://www.atlassian.com/teams/it) are ready to address issues. The key principles of service transition encourage teams to:

- Manage and predict potential course corrections.

- Repurpose existing services for efficiency.

- Maintain important services during the transition.

- Transfer critical knowledge for faster, more accurate [decision-making](https://www.atlassian.com/work-management/team-management-and-leadership/decision-making).

- Define [roles and responsibilities](https://www.atlassian.com/team-playbook/plays/roles-and-responsibilities) for timely, knowledgeable responses.


## ITIL service transition process

Service transition in ITIL helps IT teams identify hidden risks, clarify roles, share knowledge before it’s necessary, plan for contingencies, and assist customers with the changes. The ITIL service transition process consists of the following steps:

### Planning and coordination

Planning and coordination give teams clearly defined activities to complete during the transition. Teams map each role and responsibility collaboratively. They also identify key stakeholders, which helps create a clear understanding and agreement on what to do and who will do it.

### Change evaluation

Change evaluation addresses significant changes to critical business systems, such as customer relationship management or payment processing services. The [Change Advisory Board (CAB)](https://www.atlassian.com/itsm/change-management/change-advisory-board) often recommends these changes because they offer benefits that outweigh the risks.

[Change management](https://www.atlassian.com/itsm/change-management) assesses the details of the changes, reviews risks, and often includes an impact analysis. The CAB prioritizes changes so developers can focus on the technical aspects of the changes.

### Release and deployment

Release and deployment are central to the success of ITIL service transition. This step manages building, testing, planning, and deploying services. This can include pilots, communicating with stakeholders, training customers, and adhering to [service level agreements (SLA)](https://www.atlassian.com/itsm/service-request-management/slas).

Categorizing releases into types helps IT teams prioritize based on need. Major releases may include hardware and software components or new features. A minor release may consist of significant changes to existing services. Emergency releases require immediate attention and can include temporary patches or workarounds.

### Service validation and testing

Service validation and testing ensures the quality and reliability of the service in the production environment. For example, a payment processing service change may require additional rounds of prerelease testing and post-implementation validation to ensure the service works as expected.

### Knowledge transfer

Gathering, documenting, and sharing information about the service change prepares customers for success. This is especially critical for support teams, who need to respond knowledgeably to unforeseen issues. Good knowledge transfer decreases downtime and helps eliminate user frustration.

### Release closure

The release closure step clearly defines the end of the project. It also allows teams to review the process from an experienced perspective. This promotes [continuous improvement](https://www.atlassian.com/agile/project-management/continuous-improvement) and [team collaboration](https://www.atlassian.com/work-management/project-collaboration/collaborative-culture/team-collaboration). Examining stumbling blocks and issues should focus on identifying solutions and never on placing blame.

## Benefits of ITIL service transition

ITIL service transition improves the overall success and efficiency of changes in several ways:

- Unforeseen delays and downtime decrease.

- User experience and confidence in support preparedness improve.

- Improvements are cost-effective and based on business needs.

- Maintainability improves.

- Support staff and customers gain more knowledge.


## Service transition roles and responsibilities

Depending on the complexity of the change, the roles and responsibilities of ITIL service transition teams can vary. They can include a [change manager](https://www.atlassian.com/itsm/change-management/roles-and-responsibilities) who oversees the [CAB](https://www.atlassian.com/itsm/change-management/change-advisory-board), which assesses and authorizes the change. It can include a release manager who focuses on the detailed tasks of the release itself. Configuration management, which controls and maintains information about relationships and dependencies, is often a key area of responsibility. Or, it can include application developers and managers who oversee testing, knowledge, and projects.

## Integration with other ITIL lifecycle stages

Service transition is the third stage in the ITIL lifecycle. It builds on the preceding [service strategy](https://www.atlassian.com/itsm/itil/service-strategy) and service design stages. Service transition transforms the approved change from a [strategic goal](https://www.atlassian.com/work-management/strategic-planning/framework) to a completed, integrated service in the production environment. Release management unites these stages. It includes mapping plans for operation and continual service improvement.

## Jira Service Management for service transition

[Jira Service Management](https://www.atlassian.com/software/jira/service-management) is a comprehensive tool for effective service transition. It allows teams to manage every step of the deployment–planning, prioritizing, assigning responsibility, tracking tasks, testing, and information sharing.

With Jira Service Management, IT service management ( [ITSM](https://www.atlassian.com/itsm)) teams break down silos with optimized workflows on a single platform. It promotes team collaboration, manages progress tracking, and makes [incident management](https://www.atlassian.com/incident-management) easier. By eliminating repetitive tasks and manual processes, teams can scale to meet the needs of the business.

[Learn more about how developers use Jira Service Management](https://www.atlassian.com/webinars/it/jira-service-management-for-software-development-teams)

## Service management: Frequently asked questions

### What is the purpose of service transition?

Service transition involves every aspect of moving new and changed services from the development and testing environments into production. It identifies risks, defines roles and responsibilities, and ensures adherence to policies and service-level agreements. It also coordinates affected services and provides necessary technical knowledge and user training for successful integration.

### What is the difference between service transition and change management?

Both service transition and change management focus on changes to business systems. [Change management](https://www.atlassian.com/itsm/change-management) is a standardized process for assessing and prioritizing all changes. It often includes the CAB, which approves and prioritizes change requests. Service transition focuses on specific, pre-approved changes and moving those changes into the production environment.

### What are the 5 stages of an ITIL service lifecycle?

The service lifecycle includes the following five stages:

1. [**ITIL service strategy**](https://www.atlassian.com/itsm/itil/service-strategy) aligns business goals and customer needs with implementation strategies.

2. **Service design** focuses on holistic approaches to designing and delivering improved services.

3. **Service transition** deploys the service to the production environment.

4. **Service operation** refers to the day-to-day operation of the company.

5. **Continuous service improvement** strategically identifies further opportunities to improve.


## Recommended for you

WHITEPAPER

### Atlassian's guide to agile ways of working with ITIL 4

ITIL 4 is here—and it’s more agile than ever. Learn tips to bring agility and collaboration into ITSM with Atlassian.

[Read the whitepaper](https://www.atlassian.com/whitepapers/itil4)

ARTICLE

### What is a service request?

Service Request Management enables IT teams to quickly and easily fulfill customer requests. Check out the process and best practices.

[Read the article](https://www.atlassian.com/itsm/service-request-management)

### Learn more about ITSM

Find more ITSM guides and resources in this hub.

[Read this article](https://www.atlassian.com/itsm)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**