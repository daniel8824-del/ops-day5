<!-- source: https://docs.gitlab.com/operations/incident_management/escalation_policies -->

/

* * *

# Escalation policies

- Tier: Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

Escalation policies protect your company from missed critical alerts. Escalation policies contain
time-boxed steps that automatically page the next responder in the escalation step if the responder
in the previous step has not responded. You can create an escalation policy in the GitLab project
where you manage [on-call schedules](https://docs.gitlab.com/operations/incident_management/oncall_schedules/).

## Add an escalation policy [Permalink](https://docs.gitlab.com/operations/incident_management/escalation_policies/\#add-an-escalation-policy "Permalink")

Prerequisites:

- You must have the Maintainer or Owner role.
- You must have an [on-call schedule](https://docs.gitlab.com/operations/incident_management/oncall_schedules/).

To create an escalation policy:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Monitor** \> **Escalation Policies**.
3. Select **Add an escalation policy**.
4. Enter the policy’s name and description, and
escalation rules to follow when a primary responder misses an alert.
5. Select **Add escalation policy**.

![Escalation Policy](https://docs.gitlab.com/operations/incident_management/img/escalation_policy_v14_1.png)

### Select the responder of an escalation rule [Permalink](https://docs.gitlab.com/operations/incident_management/escalation_policies/\#select-the-responder-of-an-escalation-rule "Permalink")

When configuring an escalation rule, you can designate who to page:

- **Email on-call user in schedule**: notifies the users who are on-call when the rule is triggered,
covering all rotations on the specified [on-call schedule](https://docs.gitlab.com/operations/incident_management/oncall_schedules/).
- **Email user**: notifies the specified user directly.

When a notification is sent to a user through an on-call schedule or directly, a system note listing
the paged users is created on the alert.

The time specified for an escalation rule must be between 0 and 1440 minutes.

## Edit an escalation policy [Permalink](https://docs.gitlab.com/operations/incident_management/escalation_policies/\#edit-an-escalation-policy "Permalink")

To update an escalation policy:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Monitor** \> **Escalation Policies**.
3. Select **Edit escalation policy** (pencil).
4. Edit the information.
5. Select **Save changes**.

## Delete an escalation policy [Permalink](https://docs.gitlab.com/operations/incident_management/escalation_policies/\#delete-an-escalation-policy "Permalink")

To delete an escalation policy:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Monitor** \> **Escalation Policies**.
3. Select **Delete escalation policy** (remove).
4. On the confirmation dialog, select **Delete escalation policy**.

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**