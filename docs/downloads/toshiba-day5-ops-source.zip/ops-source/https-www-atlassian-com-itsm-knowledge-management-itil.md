<!-- source: https://www.atlassian.com/itsm/knowledge-management/ITIL -->

Get it free

Search

Sign in

Jira Service Management is now more powerful than ever as part of Service Collection. Unlock exceptional service experiences with Rovo, Assets, and our new Customer Service Management app.

[Try it now](https://www.atlassian.com/try/cloud/signup?bundle=service-collection&edition=premium)

# 4 ways knowledge management can support your IT service practices

Having a [knowledge-centered service desk](https://www.atlassian.com/itsm/knowledge-management/kcs) allows teams to respond to and resolve issues quickly, provide consistent answers, and enable self service. But how does [knowledge management](https://www.atlassian.com/itsm/knowledge-management) support other service management practices?

[Get it free](https://www.atlassian.com/software/jira/service-management/free)

Effective knowledge management enables teams to deliver service according to the [ITIL guiding principles](https://www.atlassian.com/itsm/itil). Knowledge management keeps things simple and practical by giving users easy access to information, wherever they are. From service request management and incident management to problem and change management, employees and customers can access the information they need to keep things running smoothly.

A good knowledge base tool and strong knowledge management practices can help keep teams calm, cool, and collected. Here’s how knowledge management supports IT service practices in [Jira Service Management](https://www.atlassian.com/software/jira/service-management/features/itsm#knowledge-management).

### How knowledge management enables service request management

A strong knowledge management practice streamlines service request practices for IT and other service teams. For example, an employee may submit a service request describing an issue with VPN access. When they visit the Jira Service Management Help Center, they input the description of their service issue and relevant articles are automatically surfaced. This can offer immediate answers and helps employees troubleshoot problems faster—and often more conveniently—than waiting for support.

![service request for vpn](https://dam-cdn.atl.orangelogic.com/AssetLink/1iy6ex08wstt0vv1j430p0700kcg40tp.png)

When a support agent is responding to a service request, Jira Service Management will scan the issue and automatically suggest any [knowledge base](https://www.atlassian.com/itsm/knowledge-management/what-is-a-knowledge-base) articles that relate to keywords in the issue. Then, the agent can consult the article to provide guidance to the help seeker. When agents come across common new issues, they can also document resolution approaches in knowledge base articles to enable the rest of the team and avoid repetitive work. Agents are empowered to view, search, and share knowledge base articles directly from Jira Service Management issues.

![Related articles to service request](https://dam-cdn.atl.orangelogic.com/AssetLink/1gft236qwqbc23l52145606f3304oc87.png)

A strong knowledge management practice means that support agents spend less time on requests, provide more consistent customer experiences, and provide a blueprint for [continuous improvement](https://www.atlassian.com/agile/project-management/continuous-improvement). On the other hand, employees have the ability to troubleshoot issues faster, as these articles allow them to self-service.

### Streamline incident management practices with knowledge management

Imagine you work for an e-commerce company that launches a new product line. Expectations are high, and customers love the product. Suddenly, a major service outage hits the website, resulting in a checkout glitch, yielding disappointed, unhappy customers (not to mention a loss in sales).

Strong knowledge management practices are critical during times when the IT team is in the trenches, dealing with major outages like Sev1 and 2 tickets. Having answers at an agent’s fingertips is the difference between time spent searching for an answer and time spent resolving an issue. For instance, developing an [incident response playbook](https://www.atlassian.com/incident-management/incident-response/how-to-create-an-incident-response-playbook) that houses step-by-step response practices and defines roles and responsibilities for your team can be a source of knowledge that makes or breaks a successful incident response. Without that readily available knowledge, teams are left scrambling to respond to unpredictable incidents.

While the short-term goal is fast incident resolution, the long-term goal should always be to lower the overall incident [mean-time-to-resolution (MTTR)](https://www.atlassian.com/incident-management/kpis/common-metrics). Knowledge management means the team can continuously learn from incidents, document their findings, and develop playbooks to achieve faster incident resolution when issues do arise.

### Use knowledge management documentation for problem management

Knowledge management is critical for [problem management](https://www.atlassian.com/itsm/problem-management) and root-cause analysis. With documentation outlining the cause, incidents, known errors, workarounds, and resolution for incidents, teams are armed with information.

[Incident postmortems](https://www.atlassian.com/incident-management/postmortem), sometimes referred to as post-incident reviews (PIRs), can serve as a source of knowledge to better tackle future incidents and problems. An incident postmortem brings people together to discuss the details of an incident: why it happened, its impact, what actions were taken to mitigate it and resolve it, and what should be done to prevent it from happening again. Following through with the postmortem process can contribute to a body of knowledge that could potentially prevent future incidents and problems.

An action item resulting from an incident postmortem might be to publish a knowledge base entry addressing the workaround to quickly resolve that incident. This way, lessons learned from previous incidents can help resolve future incidents faster, or prevent them altogether.

![Action item from post mortem report](https://dam-cdn.atl.orangelogic.com/AssetLink/ot24x7rkg0352t0221qdk24366dy1u60.jpeg)

### Change management is made simple with knowledge management tools

Strong [change management](https://www.atlassian.com/itsm/change-management) practices make use of change plans to create a game plan for the change, helping teams to properly evaluate risk before making operational changes.

Dev, ops, and business teams can use [change plan templates](https://www.atlassian.com/software/confluence/templates/itsm-change-management) to manage and track change requests and implementation plans. And, with everyone literally on the same page, teams can collaborate asynchronously and reduce bottlenecks that can occur with traditional CAB approval processes.

![Change details](https://dam-cdn.atl.orangelogic.com/AssetLink/agxd555a0bpp5x6f358r74032i60cfng.jpeg)

With knowledge base articles linked to change requests, teams can minimize risk with full context into the details of a change and collaboratively deploy changes more frequently.

### Strong knowledge management practices are crucial for delivering fast service

A robust knowledge management system can act as a support for IT service management practices. A knowledge base can increase your service team’s efficiency and provide a more user-friendly experience by offering a self-help option to your customers. The IT operations team is also empowered to resolve incidents faster, share crucial problem management records, and plan for changes with full context.

Want to start bringing knowledge management into your service desk?

[Try Jira Service Management](https://www.atlassian.com/software/jira/service-management/features/itsm#knowledge-management)

## Recommended for you

WHITEPAPER

### The Total Economic Impact™ Of Atlassian For ITSM

The Total Economic Impact™ of Atlassian Jira Service Management. The report includes cost savings and business benefits enabled by Jira Service Management.

[Read the whitepaper](https://www.atlassian.com/whitepapers/forrester-total-economic-impact-atlassian-for-itsm)

WHITEPAPER

### Atlassian's guide to agile ways of working with ITIL 4

ITIL 4 is here—and it’s more agile than ever. Learn tips to bring agility and collaboration into ITSM with Atlassian.

[Read the whitepaper](https://www.atlassian.com/whitepapers/itil4)

### Learn more about ITSM

Find more ITSM guides and resources in this hub.

[Read this article](https://www.atlassian.com/itsm)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**