<!-- source: https://www.businesswire.com/news/home/20251202251261/en/Weis-Markets-Completes-Technology-Transformation-with-Toshibas-ELERA-Security-Suite -->

Dec 2, 2025 9:53 AM Eastern Standard Time

# **Weis Markets Completes Technology Transformation with Toshiba’s ELERA® Security Suite**

Share

* * *

_Weis Markets’ successful implementation of Toshiba’s ELERA® underscores its commitment to innovation and operational excellence_

[![original Weis Markets implements Toshiba’s ELERA® Security Suite to enhance loss prevention measures and improve the overall customer experience.](https://mms.businesswire.com/media/20251202251261/en/2656935/4/Weis_1.jpg?download=1)](https://mms.businesswire.com/media/20251202251261/en/2656935/5/Weis_1.jpg?download=1)

Weis Markets implements Toshiba’s ELERA® Security Suite to enhance loss prevention measures and improve the overall customer experience.

[Download media](https://mms.businesswire.com/media/20251202251261/en/2656935/5/Weis_1.jpg?download=1)

![thumbnail Weis Markets implements Toshiba’s ELERA® Security Suite to enhance loss prevention measures and improve the overall customer experience.](https://mms.businesswire.com/media/20251202251261/en/2656935/4/Weis_1.jpg)![thumbnail ](https://mms.businesswire.com/media/20251202251261/en/792024/4/Toshiba_RGB.jpg)

RESEARCH TRIANGLE PARK, N.C.--( [BUSINESS WIRE](https://www.businesswire.com/))-- [Weis Markets](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fwww.weismarkets.com%2F&esheet=54365664&newsitemid=20251202251261&lan=en-US&anchor=Weis+Markets&index=1&md5=d3e89189e9e17ba27dd59befba96267e) is expanding its investment in innovative retail technology by partnering with [Toshiba Global Commerce Solutions](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fcommerce.toshiba.com%2F&esheet=54365664&newsitemid=20251202251261&lan=en-US&anchor=Toshiba+Global+Commerce+Solutions&index=2&md5=45a002662f4a843c065a366258651900) and successfully implementing [ELERA® Security Suite](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fcommerce.toshiba.com%2Fwps%2Fportal%2Fmarketing%2F%3Furile%3Dwcm%3Apath%3A%2Fen-us%2Fhome%2Fsoftware%2Fiot-suite%2Felera-security-suite&esheet=54365664&newsitemid=20251202251261&lan=en-US&anchor=ELERA%26%23174%3B+Security+Suite&index=3&md5=6a9580b09dead05835c180e08b36b0c7) to enhance loss prevention measures and improve the overall customer experience.

> “We are one of the first retail chains with ELERA® Security Suite across our stores, ensuring speed, privacy, and performance. It is already strengthening real-time loss prevention.”
>
> Share

ELERA® Security Suite is now operational across self-checkout lanes in all 199 Weis locations, with plans to extend the technology to dual-use and cashier lanes. ELERA® Security Suite – which includes ELERA® Loss Prevention and ELERA® Produce Recognition offers a comprehensive solution that delivers key benefits for security and checkout experiences.

“Our goal is to upgrade our technology stack and invest in ELERA® Security Suite to provide a frictionless experience for our customers. Our customers have embraced produce recognition, with over 94% selecting to use it at self-checkout,” said Greg Zeh, CIO and SVP of Weis Markets. “We are one of the first retail chains with ELERA® Security Suite across our stores, ensuring speed, privacy, and performance. It is already strengthening real-time loss prevention.”

Effective loss prevention solutions must include dynamic human factors, speed, and data. Empowered by edge AI, ELERA® Security Suite enables real-time, on-device processing at self-checkout stations to automatically identify produce items and proactively correct loss-related behaviors. Unlike systems that only detect incidents after they happen, the suite prompts immediate action with minimal customer disruption.

“Weis Markets has been a trusted partner for over two decades, and we’re thrilled to support their continued innovation. By understanding the real-world complexities of shrink, we designed a system that helps retailers like Weis Markets to enhance the shopping experience and empower associates,” said Yevgeni Tsirulnik, SVP Portfolio Management at Toshiba Global Commerce Solutions. “ELERA® Security Suite represents a significant leap forward in self-checkout solutions. Its edge AI operates locally at checkout, shifting loss prevention from reactive detection to proactive influence and built to evolve with changing business needs.”

The implementation is part of Weis Markets’ ongoing ELERA® journey with Toshiba. The scalable solution boosts operational performance and reduces store costs through serverless, energy-efficient edge processing, providing Weis Markets with powerful, real-time insights. Its modular design integrates seamlessly with existing store hardware and the ELERA® Commerce Platform POS used by Weis Markets, lowering infrastructure costs and complexity. With an integrated dashboard for loss prevention and produce recognition, Weis Markets can proactively manage and streamline store operations while driving meaningful cost savings. ELERA® also safely handles all customer and payment data across POS, self-service, mobile, loyalty, and payment systems to deliver a faster, more secure experience for shoppers.

Toshiba will showcase ELERA® Security Suite and other retail innovations across software, hardware, and services in [their booth](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fcommerce.toshiba.com%2Fwps%2Fportal%2Fmarketing%2F%3Furile%3Dwcm%3Apath%3A%2Fen-us%2Fhome%2Fcompany%2Fevents%2Fnrf-2026%26mapping%3Dtgcs_new.portal.company.eventdetails&esheet=54365664&newsitemid=20251202251261&lan=en-US&anchor=their+booth&index=4&md5=2d5620375b6bd1d2da2d6c764bc0a3ae) at the upcoming [NRF 2026: Retail’s Big Show](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fnrfbigshow.nrf.com%2F%3Fgad_source%3D1%26gad_campaignid%3D21195323163%26gbraid%3D0AAAAADtpYfojn_tLf2zJD1IAvB6OLI-TN%26gclid%3DCj0KCQjw9obIBhCAARIsAGHm1mQTMBkRb1x1e56cMq3vJmHrymWRbrBjKjF3abETn4M9kVbdnY5O-4waAkE3EALw_wcB&esheet=54365664&newsitemid=20251202251261&lan=en-US&anchor=NRF+2026%3A+Retail%26%238217%3Bs+Big+Show&index=5&md5=70968e00811866a355f5b74d9418a949) in January.

**About Weis Markets** Founded in 1912, Weis Markets, Inc. is a Mid Atlantic food retailer operating 197 stores in Pennsylvania, Maryland, Delaware, New Jersey, New York, West Virginia and Virginia. For more information, please visit: [WeisMarkets.com](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fwww.weismarkets.com%2F&esheet=54365664&newsitemid=20251202251261&lan=en-US&anchor=WeisMarkets.com&index=6&md5=7a96bd073ba006fccd4193989f1bd4f5) or [Facebook.com/WeisMarkets](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fwww.facebook.com%2FWeisMarkets&esheet=54365664&newsitemid=20251202251261&lan=en-US&anchor=Facebook.com%2FWeisMarkets&index=7&md5=d1fa7d654ebfd2e69c88769e2f5a8b93).

**About Toshiba Global Commerce Solutions:** Toshiba Global Commerce Solutions empowers retail to thrive and prosper through a dynamic ecosystem of smarter, more agile solutions and services that enable retailers to resiliently evolve with generations of consumers and adapt to market conditions. Supported by a global organization of devoted employees and partners, retailers gain more visibility and control over operations while enjoying the flexibility to build, scale, and transform retail experiences that anticipate and fulfill consumers’ ever-changing needs. Visit [commerce.toshiba.com](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fcommerce.toshiba.com%2F&esheet=54365664&newsitemid=20251202251261&lan=en-US&anchor=commerce.toshiba.com&index=8&md5=a64129f20289c0e8dfc9b6189a662f9b) and engage with us on [X, formerly known as Twitter](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Ftwitter.com%2FToshibaCommerce&esheet=54365664&newsitemid=20251202251261&lan=en-US&anchor=X%2C+formerly+known+as+Twitter&index=9&md5=62e8e9d86977f65c8bb5d580d3390de4), [Facebook](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fwww.facebook.com%2FToshibaCommerce%2F&esheet=54365664&newsitemid=20251202251261&lan=en-US&anchor=Facebook&index=10&md5=cd3583b9ff2d671a164ba1e9b31e9f86), [LinkedIn](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fwww.linkedin.com%2Fcompany%2Ftoshibacommerce&esheet=54365664&newsitemid=20251202251261&lan=en-US&anchor=LinkedIn&index=11&md5=6d6fc07e5141cd66bb2bbfc4e24610f0), [Instagram](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fwww.instagram.com%2Ftoshibacommerce%2F&esheet=54365664&newsitemid=20251202251261&lan=en-US&anchor=Instagram&index=12&md5=cc86f915efc95d45b55d9602230df6a7), and [YouTube](https://cts.businesswire.com/ct/CT?id=smartlink&url=https%3A%2F%2Fwww.youtube.com%2Ftoshibacommerce&esheet=54365664&newsitemid=20251202251261&lan=en-US&anchor=YouTube&index=13&md5=729b183b5f788b59e4286163770a9b84), to learn more.

_Toshiba Global Commerce Solutions is a wholly owned subsidiary of Toshiba Tec Corporation, which is traded on the Tokyo Stock Exchange._

## Contacts

**MEDIA CONTACT:**

Toshiba Global Commerce Solutions

Elizabeth Romero / Amy Gray

[elizabeth.romero@toshibagcs.com](mailto:elizabeth.romero@toshibagcs.com) [amy.gray@toshibagcs.com](mailto:amy.gray@toshibagcs.com)

Industry:

- [Technology](https://www.businesswire.com/newsroom?industry=1000178)
- [Mobile/Wireless](https://www.businesswire.com/newsroom?industry=1050096)
- [Online Privacy](https://www.businesswire.com/newsroom?industry=1778610)
- [Retail](https://www.businesswire.com/newsroom?industry=1000162)
- [Other Technology](https://www.businesswire.com/newsroom?industry=1000139)
- [Other Retail](https://www.businesswire.com/newsroom?industry=1000137)
- [Software](https://www.businesswire.com/newsroom?industry=1000169)
- [Networks](https://www.businesswire.com/newsroom?industry=1000120)
- [Supermarket](https://www.businesswire.com/newsroom?industry=1000174)
- [Internet](https://www.businesswire.com/newsroom?industry=1000098)
- [Specialty](https://www.businesswire.com/newsroom?industry=1000170)
- [Data Management](https://www.businesswire.com/newsroom?industry=1000056)
- [Security](https://www.businesswire.com/newsroom?industry=1050094)
- [Food/Beverage](https://www.businesswire.com/newsroom?industry=1000078)

[![Toshiba Logo](https://mms.businesswire.com/media/20251202251261/en/792024/4/Toshiba_RGB.jpg)](https://commerce.toshiba.com/)

### Toshiba

* * *

Release Summary

Weis Markets implements Toshiba’s ELERA® Security Suite to underscore its commitment to innovation and operational excellence.

Release Versions

[English](https://www.businesswire.com/news/home/20251202251261/en/Weis-Markets-Completes-Technology-Transformation-with-Toshibas-ELERA-Security-Suite)

* * *

### Contacts

**MEDIA CONTACT:**

Toshiba Global Commerce Solutions

Elizabeth Romero / Amy Gray

[elizabeth.romero@toshibagcs.com](mailto:elizabeth.romero@toshibagcs.com) [amy.gray@toshibagcs.com](mailto:amy.gray@toshibagcs.com)

Social Media Profiles

[Toshiba Global Commerce Solutions on Facebook](https://www.facebook.com/ToshibaCommerce)

[Toshiba Global Commerce Solutions on Instagram](https://www.instagram.com/toshibacommerce/)

[Toshiba Global Commerce Solutions on LinkedIn](https://www.linkedin.com/company/toshibacommerce)

[Toshiba Global Commerce Solutions on X](https://twitter.com/ToshibaCommerce)

[Toshiba Global Commerce Solutions on YouTube](https://www.youtube.com/channel/UCzD2PuqeUSITJxkylZyniJw)

More News From Toshiba

Get RSS Feed

[**Toshiba Named a Leader in the IDC MarketScape: Worldwide Point-of-Sale Software in Grocery and Food Store Retail 2026 Vendor Assessment**](https://www.businesswire.com/news/home/20260507456086/en/Toshiba-Named-a-Leader-in-the-IDC-MarketScape-Worldwide-Point-of-Sale-Software-in-Grocery-and-Food-Store-Retail-2026-Vendor-Assessment)

RESEARCH TRIANGLE PARK, N.C.--( [BUSINESS WIRE](https://www.businesswire.com/))--IDC MarketScape names Toshiba as a Leader in the latest POS software in grocery and food retail 2026 vendor assessment....

![Toshiba_Logo_Red_cmyk.jpg](https://mms.businesswire.com/media/20260507456086/en/2798149/21/Toshiba_Logo_Red_cmyk.jpg)

[**Toshiba Global Commerce Solutions Promotes Eugene Shvartsman to Chief Revenue Officer to Accelerate Global Growth**](https://www.businesswire.com/news/home/20260408466551/en/Toshiba-Global-Commerce-Solutions-Promotes-Eugene-Shvartsman-to-Chief-Revenue-Officer-to-Accelerate-Global-Growth)

RESEARCH TRIANGLE PARK, N.C.--( [BUSINESS WIRE](https://www.businesswire.com/))--Eugene Shvartsman will now serve as CRO at Toshiba Global Commerce Solutions....

![ES_Mar2026.jpg](https://mms.businesswire.com/media/20260408466551/en/2767979/21/ES_Mar2026.jpg)

[**Retailers Invited to Connect with Toshiba Innovation Experts and Rethink Store Technology at the Retail Technology Show 2026**](https://www.businesswire.com/news/home/20260407255301/en/Retailers-Invited-to-Connect-with-Toshiba-Innovation-Experts-and-Rethink-Store-Technology-at-the-Retail-Technology-Show-2026)

LONDON--( [BUSINESS WIRE](https://www.businesswire.com/))--Toshiba Global Commerce Solutions is sponsoring the Retailers Lounge at the Retail Technology Show, taking place on 22–23 April 2026 at ExCeL London....

![RTS26_Press_Release_Image.jpg](https://mms.businesswire.com/media/20260407255301/en/2767002/21/RTS26_Press_Release_Image.jpg)

[Back to Newsroom](https://www.businesswire.com/newsroom)

[![Toshiba Logo](https://mms.businesswire.com/media/20251202251261/en/792024/4/Toshiba_RGB.jpg)](https://commerce.toshiba.com/)

### Toshiba

* * *

Release Summary

Weis Markets implements Toshiba’s ELERA® Security Suite to underscore its commitment to innovation and operational excellence.

Release Versions

[English](https://www.businesswire.com/news/home/20251202251261/en/Weis-Markets-Completes-Technology-Transformation-with-Toshibas-ELERA-Security-Suite)

* * *

### Contacts

**MEDIA CONTACT:**

Toshiba Global Commerce Solutions

Elizabeth Romero / Amy Gray

[elizabeth.romero@toshibagcs.com](mailto:elizabeth.romero@toshibagcs.com) [amy.gray@toshibagcs.com](mailto:amy.gray@toshibagcs.com)

Social Media Profiles

[Toshiba Global Commerce Solutions on Facebook](https://www.facebook.com/ToshibaCommerce)

[Toshiba Global Commerce Solutions on Instagram](https://www.instagram.com/toshibacommerce/)

[Toshiba Global Commerce Solutions on LinkedIn](https://www.linkedin.com/company/toshibacommerce)

[Toshiba Global Commerce Solutions on X](https://twitter.com/ToshibaCommerce)

[Toshiba Global Commerce Solutions on YouTube](https://www.youtube.com/channel/UCzD2PuqeUSITJxkylZyniJw)

## Wish your news had this kind of reach?

[Sign Up](https://www.businesswire.com/sign-up/account) [Learn About Business Wire](https://www.businesswire.com/why-business-wire)