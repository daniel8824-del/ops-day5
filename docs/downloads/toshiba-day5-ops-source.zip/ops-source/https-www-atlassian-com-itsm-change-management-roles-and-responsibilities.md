<!-- source: https://www.atlassian.com/itsm/change-management/roles-and-responsibilities -->

Get it free

Search

Sign in

Jira Service Management is now more powerful than ever as part of Service Collection. Unlock exceptional service experiences with Rovo, Assets, and our new Customer Service Management app.

[Try it now](https://www.atlassian.com/try/cloud/signup?bundle=service-collection&edition=premium)

# How teams share change management roles and responsibilities

The primary objective of any [change management](https://www.atlassian.com/itsm/change-management) practice is reducing incidents as updates are shipped so customers stay happy and you stay ahead of the competition. Today, customers have heightened expectations for always-on, high-performing services.

[Get it free](https://www.atlassian.com/software/jira/service-management/free)

It is critical to properly manage service interruptions and ship frequent improvements with care. Today’s teams have embraced risk mitigation tactics while delivering customer value in the most streamlined, agile manner possible, often leveraging tools like [Jira Service Management](https://www.atlassian.com/software/jira/service-management).

To achieve these goals, companies have designated various roles and responsibilities associated with change management. For enterprise companies, these roles are typically shared by multiple employees or teams.

For smaller companies, a single employee may take on change management responsibilities alongside other duties. Someone with change management responsibilities may also be a developer or team lead, for example. Alternatively, change management responsibilities might be integrated into the role of an IT administrator. In other cases, automated processes may be slowly built and shared among existing teams.

While there is no one-size-fits-all model for assigning change management responsibilities, companies should adopt a framework that best suits their needs. Teams of every size can benefit from reevaluating the practice of giving change responsibilities to individuals with specific titles, especially when they are far removed from the projects they are reviewing.

By embracing new opportunities to automate change processes and integrate best practices into existing workflows, team members assuming change management responsibilities can step into more strategic roles and recoup precious time better spent on pursuing core business objectives.

## Common change management roles

The roles involved in change management depend on a number of factors, including the type and size of an organization. Below are several common change management roles.

### Change manager/coordinator

Change managers—sometimes called change coordinators—are typically responsible for managing all aspects of IT changes. They prioritize change requests, assess their impact, and accept or reject changes. [Jira Service Management](https://www.atlassian.com/software/jira/service-management) can significantly enhance these tasks by providing advanced ticketing systems and streamlined communication channels. Change managers also document change management processes and change plans. Most importantly, they organize change management strategies and act as chairs of change advisory board (CAB) meetings. A change manager’s success is typically assessed by whether they meet timing and budget objectives.

#### Change manager job description

Change managers within an organization take charge of change management initiatives, guiding their implementation. They design and execute strategies to facilitate employee adoption of workplace changes, such as overseeing the smooth transition to a new project management software or implementing a flexible remote work policy.

These senior leaders collaborate closely with other key stakeholders to ensure changes align with corporate strategic objectives. They also work with project managers to ensure smooth operations, continuously monitor progress and make necessary adjustments. Change managers may also analyze employee experiences and offer solutions for a smooth transition.

#### What is the difference between a change manager and a project manager?

The change manager's primary focus is on minimizing the adverse effects of organizational changes and optimizing positive results. This role places a strong emphasis on addressing the human aspect of change, including understanding its impact on individuals and facilitating their adaptation to new circumstances. In contrast, the project manager concentrates on delivering the actual product, ensuring it is completed within established timelines, budget constraints, and in line with stakeholder expectations.

### Change authorities/approvers

A change authority is a person who decides whether or not to authorize a change. Sometimes, this is a single person—usually a senior manager or executive. Sometimes, it’s a group on a change advisory board. Sometimes, it’s a peer reviewer.

According to [ITIL 4](https://www.axelos.com/store/book/itil-foundation-itil-4-edition), “In high-velocity organizations, it is common practice to decentralize change approval, making the peer review a top predictor of high performance.” [Jira Service Management](https://www.atlassian.com/software/jira/service-management) supports this approach, providing a platform for effective peer reviews and decentralized decision-making.

Change managers typically work closely with the change authority to approve and implement strategies to move changes forward. In some cases, particularly in small companies, the change manager is the change authority and, as such, has the power to make decisions without looping in additional teams.

### Business stakeholders

Business stakeholders are often involved in change management and may be looped into the authorization process. This is increasingly common, given the critical importance of software services to most enterprises. For example, suppose a change impacts the connection between the finance team’s payment tracking software and the sales team’s CRM. In that case, senior leaders from the finance and sales teams may need to be involved in CAB meetings and the decision-making process.

### Engineers/developers

Development teams typically submit changes for approval and document the case for its necessity. Once a change is approved, change managers or CABs adopting the [you-built-it-you-run-it](https://www.atlassian.com/incident-management/devops/you-built-it-you-run-it) approach may direct dev teams to deploy changes, monitor them, and respond to any incidents arising from them. In other cases, an incident management team may be responsible for responding to any problems. This team may be separate from the development team.

### Service desk agents

Service desk agents play a vital role in change management, offering a unique front-line perspective on incidents and common service issues that may arise due to changes. Their close interaction with end-users equips them to identify potential challenges and gather valuable feedback, making them essential in ensuring smooth transitions during change implementation. Their insights help craft effective communication strategies and swift problem resolution, ultimately contributing to the overall success of change initiatives. Jira Service Management, a comprehensive [service desk solution](https://www.atlassian.com/software/jira/service-management/features/service-desk), further enhances the capabilities of service desk agents in change management. By leveraging its robust features, such as advanced ticketing systems and streamlined communication channels, service desk agents can efficiently track and manage change requests, ensuring a smooth integration of changes while maintaining a high level of customer satisfaction.

### Operations managers

Operations managers, responsible for the continuous functioning of systems on a daily basis, play a pivotal role in assessing and managing risk and dependencies. Their expertise in maintaining system stability and performance allows them to provide project managers with critical insights into the potential impact of changes, ensuring a balanced approach to change management that prioritizes innovation and operational reliability.

### Customer relationship managers

With exceptional communication skills, customer relationship managers act as a bridge between the organization and its customers, enabling them to represent the voice of the customer effectively to key stakeholders. They offer valuable insights into customer mindsets, concerns, and evolving requirements, helping companies stay attuned to the ever-changing needs of their clientele. By providing this essential feedback, they contribute to shaping customer-centric change initiatives and enhancing overall customer satisfaction.

### Information security officers and network engineers

Information security officers and network engineers, possessing specialized expertise in network security and cloud infrastructure, play a critical role in identifying and addressing threats and vulnerabilities. Their insights and recommendations help strengthen an organization’s security posture, ensuring that changes are implemented with a keen awareness of potential risks.

By collaborating with these professionals, companies can fortify their defenses and maintain the integrity of their digital infrastructure and business processes in the face of evolving security challenges.

## Transforming the role of change advisory boards (CABs)

Change advisory boards have historically played a crucial role in assessing the risks associated with change requests and approving or rejecting them. Traditional CABs often acted as gatekeepers controlling the release of proposed changes.

However, they have been criticized for poor time management skills, lengthy change request backlogs, and their detachment from the actual work. Fortunately, CABs are evolving to become more strategic advisors, transforming their role in the change management process.

### Challenges of traditional CABs

Traditional CABs have often been criticized for their inefficiency, resulting in unproductive meetings that waste time and involve too many stakeholders. This is likely due to the fact that they have been burdened with broad responsibilities.

Consider a control tower at an airport. Its sole purpose is to clear planes for landing, not assess aircraft safety or pilot credentials. Many CABs, on the other hand, are tasked with making extensive safety decisions about various changes, often during the week when participants are eager to leave for the weekend. This setup hinders their effectiveness.

Furthermore, CABs often prioritize the risk of changes causing incidents but may overlook the risk of delaying valuable changes, which can harm customers and have a negative impact on an organization’s ability to compete within the market.

### Repositioning CABs as strategic advisors

To transform CABs into strategic advisors, companies should reconsider the traditional, heavyweight change management processes that often hinder software delivery performance. Data from the [State of DevOps Report 2019](https://services.google.com/fh/files/misc/state-of-devops-2019.pdf) indicates that procedures requiring CAB approval can negatively affect performance, with no evidence suggesting lower change fail rates due to formal approval processes.

Today’s teams are taking the following steps to improve their CABs:

1. **Customized approach**: Stop treating change requests uniformly. Each change request presents an opportunity to gather valuable data, allowing for pre-approval and automation of less consequential changes.

2. **Integration of change and release management**: Bring change and release management closer together and avoid bundling large packages of changes for review and approval, which can lead to significant incidents and delays.

3. **Progressive releases**: Implement progressive deploys to test and iterate changes on a small subset of users, reducing the scope of potential incidents and ensuring deployment success.

4. **Automation**: Rethink approval models and embrace automation to streamline change management processes, making them more efficient and reducing manual tasks.

5. **Shift left**: Implement peer review as a common strategy to replace or reduce CAB approvals, putting the responsibility for identifying issues in the code on those who understand it best. Ensure meticulous documentation to comply with regulations.

6. **Convene experts**: Rather than approving individual requests, CABs can focus on process improvement, offering recommendations, providing resources, and using change management tools to enhance performance and speed up value delivery to the market.


## Defining change management principles and responsibilities

When defining roles and responsibilities in change management teams, there is no one-size-fits-all approach. Consider your company’s culture, team structures, skills, and regulatory requirements. Engage teams in discussion to understand their essential contributions and needs, considering various frameworks like DevOps, CI/CD, and ITIL. Evaluate your current change process, identify areas for improvement, and work on shifting regular changes to standard or pre-approved status.

Change management is an essential practice, and there is always room for improvement. Whether you are just starting in business management or seeking to enhance your change management practices, there are ways to track changes, implement risk assessment and automation systems, and empower your operations teams to manage change with tools like [Jira Service Management](https://www.atlassian.com/software/jira/service-management).

[Get started with change management](https://www.atlassian.com/software/jira/service-management/product-guide/getting-started/change-management)

## Recommended for you

WHITEPAPER

### Atlassian's guide to agile ways of working with ITIL 4

ITIL 4 is here—and it’s more agile than ever. Learn tips to bring agility and collaboration into ITSM with Atlassian.

[Read the whitepaper](https://www.atlassian.com/whitepapers/itil4)

### What Is Knowledge Management?

Knowledge management processes create, curate, share, use, and manage knowledge across an organization and even across industries. Learn more here.

[Read the article](https://www.atlassian.com/itsm/knowledge-management)

### Learn more about ITSM

Find more ITSM guides and resources in this hub.

[Read this article](https://www.atlassian.com/itsm)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**