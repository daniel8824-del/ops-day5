<!-- source: https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcxpay/!ut/p/z0/fYy9DoIwFEafxYGR3FrxbyQMGA1RBk29i6mkQBVaoFXs21sTFxe37-Q7OYDAABV_yopbqRVvPJ9xcdmto3izSsgh3dM5ybOIHpenfJZOKWwB_wu-IG99jzFgoZUVLwtMqPBhAlLrVgTE6NKOfPCrERUvXGicsaL1vy1eHXefAh2yJKsAO27rUKpSA_uVgX3l7o5XN8aTN5iBuqw! -->

![logo](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcxpay/!ut/p/z1/nZJfT4MwFMU_iw88jl4BEX1juODcyGAJA_tiOlIKBiiDToaffjX6IAuZxD71z-_cnp5bhFGMcEU-ckZEzitSyPUrNt9WD4b9bDnguxvtDgLP0ML7XaC7txqKLgDfdiAwQ9e3lo5u7EyEp-hhMGyYb7W5DiDx_-h_V5qmvwLg6-Vf_rpAJpi_Hw7YRjjhlaAngWJazY6tAhkvqQItT0VHGjkrKCNJP2v7VtBSnovkVJP-q4LWeI7HEK6JyGZ5lXIUD2EU_8ARwkNH1ma5kI427spYPwGYxiUw0rKRRw97MiEVVvD99weyq71uSfMNTWlDG_XYyO1MiLp9VECBrutUxjkrqJrwUoExScZbGduQRHUZhmH8uaaRXy-2Vq8X7OYMCMgA4w!!/images/logo.png)X

Sign in to your Toshiba account

For optimum experience,
please log in on your desktop computer

UserName

Password

Sign In [Forgot password?](https://www.toshibacommerce.com/tgcs109/tsim/forgotpassword.do) [Enterprise Login](https://www.toshibacommerce.com/mga/sps/authsvc?PolicyId=urn:ibm:security:authentication:asf:externalIDPLogin&target=https%3A%2F%2Ftoshibacommerce.com%2Fwps%2Fmyportal)

Don't have an ID? [Request one here](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/faqs)

{}

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

# TCx® Pay

Ensure your payments solution has the performance, flexibility, and support that supports your business’ long-term growth. All while offering your customers the choice of how to pay.

Meet TCx® Pay.

Select a Language for your download.EnglishDownload TCx® Pay Brochure

![product-img](https://commerce.toshiba.com/wps/wcm/connect/marketing/1f03cb9e-e122-4794-9d4c-e000eac248f2/WW2020-Main-Product-Image-TCx-Pay.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-1f03cb9e-e122-4794-9d4c-e000eac248f2-o.aOnR7)

![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcxpay/!ut/p/z1/nZJfT4MwFMU_iw88jl4BEX1juODcyGAJA_tiOlIKBiiDToaffjX6IAuZxD71z-_cnp5bhFGMcEU-ckZEzitSyPUrNt9WD4b9bDnguxvtDgLP0ML7XaC7txqKLgDfdiAwQ9e3lo5u7EyEp-hhMGyYb7W5DiDx_-h_V5qmvwLg6-Vf_rpAJpi_Hw7YRjjhlaAngWJazY6tAhkvqQItT0VHGjkrKCNJP2v7VtBSnovkVJP-q4LWeI7HEK6JyGZ5lXIUD2EU_8ARwkNH1ma5kI427spYPwGYxiUw0rKRRw97MiEVVvD99weyq71uSfMNTWlDG_XYyO1MiLp9VECBrutUxjkrqJrwUoExScZbGduQRHUZhmH8uaaRXy-2Vq8X7OYMCMgA4w!!/images/i_swiper-next-dark.svg)

![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcxpay/!ut/p/z1/nZJfT4MwFMU_iw88jl4BEX1juODcyGAJA_tiOlIKBiiDToaffjX6IAuZxD71z-_cnp5bhFGMcEU-ckZEzitSyPUrNt9WD4b9bDnguxvtDgLP0ML7XaC7txqKLgDfdiAwQ9e3lo5u7EyEp-hhMGyYb7W5DiDx_-h_V5qmvwLg6-Vf_rpAJpi_Hw7YRjjhlaAngWJazY6tAhkvqQItT0VHGjkrKCNJP2v7VtBSnovkVJP-q4LWeI7HEK6JyGZ5lXIUD2EU_8ARwkNH1ma5kI427spYPwGYxiUw0rKRRw97MiEVVvD99weyq71uSfMNTWlDG_XYyO1MiLp9VECBrutUxjkrqJrwUoExScZbGduQRHUZhmH8uaaRXy-2Vq8X7OYMCMgA4w!!/images/i_swiper-prev-dark.svg)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

## About This Item

### General Info

- Secure ways to accept payments across store touch points
- Freedom to choose which processors or payment devices are right for you
- Remove the burden of managing growing payments complexity
- Flexible support for current and future payments requirements
- Use a single-source supplier for entire payments value chain
- Frees up IT teams and budgets for other operational priorities

![IMPLEMENT](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcxpay/!ut/p/z1/nZJfT4MwFMU_iw88jl4BEX1juODcyGAJA_tiOlIKBiiDToaffjX6IAuZxD71z-_cnp5bhFGMcEU-ckZEzitSyPUrNt9WD4b9bDnguxvtDgLP0ML7XaC7txqKLgDfdiAwQ9e3lo5u7EyEp-hhMGyYb7W5DiDx_-h_V5qmvwLg6-Vf_rpAJpi_Hw7YRjjhlaAngWJazY6tAhkvqQItT0VHGjkrKCNJP2v7VtBSnovkVJP-q4LWeI7HEK6JyGZ5lXIUD2EU_8ARwkNH1ma5kI427spYPwGYxiUw0rKRRw97MiEVVvD99weyq71uSfMNTWlDG_XYyO1MiLp9VECBrutUxjkrqJrwUoExScZbGduQRHUZhmH8uaaRXy-2Vq8X7OYMCMgA4w!!/images/i_shield-check-solid.svg)

### **FREEDOM**

Switch between your devices, device providers, and payment processors

![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcxpay/!ut/p/z1/nZJfT4MwFMU_iw88jl4BEX1juODcyGAJA_tiOlIKBiiDToaffjX6IAuZxD71z-_cnp5bhFGMcEU-ckZEzitSyPUrNt9WD4b9bDnguxvtDgLP0ML7XaC7txqKLgDfdiAwQ9e3lo5u7EyEp-hhMGyYb7W5DiDx_-h_V5qmvwLg6-Vf_rpAJpi_Hw7YRjjhlaAngWJazY6tAhkvqQItT0VHGjkrKCNJP2v7VtBSnovkVJP-q4LWeI7HEK6JyGZ5lXIUD2EU_8ARwkNH1ma5kI427spYPwGYxiUw0rKRRw97MiEVVvD99weyq71uSfMNTWlDG_XYyO1MiLp9VECBrutUxjkrqJrwUoExScZbGduQRHUZhmH8uaaRXy-2Vq8X7OYMCMgA4w!!/images/i_puzzle-piece-solid.svg)

### SPEED

Reduce implementation time with out-of-the-box integrations

![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcxpay/!ut/p/z1/nZJfT4MwFMU_iw88jl4BEX1juODcyGAJA_tiOlIKBiiDToaffjX6IAuZxD71z-_cnp5bhFGMcEU-ckZEzitSyPUrNt9WD4b9bDnguxvtDgLP0ML7XaC7txqKLgDfdiAwQ9e3lo5u7EyEp-hhMGyYb7W5DiDx_-h_V5qmvwLg6-Vf_rpAJpi_Hw7YRjjhlaAngWJazY6tAhkvqQItT0VHGjkrKCNJP2v7VtBSnovkVJP-q4LWeI7HEK6JyGZ5lXIUD2EU_8ARwkNH1ma5kI427spYPwGYxiUw0rKRRw97MiEVVvD99weyq71uSfMNTWlDG_XYyO1MiLp9VECBrutUxjkrqJrwUoExScZbGduQRHUZhmH8uaaRXy-2Vq8X7OYMCMgA4w!!/images/i_object-intersect-solid.svg)

### SECURITY

Best-in-class security takes POS out of PCI scope, and includes P2PE and Tokenization

![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcxpay/!ut/p/z1/nZJfT4MwFMU_iw88jl4BEX1juODcyGAJA_tiOlIKBiiDToaffjX6IAuZxD71z-_cnp5bhFGMcEU-ckZEzitSyPUrNt9WD4b9bDnguxvtDgLP0ML7XaC7txqKLgDfdiAwQ9e3lo5u7EyEp-hhMGyYb7W5DiDx_-h_V5qmvwLg6-Vf_rpAJpi_Hw7YRjjhlaAngWJazY6tAhkvqQItT0VHGjkrKCNJP2v7VtBSnovkVJP-q4LWeI7HEK6JyGZ5lXIUD2EU_8ARwkNH1ma5kI427spYPwGYxiUw0rKRRw97MiEVVvD99weyq71uSfMNTWlDG_XYyO1MiLp9VECBrutUxjkrqJrwUoExScZbGduQRHUZhmH8uaaRXy-2Vq8X7OYMCMgA4w!!/images/i_gears-solid.svg)

### REPORTING

Device state management, audit and reconciliation insights, and enterprise reporting tools

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/cff54720-d9f3-4d2d-97f4-60b1a1b72b58/Easy%2Bto%2Bintegrate.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-cff54720-d9f3-4d2d-97f4-60b1a1b72b58-o.aLGL2)

### Flexible Payments

Your payments platform needs to flexibly support your business.

Whether adopting new ways for your customers to pay, accepting EMV chip cards and new tender types, or incorporating digital marketing into the device display, TCx Pay lets your customers choose how they want to pay.

Take advantage of our dedicated high-availability, single end-to-end, turn-key solution with best-in-class security to simplify your supplier complexity in a single step.

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcxpay/!ut/p/z1/nZJfT4MwFMU_iw88jl4BEX1juODcyGAJA_tiOlIKBiiDToaffjX6IAuZxD71z-_cnp5bhFGMcEU-ckZEzitSyPUrNt9WD4b9bDnguxvtDgLP0ML7XaC7txqKLgDfdiAwQ9e3lo5u7EyEp-hhMGyYb7W5DiDx_-h_V5qmvwLg6-Vf_rpAJpi_Hw7YRjjhlaAngWJazY6tAhkvqQItT0VHGjkrKCNJP2v7VtBSnovkVJP-q4LWeI7HEK6JyGZ5lXIUD2EU_8ARwkNH1ma5kI427spYPwGYxiUw0rKRRw97MiEVVvD99weyq71uSfMNTWlDG_XYyO1MiLp9VECBrutUxjkrqJrwUoExScZbGduQRHUZhmH8uaaRXy-2Vq8X7OYMCMgA4w!!/images/g_cta-dark-left-squares.svg)

## Specifications

Specification Summary [Download Specifications](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/b3mx/mjc1/~edisp/prod.tos1275773.pdf)

## **Software features** **:**

**Features / Benefits**

**Encryption**

The proprietary application’s Card Data Entry (CDE) process includes encryption at the time of insert or swipe, secure transport of the card payment data to the payment switch, and tokenization of the payment receipt. Point-to-Point encryption (P2PE) is provided as part of the solution at no additional cost, delivering security throughout the process. In addition, the solution is PA—DSS 3.0 and PCI—DSS 3.0 certified.

**Tokenization**

TCx Pay provides a single token across all retailer channels that can be used to more effectively track transactions and securely mine CRM data for more actionable insights.

**Payment Processor**

Integration with major processors in 20 countries, including the US, Canada and Mexico, gives retailers the flexibility to select one or more processors. Additionally, retailers can make processor changes without EMV recertification issues or changes to their store systems or POS registers.

**Pin Pads**

- TCx Pay is interoperable with a broad selection of Ingenico and Verifone terminals allowing for complete flexibility to upgrade to the latest device or introduce mobile checkout and Bring Your Own Device (mobile wallets)
- TCx Pay V1R2 additionally provides:
  - Expanded EMV contactless support for Ingenico iSC250 and Ingenico iSC480 devices
  - Online WIC support enabled on Verifone and Ingenico devices
  - Smart Card WIC support on Verifone devices
  - Moneris Solutions Certification (in process)

**Speedy Payment Innovation**

TCx Pay manages all changes in payment compliance processes including EMV plus enables acceptance of payment products such as Apple Pay, PayPal, Samsung Pay, NFC, AliPay and other future payment products, as well as enabling the quick adoption and integration of new payment types without having to go through a recertification process. TCx Pay is already Quick Chip enabled for frictionless checkout experiences.

**Architecture Enhancements**

TCx Pay and ACE/EPS Co-Existence – Retailers now have the ability to utilize both EPS and/or TCx Pay for cashless transactions, allowing retailers the flexibility to enable a mixed environment, and helps smooth the transition from a fully integrated to semi-integrated payments infrastructure

**Touchpoints and Retailer Types**

- CHEC Enablement – Allows retailers to consolidate their payments infrastructure across devices, leveraging all the features and capabilities of TCx Pay, now for their self-service lanes
- AIG & AIR Enablement - Independent retailers and grocers can now take advantage of TCx Pay

**Performance Improvements**

- Improved dip speed and EMV Quick Chip - help retailers dramatically improve the customer experience and optimize payment during checkout
- Automated Application Installer - Simplifies Credit Card Terminal provisioning and setup in existing hardware environments, protecting retailer's investments and helping to streamline the provisioning process with much lower service costs
- Scrolling Receipt - Enables retailers to show a running record of purchases on the Credit Card Terminal, allowing customers to verify items scanned and receive real-time feedback -- like discounts or coupons -- as items in their cart are being scanned.

**Point of Interaction**

Improve the overall shopping experience by enabling retailers to deliver marketing programs to customers through the pin pad, including targeted marketing messages, customer surveys, instant rewards, and membership opportunities.

**Powerful Business Insights**

TCx Pay is designed to make the back office procedures easy and keep areas like accounting reconciliation, analysis, and device monitoring in compliance with PCI requirements. To ensure easy manageability and access to powerful insights, an enterprise reporting portal is included. Retailers also control their own data, which is stored in co-located data centers

**Easy Omni-channel Integration**

TCx Pay can easily integrate with various retailer payment points. From traditional to cloud-based POS solutions, the flexible SDK can be integrated in a few weeks. For highly customized solutions, integration can be accomplished in weeks instead of months, and with minimal to no changes to the existing POS software. TCx Pay also offers SDKs for e-commerce, in store mobile tablets and customer mobile wallets allowing retailers to deliver a seamless shopping experience.

**Return on Investment**

TCx Pay can easily integrate with various retailer payment points. From traditional to cloud-based POS solutions, the flexible SDK can be integrated in a few weeks. For highly customized solutions, integration can be accomplished in weeks instead of months, and with minimal to no changes to the existing POS software. TCx Pay also offers SDKs for e-commerce, in store mobile tablets and customer mobile wallets allowing retailers to deliver a seamless shopping experience.

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcxpay/!ut/p/z1/nZJfT4MwFMU_iw88jl4BEX1juODcyGAJA_tiOlIKBiiDToaffjX6IAuZxD71z-_cnp5bhFGMcEU-ckZEzitSyPUrNt9WD4b9bDnguxvtDgLP0ML7XaC7txqKLgDfdiAwQ9e3lo5u7EyEp-hhMGyYb7W5DiDx_-h_V5qmvwLg6-Vf_rpAJpi_Hw7YRjjhlaAngWJazY6tAhkvqQItT0VHGjkrKCNJP2v7VtBSnovkVJP-q4LWeI7HEK6JyGZ5lXIUD2EU_8ARwkNH1ma5kI427spYPwGYxiUw0rKRRw97MiEVVvD99weyq71uSfMNTWlDG_XYyO1MiLp9VECBrutUxjkrqJrwUoExScZbGduQRHUZhmH8uaaRXy-2Vq8X7OYMCMgA4w!!/images/g_cta-block-support-left.svg)![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcxpay/!ut/p/z1/nZJfT4MwFMU_iw88jl4BEX1juODcyGAJA_tiOlIKBiiDToaffjX6IAuZxD71z-_cnp5bhFGMcEU-ckZEzitSyPUrNt9WD4b9bDnguxvtDgLP0ML7XaC7txqKLgDfdiAwQ9e3lo5u7EyEp-hhMGyYb7W5DiDx_-h_V5qmvwLg6-Vf_rpAJpi_Hw7YRjjhlaAngWJazY6tAhkvqQItT0VHGjkrKCNJP2v7VtBSnovkVJP-q4LWeI7HEK6JyGZ5lXIUD2EU_8ARwkNH1ma5kI427spYPwGYxiUw0rKRRw97MiEVVvD99weyq71uSfMNTWlDG_XYyO1MiLp9VECBrutUxjkrqJrwUoExScZbGduQRHUZhmH8uaaRXy-2Vq8X7OYMCMgA4w!!/images/i_toolbox.svg)

## Product Support & Maintenance

Need help with your Toshiba product?

[Get Support](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcxpay/!ut/p/z1/nZJfT4MwFMU_iw88jl4BEX1juODcyGAJA_tiOlIKBiiDToaffjX6IAuZxD71z-_cnp5bhFGMcEU-ckZEzitSyPUrNt9WD4b9bDnguxvtDgLP0ML7XaC7txqKLgDfdiAwQ9e3lo5u7EyEp-hhMGyYb7W5DiDx_-h_V5qmvwLg6-Vf_rpAJpi_Hw7YRjjhlaAngWJazY6tAhkvqQItT0VHGjkrKCNJP2v7VtBSnovkVJP-q4LWeI7HEK6JyGZ5lXIUD2EU_8ARwkNH1ma5kI427spYPwGYxiUw0rKRRw97MiEVVvD99weyq71uSfMNTWlDG_XYyO1MiLp9VECBrutUxjkrqJrwUoExScZbGduQRHUZhmH8uaaRXy-2Vq8X7OYMCMgA4w!!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fsupport)![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcxpay/!ut/p/z1/nZJfT4MwFMU_iw88jl4BEX1juODcyGAJA_tiOlIKBiiDToaffjX6IAuZxD71z-_cnp5bhFGMcEU-ckZEzitSyPUrNt9WD4b9bDnguxvtDgLP0ML7XaC7txqKLgDfdiAwQ9e3lo5u7EyEp-hhMGyYb7W5DiDx_-h_V5qmvwLg6-Vf_rpAJpi_Hw7YRjjhlaAngWJazY6tAhkvqQItT0VHGjkrKCNJP2v7VtBSnovkVJP-q4LWeI7HEK6JyGZ5lXIUD2EU_8ARwkNH1ma5kI427spYPwGYxiUw0rKRRw97MiEVVvD99weyq71uSfMNTWlDG_XYyO1MiLp9VECBrutUxjkrqJrwUoExScZbGduQRHUZhmH8uaaRXy-2Vq8X7OYMCMgA4w!!/images/g_cta-block-support-right.svg)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

## Featured

### Related Solutions

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/b4097981-0367-4944-ae2d-99ca49fe4e62/WW2020-Cross-Promotion-Space-ELERA-Point-of-sale.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-b4097981-0367-4944-ae2d-99ca49fe4e62-oPr5Nl6)\\
\\
**ELERA® Point-of-Sale** \\
\\
Commerce](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcxpay/!ut/p/z1/nZJfT4MwFMU_iw88jl4BEX1juODcyGAJA_tiOlIKBiiDToaffjX6IAuZxD71z-_cnp5bhFGMcEU-ckZEzitSyPUrNt9WD4b9bDnguxvtDgLP0ML7XaC7txqKLgDfdiAwQ9e3lo5u7EyEp-hhMGyYb7W5DiDx_-h_V5qmvwLg6-Vf_rpAJpi_Hw7YRjjhlaAngWJazY6tAhkvqQItT0VHGjkrKCNJP2v7VtBSnovkVJP-q4LWeI7HEK6JyGZ5lXIUD2EU_8ARwkNH1ma5kI427spYPwGYxiUw0rKRRw97MiEVVvD99weyq71uSfMNTWlDG_XYyO1MiLp9VECBrutUxjkrqJrwUoExScZbGduQRHUZhmH8uaaRXy-2Vq8X7OYMCMgA4w!!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fsoftware%2Fcommerce-suite%2Felera-pos?mapping=tgcs_new.portal.software)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/0a052dc9-6977-4dcc-bd5d-89afa00fb5e7/WW2020-Cross-Promotion-Space-TCxSimplify.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-0a052dc9-6977-4dcc-bd5d-89afa00fb5e7-p8GsHgR)\\
\\
**TCx® Simplify**](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcxpay/!ut/p/z1/nZJfT4MwFMU_iw88jl4BEX1juODcyGAJA_tiOlIKBiiDToaffjX6IAuZxD71z-_cnp5bhFGMcEU-ckZEzitSyPUrNt9WD4b9bDnguxvtDgLP0ML7XaC7txqKLgDfdiAwQ9e3lo5u7EyEp-hhMGyYb7W5DiDx_-h_V5qmvwLg6-Vf_rpAJpi_Hw7YRjjhlaAngWJazY6tAhkvqQItT0VHGjkrKCNJP2v7VtBSnovkVJP-q4LWeI7HEK6JyGZ5lXIUD2EU_8ARwkNH1ma5kI427spYPwGYxiUw0rKRRw97MiEVVvD99weyq71uSfMNTWlDG_XYyO1MiLp9VECBrutUxjkrqJrwUoExScZbGduQRHUZhmH8uaaRXy-2Vq8X7OYMCMgA4w!!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fexpired%2Ffinancing?mapping=tgcs_new.portal.software)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/e40f6665-6bb5-4c60-84f5-4087522564c5/WW2020-Cross-Promotion-Space-ELERA-Produce.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-e40f6665-6bb5-4c60-84f5-4087522564c5-oPr5P.a)\\
\\
**ELERA® Produce Recognition** \\
\\
Commerce](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcxpay/!ut/p/z1/nZJfT4MwFMU_iw88jl4BEX1juODcyGAJA_tiOlIKBiiDToaffjX6IAuZxD71z-_cnp5bhFGMcEU-ckZEzitSyPUrNt9WD4b9bDnguxvtDgLP0ML7XaC7txqKLgDfdiAwQ9e3lo5u7EyEp-hhMGyYb7W5DiDx_-h_V5qmvwLg6-Vf_rpAJpi_Hw7YRjjhlaAngWJazY6tAhkvqQItT0VHGjkrKCNJP2v7VtBSnovkVJP-q4LWeI7HEK6JyGZ5lXIUD2EU_8ARwkNH1ma5kI427spYPwGYxiUw0rKRRw97MiEVVvD99weyq71uSfMNTWlDG_XYyO1MiLp9VECBrutUxjkrqJrwUoExScZbGduQRHUZhmH8uaaRXy-2Vq8X7OYMCMgA4w!!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fsoftware%2Fiot-suite%2Fproduce-recognition?mapping=tgcs_new.portal.software)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/466446cc-7f80-4622-b7b8-40726a74528f/product-teaser-img2.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-466446cc-7f80-4622-b7b8-40726a74528f-p8GrUVs)\\
\\
**Maintenance Services**](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcxpay/!ut/p/z1/nZJfT4MwFMU_iw88jl4BEX1juODcyGAJA_tiOlIKBiiDToaffjX6IAuZxD71z-_cnp5bhFGMcEU-ckZEzitSyPUrNt9WD4b9bDnguxvtDgLP0ML7XaC7txqKLgDfdiAwQ9e3lo5u7EyEp-hhMGyYb7W5DiDx_-h_V5qmvwLg6-Vf_rpAJpi_Hw7YRjjhlaAngWJazY6tAhkvqQItT0VHGjkrKCNJP2v7VtBSnovkVJP-q4LWeI7HEK6JyGZ5lXIUD2EU_8ARwkNH1ma5kI427spYPwGYxiUw0rKRRw97MiEVVvD99weyq71uSfMNTWlDG_XYyO1MiLp9VECBrutUxjkrqJrwUoExScZbGduQRHUZhmH8uaaRXy-2Vq8X7OYMCMgA4w!!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fservices%2Fmaintain?mapping=tgcs_new.portal.software)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/1a58e713-c31d-4457-b6c8-6d4ddba04af3/WW2020-Cross-Promotion-Space-ELERA.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-1a58e713-c31d-4457-b6c8-6d4ddba04af3-p8GrQ5A)\\
\\
**ELERA®**](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcxpay/!ut/p/z1/nZJfT4MwFMU_iw88jl4BEX1juODcyGAJA_tiOlIKBiiDToaffjX6IAuZxD71z-_cnp5bhFGMcEU-ckZEzitSyPUrNt9WD4b9bDnguxvtDgLP0ML7XaC7txqKLgDfdiAwQ9e3lo5u7EyEp-hhMGyYb7W5DiDx_-h_V5qmvwLg6-Vf_rpAJpi_Hw7YRjjhlaAngWJazY6tAhkvqQItT0VHGjkrKCNJP2v7VtBSnovkVJP-q4LWeI7HEK6JyGZ5lXIUD2EU_8ARwkNH1ma5kI427spYPwGYxiUw0rKRRw97MiEVVvD99weyq71uSfMNTWlDG_XYyO1MiLp9VECBrutUxjkrqJrwUoExScZbGduQRHUZhmH8uaaRXy-2Vq8X7OYMCMgA4w!!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fsoftware%2Fsolutions-platform%2Felera?mapping=tgcs_new.portal.hardware)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/5dfc9dff-91d7-4fa9-bccd-8018e3fc8ff2/WW2020-Cross-Promotion-Space-Tcx810e.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-5dfc9dff-91d7-4fa9-bccd-8018e3fc8ff2-p8GqrVa)\\
\\
**TCx® 810E**](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcxpay/!ut/p/z1/nZJfT4MwFMU_iw88jl4BEX1juODcyGAJA_tiOlIKBiiDToaffjX6IAuZxD71z-_cnp5bhFGMcEU-ckZEzitSyPUrNt9WD4b9bDnguxvtDgLP0ML7XaC7txqKLgDfdiAwQ9e3lo5u7EyEp-hhMGyYb7W5DiDx_-h_V5qmvwLg6-Vf_rpAJpi_Hw7YRjjhlaAngWJazY6tAhkvqQItT0VHGjkrKCNJP2v7VtBSnovkVJP-q4LWeI7HEK6JyGZ5lXIUD2EU_8ARwkNH1ma5kI427spYPwGYxiUw0rKRRw97MiEVVvD99weyq71uSfMNTWlDG_XYyO1MiLp9VECBrutUxjkrqJrwUoExScZbGduQRHUZhmH8uaaRXy-2Vq8X7OYMCMgA4w!!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fhardware%2Fpos%2Ftcx810e?mapping=tgcs_new.portal.hardware)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/6dc8a6fd-b511-4298-864c-d4068e663883/WW2020-Cross-Promotion-Space-ELERA-Mom.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-6dc8a6fd-b511-4298-864c-d4068e663883-p8Gqgxc)\\
\\
**ELERA® Mobile Assist** \\
\\
Marketing](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcxpay/!ut/p/z1/nZJfT4MwFMU_iw88jl4BEX1juODcyGAJA_tiOlIKBiiDToaffjX6IAuZxD71z-_cnp5bhFGMcEU-ckZEzitSyPUrNt9WD4b9bDnguxvtDgLP0ML7XaC7txqKLgDfdiAwQ9e3lo5u7EyEp-hhMGyYb7W5DiDx_-h_V5qmvwLg6-Vf_rpAJpi_Hw7YRjjhlaAngWJazY6tAhkvqQItT0VHGjkrKCNJP2v7VtBSnovkVJP-q4LWeI7HEK6JyGZ5lXIUD2EU_8ARwkNH1ma5kI427spYPwGYxiUw0rKRRw97MiEVVvD99weyq71uSfMNTWlDG_XYyO1MiLp9VECBrutUxjkrqJrwUoExScZbGduQRHUZhmH8uaaRXy-2Vq8X7OYMCMgA4w!!/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fsoftware%2Fcommerce-suite%2Fmobile-operations-manager)

![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcxpay/!ut/p/z1/nZJfT4MwFMU_iw88jl4BEX1juODcyGAJA_tiOlIKBiiDToaffjX6IAuZxD71z-_cnp5bhFGMcEU-ckZEzitSyPUrNt9WD4b9bDnguxvtDgLP0ML7XaC7txqKLgDfdiAwQ9e3lo5u7EyEp-hhMGyYb7W5DiDx_-h_V5qmvwLg6-Vf_rpAJpi_Hw7YRjjhlaAngWJazY6tAhkvqQItT0VHGjkrKCNJP2v7VtBSnovkVJP-q4LWeI7HEK6JyGZ5lXIUD2EU_8ARwkNH1ma5kI427spYPwGYxiUw0rKRRw97MiEVVvD99weyq71uSfMNTWlDG_XYyO1MiLp9VECBrutUxjkrqJrwUoExScZbGduQRHUZhmH8uaaRXy-2Vq8X7OYMCMgA4w!!/images/i_swiper-next-dark.svg)

![](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcxpay/!ut/p/z1/nZJfT4MwFMU_iw88jl4BEX1juODcyGAJA_tiOlIKBiiDToaffjX6IAuZxD71z-_cnp5bhFGMcEU-ckZEzitSyPUrNt9WD4b9bDnguxvtDgLP0ML7XaC7txqKLgDfdiAwQ9e3lo5u7EyEp-hhMGyYb7W5DiDx_-h_V5qmvwLg6-Vf_rpAJpi_Hw7YRjjhlaAngWJazY6tAhkvqQItT0VHGjkrKCNJP2v7VtBSnovkVJP-q4LWeI7HEK6JyGZ5lXIUD2EU_8ARwkNH1ma5kI427spYPwGYxiUw0rKRRw97MiEVVvD99weyq71uSfMNTWlDG_XYyO1MiLp9VECBrutUxjkrqJrwUoExScZbGduQRHUZhmH8uaaRXy-2Vq8X7OYMCMgA4w!!/images/i_swiper-prev-dark.svg)

Start a conversation

First name

Last name

Email

Company

Country

Phone

I am a

Business PartnerOtherPress / AnalystRetailerSupplierToshiba Employee

- Business Partner

- Other

- Press / Analyst

- Retailer

- Supplier

- Toshiba Employee


My Retail Segment

Fashion & ApparelFood ServiceGas & ConvenienceGroceryMass MerchandiseOtherPharmacy / Drug StoreSpecialty

- Fashion & Apparel

- Food Service

- Gas & Convenience

- Grocery

- Mass Merchandise

- Other

- Pharmacy / Drug Store

- Specialty


I am interested in learning more about

Add me to Toshiba Global Commerce Solutions' email marketing list

I am allowing Toshiba to contact me in regards to the information on this form

Comments

By submitting this form I agree that Toshiba Global Commerce Solutions, Inc. and its affiliates, including all subsidiaries and branches, may process my data as indicated above and as described in the [Toshiba Global Commerce Solutions Privacy Declaration.](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/common-content/general-content/privacy-policy&mapping=tgcs_new.portal.generaldetails)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**

reCAPTCHA is changing its terms of service. [Take action.](https://google.com/recaptcha/admin/migrate)

![success](https://commerce.toshiba.com/wps/portal/marketing/legacy-systems/tcxpay/!ut/p/z1/nZJfT4MwFMU_iw88jl4BEX1juODcyGAJA_tiOlIKBiiDToaffjX6IAuZxD71z-_cnp5bhFGMcEU-ckZEzitSyPUrNt9WD4b9bDnguxvtDgLP0ML7XaC7txqKLgDfdiAwQ9e3lo5u7EyEp-hhMGyYb7W5DiDx_-h_V5qmvwLg6-Vf_rpAJpi_Hw7YRjjhlaAngWJazY6tAhkvqQItT0VHGjkrKCNJP2v7VtBSnovkVJP-q4LWeI7HEK6JyGZ5lXIUD2EU_8ARwkNH1ma5kI427spYPwGYxiUw0rKRRw97MiEVVvD99weyq71uSfMNTWlDG_XYyO1MiLp9VECBrutUxjkrqJrwUoExScZbGduQRHUZhmH8uaaRXy-2Vq8X7OYMCMgA4w!!/images/tgcs/success.svg)

## Success!

Thank you for reaching out. One of our team members will be in contact soon. We hope you have a great day.

Close

Complementary
Content [Deferred Modules](https://commerce.toshiba.com/wps/contenthandler/marketing/!ut/p/digest!M6zrA0PEiotCbddBEGnoVg/mashup/ra:collection?themeID=ZJ_JQGEHK01N0LM806KGPAKPA0UO0&locale=en&mime-type=text%2Fjavascript&lm=1778876784000&entry=st_skin__0.0%3Aconfig_js&entry=wp_liveobject_framework_core__0.0%3Aconfig_js&entry=wp_portal_ui_utils__0.0%3Aconfig_js&entry=wp_contextmenu_js__0.0%3Aconfig_js&entry=wp_skin_cam__0.0%3Aconfig_js&entry=wp_contextmenu_config_lof__0.0%3Aconfig_js&entry=wp_federated_documents_picker__0.0%3Aconfig_js&entry=wp_dnd_main__0.0%3Aconfig_js&entry=wp_movecontrols__0.0%3Aconfig_js&entry=wp_toolbar_controlactions__0.0%3Aconfig_js&entry=wp_content_targeting_cam__0.0%3Aconfig_js&deferred=true)

- ${title}${badge}

${loading}

[Deferred Modules](https://commerce.toshiba.com/wps/contenthandler/marketing/!ut/p/digest!SpZvrtUURDcRHYzcbiqg-Q/mashup/ra:collection?themeID=ZJ_JQGEHK01N0LM806KGPAKPA0UO0&locale=en&mime-type=text%2Fplain&entry=wp_contextmenu_templates__0.0%3Aconfig_markup&entry=wp_skin_cam__0.0%3Aconfig_markup&entry=wp_dnd_main__0.0%3Aconfig_markup&deferred=true)

reCAPTCHA

Select all images with **cars** Click verify once there are none left

|     |     |     |
| --- | --- | --- |
| ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA4yrnUNSB-pjailCIEyGyPg1AybUZ2GS-te5U0L_Y1WhoWBy0D5CgptnEmUZ0Dv4a2qVUKa9rVwdoFILE9mpV1yZscK3GGhhDVrvWPdT8aH5PKiPy5i2rtGUE1IXcrHNuu7o4VxYtIlLdOGWpG1wjGUj-9z__u1iTdsJAnk3nDc5gwTj-DDQW33IQm3XC_r_wNWGCGaX8ghH9XlcaXHJCRQu7w-7w&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA4yrnUNSB-pjailCIEyGyPg1AybUZ2GS-te5U0L_Y1WhoWBy0D5CgptnEmUZ0Dv4a2qVUKa9rVwdoFILE9mpV1yZscK3GGhhDVrvWPdT8aH5PKiPy5i2rtGUE1IXcrHNuu7o4VxYtIlLdOGWpG1wjGUj-9z__u1iTdsJAnk3nDc5gwTj-DDQW33IQm3XC_r_wNWGCGaX8ghH9XlcaXHJCRQu7w-7w&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA4yrnUNSB-pjailCIEyGyPg1AybUZ2GS-te5U0L_Y1WhoWBy0D5CgptnEmUZ0Dv4a2qVUKa9rVwdoFILE9mpV1yZscK3GGhhDVrvWPdT8aH5PKiPy5i2rtGUE1IXcrHNuu7o4VxYtIlLdOGWpG1wjGUj-9z__u1iTdsJAnk3nDc5gwTj-DDQW33IQm3XC_r_wNWGCGaX8ghH9XlcaXHJCRQu7w-7w&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) |
| ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA4yrnUNSB-pjailCIEyGyPg1AybUZ2GS-te5U0L_Y1WhoWBy0D5CgptnEmUZ0Dv4a2qVUKa9rVwdoFILE9mpV1yZscK3GGhhDVrvWPdT8aH5PKiPy5i2rtGUE1IXcrHNuu7o4VxYtIlLdOGWpG1wjGUj-9z__u1iTdsJAnk3nDc5gwTj-DDQW33IQm3XC_r_wNWGCGaX8ghH9XlcaXHJCRQu7w-7w&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA4yrnUNSB-pjailCIEyGyPg1AybUZ2GS-te5U0L_Y1WhoWBy0D5CgptnEmUZ0Dv4a2qVUKa9rVwdoFILE9mpV1yZscK3GGhhDVrvWPdT8aH5PKiPy5i2rtGUE1IXcrHNuu7o4VxYtIlLdOGWpG1wjGUj-9z__u1iTdsJAnk3nDc5gwTj-DDQW33IQm3XC_r_wNWGCGaX8ghH9XlcaXHJCRQu7w-7w&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA4yrnUNSB-pjailCIEyGyPg1AybUZ2GS-te5U0L_Y1WhoWBy0D5CgptnEmUZ0Dv4a2qVUKa9rVwdoFILE9mpV1yZscK3GGhhDVrvWPdT8aH5PKiPy5i2rtGUE1IXcrHNuu7o4VxYtIlLdOGWpG1wjGUj-9z__u1iTdsJAnk3nDc5gwTj-DDQW33IQm3XC_r_wNWGCGaX8ghH9XlcaXHJCRQu7w-7w&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) |
| ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA4yrnUNSB-pjailCIEyGyPg1AybUZ2GS-te5U0L_Y1WhoWBy0D5CgptnEmUZ0Dv4a2qVUKa9rVwdoFILE9mpV1yZscK3GGhhDVrvWPdT8aH5PKiPy5i2rtGUE1IXcrHNuu7o4VxYtIlLdOGWpG1wjGUj-9z__u1iTdsJAnk3nDc5gwTj-DDQW33IQm3XC_r_wNWGCGaX8ghH9XlcaXHJCRQu7w-7w&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA4yrnUNSB-pjailCIEyGyPg1AybUZ2GS-te5U0L_Y1WhoWBy0D5CgptnEmUZ0Dv4a2qVUKa9rVwdoFILE9mpV1yZscK3GGhhDVrvWPdT8aH5PKiPy5i2rtGUE1IXcrHNuu7o4VxYtIlLdOGWpG1wjGUj-9z__u1iTdsJAnk3nDc5gwTj-DDQW33IQm3XC_r_wNWGCGaX8ghH9XlcaXHJCRQu7w-7w&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA4yrnUNSB-pjailCIEyGyPg1AybUZ2GS-te5U0L_Y1WhoWBy0D5CgptnEmUZ0Dv4a2qVUKa9rVwdoFILE9mpV1yZscK3GGhhDVrvWPdT8aH5PKiPy5i2rtGUE1IXcrHNuu7o4VxYtIlLdOGWpG1wjGUj-9z__u1iTdsJAnk3nDc5gwTj-DDQW33IQm3XC_r_wNWGCGaX8ghH9XlcaXHJCRQu7w-7w&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) |

Please try again.

Please select all matching images.

Please also check the new images.

Please select around the object, or reload if there are none.

Verify