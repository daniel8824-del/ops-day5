<!-- source: https://docs.gitlab.com/operations/incident_management/paging -->

/

* * *

# Paging and notifications

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

When there is a new alert or incident, it is important for a responder to be notified
immediately so they can triage and respond to the problem. Responders can receive
notifications using the methods described on this page.

## Slack notifications [Permalink](https://docs.gitlab.com/operations/incident_management/paging/\#slack-notifications "Permalink")

The GitLab for Slack app can be used to receive important incident notifications.

When [the GitLab for Slack app is configured](https://docs.gitlab.com/operations/incident_management/slack/), incident responders are notified in Slack
every time a new incident is declared. To ensure you don’t miss any important incident notifications
on your mobile device, enable notifications for Slack on your phone.

## Email notifications for alerts [Permalink](https://docs.gitlab.com/operations/incident_management/paging/\#email-notifications-for-alerts "Permalink")

Email notifications are available in projects for triggered alerts. Project
members with the **Owner** or **Maintainer** roles have the option to receive
a single email notification for new alerts.

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Settings** \> **Monitor**.
3. Expand **Alerts**.
4. On the **Alert settings** tab, select the
**Send a single email notification to Owners and Maintainers for new alerts** checkbox.
5. Select **Save changes**.

[Update the alert’s status](https://docs.gitlab.com/operations/incident_management/alerts/#change-an-alerts-status) to manage email notifications for an alert.

## Paging [Permalink](https://docs.gitlab.com/operations/incident_management/paging/\#paging "Permalink")

- Tier: Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

In projects that have an [escalation policy](https://docs.gitlab.com/operations/incident_management/escalation_policies/) configured, on-call responders
can be automatically paged about critical problems through email.

### Escalating an alert [Permalink](https://docs.gitlab.com/operations/incident_management/paging/\#escalating-an-alert "Permalink")

When an alert is triggered, it begins escalating to the on-call responders immediately.
For each escalation rule in the project’s escalation policy, the designated on-call
responders receive one email when the rule fires. You can respond to a page
or stop alert escalations by [updating the alert’s status](https://docs.gitlab.com/operations/incident_management/alerts/#change-an-alerts-status).

### Escalating an incident [Permalink](https://docs.gitlab.com/operations/incident_management/paging/\#escalating-an-incident "Permalink")

History

- [Introduced](https://gitlab.com/groups/gitlab-org/-/epics/5716) in GitLab 14.9 [with a flag](https://docs.gitlab.com/administration/feature_flags/) named `incident_escalations`. Disabled by default.
- [Enabled on GitLab.com and GitLab Self-Managed](https://gitlab.com/gitlab-org/gitlab/-/issues/345769) in GitLab 14.10.
- [Feature flag `incident_escalations`](https://gitlab.com/gitlab-org/gitlab/-/issues/345769) removed in GitLab 15.1.

For incidents, paging on-call responders is optional for each individual incident.

To begin escalating the incident, [set the incident’s escalation policy](https://docs.gitlab.com/operations/incident_management/manage_incidents/#change-escalation-policy).

For each escalation rule, the designated on-call responders receive one email when
the rule fires. Respond to a page or stop incident escalations by
[changing the incident’s status](https://docs.gitlab.com/operations/incident_management/manage_incidents/#change-status) or
changing the incident’s escalation policy back to **No escalation policy**.

In GitLab 15.1 and earlier, [incidents created from alerts](https://docs.gitlab.com/operations/incident_management/manage_incidents/#from-an-alert)
do not support independent escalation. In [GitLab 15.2 and later](https://gitlab.com/gitlab-org/gitlab/-/issues/356057),
all incidents can be escalated independently.

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**