<!-- source: https://www.atlassian.com/itsm/problem-management/template -->

Get it free

Search

Sign in

Jira Service Management is now more powerful than ever as part of Service Collection. Unlock exceptional service experiences with Rovo, Assets, and our new Customer Service Management app.

[Try it now](https://www.atlassian.com/try/cloud/signup?bundle=service-collection&edition=premium)

# Get to the bottom of things with this free problem management template

[Problem management](https://www.atlassian.com/itsm/problem-management) is the process of identifying and managing the causes of incidents on an IT service. It is a core component of ITSM frameworks. Using a template can ensure consistency in process and make sure your teams are capturing the right information about a problem every time.

[Get it free](https://www.atlassian.com/software/jira/service-management/free)

Below are the custom fields available for a problem ticket in Jira Service Management, along with a short description of how they’re used. Feel free to copy and adapt this template for your own problem management. Or if you want this ready to go in one solution, give [Jira Service Management](https://www.atlassian.com/software/jira/service-management) a try for free.

| Field | Description |
| --- | --- |
| Reporter | Description<br>The person who submitted the request. |
| Assignee | Description<br>The team member assigned to work on the request. |
| Priority | Description<br>The importance of the request's resolution, usually in regards to your business needs and goals. Sometimes, priority is calculated by impact and urgency. |
| Impact | Description<br>The scope of the problem, usually in regards to service level agreements. |
| Urgency | Description<br>The time available before the business feels the problem's impact. |
| Source | Description<br>The asset or system where the problem originated. |
| Investigation reason | Description<br>The trigger for prompting an investigation. For example, reoccurring incidents, non-routine incidents, or other. |
| Root cause | Description<br>The original cause of the incidents related to the problem. |
| Summary | Description<br>The detailed description of a temporary, known solution to restore a service. We recommend documenting your workaround in your Jira Service Management knowledge base. |
| Component(s) | Description<br>Segments of IT infrastructure that relate to the request. For example, Billing services or VPN server. These are used for labeling, categorization, and reporting. |
| Attachment | Description<br>Files or images added to the request. |
| Summary | Description<br>A short description of the request. |
| Description | Description<br>A long, detailed description of the request. |
| Linked Issues | Description<br>A list of other requests that affect or are effected by the request. If your business uses other Atlassian products, this list may include linked development issues. |
| Labels | Description<br>A list of additional custom labels used for categorizing or querying records. |
| Request participants | Description<br>A list of extra customers who take part in the request, for example, people from other teams, or vendors. Learn more about adding request participants. |
| Approvers | Description<br>A list of people responsible for approving the request, usually business, financial or technical contacts. |
| Organizations | Description<br>A list of customer groups interested in the request's resolution. Learn more about [organizations in Jira Service Management](https://support.atlassian.com/jira-service-desk-cloud/docs/add-an-organization-to-a-service-desk-project). |
| Pending reason | Description<br>A short description or code that indicates why the problem is not progressing. |
| Product categorization | Description<br>A category of IT asset or system that the request effects. |
| Operational categorization | Description<br>A category of action or function required to fulfill the request. |

## Go deeper: Resources, plans, and tutorials

Templates and samples are helpful, but they’re only a small part of the bigger picture when it comes to problem management. The best service management teams build and refine a plan, combining the right tools with the right practices. Here are some more resources to help you build a problem management process:

- [What is problem management](https://www.atlassian.com/itsm/problem-management)

- [Best practices for problem management](https://support.atlassian.com/jira-service-management-cloud/docs/best-practises-for-problem-management/)

- [Problem management in Jira Service Management demo video](https://www.youtube.com/watch?v=doXc8fybKcE&feature=emb_title)


## Recommended for you

WHITEPAPER

### Atlassian's guide to agile ways of working with ITIL 4

ITIL 4 is here—and it’s more agile than ever. Learn tips to bring agility and collaboration into ITSM with Atlassian.

[Read the whitepaper](https://www.atlassian.com/whitepapers/itil4)

### IT Change Management: ITIL Framework & Best Practices

IT Change Management minimizes risk while making changes to systems and services. Learn about the change management process, its importance, best practices

[Read this article](https://www.atlassian.com/itsm/change-management)

### Learn more about ITSM

Find more ITSM guides and resources in this hub.

[Read this article](https://www.atlassian.com/itsm)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**