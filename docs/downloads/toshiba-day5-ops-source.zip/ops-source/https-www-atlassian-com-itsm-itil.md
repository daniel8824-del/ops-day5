<!-- source: https://www.atlassian.com/itsm/itil -->

Get it free

Sign in

Jira Service Management is now more powerful than ever as part of Service Collection. Unlock exceptional service experiences with Rovo, Assets, and our new Customer Service Management app.

[Try it now](https://www.atlassian.com/try/cloud/signup?bundle=service-collection&edition=premium)

# Ultimate guide to ITIL 4: Guiding principles and practices

**Key Takeaway**: ITIL is a framework that standardizes the delivery of IT services, enabling teams to align IT with business goals, mitigate risk, and enhance the customer experience.

- What it is: A set of best practices for designing, delivering, and continually improving IT services.

- Why it matters: Helps reduce incidents, improve predictability, and make IT a strategic partner to the business instead of just a cost center.

- How Jira Service Management helps: Provides a flexible, modern platform to apply ITIL concepts (incidents, changes, requests, problems) in agile, cloud, and DevOps environments.


IT service management has changed. The old ways of handling IT services, which included rigid processes, endless documentation, and slow approvals, don’t work anymore when businesses need to move fast. [ITIL 4](https://www.atlassian.com/webinars/it/new-ways-of-working-with-itil-4-and-atlassian) updates the framework that’s been around since the 1980s to actually fit how [IT teams](https://www.atlassian.com/teams/it) work today.

In this article, we’ll walk through how the framework is structured, what principles guide your decisions, and how to actually apply it to improve your IT services.

Use Jira Service Management via the Service Collection to improve your IT service management processes.

[Get Service Management free](https://www.atlassian.com/software/jira/service-management/free)

## What is ITIL 4?

ITIL 4 is a flexible framework for managing IT services. Rather than prescribing rigid processes, it offers guidance that organizations can adapt to their unique needs and constraints. The focus is on delivering value to the business while maintaining the agility to respond to changing circumstances, which is a fundamental shift in how [ITSM](https://www.atlassian.com/itsm) frameworks approach service delivery.

The differences from previous [ITIL](https://www.atlassian.com/itsm/itil) versions are quite substantial. Earlier iterations emphasized process compliance and documentation, often creating bureaucracy that slows down [IT operations](https://www.atlassian.com/itsm/it-operations). ITIL 4 incorporates principles from [Agile](https://www.atlassian.com/agile) and DevOps, acknowledging that modern [IT support](https://www.atlassian.com/itsm/service-request-management/it-support) teams face competing demands. They need to maintain stable, reliable services while simultaneously delivering new capabilities and responding to urgent business requests.

### The history of ITIL

ITIL is the world’s leading framework for IT service management (ITSM), continuously evolving to meet the changing needs of organizations worldwide. Since its introduction in the 1980s, ITIL has grown into a globally recognized best practice.

The latest version, ITIL 4, launched in 2019, offers a modern, flexible approach that helps businesses navigate digital transformation and deliver real value. [PeopleCert](http://www.peoplecert.org/browse-certifications/it-governance-and-service-management) oversees ITIL 4 certification and provides a wide range of courses to help professionals master the framework, with the ITIL 4 foundation level being the entry point for most people.

## The ITIL 4 service value system

The service value system (SVS) provides a comprehensive view of how organizational components work together to create value. It encompasses the guiding principles, governance structures, the service value chain, management practices, and continuous improvement mechanisms. Rather than treating each element in isolation, the SVS demonstrates its interdependencies and collective contribution to business outcomes.

The service value chain represents the core activities that drive service delivery. These activities (plan, improve, engage, design and transition, obtain/build, and deliver and support) combine in various configurations depending on the situation.

This flexibility distinguishes it from traditional linear process models. Teams can adapt the sequence and combination of activities based on what they’re trying to accomplish, making the framework responsive to real-world complexity.

## What are the four dimensions of service management?

ITIL 4 requires organizations to consider service management from four distinct perspectives. Neglecting any single dimension creates vulnerabilities that can undermine service delivery. The four dimensions are:

- **Organizations and people:** This dimension addresses workforce capabilities, organizational culture, and the team structures necessary for effective service delivery. It covers everything from hiring and training to creating a culture that supports innovation and continuous improvement. Organizations must ensure their people have the right skills, clear roles, and the support they need to deliver quality services.

- **Information and technology:** This dimension covers the systems, tools, and data infrastructure that enable and support IT services. It includes the applications, databases, networks, and security systems that form the technical foundation of service delivery. Organizations need to ensure their technology is reliable, scalable, and aligned with business needs.

- **Partners and suppliers:** This dimension examines external relationships and vendor management that extend service capabilities beyond internal resources. Most organizations rely on third-party providers for certain services, whether it’s cloud hosting, software licensing, or specialized support. Managing these relationships effectively ensures that external dependencies don’t become points of failure.

- **Value streams and processes:** This dimension defines how work flows through the organization to deliver outcomes and create value. It examines the sequence of activities required to create and deliver services, identifying where value is added and where waste can be eliminated. Organizations use this dimension to optimize workflows and ensure efficient service delivery.


## ITIL 4 guiding principles

ITIL 4 is grounded in a set of practical, universal principles that guide organizations in delivering effective IT services. These principles help businesses align IT efforts with strategic goals, adapt to change, and maximize the value of their IT investments. Explore the core guiding principles of ITIL 4 below.

### Focus on value

ITIL emphasizes the importance of delivering value to the business. The focus is on understanding and meeting the organization's needs, ensuring that every IT activity contributes to the overall value proposition.

### Start where you are

ITIL encourages organizations to assess their current state and build upon existing processes and practices. This principle promotes a practical and realistic approach to improvement, acknowledging each organization's unique context and circumstances.

### Progress iteratively with feedback

The iterative approach is central to ITIL 4, allowing for [continuous improvement](https://www.atlassian.com/agile/project-management/continuous-improvement). Organizations are urged to implement changes in small, manageable increments, with a constant feedback loop to refine and enhance processes over time.

### Collaborate and promote visibility

Collaboration is key to successful IT service management. ITIL advocates for open communication and team collaboration, promoting visibility into processes and activities to foster a culture of shared responsibility and [continual service improvement](https://www.atlassian.com/itsm/itil/continual-service-improvement).

### Think and work holistically

ITIL encourages a holistic perspective by considering the entire service value system. This principle emphasizes the interconnectedness of different components within an organization and promotes a comprehensive understanding of how they contribute to the overall business objectives.

### Keep it simple and practical

Simplicity and practicality are core principles of ITIL. Organizations are advised to avoid unnecessary complexity and focus on straightforward, effective, and aligned solutions that support business goals.

### Optimize and automate

Continuous optimization and [automation](https://www.atlassian.com/software/jira/service-management/product-guide/tips-and-tricks/automation) are essential for efficiency. ITIL promotes using technology to [automate repetitive tasks](https://www.atlassian.com/software/jira/automation-template-library/jira-service-management) and streamline processes, allowing IT and operations management teams to focus on delivering value-added services.

## ITIL 4 practices

ITIL 4 defines 34 practices that support the service value system and guide IT services. These practices replaced what earlier ITIL versions called "processes," reflecting a fundamental shift in approach. Rather than prescribing specific procedures, practices describe objectives and considerations, allowing organizations to adapt implementation to their circumstances.

These practices help organizations manage services by providing proven approaches to common challenges while remaining flexible enough to fit different contexts. They span the entire service lifecycle, from strategic planning to day-to-day operations, ensuring comprehensive coverage of service management activities. The 34 practices are divided into three categories based on their primary focus:

### General management practices

General management practices apply business management principles to IT service management. Continual improvement establishes mechanisms for ongoing service and practice enhancement. Project management structures temporary initiatives with defined objectives and timelines, and risk management identifies and addresses potential threats to service delivery.

These practices support IT service management by bringing established business disciplines into IT contexts. They extend beyond IT-specific processes to address organizational capabilities like strategy, portfolio management, and relationship management, creating consistency with broader organizational management approaches.

### Service management practices

Service management practices address IT service delivery directly. Incident management restores service operation when disruptions occur. Change control manages modifications to minimize risk and unintended consequences. The service desk provides a single point of contact for user requests and issues.

These practices improve service delivery and user satisfaction by establishing reliable, consistent processes for common scenarios. They create clear [ITIL processes](https://www.atlassian.com/itsm/itil/service-strategy) that teams can follow, reducing variability in how services are delivered and ensuring predictable outcomes for service users.

### Technology management practices

Technical management practices enable infrastructure and development activities. Deployment management coordinates the release of new or changed services. Software development guides custom application creation. Infrastructure management maintains the underlying technical foundation on which all services depend.

These practices enable technical support and innovation by providing frameworks that balance stability with progress. They allow technical teams to introduce new capabilities while preserving reliability in production environments, supporting both operational excellence and technological advancement.

## Implement ITIL 4 practices to drive continuous improvement

To correctly apply ITIL 4 principles, you need tools that can handle the operational demands of modern service management.

[ITSM software](https://www.atlassian.com/software/jira/service-management/itsm-software) platforms like Jira Service Management provide the workflows, automation, and collaboration capabilities needed to execute ITIL 4 practices effectively. The platform supports incident management through intelligent routing and SLA tracking, enables change control with approval workflows and impact assessment, and powers service desks with self-service knowledge bases and AI-assisted support.

Organizations don't need to implement every ITIL 4 practice at once. Start with what you're already doing, and add new practices when your team is ready for them. Jira Service Management maintains visibility across your services as you make these improvements.

## Recommended for you

WHITEPAPER

### Atlassian's guide to agile ways of working with ITIL 4

ITIL 4 is here—and it’s more agile than ever. Learn tips to bring agility and collaboration into ITSM with Atlassian.

[Read the whitepaper](https://www.atlassian.com/whitepapers/itil4)

ARTICLE

### What is a service request?

Service Request Management enables IT teams to quickly and easily fulfill customer requests. Check out the process and best practices.

[Read the article](https://www.atlassian.com/itsm/service-request-management)

### Learn more about ITSM

Find more ITSM guides and resources in this hub.

[Read this article](https://www.atlassian.com/itsm)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**