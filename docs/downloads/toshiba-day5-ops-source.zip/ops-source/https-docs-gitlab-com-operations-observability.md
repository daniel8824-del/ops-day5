<!-- source: https://docs.gitlab.com/operations/observability -->

/

* * *

# Observability

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed
- Status: Experiment

History

- [Introduced](https://gitlab.com/gitlab-org/embody-team/experimental-observability/documentation/-/work_items/6) in GitLab 18.1 as an experiment available to all users.

GitLab Observability provides distributed tracing, metrics, and logs, all in one platform.
No cardinality limits. No separate tool for your team to learn.

Use GitLab Observability to:

- Monitor application performance through distributed tracing across microservices.
- Correlate code changes with production issues.
- Instrument CI/CD pipelines automatically without code changes.
- Send high-cardinality metrics without limits by using OpenTelemetry standards.

GitLab Observability is an experimental feature that is actively evolving.
You can start sending traces, logs, and metrics now. To get familiar with the workflow,
try it on a non-critical service first, then expand usage as needed.

For a detailed overview, see [GitLab Observability (O11y) Introduction](https://www.youtube.com/watch?v=XI9ZruyNEgs).

GitLab Observability is available and free for all tiers. [Share feedback or request features](https://docs.gitlab.com/operations/observability/observability/#share-your-feedback).

## Get started [Permalink](https://docs.gitlab.com/operations/observability/observability/\#get-started "Permalink")

1. Set up Observability, either on [your GitLab Self-Managed instance](https://docs.gitlab.com/operations/observability/setup_self_managed/), or on [GitLab.com](https://docs.gitlab.com/operations/observability/setup_gitlab_com/).
2. Add your OTLP endpoint to [start sending telemetry](https://docs.gitlab.com/operations/observability/send/), or [view CI/CD pipeline telemetry](https://docs.gitlab.com/operations/observability/ci_cd/).
3. View your first trace.
4. Debug a slow request.
5. [Access the API](https://docs.gitlab.com/operations/observability/api_access/) to query data programmatically.

Watch: [GitLab Observability setup](https://www.youtube.com/watch?v=lZtgor6chMs).

GitLab Observability (O11y) Setup Tutorial — Traces, Metrics & Logs - YouTube

Tap to unmute

[GitLab Observability (O11y) Setup Tutorial — Traces, Metrics & Logs](https://www.youtube.com/watch?v=lZtgor6chMs) [GitLab Unfiltered](https://www.youtube-nocookie.com/channel/UCMtZ0sc1HHNtGGWZFDRTh5A)

GitLab Unfiltered43.1K subscribers

## Real-world usage [Permalink](https://docs.gitlab.com/operations/observability/observability/\#real-world-usage "Permalink")

GitLab Observability is being used by teams worldwide to monitor their applications and infrastructure.

Our users are actively monitoring their systems with GitLab Observability on GitLab.com (as of the week of April 21, 2026):

- More than 57 million traces processed daily.
- More than 3,000 services actively monitored.

## Key features [Permalink](https://docs.gitlab.com/operations/observability/observability/\#key-features "Permalink")

### Monitor performance, trace issues [Permalink](https://docs.gitlab.com/operations/observability/observability/\#monitor-performance-trace-issues "Permalink")

Find and debug issues more quickly.

- Enhanced development workflow. Correlate code changes directly with application performance metrics to identify when deployments introduce issues.
- Streamlined incident response. See recent deployments, code changes, and the developers involved in one place.

When an issue occurs, view:

- The performance trace that shows the slow query.
- The merge request that introduced the change.
- The developer who can fix it.
- The deployment that rolled it out.

### Unified platform [Permalink](https://docs.gitlab.com/operations/observability/observability/\#unified-platform "Permalink")

Monitor application performance through a unified dashboard that combines:

- Distributed tracing. Follow requests across microservices to identify bottlenecks.
- Metrics. Track application and infrastructure performance over time.
- Logs. Correlate log entries with traces and metrics for complete context.

Centralized management provides:

- Simplified access management. New engineers automatically gain access to production observability data when they receive code repository access.
- No context switching. Access monitoring data without leaving GitLab.

### Developer-friendly integration [Permalink](https://docs.gitlab.com/operations/observability/observability/\#developer-friendly-integration "Permalink")

Send the same OpenTelemetry data to multiple backends while you evaluate GitLab Observability.

- Migrate from Datadog or New Relic. If you’re using OpenTelemetry, just change your OTLP endpoint.
- No vendor lock-in. Use standard OpenTelemetry instrumentation libraries. Switch providers anytime by changing your OTLP endpoint.

### Fast setup and instrumentation [Permalink](https://docs.gitlab.com/operations/observability/observability/\#fast-setup-and-instrumentation "Permalink")

Most teams are seeing their first traces within 5-10 minutes of enabling the feature.

- Pre-built dashboards. Start with templates for common use cases.
- Automatic CI/CD instrumentation. Set one environment variable and GitLab automatically instruments your CI/CD pipelines.

### Cost-effective and scalable [Permalink](https://docs.gitlab.com/operations/observability/observability/\#cost-effective-and-scalable "Permalink")

- Free for all tiers. No per-seat, per-metric, or per-host charges. No limits on traces, metrics, or logs.
- No cardinality limits. Send high-cardinality metrics without cost concerns.
- Open source model. Contribute features and fixes directly.
- Predictable costs. No surprise bills from metric explosions.

### Compliance and audit trails [Permalink](https://docs.gitlab.com/operations/observability/observability/\#compliance-and-audit-trails "Permalink")

The integration creates comprehensive audit trails that link code changes to system behavior,
valuable for compliance requirements and post-incident analysis.

## Learn more [Permalink](https://docs.gitlab.com/operations/observability/observability/\#learn-more "Permalink")

- [Access the Observability API](https://docs.gitlab.com/operations/observability/api_access/). Query traces, metrics, and logs programmatically.
- [OpenTelemetry documentation](https://opentelemetry.io/docs/instrumentation/). Language-specific instrumentation guides.
- [GitLab Observability Templates](https://gitlab.com/gitlab-org/embody-team/experimental-observability/o11y-templates/). Pre-built dashboards and examples.
- [Proposed features](https://gitlab.com/gitlab-org/embody-team/experimental-observability/gitlab_o11y/-/issues/8)

## Get help [Permalink](https://docs.gitlab.com/operations/observability/observability/\#get-help "Permalink")

- [Discord community](https://discord.com/channels/778180511088640070/1379585187909861546). Join the conversation with other users.
- [GitLab issues](https://gitlab.com/gitlab-org/embody-team/experimental-observability/gitlab_o11y/-/issues). Report bugs or request features.
- [Troubleshooting information](https://docs.gitlab.com/operations/observability/troubleshooting/).

## Share your feedback [Permalink](https://docs.gitlab.com/operations/observability/observability/\#share-your-feedback "Permalink")

GitLab Observability is enhanced based on user feedback. To provide feedback:

- Join the [Discord channel](https://discord.com/channels/778180511088640070/1379585187909861546).
- [Open an issue](https://gitlab.com/gitlab-org/embody-team/experimental-observability/gitlab_o11y/-/issues) to report bugs or request features.

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**