<!-- source: https://commerce.toshiba.com/wps/portal/marketing/newsmedia/!ut/p/z1/tZbdc6IwEMD_lnvwMZNN-AqPaD1AK0ivaOWlEyBY7gSs0Pa8v_5i25t-jIpzlrxkkuz-NrvZbIIjfIOjkj_mS97kVclXcryI9NuxqVoOG8DU9qkGwUSloTELFNuheIYjHK2TPMULosQEskxDOuUpUikkiKVagnShmTGLzQy4tpNOymbd3OGFKNFD3YO7qhA9SKpizcttD0rxVBcizTmev9i2wCIWUA-GngW6bhF63R8Tn6k4er815rtDuTXfHquXFwC6-k__sMBO3zUJhfEYfDaxNTk5HQXM9Whgw6v-EYHoeGg-2ben1gACPbSnzB0o6kw_zT58aBb0r2hfAZDm_kf_Pek0_SMORsfx891ht0RgD-Oji21GorYsWEgvjFtKxwPHlFlke8oF6AEZsDAMQbUMPH_MxRMOy2pTyIT_8ZbPqcJjlugEcQoaUokmEDeMGGWEqCYwBjKhsQMtFgL1TAsteL1bvHYmfvRyPocvsaww-c_7-8iShaEqG_G7wTf7K0O8qpY9SPNl3vAVEhuO6ockEXX96sOhVKZw2AfQzTQ2MkCqoSTSh0RFcUJipMWCpUylcazFbXjaLZ50i1c6xbvdxt7tNvZut7F3z439qK2Et16uvEwf6maTCzlTr0WS81Wz3YiG589vP91MBpOl3BNv7lBeZhW--Sz1yUXf8XcFeBjOho5HwT5S_U76L7Tg9W7x2tfi7Qtnh5_13SmxwSbka_Hs2vsOwXBGZn3blQW4Y7zSKd6HM_Gjtv_Z6S_P2590_514W18XBVO2-XNDv66cP30P2YOYPV1nhey2ym5iMXrc312K-dFF69tfitOEQw!! -->

![logo](https://commerce.toshiba.com/wps/portal/marketing/newsmedia/!ut/p/z1/tZZde5owFIB_yy68THMSPoy7Q-sArSJd1cpNnwSCsik4wDr36xfb7unHVLpZuMlDcs57PnJyEhzgWxyk_D6Z8zLJUr5U_7PAvOu3dMthHRjZHjXAH-h03Jz4mu1QPMEBDtZhEuEZ0QSBODaQSXmEdAohYpERIlMaLcFEKwZu7KXDtFyXCzyTKdoUDVhkK9mAMFutebprQCq3xUpGCcfTR9sWWMQCOoTu0ALTtAi9afeJx3QcvHSNeW5XuebZff3qEsDU_-gfF9jruy1Cod8Hjw1sQ02Oej5zh9S34Un_hEBwOjVv7NsjqwO-ObZHzO1o-sR8nz68-ixoX9O2BqDE_0f_Jelf_f9LIDiNn-43uyIDBxivQ6wyElRVwUxF0byjtN9xWqqK7KF2CaZPOmw8HoNuNfH0PpFbPE6zfKUK_utzPUcaFyw0CeIUDKQTQyLebAoUE6K3gDFQBY0dqLDg62daqMCb9eKNM_G9x_05fohVh0m-_fgRWKoxZGkpf5b49nBnEMts3oAomSclXyKZc1RswlAWxVMMx04qheMxgNmKRDMGpDe1UMUQ6kiERCBDSBYxnQphiCo8rRdP6sVrteLdenPv1pt7t97cu-fmvld1hVUeriSNNkWZJ1LNFGsZJnxZ7nJZ8uTh7qf5oDOYK594uUBJGmf49q3UmxA9x9s34O540nWGFOwT3e9d74UKvFkv3vhYvH3p7PGTtjsiNtiEfCye3Qy_gN-dkEnbdlUDrhmv1Yr34Ex8r-p98_6b5_lNevhMPK8ro_NlJh5fzlYqNKYkcxnLXOYXm1xNL8pyXXxuQAO22-3FPMvmS3mhLDXgkMoiK5RXryXxerVi2i55-ND3a-dXe4jsjmDbm3ilhp22n5j17g8PV3J6ejEQu-2n35fBSKA!/images/logo.png)X

Sign in to your Toshiba account

For optimum experience,
please log in on your desktop computer

UserName

Password

Sign In [Forgot password?](https://www.toshibacommerce.com/tgcs109/tsim/forgotpassword.do) [Enterprise Login](https://www.toshibacommerce.com/mga/sps/authsvc?PolicyId=urn:ibm:security:authentication:asf:externalIDPLogin&target=https%3A%2F%2Ftoshibacommerce.com%2Fwps%2Fmyportal)

Don't have an ID? [Request one here](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/faqs)

{"Z7\_22KCH902NGN3D06Q1C8UUU04A7":{"windowState":"normal","portletMode":"view"},"Z7\_22KCH902NGN3D06Q1C8UUU04Q4":{"windowState":"normal","portletMode":"view"},"Z7\_22KCH902NGN3D06Q1C8UUU04Q6":{"windowState":"normal","portletMode":"view"},"Z7\_22KCH902NGN3D06Q1C8UUU04Q5":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2Q20":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2Q22":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2Q21":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2Q23":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2QI0":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2QI2":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2QI1":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2QI3":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OOHOE0QMEUVEHN20G4":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OOHOE0QMEUVEHN20G6":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OOHOE0QMEUVEHN20G5":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OGDHE0QMVBIP1G0G11":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8TNF0QEV1VBGI0881":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8TNF0QEV1VBGI0883":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8TNF0QEV1VBGI08O0":{"windowState":"normal","portletMode":"view"}}

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

# News and Media

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/1df77467-5715-4c81-880a-8d5fe43d6c02/ToshibaRetailDiveThumbnail.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-1df77467-5715-4c81-880a-8d5fe43d6c02-pP1XzJf)

## Featured Article

### Optimizing Your Retail Tech Stack

How to Innovate Without the Overhaul

[Learn More](https://resources.industrydive.com/how-retailers-can-deploy-innovative-modular-tech)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/277e4f19-d980-4e91-b5e6-d6e2f0baba11/RetailDiveToshibaIntelBreakTheMold.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-277e4f19-d980-4e91-b5e6-d6e2f0baba11-pP1XzER)

## Featured Article

### Break the Mold

How Modular Tech Sparks Fearless Retail Innovation

[Learn More](https://resources.industrydive.com/how-modular-innovation-is-shaping-modern-retail)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/80c003f8-c9e1-4164-bdf8-a4311290fbd1/lets_talk_retail_thumbnail.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-80c003f8-c9e1-4164-bdf8-a4311290fbd1-pP1XzQR)

## Featured Article

### Toshiba's Let's Talk Retail

How Produce Recognition Tech is Revolutionizing Self-Checkout

[Learn More](https://www.youtube.com/watch?v=JGpg09DqehM)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/4c9030fa-b22f-4961-82da-e6431a3f9d46/FutureOfShoppingThumbnailSizeArticle.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-4c9030fa-b22f-4961-82da-e6431a3f9d46-pP1XzN6)

## Featured Article

### Future of Shopping

Retail 2026: What Will Shape the Future of Shopping?

[Learn More](https://events.smartbrief.com/on-demand/2778/retail-2026-what-will-shape-the-future-of-shopping/)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/1df77467-5715-4c81-880a-8d5fe43d6c02/ToshibaRetailDiveThumbnail.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-1df77467-5715-4c81-880a-8d5fe43d6c02-pP1XzJf)

## Featured Article

### Optimizing Your Retail Tech Stack

How to Innovate Without the Overhaul

[Learn More](https://resources.industrydive.com/how-retailers-can-deploy-innovative-modular-tech)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/277e4f19-d980-4e91-b5e6-d6e2f0baba11/RetailDiveToshibaIntelBreakTheMold.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-277e4f19-d980-4e91-b5e6-d6e2f0baba11-pP1XzER)

## Featured Article

### Break the Mold

How Modular Tech Sparks Fearless Retail Innovation

[Learn More](https://resources.industrydive.com/how-modular-innovation-is-shaping-modern-retail)

Break the MoldToshiba's Let's Talk RetailFuture of ShoppingOptimizing Your Retail Tech Stack

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/605c81be-4a6f-461d-878f-91f6254980fb/g_press_releases_blue2.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-605c81be-4a6f-461d-878f-91f6254980fb-pNIaMzn)

### Press Releases

From generating new ideas to fine-tuning technology solutions, our team is focused on empowering retail that supports your business needs and make the most of your investments. Using our extensive retail and technology expertise, we work with you to understand your businesses, then create tailored solutions, blueprints and strategies to help you meet your goals.

[**View our Press Releases**](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/newsmedia/news)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/458ee02d-2a01-4228-8838-7db35031d9ec/MediaCoverage-square-diamond.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-458ee02d-2a01-4228-8838-7db35031d9ec-pPyhONK)

### Media Coverage

View the latest media coverage featuring Toshiba leaders and their insights on innovation and the latest retail trends.

[**View our Media Coverage**](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/newsmedia/newsmediacoverage)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/1b70a3a8-6eb7-47b7-8b77-bac8b728a1e3/g_mediassets_toshiba_orange.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-1b70a3a8-6eb7-47b7-8b77-bac8b728a1e3-pL3ugPI)

### Media Assets

Access official logos, brand assets, and multimedia content.

[**View our Media Assets**](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/newsmedia/mediaAssets)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

# News and Media

Stay informed about how we’re bringing innovation and efficiency to brands around the world with our latest stories, news releases, and updates.

Select an Industry.Date ![](https://commerce.toshiba.com/wps/contenthandler/dav/fs-type1/themes/TGCSMarketingThemeV2/images/i_date-descending.svg)![](https://commerce.toshiba.com/wps/contenthandler/dav/fs-type1/themes/TGCSMarketingThemeV2/images/i_date-ascending.svg)

## There are no results matching your filter criteria. Please try again.

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/6eb193c2-5307-42cc-8460-1d48b55c1639/WW2020-Product-Page-THUMB-LARGE-soti-restaurant-2024.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-6eb193c2-5307-42cc-8460-1d48b55c1639-p5ioGVZ)\\
\\
Report\\
\\
May 06, 2024\\
\\
2024-05-06\\
\\
**State of the Industry: The Future of In-Restaurant Dining Report**\\
\\
Unlocking the Potential of Your Restaurant\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/soti-restaurant-2024&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/56142b6e-a6ff-4462-8a99-52442805826f/Thumbnail+2.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-56142b6e-a6ff-4462-8a99-52442805826f-pu4h2Nv)\\
\\
Report\\
\\
Apr 14, 2025\\
\\
2025-04-14\\
\\
**2025 State of the Industry: Store Innovation**\\
\\
Physical stores are evolving into multi-purpose platforms for commerce, fulfillment, and customer engagement. Based on a comprehensive study of 440 retail technology and business leaders across North America, Europe, Latin America, and Asia, this report examines how leading\\
retailers are building the foundation for tomorrow's stores, today.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/state-industry-2025&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/49ac7490-6016-4294-baf9-28ecbb1db6d2/TCx820.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-49ac7490-6016-4294-baf9-28ecbb1db6d2-pvHG0lq)\\
\\
Product Spotlight\\
\\
Jun 26, 2025\\
\\
2025-06-26\\
\\
**TCx® 820: Future Ready POS For Retail Success**\\
\\
Unlocking the Potential of Your Restaurant\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/tcx-820-future-ready&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/9c79c8ea-c846-4225-9ba5-2214ca6dca42/VK_01.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-9c79c8ea-c846-4225-9ba5-2214ca6dca42-pypTLz.)\\
\\
Product Spotlight\\
\\
Jul 11, 2025\\
\\
2025-07-11\\
\\
**MxP™ Vision Kiosk: Expanding Beyond Grocery**\\
\\
Expanding Beyond Grocery\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/mxp-vision-kiosk&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/5a983674-7589-4fd1-874b-db1ac2cd3363/3+%281%29.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-5a983674-7589-4fd1-874b-db1ac2cd3363-pxiQU.7)\\
\\
Product Spotlight\\
\\
Jul 28, 2025\\
\\
2025-07-28\\
\\
**TCx® Touch Display: Revolutionizing Retail with Sleek Displays**\\
\\
TCx® Touch displays are designed to inspire and perform across a variety of environments, going beyond the standard POS setup. Engineered with style, innovation, and reliability in mind, our advanced displays seamlessly align multiple touchpoints, empowering businesses to adapt to the ever-evolving retail landscape and beyond.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/tcx-touch-display-insight&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/4da6d5cb-f385-42f9-b3f5-27fa93e35b8e/IDCinsight.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-4da6d5cb-f385-42f9-b3f5-27fa93e35b8e-pxXjmte)\\
\\
Articles\\
\\
Aug 05, 2025\\
\\
2025-08-05\\
\\
**IDC Links Toshiba's ELERA to new Super Platform Framework**\\
\\
IDC announces that new Super Platform Frameworks like Toshiba's ELERA (R) are critical to meeting urgent retail industry needs. \\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/idc-time-is-now-ai-fueled-success&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/90c022c6-af8d-422b-9dbd-996668afc3b2/TCx+M1+Product+Photo+Thumbnail.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-90c022c6-af8d-422b-9dbd-996668afc3b2-pypYlix)\\
\\
Product Spotlight\\
\\
Aug 07, 2025\\
\\
2025-08-07\\
\\
**TCx® M1: Mobile Point-of-Sale**\\
\\
The Toshiba TCx® M1 is a point-of-sale handheld device that enables sales associates to take payments on the spot, making checkout lines, curbside pickup, and remote areas of the store even more convenient. \\
The TCx® M1 offers retailers a complete mobile POS system capable of scanning and processing all forms of payment on a sleek, secure, & low-profile device.\\
\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/tcx-m1-spotlight&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/cdca6a94-da1b-4c5c-b8cc-dbe300bf924f/ELERA-Mobile-Operations-Manager-01+%281%29.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-cdca6a94-da1b-4c5c-b8cc-dbe300bf924f-pzd.TjI)\\
\\
Product Spotlight\\
\\
Aug 21, 2025\\
\\
2025-08-21\\
\\
**ELERA® Mobile Assist: Enhance Customer Experience and Increase In-Store Productivity**\\
\\
Expanding Beyond Grocery\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/elera-mobile-assist-insight&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/361424aa-bde8-4e96-bef0-058aef496883/ELERA-Associate-Mobile-Spotlight.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-361424aa-bde8-4e96-bef0-058aef496883-pBeP8an)\\
\\
Product Spotlight\\
\\
Sep 05, 2025\\
\\
2025-09-05\\
\\
**ELERA® Associate Mobile: Mobilizing Your Point-of-Sale**\\
\\
Toshiba’s ELERA® Associate Mobile is a mobile Point-of-Sale (POS) application that provides retailers with a complete POS system on a mobile device. As the mobile touchpoint of the ELERA® Commerce Platform, ELERA® Associate Mobile boosts productivity and customer experience by enabling associates to drive frictionless checkouts at shopper convenience.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/elera-associate-mobile-insight&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/15edfdb4-4020-4240-bb29-fdf0882583fd/OperateWithExcellence_Insight.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-15edfdb4-4020-4240-bb29-fdf0882583fd-pMvgnwj)\\
\\
Report\\
\\
Feb 02, 2026\\
\\
2026-02-02\\
\\
**How Retailers are Leveraging Tech to Stay Agile & Secure**\\
\\
Retailers are accelerating technology investments to stay agile, blending modular innovation with legacy systems to improve efficiency, empower associates, and deliver more personalized customer experiences.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/operate-with-excellence-retail-insight&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/268dda64-ba38-477e-b5bd-55f1b14e276a/VoicesFromTheIndustryKitestring.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-268dda64-ba38-477e-b5bd-55f1b14e276a-pQC308U)\\
\\
Product Spotlight\\
\\
Mar 24, 2026\\
\\
2026-03-24\\
\\
**NRF Video Spotlight – Kitestring: From Buzzword to Business Value, AI in Retail**\\
\\
Learn how retailers can turn AI into real business value by aligning technology with people, processes, and operational needs.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/ai-in-retail-business-value-kitestring-nrf-video&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/a8df7e75-8851-4a11-ae2c-331caf85ee59/TGCSqualcommNRF.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-a8df7e75-8851-4a11-ae2c-331caf85ee59-pR5zvcS)\\
\\
Product Spotlight\\
\\
Mar 31, 2026\\
\\
2026-03-31\\
\\
**NRF Video Spotlight – Qualcomm: From Chip to Checkout: Powering Smart Retail**\\
\\
Learn how retailers can turn AI into real business value by aligning technology with people, processes, and operational needs.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/nrf-video-spotlight-qualcomm-smart-retail&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/33fa02c9-d079-4c16-a4aa-e1c9bbfdce90/VoicesFromIndustryToshibaIntel.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-33fa02c9-d079-4c16-a4aa-e1c9bbfdce90-pSiztdR)\\
\\
Product Spotlight\\
\\
Apr 15, 2026\\
\\
2026-04-15\\
\\
**NRF Video Spotlight – Intel: Modernizing Retail Through Modular Innovation**\\
\\
Explore how Intel and Toshiba discuss modular innovation in retail, enabling modernization, flexibility, and cost-effective technology transformation.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/nrf-video-intel-modular-retail-innovation&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/7a99f59e-30f1-4522-8f25-23e4c072ce10/NRF_Spotlight_deloitte-toshiba.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-7a99f59e-30f1-4522-8f25-23e4c072ce10-pRKrAzE)\\
\\
Product Spotlight\\
\\
Apr 07, 2026\\
\\
2026-04-07\\
\\
**NRF Video Spotlight - Deloitte: Navigating Retail Challenges and Consumer Demands**\\
\\
Explore how Deloitte and Toshiba discuss retail challenges, evolving consumer demands, AI adoption, and strategies for modernizing retail technology.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/nrf-video-deloitte-retail-challenges-consumer-demands&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/d320c887-ed27-4730-959a-28bd5e726a2a/VoicesFromIndustryIncisivToshiba.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-d320c887-ed27-4730-959a-28bd5e726a2a-pSSA6ns)\\
\\
Product Spotlight\\
\\
Apr 20, 2026\\
\\
2026-04-20\\
\\
**NRF Video Spotlight – Incisiv: Bridging the Retail Experience Gap**\\
\\
How can retailers close the experience gap? Discover insights on unified commerce, operations, and customer expectations from Toshiba and Incisiv.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/nrf-video-incisiv-bridging-retail-experience-gap&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/1163bc75-769c-437f-aa0c-40756856cc1a/VoicesFromTheIndustry_Toshiba_Google.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-1163bc75-769c-437f-aa0c-40756856cc1a-pTlO8a9)\\
\\
Product Spotlight\\
\\
Apr 28, 2026\\
\\
2026-04-28\\
\\
**NRF Video Spotlight – Google: Developing a Modern Edge Strategy**\\
\\
Explore how edge computing and cloud infrastructure are transforming retail, enabling faster innovation, real-time insights, and more connected store operations.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/nrf-video-google-modern-edge-strategy&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/be1e5e77-aeb7-46e1-9a03-dccc517d27c5/IDC-Logo-RGB-Icon%2BWordmark-BeaconBlue-Small.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-be1e5e77-aeb7-46e1-9a03-dccc517d27c5-pU3W8cY)\\
\\
Product Spotlight\\
\\
May 06, 2026\\
\\
2026-05-06\\
\\
**Toshiba Named a Leader in the IDC MarketScape: Worldwide Point-of-Sale Software in Grocery and Food Store Retail 2026 Vendor Assessment**\\
\\
Explore IDC MarketScape insights on the future of retail point-of-sale software, including cloud architecture, real-time data, AI-driven insights, and scalable retail operations.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/idc-marketscape-grocery-pos-software-2026&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/cbe28333-9063-4891-a7db-5f196f07b11e/WW2020-Product-Page-THUMB-LARGE-tcx810-compare-Infographic.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-cbe28333-9063-4891-a7db-5f196f07b11e-oToQ1nm)\\
\\
Infographic\\
\\
Feb 12, 2024\\
\\
2024-02-12\\
\\
**TCx® 810 Comparison Infographic**\\
\\
In a series of technical tests, Toshiba’s TCx 810 point-of-sale (POS) device was shown to be superior to competing brands’ POS models.\\
\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/tcx810-comparison-info&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/ae033034-f9d5-4428-9ece-bceb71baef38/WW2020-Product-Page-THUMB-LARGE-Tcx810-compare-Whitepaper-CENTER.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-ae033034-f9d5-4428-9ece-bceb71baef38-pQwm0v-)\\
\\
White Paper\\
\\
Feb 12, 2024\\
\\
2024-02-12\\
\\
**TCx® 810 Comparison White Paper**\\
\\
This white paper explores the challenges retailers face and how Toshiba’s retail-hardened POS systems solve hardware challenges to ensure they meet their goals.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/tcx810-compare-wp&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/0f30e6f8-2e5a-4312-aff1-db0f762063c9/CYT+Logo.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-0f30e6f8-2e5a-4312-aff1-db0f762063c9-pCHSYFK)\\
\\
Infographic\\
\\
Oct 01, 2025\\
\\
2025-10-01\\
\\
**Rethinking Retail: Strategies to Meet Evolving Customer Expectations**\\
\\
Retail is entering a new chapter where every interaction has the potential to shape lasting connections with customers.\\
\\
This infographic explores how personalization, ease, and engagement are redefining the shopping journey and creating opportunities for retailers to deliver meaningful experiences.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/createyourtomorrow-infographic&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/4ef3fed7-db7f-4ffa-9a4b-afffcebf82aa/ResilientFoodserviceOpsToshiba.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-4ef3fed7-db7f-4ffa-9a4b-afffcebf82aa-pLs0aGv)\\
\\
Infographic\\
\\
Oct 02, 2025\\
\\
2025-10-02\\
\\
**What Resilient Foodservice Ops Look Like**\\
\\
Restaurants are unifying technology systems across on-premise and online platforms to boost efficiency – yet only 22% are satisfied with current systems.\\
\\
Devices like Toshiba's TCx® M11 tablet are being adopted to drive innovation and future-proof guest experiences.\\
\\
Explore where the industry is heading.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/resilient-foodservice-ops-infographic&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/6ae04630-b0f8-4ef8-a98b-d90810149030/IndustryDiveOct2025logos.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-6ae04630-b0f8-4ef8-a98b-d90810149030-pCX5WIz)\\
\\
Articles\\
\\
Oct 02, 2025\\
\\
2025-10-02\\
\\
**How Modular Tech Helps Retailers Stay Agile and Resilient While Innovating**\\
\\
In a world where change happens fast, adaptability has become the key to lasting growth. As innovation accelerates and customer needs evolve, businesses are turning to technology that helps them stay flexible, connected, and ahead of what’s next.\\
\\
This infographic explores how modular POS systems bring flexibility, scalability, and simplicity to modern retail helping brands innovate confidently and create seamless shopping experiences built to last.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/moduar-tech-helps-retailers-stay-agile&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/fdc19945-77ae-401f-bfea-521ed0f6efc8/IncisivBrief.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-fdc19945-77ae-401f-bfea-521ed0f6efc8-pL2PetC)\\
\\
Articles\\
\\
Jan 07, 2026\\
\\
2026-01-07\\
\\
**The Adaptive Store: Balancing Experience and Efficiency in Specialty Retail**\\
\\
Running a specialty retail store today means balancing how customers want to shop with how stores actually operate.\\
\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/incisiv-the-adaptive-store-industrybrief&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/ebda821b-dff1-4a14-ab87-154224a69a69/IncisivAdaptivePlaybook.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-ebda821b-dff1-4a14-ab87-154224a69a69-pKwrzqA)\\
\\
Articles\\
\\
Jan 07, 2026\\
\\
2026-01-07\\
\\
**Incisiv Playbook: Building Adaptive Specialty Retail Stores**\\
\\
A Transformation Framework for Experience-Driven Operations\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/incisiv-playbook-building-adaptive-specialty-retail-stores&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/3fd2f85a-762e-40b3-aea8-c9f7c59deff2/WW2020-Product-Page-THUMB-LARGE-Innovation2024.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-3fd2f85a-762e-40b3-aea8-c9f7c59deff2-p5ioJVr)\\
\\
Report\\
\\
Jan 22, 2024\\
\\
2024-01-22\\
\\
**State of the Industry: Innovation in Retail 2024**\\
\\
This State of the Industry: Innovation in Retail report presents key findings and analysis from a study of US, Canadian, and LATAM retailers covering innovation perspectives, impact of AI and other tech advancements, and leaderships role in innovation.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/soti-innovation-2024&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/06dfb677-5098-4ab3-a905-cd008d3df246/TechPlatform.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-06dfb677-5098-4ab3-a905-cd008d3df246-pmBBJXP)\\
\\
White Paper\\
\\
Aug 31, 2024\\
\\
2024-08-31\\
\\
**Customized Tech Platforms Help Supermarkets Maximize Food Service Whitepaper**\\
\\
Supermarket retailers must find new ways to bring customers into their stores, maximize their high-margin categories, and boost basket size. Read this whitepaper to learn how expanded food service, supported by the innovative Toshiba and CBS NorthStar joint solution, has been a highly successful strategy for grocers.\\
\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/custom-techplatform-2024&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/f3ff7052-c704-40b4-92f6-788091fc0267/CustomTechPlatforms.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-f3ff7052-c704-40b4-92f6-788091fc0267-px3aj05)\\
\\
White Paper\\
\\
Jul 25, 2025\\
\\
2025-07-25\\
\\
**Embracing Modularity in POS Tech: Innovate with Confidence**\\
\\
This whitepaper explores how modular, adaptable point-of-sale (POS) technologies are reshaping retail and restaurant operations. Sponsored by Toshiba in partnership with Retail Customer Experience, it highlights how businesses can confidently adopt emerging technologies without the risks of long-term lock-in, helping them stay competitive and future-ready.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/embracing-modularity-in-pos-tech&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/a30e1980-9083-4217-9ad4-ca82656d0f41/LivingOnTheEdgeCamera.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-a30e1980-9083-4217-9ad4-ca82656d0f41-pA.q4aq)\\
\\
White Paper\\
\\
Sep 12, 2025\\
\\
2025-09-12\\
\\
**Living on the Edge**\\
\\
Retail is entering a new era, as edge-enabled intelligence replaces costly, centralized systems. This whitepaper shows how retailers can cut shrink, reduce infrastructure costs, and build sustainable, future-ready operations by moving camera analytics and AI to the edge.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/living-on-the-edge-whitepaper&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/48734b2d-16fa-4429-8671-2461632ce9b2/ToshibaBuiltToAdaptModularPOS.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-48734b2d-16fa-4429-8671-2461632ce9b2-pLs0lwY)\\
\\
Infographic\\
\\
Nov 04, 2025\\
\\
2025-11-04\\
\\
**Built to Adapt: How Modular POS Powers the Future of Retail**\\
\\
Adaptability has become the new measure of success in retail.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/modular-pos-powers-future-of-retail&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/f7098945-ff71-4311-8539-7f801d862e4e/WW2020-Product-Page-THUMB-LARGE-Whitepaper-CENTER.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-f7098945-ff71-4311-8539-7f801d862e4e-oToSZOP)\\
\\
White Paper\\
\\
Dec 15, 2023\\
\\
2023-12-15\\
\\
**State of the Industry: Future of C-Stores**\\
\\
This industry report presents key findings and analysis from a study of 125 convenience retail executives in the United States and Canada to gain insights into the impact of increased competition and eCommerce adoption in Convenience, Convenience retailers' outlook towards the future of the c-store, and current adoption and future plans to acquire key commerce experiences and capabilities.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/soti-future-c-stores&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/232861f6-cd10-451c-b2c4-f73340ef57b9/WW2020-Product-Page-THUMB-LARGE-Whitepaper-grocery.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-232861f6-cd10-451c-b2c4-f73340ef57b9-oTokUxw)\\
\\
Report\\
\\
Dec 14, 2023\\
\\
2023-12-14\\
\\
**State of the Industry: Unified Commerce in Food & Grocery**\\
\\
This industry report presents key findings and analysis from a study of 142 grocery executives in North America and 100 grocery executives in Latin America to gain insight into the executive perspective and approach towards the fast-evolving trends redefining the grocery landscape.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/soti-unified-commerce-grocery&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/d0161d0f-7f2a-4174-a833-ecc9141dac8f/WW2020-Product-Page-THUMB-LARGE-Whitepaper-CENTER.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-d0161d0f-7f2a-4174-a833-ecc9141dac8f-oTokUHX)\\
\\
Report\\
\\
Dec 13, 2023\\
\\
2023-12-13\\
\\
**Balancing Shrink & Customer Experience in Retail: The Evolution of Self-Checkout & A.I.-Powered Loss Prevention**\\
\\
Self-checkout (SCO) technology initially emerged as a means for retailers to streamline the checkout process and reduce labor costs. Early iterations of these systems were very basic, often plagued by technical glitches, and faced resistance from both retailers and shoppers.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/balancing-shrink-cx&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/1772e24c-cabf-4b88-95a2-0ad615232601/WW2020-Product-Page-THUMB-LARGE-Whitepaper-CENTER.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-1772e24c-cabf-4b88-95a2-0ad615232601-oTokURV)\\
\\
Report\\
\\
Aug 07, 2023\\
\\
2023-08-07\\
\\
**Innovation and the Customer Experience**\\
\\
Discover how innovation impacts the customer experience and how retailers can close the gap between intention and implementation, improve profitability, and keep up with customer expectations.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/innovation-cx-2023&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/e4c8ba71-c4d3-40eb-931b-0ac918f0f0a7/WW2020-Product-Page-THUMB-LARGE-Infographic.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-e4c8ba71-c4d3-40eb-931b-0ac918f0f0a7-oToLd5H)\\
\\
Report\\
\\
Apr 13, 2023\\
\\
2023-04-13\\
\\
**Convenience Trends Infographic 2023**\\
\\
New research shows how convenience and fuel retailers are tackling self-checkout and all of the challenges and opportunities that come along with it.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/convenience-trends-ig2023&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/4d53bd9d-f36c-48b2-949e-300f51b24c78/WW2020-Product-Page-THUMB-LARGE-Infographic.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-4d53bd9d-f36c-48b2-949e-300f51b24c78-oToMWS0)\\
\\
Report\\
\\
Apr 13, 2023\\
\\
2023-04-13\\
\\
**Grocery Trends Infographic 2023**\\
\\
Are retailers' unified commerce strategies aligned with their growth imperatives? What are their key priorities? This infographic provides insight into how grocers are trying to shift their priorities around their physical and digital strategies.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/grocery-trends-ig2023&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/0736c529-f7fd-4827-b294-d404bdd6dc9a/WW2020-Product-Page-THUMB-LARGE-Whitepaper-CENTER.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-0736c529-f7fd-4827-b294-d404bdd6dc9a-oTokVoU)\\
\\
Report\\
\\
Apr 05, 2023\\
\\
2023-04-05\\
\\
**State of the Industry: Future of In-Restaurant Dining**\\
\\
This industry report presents key findings and analysis from a study of over 141 U.S. restaurant executives to gain insights into the impact of shifts in food ordering, improving the in-restaurant experience, and addressing key challenges facing the industry.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/soti-future-restaurant&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/16439a34-6283-4273-aa50-20825cdc610d/WW2020-Product-Page-THUMB-LARGE-Infographic.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-16439a34-6283-4273-aa50-20825cdc610d-oTokVA4)\\
\\
Report\\
\\
Feb 16, 2023\\
\\
2023-02-16\\
\\
**Innovation in Retail Infographic**\\
\\
As technology continues to evolve, retailers must embrace new innovations and continuously experiment to find new ways to better serve customers and remain competitive.\\
\\
This infographic provides insights into retailers’ key innovation priorities, strategies, and future investment plans based on key findings and analysis from a study of 225+ retail executives.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/innovation-retail-2023-infographic&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/9f9ad837-3f90-43d9-bc43-c7d1e11c67a3/WW2020-Product-Page-THUMB-LARGE-Whitepaper-CENTER.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-9f9ad837-3f90-43d9-bc43-c7d1e11c67a3-oTokVK.)\\
\\
Report\\
\\
Jan 24, 2023\\
\\
2023-01-24\\
\\
**State of the Industry: Unified Commerce in Food and Grocery**\\
\\
This industry report presents key findings and analysis from a study of over 135 food and grocery retail executives to gain insights into the current and future readiness for unified commerce.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/soi-unified-commerce-food-grocery&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/affa0ec2-7de8-479b-b755-0453286a54f3/WW2020-Product-Page-THUMB-LARGE-Whitepaper-CENTER.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-affa0ec2-7de8-479b-b755-0453286a54f3-oTokVWv)\\
\\
Report\\
\\
Jan 24, 2023\\
\\
2023-01-24\\
\\
**State of the Industry: Future of Convenience Stores**\\
\\
This industry report presents key findings and analysis from a study of 128 convenience retail executives to gain insights into the current and future plans of Convenience retailers.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/soi-future-convenience-stores&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/df20b1cf-2759-4fc8-a4de-6a19f623fae8/WW2020-Product-Page-THUMB-LARGE-Whitepaper-CENTER.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-df20b1cf-2759-4fc8-a4de-6a19f623fae8-oTokW4X)\\
\\
Report\\
\\
Jan 24, 2023\\
\\
2023-01-24\\
\\
**State of the Industry: Innovation in Retail**\\
\\
This industry report presents key findings and analysis from a study of over 225 retail executives to gain insights into the current and future readiness, capabilities, and maturity of innovation strategies.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/soi-innovation-retail&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/442f2404-2f5d-4b84-a37d-4a2568eb723e/WW2020-Product-Page-THUMB-LARGE-Infographic.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-442f2404-2f5d-4b84-a37d-4a2568eb723e-oTokWKC)\\
\\
Report\\
\\
Mar 02, 2022\\
\\
2022-03-02\\
\\
**2022 Customer Loyalty Infographic**\\
\\
With the changes in retail, businesses need to rebuild or strengthen loyalty with their customers with the experiences they are looking for. New data gives insights into what shopper expectations look like in 2022.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/cx-loyalty-info-2022&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/4778c354-18f0-40ec-9740-0f394b0e00c9/WW2020-Product-Page-THUMB-LARGE-Whitepaper-CENTER.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-4778c354-18f0-40ec-9740-0f394b0e00c9-oTokWgD)\\
\\
Report\\
\\
Jan 15, 2022\\
\\
2022-01-15\\
\\
**Decoding Consumer Affinity**\\
\\
New research finds that many pharmacy and grocery shoppers are actually loyal to the digital features that produce positive customer experiences — not the retail brand itself. Read the new report to learn more about customer loyalty to merchants.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/decoding-consumer-affinity&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/a8c11715-95e5-42fe-8e5b-c7701cad71a8/WW2020-Product-Page-THUMB-LARGE-Whitepaper-CENTER.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-a8c11715-95e5-42fe-8e5b-c7701cad71a8-oTokW-D)\\
\\
Report\\
\\
Oct 28, 2021\\
\\
2021-10-28\\
\\
**Why Your Retail Business Needs a Trusted Service Provider**\\
\\
Retailers are constantly looking for better ways to make every dollar count, especially when upgrading, configuring, migrating, or deploying new retail solutions that would typically take significant time and money to implement. Selecting the right service provider is key to enabling your business to succeed.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/need-tsp&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/44db08fd-f184-4c50-8604-c29202a010a0/WW2020-Product-Page-THUMB-LARGE-Whitepaper-CENTER.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-44db08fd-f184-4c50-8604-c29202a010a0-oTokWqT)\\
\\
Report\\
\\
Jul 01, 2021\\
\\
2021-07-01\\
\\
**Today’s Self-Service Shopping Journey**\\
\\
New research shows shoppers want modern, user-friendly, self-service experiences that allow them to shop when, where and how they want and skip the traditional checkout. Read the report to learn more.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/self-service-shopping-journey&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/ef59822d-20e1-41af-a488-dddd85037807/WW2020-Product-Page-THUMB-LARGE-Whitepaper-CENTER.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-ef59822d-20e1-41af-a488-dddd85037807-oTokXdH)\\
\\
Report\\
\\
Jun 29, 2021\\
\\
2021-06-29\\
\\
**Retail Hardened Technology White Paper**\\
\\
Reliability is one of the most important performance factors for any point of sale and self-service hardware. If the system goes down, even for a few minutes, the store can’t complete the transaction, which can lead to frustrated shoppers and hurt customer loyalty and result in potential lost sales and revenue.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/retail-hardened-technology-white-paper&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/88023256-05de-44f3-bffc-4ea2d862f00b/WW2020-Product-Page-THUMB-LARGE-Infographic.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-88023256-05de-44f3-bffc-4ea2d862f00b-oTokXpx)\\
\\
Report\\
\\
Jun 29, 2021\\
\\
2021-06-29\\
\\
**Retail Hardened Testing Metrics Infographic**\\
\\
Retailers don’t have time to deal with disruptions caused by common hazards. Reliability and durability are important considerations when you’re investing in point-of-sale hardware. That’s why it’s vital that your retail technology is retail hardened.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/retail-hardened-testing-infographic&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/08798bbe-6fed-43d9-b4fd-5f01ff6c161e/WW2020-Product-Page-THUMB-LARGE-Edison-CENTER.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-08798bbe-6fed-43d9-b4fd-5f01ff6c161e-oTokXA7)\\
\\
Report\\
\\
Apr 16, 2021\\
\\
2021-04-16\\
\\
**Redefining the Guest Experience through Unified Commerce**\\
\\
The food industry must adapt their models to remove friction from the buying journey that most often starts in the digital realm. This Market Snapshot provides insights into how point-of-sale systems must provide restaurant chains the ability to quickly adapt to a dynamic environment.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/redefining-guest-experience-unified-commerce&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/b92d8297-f599-4197-94c6-20b32ed48ac9/WW2020-Product-Page-THUMB-LARGE-Edison-CENTER.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-b92d8297-f599-4197-94c6-20b32ed48ac9-oTokXLF)\\
\\
Report\\
\\
Apr 16, 2021\\
\\
2021-04-16\\
\\
**The Four Imperatives of the Redefined Restaurant Environment**\\
\\
Restaurants have to adopt a business model that enables more flexibility in uncertain environments. This Market Snapshot provides insights into how to enable new safety requirements and rethink their systems approach to deliver in-location dining experiences to meet guests' expectations.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/4-imperatives-restaurant-environment&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/e76c2ab4-e1ed-4083-85d1-e98a135eb839/WW2020-Product-Page-THUMB-LARGE-Edison-CENTER.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-e76c2ab4-e1ed-4083-85d1-e98a135eb839-oTokXWL)\\
\\
Report\\
\\
Apr 16, 2021\\
\\
2021-04-16\\
\\
**The Four Imperatives for Store Success in Apparel/Specialty Retail**\\
\\
Apparel & Specialty retailers faced an unprecedented 2020. This has lead to massive changes across the enterprise. This Market Snapshot provides insights into how to enable new safety requirements and new consumer expectations for apparel/specialty shopping, retailers need to rethink their systems approach.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/4-imperatives-apparel-specialty&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/54c7d8fe-ab5e-48c0-912b-df048c17a5da/WW2020-Product-Page-THUMB-LARGE-Infographic.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-54c7d8fe-ab5e-48c0-912b-df048c17a5da-oTonlZW)\\
\\
Infographic\\
\\
Mar 25, 2021\\
\\
2021-03-25\\
\\
**Pro-X Hybrid Kiosk Infographic**\\
\\
Extend your front-end to the rest of your store. Designed for any retail environment, our new self-service solution offers a modern, flexible and attractive self-service touchpoint that can be installed virtually anywhere enabling retailers to reimagine their store design and increase store capacities.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/pro-x-kiosk-infographic&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/547780e2-b75d-4711-896b-e21f942dc485/WW2020-Product-Page-THUMB-Edison-Report.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-547780e2-b75d-4711-896b-e21f942dc485-oTomo7k)\\
\\
Report\\
\\
Jan 13, 2021\\
\\
2021-01-13\\
\\
**Accelerating the Future of Retail With a Microservices Commerce Platform**\\
\\
Many brick-and-mortar retailers in the United States and abroad were forced to adapt to the uncertainty of nationwide closures. Ever since, retailers have navigated a new landscape of commerce and sought out effective ways to meet the still-evolving needs of retail consumers — a journey that highlights the ongoing relevance of retail technology that reduces friction.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/elera-smart-focus-whitepaper&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/cf0b4769-4996-4606-942b-30287f4919a1/WW2020-Product-Page-THUMB-Edison-Report.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-cf0b4769-4996-4606-942b-30287f4919a1-oTomcXG)\\
\\
Report\\
\\
Nov 10, 2020\\
\\
2020-11-10\\
\\
**Retail in 2021: The impact of COVID-19 on Retail Technology**\\
\\
Many brick-and-mortar retailers in the United States and abroad were forced to adapt to the uncertainty of nationwide closures. Ever since, retailers have navigated a new landscape of commerce and sought out effective ways to meet the still-evolving needs of retail consumers — a journey that highlights the ongoing relevance of retail technology that reduces friction.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/retail-in-2021-covid-19&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/32324c48-2409-422b-9ce3-fa5a356f149e/WW2020-Product-Page-THUMB-Edison-Report.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-32324c48-2409-422b-9ce3-fa5a356f149e-oTomd5H)\\
\\
Report\\
\\
Jul 13, 2020\\
\\
2020-07-13\\
\\
**5 Retail Technology Infrastructure Must-Haves**\\
\\
To keep pace with changing consumer expectations while also controlling costs in today’s dynamic environment, brands need a set of infrastructure solutions designed for retail. \\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/5-retail-technology-infrastructure-must-haves&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/4c57d219-07fd-46af-adc0-61d32ff4cd0a/WW2020-Product-Page-THUMB-Edison-Report.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-4c57d219-07fd-46af-adc0-61d32ff4cd0a-oTomdf8)\\
\\
Report\\
\\
Jun 03, 2020\\
\\
2020-06-03\\
\\
**Retail Store Reopening Guide**\\
\\
As you reopen your store, there are also several practical items to think about for the safety and well-being of your employees and visitors while providing an opportunity to be transformational for the future.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/retail+store+reopening+guide&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/94f94c38-9f2e-43ce-a26f-4bc14b79ad79/WW2020-Product-Page-THUMB-Edison-Report.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-94f94c38-9f2e-43ce-a26f-4bc14b79ad79-oTomdoW)\\
\\
Report\\
\\
May 19, 2020\\
\\
2020-05-19\\
\\
**3 Ways Retail Executives Are Preparing for the Future of In-Store Tech**\\
\\
Toshiba, together with Retail Dive, surveyed 148 retail executives to find out how they are utilizing technology to change the in-store experience for shoppers and create unique, operational benefits.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/3+ways+retail+executives+are+preparing+for+the+future+of+in-store+tech&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/9c9fa01f-77a8-43d8-919a-9984ced8819f/WW2020-Product-Page-THUMB-eBook.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-9c9fa01f-77a8-43d8-919a-9984ced8819f-oTomeTI)\\
\\
Report\\
\\
Nov 01, 2019\\
\\
2019-11-01\\
\\
**The 5 Store Formats Reshaping Apparel and Specialty Retail**\\
\\
We are in a retail renaissance. Both digital upstarts and incumbent retailers are re-imagining stores as hubs of experience, convenience and service. Apparel and specialty retailers are experimenting with, and scaling, five unique store formats that deliver a combination of experience, convenience and service. These store formats are reshaping the future of brick and mortar retail.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/5-store-formats&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/30bfc432-4c08-4bcf-a00d-b695d7f24ba4/WW2020-Product-Page-THUMB-Infographic.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-30bfc432-4c08-4bcf-a00d-b695d7f24ba4-oTomg0O)\\
\\
Report\\
\\
May 01, 2019\\
\\
2019-05-01\\
\\
**Beyond Millennials Consumer Research Infographic**\\
\\
New research indicates shoppers view the store as an integral part of engagement, transaction, and retention. Learn how to connect with your consumers so you can attract and retain them with better experiences\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/beyond-millennials&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/198a3d95-2ecd-4bc1-8c58-0168fc225cb3/WW2020-Product-Page-THUMB-Infographic.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-198a3d95-2ecd-4bc1-8c58-0168fc225cb3-pwfrmuK)\\
\\
Report\\
\\
Nov 01, 2019\\
\\
2019-11-01\\
\\
**TCx® 800 All-in-One POS Platform Infographic**\\
\\
As a fully functional point-of-sale system, kiosk, or self-service unit, the TCx® 800 All-in-One POS platform is designed for retail by combining robust performance and exceptional reliability.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/all-in-one-pos-infographic&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/a95542d7-bc95-4160-9d43-de3a99aaa867/WW2020-Product-Page-THUMB-Checklist.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-a95542d7-bc95-4160-9d43-de3a99aaa867-oTomeJJ)\\
\\
Report\\
\\
Oct 01, 2019\\
\\
2019-10-01\\
\\
**POS Checklist: 5 Things Retailers Must Know Before Upgrading**\\
\\
Retailers know that a reliably functioning point-of-sale (POS) system is critical to customer satisfaction. According to the 2019 POS/Customer Engagement Survey from BRP, 82% of consumers say the ease of checkout and payment is an important factor in choosing where they shop.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/5-things-retailers-must-know&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/a719758d-de36-4a38-b1a7-25e7983a3c04/WW2020-Product-Page-THUMB-TL-Atricle.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-a719758d-de36-4a38-b1a7-25e7983a3c04-oTomgin)\\
\\
Report\\
\\
Nov 01, 2018\\
\\
2018-11-01\\
\\
**Rethinking Retail Ahead of The Holidays**\\
\\
The holidays are upon us, and retailers have to be ready with seamless, cross-channel shopping experiences that live up to consumers' expectations. So what can the industry expect after Thanksgiving dinner is done, and how can retailers prepare themselves to make the most of the busiest season of the year?\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/holidays-rethinking-retail&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/5cc85022-8225-4c7c-add3-fdad26a403c0/WW2020-Product-Page-THUMB-Infographic.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-5cc85022-8225-4c7c-add3-fdad26a403c0-pwfrsRO)\\
\\
Report\\
\\
Nov 01, 2019\\
\\
2019-11-01\\
\\
**TCx® Printers Infographic**\\
\\
Toshiba TCx® Printers were designed for retail to bring easy systems management, efficiency and reliability to a variety of retail environments.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/tcx-printers-infographic&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/8c78e47d-1b66-44a9-86af-3ae71e5221e6/WW2020-Product-Page-THUMB-White-Paper.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-8c78e47d-1b66-44a9-86af-3ae71e5221e6-oTomeAe)\\
\\
Report\\
\\
Feb 01, 2019\\
\\
2019-02-01\\
\\
**Beyond Millenials: How to Attract and Retain Today's Consumers**\\
\\
Consumer research from Toshiba Global Commerce Solutions indicates shoppers, of all generations, view the store as an integral part of engagement, transaction and retention. In this report, we reveal critical insights to create meaningful connections with consumers across points of decision, from home to store and in between."\\
\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/beyond-millenials&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/75eab926-b584-48c9-ae38-bf7d621d202d/WW2020-Product-Page-THUMB-TL-Atricle.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-75eab926-b584-48c9-ae38-bf7d621d202d-oTomg9J)\\
\\
Report\\
\\
Oct 01, 2018\\
\\
2018-10-01\\
\\
**IDC MarketScape Report 2018**\\
\\
Toshiba was named a Leader in the IDC MarketScape: Worldwide Point-of-Sale Software in Fast-Moving Consumer Goods Retail 2018 Vendor Assessment\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/idc-marketscape-report-2018&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/cac37bbf-7a81-4375-bb45-785fadd39c18/WW2020-Product-Page-THUMB-White-Paper.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-cac37bbf-7a81-4375-bb45-785fadd39c18-oTomerL)\\
\\
Report\\
\\
Dec 01, 2018\\
\\
2018-12-01\\
\\
**Getting set for the Holidays: Giving Shoppers the Gift of the Ideal Experience**\\
\\
"The fun of shopping is never as pronounced as during the holidays. Shopping centers become places to ice skate with family, take pictures with Santa, sip hot cocoa and browse for the perfect gift for a loved one. While purchasing online can eliminate the anxiety of dealing with crowds and long lines, it also takes away the sensory joys of the season."\\
\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/getting-set-for-the-holidays&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/75521acb-a09e-4048-97f7-760935a523cf/WW2020-Product-Page-THUMB-Infographic.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-75521acb-a09e-4048-97f7-760935a523cf-oTomfAX)\\
\\
Report\\
\\
Oct 01, 2017\\
\\
2017-10-01\\
\\
**Digital Signage Infographic**\\
\\
Retailers are increasingly relying on Digital Signage as an engaging way to communicate about brands, interact with shoppers, and increase their profits.\\
\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/digital-signage-infographic&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/8ac2d825-ad16-4f30-ac48-2f8ee2c2ffd3/WW2020-Product-Page-THUMB-White-Paper.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-8ac2d825-ad16-4f30-ac48-2f8ee2c2ffd3-oTomeiq)\\
\\
Report\\
\\
Nov 01, 2018\\
\\
2018-11-01\\
\\
**Getting the Best of Both Worlds in Retail: Digital and In-store commerce are no longer distinct**\\
\\
By now, it’s clear that digital is not the death-knell of traditional retail. In fact, about 4,000 more stores opened than closed in the United States last year, according to a study by IHL Group. Large retailers that expanded in 2017 include Dollar General, Aldi, GNC, Tractor Supply and Ulta. Even digital retail king Amazon is expanding its brick-and-mortar footprint.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/best-of-both-worlds&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/93addc49-357b-4db4-8bea-089f66ce37d0/WW2020-Product-Page-THUMB-TL-Atricle.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-93addc49-357b-4db4-8bea-089f66ce37d0-oTomfsd)\\
\\
Report\\
\\
May 01, 2018\\
\\
2018-05-01\\
\\
**Elevating Retail to Endless Points of Experience**\\
\\
Customer expectations continue to evolve, so retailers must start elevating their retail experiences from simple points of sale to endless points of experience. The time is now to enable new customer journeys and personalized interactions that transform frustrations into shopper enjoyment.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/elevating-retail&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/8ca6ed92-11ab-4010-b51f-c9c33b38ca35/WW2020-Product-Page-THUMB-TL-Atricle.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-8ca6ed92-11ab-4010-b51f-c9c33b38ca35-oTomfjz)\\
\\
Report\\
\\
Jun 01, 2019\\
\\
2019-06-01\\
\\
**In Pursuit of Frictionless**\\
\\
InnovationFriction is everywhere. As retailers and retail enthusiasts we’re trained to identify it, removed it and measure the benefit. Then, repeat. That makes the frictionless wave sweeping across the retail industry even more exciting. Are you ready?\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/pursuit-of-frictionless&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/7c941e69-032d-4221-b99d-e390234cdd6b/WW2020-Product-Page-THUMB-Edison-Report.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-7c941e69-032d-4221-b99d-e390234cdd6b-oTome8t)\\
\\
Report\\
\\
Sep 01, 2018\\
\\
2018-09-01\\
\\
**Comparing Toshiba all-in-one POS platform against its competitors**\\
\\
Test results clearly indicate that Toshiba has the premium integrated POS platform, earning high ratings in almost every evaluation criterion. Starting with several retail hardening features, Toshiba’s POS all-in-one platform includes advanced air cooling, flexible screen tilting, formalized cable management, ease of service and future-proof architecture."\\
\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/toshiba-all-in-one-pos&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/9d0c0b38-0cc2-433e-a291-e60cea880235/WW2020-Product-Page-THUMB-TL-Atricle.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-9d0c0b38-0cc2-433e-a291-e60cea880235-oTomfaS)\\
\\
Report\\
\\
Nov 01, 2019\\
\\
2019-11-01\\
\\
**Re-imagining Retail for the Digital Age**\\
\\
Retail is currently experiencing a renaissance where the role of the store is changing rapidly. Convenience, customer-focused service, and basic omnichannel services are standard expectations and no longer serve as differentiators for stores. Retailers must now fundamentally change their store formats in order to deliver shopping experiences that engage customers. That means retailers must create unified shopping experiences by orchestrating new investments in technology alongside mission-critical store systems to exceed expectations in this new digital age.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/re-imagining-retail&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/88d2e326-75cf-44ff-90ee-bc1ca45f6dcc/WW2020-Product-Page-THUMB-Edison-Report.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-88d2e326-75cf-44ff-90ee-bc1ca45f6dcc-pwfrz3z)\\
\\
Report\\
\\
Sep 01, 2019\\
\\
2019-09-01\\
\\
**Comparing Toshiba TCx® Dual Station POS Printers against Epson**\\
\\
Edison Group conducted research and a series of tests comparing Dual Station Point-of-Sale (POS) printers, namely, Toshiba TCx® Dual Station Printer (6145-2TN) vs. Epson (TM-H6000V) focusing on four categories, namely performance, economy, architecture and serviceability as they are the main considerations when purchasing a POS printer for retail.\\
\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/dual-station-vs-epson&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/e47e0418-734a-498f-bb20-f88a8f15bddd/WW2020-Product-Page-THUMB-White-Paper.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-e47e0418-734a-498f-bb20-f88a8f15bddd-oTomdI0)\\
\\
Report\\
\\
Feb 03, 2020\\
\\
2020-02-03\\
\\
**How Advanced Loss Prevention Tools Balance Friction and Risk At Checkout**\\
\\
With customers consistently seeking fast, convenient and simple self-checkout experiences, retailers are understandably reluctant to do anything that will add friction at checkout in order to protect their bottom line while maximizing trust and loyalty. Customers want to feel confident that their transactions are accurate, and retailers need to trust in the systems’ capability to protect the store from shrink.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/loss+prevention+tools+balance+friction+and+risk+at+checkout&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/1a393c34-2449-4eea-8dd0-0e900ed8b606/WW2020-Product-Page-THUMB-White-Paper.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-1a393c34-2449-4eea-8dd0-0e900ed8b606-oTomdyu)\\
\\
Report\\
\\
Feb 07, 2020\\
\\
2020-02-07\\
\\
**Optimizing Automated Checkout for an Excellent Customer Experience**\\
\\
Toshiba’s System 7 self-service solution was designed with shoppers in mind. This next-generation, customer-focused solution – a product of advancements in Toshiba’s self-checkout technology, processes and training – gives shoppers choice, control, privacy, and convenience at checkout. \\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/optimizing+automated+checkout+for+an+excellent+customer+experience&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/047e77ab-aa18-4542-9508-44ecc1211f79/WW2020-Product-Page-THUMB-Edison-Report.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-047e77ab-aa18-4542-9508-44ecc1211f79-pwfrGWd)\\
\\
Report\\
\\
Sep 01, 2019\\
\\
2019-09-01\\
\\
**Comparing Toshiba TCx® Single Station Printers against Epson**\\
\\
Edison Group conducted research and a series of tests comparing Single Station Point-of-Sale (POS) printers, namely, Toshiba TCx® Printer 1 Station (6145-1TN) vs. Epson (TM-T88VI) focusing on four categories, namely performance, economy, architecture and serviceability as they are the main considerations when purchasing a POS printer for retail.\\
\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/single-station-vs-epson&mapping=tgcs_new.portal.company.newsdetails.new "") [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/f0521dfb-22cd-44d7-aed1-6ea4c4d3beb2/WW2020-Product-Page-THUMB-TL-Atricle.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-f0521dfb-22cd-44d7-aed1-6ea4c4d3beb2-oTomf1j)\\
\\
Report\\
\\
Aug 01, 2019\\
\\
2019-08-01\\
\\
**In Pursuit of Frictionless Commerce**\\
\\
The store of the future is here. Retailers must take steps toward a frictionless future by transforming in-store experiences to create sustainable business growth while also realizing value each step along the journey through customer tracking, inventory and planogram compliance and more, all ultimately evolving to a frictionless shopping experience.\\
\\
\\
Read More](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/company/insights/pursuit-of-frictionless-commerce&mapping=tgcs_new.portal.company.newsdetails.new "")

See More

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

## Our Awards & Recognitions

### Excellence in Retail

Guided by our values, we are a leader in retail recognized for developing innovative solutions that accelerate retail.

We’re committed to building a company culture focused on our employees, partners, and customers.

Above all, we’re driven to create the best possible experiences—ones that make a real difference for retailers, associates, shoppers, and communities.

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/4b7055a7-7453-488c-9266-4a14f32876d1/VIPbestMultiVendorCommercePlatform2026toshiba.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-4b7055a7-7453-488c-9266-4a14f32876d1-pM62Knc)](https://commerce.toshiba.com/wps/portal/marketing/newsmedia/!ut/p/z1/tZZde5owFIB_yy68THMSPoy7Q-sArSJd1cpNnwSCsik4wDr36xfb7unHVLpZuMlDcs57PnJyEhzgWxyk_D6Z8zLJUr5U_7PAvOu3dMthHRjZHjXAH-h03Jz4mu1QPMEBDtZhEuEZ0QSBODaQSXmEdAohYpERIlMaLcFEKwZu7KXDtFyXCzyTKdoUDVhkK9mAMFutebprQCq3xUpGCcfTR9sWWMQCOoTu0ALTtAi9afeJx3QcvHSNeW5XuebZff3qEsDU_-gfF9jruy1Cod8Hjw1sQ02Oej5zh9S34Un_hEBwOjVv7NsjqwO-ObZHzO1o-sR8nz68-ixoX9O2BqDE_0f_Jelf_f9LIDiNn-43uyIDBxivQ6wyElRVwUxF0byjtN9xWqqK7KF2CaZPOmw8HoNuNfH0PpFbPE6zfKUK_utzPUcaFyw0CeIUDKQTQyLebAoUE6K3gDFQBY0dqLDg62daqMCb9eKNM_G9x_05fohVh0m-_fgRWKoxZGkpf5b49nBnEMts3oAomSclXyKZc1RswlAWxVMMx04qheMxgNmKRDMGpDe1UMUQ6kiERCBDSBYxnQphiCo8rRdP6sVrteLdenPv1pt7t97cu-fmvld1hVUeriSNNkWZJ1LNFGsZJnxZ7nJZ8uTh7qf5oDOYK594uUBJGmf49q3UmxA9x9s34O540nWGFOwT3e9d74UKvFkv3vhYvH3p7PGTtjsiNtiEfCye3Qy_gN-dkEnbdlUDrhmv1Yr34Ex8r-p98_6b5_lNevhMPK8ro_NlJh5fzlYqNKYkcxnLXOYXm1xNL8pyXXxuQAO22-3FPMvmS3mhLDXgkMoiK5RXryXxerVi2i55-ND3a-dXe4jsjmDbm3ilhp22n5j17g8PV3J6ejEQu-2n35fBSKA!/)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/bd4f8c74-9f9f-459c-a2ff-8b230009d6ee/2022-CEO-Year-C-suite-Awards.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-bd4f8c74-9f9f-459c-a2ff-8b230009d6ee-owh70mH)](https://commerce.toshiba.com/wps/portal/marketing/newsmedia/!ut/p/z1/tZZde5owFIB_yy68THMSPoy7Q-sArSJd1cpNnwSCsik4wDr36xfb7unHVLpZuMlDcs57PnJyEhzgWxyk_D6Z8zLJUr5U_7PAvOu3dMthHRjZHjXAH-h03Jz4mu1QPMEBDtZhEuEZ0QSBODaQSXmEdAohYpERIlMaLcFEKwZu7KXDtFyXCzyTKdoUDVhkK9mAMFutebprQCq3xUpGCcfTR9sWWMQCOoTu0ALTtAi9afeJx3QcvHSNeW5XuebZff3qEsDU_-gfF9jruy1Cod8Hjw1sQ02Oej5zh9S34Un_hEBwOjVv7NsjqwO-ObZHzO1o-sR8nz68-ixoX9O2BqDE_0f_Jelf_f9LIDiNn-43uyIDBxivQ6wyElRVwUxF0byjtN9xWqqK7KF2CaZPOmw8HoNuNfH0PpFbPE6zfKUK_utzPUcaFyw0CeIUDKQTQyLebAoUE6K3gDFQBY0dqLDg62daqMCb9eKNM_G9x_05fohVh0m-_fgRWKoxZGkpf5b49nBnEMts3oAomSclXyKZc1RswlAWxVMMx04qheMxgNmKRDMGpDe1UMUQ6kiERCBDSBYxnQphiCo8rRdP6sVrteLdenPv1pt7t97cu-fmvld1hVUeriSNNkWZJ1LNFGsZJnxZ7nJZ8uTh7qf5oDOYK594uUBJGmf49q3UmxA9x9s34O540nWGFOwT3e9d74UKvFkv3vhYvH3p7PGTtjsiNtiEfCye3Qy_gN-dkEnbdlUDrhmv1Yr34Ex8r-p98_6b5_lNevhMPK8ro_NlJh5fzlYqNKYkcxnLXOYXm1xNL8pyXXxuQAO22-3FPMvmS3mhLDXgkMoiK5RXryXxerVi2i55-ND3a-dXe4jsjmDbm3ilhp22n5j17g8PV3J6ejEQu-2n35fBSKA!/)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/d3625726-0052-4fc5-adac-032e89177535/ARtopAI_Leaders_2026.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-d3625726-0052-4fc5-adac-032e89177535-pM62hM7)](https://commerce.toshiba.com/wps/portal/marketing/newsmedia/!ut/p/z1/tZZde5owFIB_yy68THMSPoy7Q-sArSJd1cpNnwSCsik4wDr36xfb7unHVLpZuMlDcs57PnJyEhzgWxyk_D6Z8zLJUr5U_7PAvOu3dMthHRjZHjXAH-h03Jz4mu1QPMEBDtZhEuEZ0QSBODaQSXmEdAohYpERIlMaLcFEKwZu7KXDtFyXCzyTKdoUDVhkK9mAMFutebprQCq3xUpGCcfTR9sWWMQCOoTu0ALTtAi9afeJx3QcvHSNeW5XuebZff3qEsDU_-gfF9jruy1Cod8Hjw1sQ02Oej5zh9S34Un_hEBwOjVv7NsjqwO-ObZHzO1o-sR8nz68-ixoX9O2BqDE_0f_Jelf_f9LIDiNn-43uyIDBxivQ6wyElRVwUxF0byjtN9xWqqK7KF2CaZPOmw8HoNuNfH0PpFbPE6zfKUK_utzPUcaFyw0CeIUDKQTQyLebAoUE6K3gDFQBY0dqLDg62daqMCb9eKNM_G9x_05fohVh0m-_fgRWKoxZGkpf5b49nBnEMts3oAomSclXyKZc1RswlAWxVMMx04qheMxgNmKRDMGpDe1UMUQ6kiERCBDSBYxnQphiCo8rRdP6sVrteLdenPv1pt7t97cu-fmvld1hVUeriSNNkWZJ1LNFGsZJnxZ7nJZ8uTh7qf5oDOYK594uUBJGmf49q3UmxA9x9s34O540nWGFOwT3e9d74UKvFkv3vhYvH3p7PGTtjsiNtiEfCye3Qy_gN-dkEnbdlUDrhmv1Yr34Ex8r-p98_6b5_lNevhMPK8ro_NlJh5fzlYqNKYkcxnLXOYXm1xNL8pyXXxuQAO22-3FPMvmS3mhLDXgkMoiK5RXryXxerVi2i55-ND3a-dXe4jsjmDbm3ilhp22n5j17g8PV3J6ejEQu-2n35fBSKA!/)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/e1da48ef-dab8-4f9d-9544-5d043d0cf6ab/RISsoftwareLeaderboard24winner.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-e1da48ef-dab8-4f9d-9544-5d043d0cf6ab-pM62Ch1)](https://commerce.toshiba.com/wps/portal/marketing/newsmedia/!ut/p/z1/tZZde5owFIB_yy68THMSPoy7Q-sArSJd1cpNnwSCsik4wDr36xfb7unHVLpZuMlDcs57PnJyEhzgWxyk_D6Z8zLJUr5U_7PAvOu3dMthHRjZHjXAH-h03Jz4mu1QPMEBDtZhEuEZ0QSBODaQSXmEdAohYpERIlMaLcFEKwZu7KXDtFyXCzyTKdoUDVhkK9mAMFutebprQCq3xUpGCcfTR9sWWMQCOoTu0ALTtAi9afeJx3QcvHSNeW5XuebZff3qEsDU_-gfF9jruy1Cod8Hjw1sQ02Oej5zh9S34Un_hEBwOjVv7NsjqwO-ObZHzO1o-sR8nz68-ixoX9O2BqDE_0f_Jelf_f9LIDiNn-43uyIDBxivQ6wyElRVwUxF0byjtN9xWqqK7KF2CaZPOmw8HoNuNfH0PpFbPE6zfKUK_utzPUcaFyw0CeIUDKQTQyLebAoUE6K3gDFQBY0dqLDg62daqMCb9eKNM_G9x_05fohVh0m-_fgRWKoxZGkpf5b49nBnEMts3oAomSclXyKZc1RswlAWxVMMx04qheMxgNmKRDMGpDe1UMUQ6kiERCBDSBYxnQphiCo8rRdP6sVrteLdenPv1pt7t97cu-fmvld1hVUeriSNNkWZJ1LNFGsZJnxZ7nJZ8uTh7qf5oDOYK594uUBJGmf49q3UmxA9x9s34O540nWGFOwT3e9d74UKvFkv3vhYvH3p7PGTtjsiNtiEfCye3Qy_gN-dkEnbdlUDrhmv1Yr34Ex8r-p98_6b5_lNevhMPK8ro_NlJh5fzlYqNKYkcxnLXOYXm1xNL8pyXXxuQAO22-3FPMvmS3mhLDXgkMoiK5RXryXxerVi2i55-ND3a-dXe4jsjmDbm3ilhp22n5j17g8PV3J6ejEQu-2n35fBSKA!/)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/bac51c00-19e7-4f99-9080-c8b36b156559/RethinkRetailTopRetailExperts2025.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-bac51c00-19e7-4f99-9080-c8b36b156559-pM62qaW)](https://commerce.toshiba.com/wps/portal/marketing/newsmedia/!ut/p/z1/tZZde5owFIB_yy68THMSPoy7Q-sArSJd1cpNnwSCsik4wDr36xfb7unHVLpZuMlDcs57PnJyEhzgWxyk_D6Z8zLJUr5U_7PAvOu3dMthHRjZHjXAH-h03Jz4mu1QPMEBDtZhEuEZ0QSBODaQSXmEdAohYpERIlMaLcFEKwZu7KXDtFyXCzyTKdoUDVhkK9mAMFutebprQCq3xUpGCcfTR9sWWMQCOoTu0ALTtAi9afeJx3QcvHSNeW5XuebZff3qEsDU_-gfF9jruy1Cod8Hjw1sQ02Oej5zh9S34Un_hEBwOjVv7NsjqwO-ObZHzO1o-sR8nz68-ixoX9O2BqDE_0f_Jelf_f9LIDiNn-43uyIDBxivQ6wyElRVwUxF0byjtN9xWqqK7KF2CaZPOmw8HoNuNfH0PpFbPE6zfKUK_utzPUcaFyw0CeIUDKQTQyLebAoUE6K3gDFQBY0dqLDg62daqMCb9eKNM_G9x_05fohVh0m-_fgRWKoxZGkpf5b49nBnEMts3oAomSclXyKZc1RswlAWxVMMx04qheMxgNmKRDMGpDe1UMUQ6kiERCBDSBYxnQphiCo8rRdP6sVrteLdenPv1pt7t97cu-fmvld1hVUeriSNNkWZJ1LNFGsZJnxZ7nJZ8uTh7qf5oDOYK594uUBJGmf49q3UmxA9x9s34O540nWGFOwT3e9d74UKvFkv3vhYvH3p7PGTtjsiNtiEfCye3Qy_gN-dkEnbdlUDrhmv1Yr34Ex8r-p98_6b5_lNevhMPK8ro_NlJh5fzlYqNKYkcxnLXOYXm1xNL8pyXXxuQAO22-3FPMvmS3mhLDXgkMoiK5RXryXxerVi2i55-ND3a-dXe4jsjmDbm3ilhp22n5j17g8PV3J6ejEQu-2n35fBSKA!/)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/eb1f5365-05ca-413d-b829-9bca3c7c1358/RethinkRetailTopRetailExperts2026.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-eb1f5365-05ca-413d-b829-9bca3c7c1358-pM62wwK)](https://commerce.toshiba.com/wps/portal/marketing/newsmedia/!ut/p/z1/tZZde5owFIB_yy68THMSPoy7Q-sArSJd1cpNnwSCsik4wDr36xfb7unHVLpZuMlDcs57PnJyEhzgWxyk_D6Z8zLJUr5U_7PAvOu3dMthHRjZHjXAH-h03Jz4mu1QPMEBDtZhEuEZ0QSBODaQSXmEdAohYpERIlMaLcFEKwZu7KXDtFyXCzyTKdoUDVhkK9mAMFutebprQCq3xUpGCcfTR9sWWMQCOoTu0ALTtAi9afeJx3QcvHSNeW5XuebZff3qEsDU_-gfF9jruy1Cod8Hjw1sQ02Oej5zh9S34Un_hEBwOjVv7NsjqwO-ObZHzO1o-sR8nz68-ixoX9O2BqDE_0f_Jelf_f9LIDiNn-43uyIDBxivQ6wyElRVwUxF0byjtN9xWqqK7KF2CaZPOmw8HoNuNfH0PpFbPE6zfKUK_utzPUcaFyw0CeIUDKQTQyLebAoUE6K3gDFQBY0dqLDg62daqMCb9eKNM_G9x_05fohVh0m-_fgRWKoxZGkpf5b49nBnEMts3oAomSclXyKZc1RswlAWxVMMx04qheMxgNmKRDMGpDe1UMUQ6kiERCBDSBYxnQphiCo8rRdP6sVrteLdenPv1pt7t97cu-fmvld1hVUeriSNNkWZJ1LNFGsZJnxZ7nJZ8uTh7qf5oDOYK594uUBJGmf49q3UmxA9x9s34O540nWGFOwT3e9d74UKvFkv3vhYvH3p7PGTtjsiNtiEfCye3Qy_gN-dkEnbdlUDrhmv1Yr34Ex8r-p98_6b5_lNevhMPK8ro_NlJh5fzlYqNKYkcxnLXOYXm1xNL8pyXXxuQAO22-3FPMvmS3mhLDXgkMoiK5RXryXxerVi2i55-ND3a-dXe4jsjmDbm3ilhp22n5j17g8PV3J6ejEQu-2n35fBSKA!/)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/79ce6bf7-a775-46a7-bd4f-6bc9da6a7a6e/ToshibaStevieWinner2025.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-79ce6bf7-a775-46a7-bd4f-6bc9da6a7a6e-pM628XP)](https://commerce.toshiba.com/wps/portal/marketing/newsmedia/!ut/p/z1/tZZde5owFIB_yy68THMSPoy7Q-sArSJd1cpNnwSCsik4wDr36xfb7unHVLpZuMlDcs57PnJyEhzgWxyk_D6Z8zLJUr5U_7PAvOu3dMthHRjZHjXAH-h03Jz4mu1QPMEBDtZhEuEZ0QSBODaQSXmEdAohYpERIlMaLcFEKwZu7KXDtFyXCzyTKdoUDVhkK9mAMFutebprQCq3xUpGCcfTR9sWWMQCOoTu0ALTtAi9afeJx3QcvHSNeW5XuebZff3qEsDU_-gfF9jruy1Cod8Hjw1sQ02Oej5zh9S34Un_hEBwOjVv7NsjqwO-ObZHzO1o-sR8nz68-ixoX9O2BqDE_0f_Jelf_f9LIDiNn-43uyIDBxivQ6wyElRVwUxF0byjtN9xWqqK7KF2CaZPOmw8HoNuNfH0PpFbPE6zfKUK_utzPUcaFyw0CeIUDKQTQyLebAoUE6K3gDFQBY0dqLDg62daqMCb9eKNM_G9x_05fohVh0m-_fgRWKoxZGkpf5b49nBnEMts3oAomSclXyKZc1RswlAWxVMMx04qheMxgNmKRDMGpDe1UMUQ6kiERCBDSBYxnQphiCo8rRdP6sVrteLdenPv1pt7t97cu-fmvld1hVUeriSNNkWZJ1LNFGsZJnxZ7nJZ8uTh7qf5oDOYK594uUBJGmf49q3UmxA9x9s34O540nWGFOwT3e9d74UKvFkv3vhYvH3p7PGTtjsiNtiEfCye3Qy_gN-dkEnbdlUDrhmv1Yr34Ex8r-p98_6b5_lNevhMPK8ro_NlJh5fzlYqNKYkcxnLXOYXm1xNL8pyXXxuQAO22-3FPMvmS3mhLDXgkMoiK5RXryXxerVi2i55-ND3a-dXe4jsjmDbm3ilhp22n5j17g8PV3J6ejEQu-2n35fBSKA!/)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/6dc6d050-a432-43cf-ab0d-418433b3fd91/ToshibaAutomatedRetailAwards.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-6dc6d050-a432-43cf-ab0d-418433b3fd91-pM62.ox)](https://commerce.toshiba.com/wps/portal/marketing/newsmedia/!ut/p/z1/tZZde5owFIB_yy68THMSPoy7Q-sArSJd1cpNnwSCsik4wDr36xfb7unHVLpZuMlDcs57PnJyEhzgWxyk_D6Z8zLJUr5U_7PAvOu3dMthHRjZHjXAH-h03Jz4mu1QPMEBDtZhEuEZ0QSBODaQSXmEdAohYpERIlMaLcFEKwZu7KXDtFyXCzyTKdoUDVhkK9mAMFutebprQCq3xUpGCcfTR9sWWMQCOoTu0ALTtAi9afeJx3QcvHSNeW5XuebZff3qEsDU_-gfF9jruy1Cod8Hjw1sQ02Oej5zh9S34Un_hEBwOjVv7NsjqwO-ObZHzO1o-sR8nz68-ixoX9O2BqDE_0f_Jelf_f9LIDiNn-43uyIDBxivQ6wyElRVwUxF0byjtN9xWqqK7KF2CaZPOmw8HoNuNfH0PpFbPE6zfKUK_utzPUcaFyw0CeIUDKQTQyLebAoUE6K3gDFQBY0dqLDg62daqMCb9eKNM_G9x_05fohVh0m-_fgRWKoxZGkpf5b49nBnEMts3oAomSclXyKZc1RswlAWxVMMx04qheMxgNmKRDMGpDe1UMUQ6kiERCBDSBYxnQphiCo8rRdP6sVrteLdenPv1pt7t97cu-fmvld1hVUeriSNNkWZJ1LNFGsZJnxZ7nJZ8uTh7qf5oDOYK594uUBJGmf49q3UmxA9x9s34O540nWGFOwT3e9d74UKvFkv3vhYvH3p7PGTtjsiNtiEfCye3Qy_gN-dkEnbdlUDrhmv1Yr34Ex8r-p98_6b5_lNevhMPK8ro_NlJh5fzlYqNKYkcxnLXOYXm1xNL8pyXXxuQAO22-3FPMvmS3mhLDXgkMoiK5RXryXxerVi2i55-ND3a-dXe4jsjmDbm3ilhp22n5j17g8PV3J6ejEQu-2n35fBSKA!/)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/4b7055a7-7453-488c-9266-4a14f32876d1/VIPbestMultiVendorCommercePlatform2026toshiba.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-4b7055a7-7453-488c-9266-4a14f32876d1-pM62Knc)](https://commerce.toshiba.com/wps/portal/marketing/newsmedia/!ut/p/z1/tZZde5owFIB_yy68THMSPoy7Q-sArSJd1cpNnwSCsik4wDr36xfb7unHVLpZuMlDcs57PnJyEhzgWxyk_D6Z8zLJUr5U_7PAvOu3dMthHRjZHjXAH-h03Jz4mu1QPMEBDtZhEuEZ0QSBODaQSXmEdAohYpERIlMaLcFEKwZu7KXDtFyXCzyTKdoUDVhkK9mAMFutebprQCq3xUpGCcfTR9sWWMQCOoTu0ALTtAi9afeJx3QcvHSNeW5XuebZff3qEsDU_-gfF9jruy1Cod8Hjw1sQ02Oej5zh9S34Un_hEBwOjVv7NsjqwO-ObZHzO1o-sR8nz68-ixoX9O2BqDE_0f_Jelf_f9LIDiNn-43uyIDBxivQ6wyElRVwUxF0byjtN9xWqqK7KF2CaZPOmw8HoNuNfH0PpFbPE6zfKUK_utzPUcaFyw0CeIUDKQTQyLebAoUE6K3gDFQBY0dqLDg62daqMCb9eKNM_G9x_05fohVh0m-_fgRWKoxZGkpf5b49nBnEMts3oAomSclXyKZc1RswlAWxVMMx04qheMxgNmKRDMGpDe1UMUQ6kiERCBDSBYxnQphiCo8rRdP6sVrteLdenPv1pt7t97cu-fmvld1hVUeriSNNkWZJ1LNFGsZJnxZ7nJZ8uTh7qf5oDOYK594uUBJGmf49q3UmxA9x9s34O540nWGFOwT3e9d74UKvFkv3vhYvH3p7PGTtjsiNtiEfCye3Qy_gN-dkEnbdlUDrhmv1Yr34Ex8r-p98_6b5_lNevhMPK8ro_NlJh5fzlYqNKYkcxnLXOYXm1xNL8pyXXxuQAO22-3FPMvmS3mhLDXgkMoiK5RXryXxerVi2i55-ND3a-dXe4jsjmDbm3ilhp22n5j17g8PV3J6ejEQu-2n35fBSKA!/)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/bd4f8c74-9f9f-459c-a2ff-8b230009d6ee/2022-CEO-Year-C-suite-Awards.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-bd4f8c74-9f9f-459c-a2ff-8b230009d6ee-owh70mH)](https://commerce.toshiba.com/wps/portal/marketing/newsmedia/!ut/p/z1/tZZde5owFIB_yy68THMSPoy7Q-sArSJd1cpNnwSCsik4wDr36xfb7unHVLpZuMlDcs57PnJyEhzgWxyk_D6Z8zLJUr5U_7PAvOu3dMthHRjZHjXAH-h03Jz4mu1QPMEBDtZhEuEZ0QSBODaQSXmEdAohYpERIlMaLcFEKwZu7KXDtFyXCzyTKdoUDVhkK9mAMFutebprQCq3xUpGCcfTR9sWWMQCOoTu0ALTtAi9afeJx3QcvHSNeW5XuebZff3qEsDU_-gfF9jruy1Cod8Hjw1sQ02Oej5zh9S34Un_hEBwOjVv7NsjqwO-ObZHzO1o-sR8nz68-ixoX9O2BqDE_0f_Jelf_f9LIDiNn-43uyIDBxivQ6wyElRVwUxF0byjtN9xWqqK7KF2CaZPOmw8HoNuNfH0PpFbPE6zfKUK_utzPUcaFyw0CeIUDKQTQyLebAoUE6K3gDFQBY0dqLDg62daqMCb9eKNM_G9x_05fohVh0m-_fgRWKoxZGkpf5b49nBnEMts3oAomSclXyKZc1RswlAWxVMMx04qheMxgNmKRDMGpDe1UMUQ6kiERCBDSBYxnQphiCo8rRdP6sVrteLdenPv1pt7t97cu-fmvld1hVUeriSNNkWZJ1LNFGsZJnxZ7nJZ8uTh7qf5oDOYK594uUBJGmf49q3UmxA9x9s34O540nWGFOwT3e9d74UKvFkv3vhYvH3p7PGTtjsiNtiEfCye3Qy_gN-dkEnbdlUDrhmv1Yr34Ex8r-p98_6b5_lNevhMPK8ro_NlJh5fzlYqNKYkcxnLXOYXm1xNL8pyXXxuQAO22-3FPMvmS3mhLDXgkMoiK5RXryXxerVi2i55-ND3a-dXe4jsjmDbm3ilhp22n5j17g8PV3J6ejEQu-2n35fBSKA!/)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/d3625726-0052-4fc5-adac-032e89177535/ARtopAI_Leaders_2026.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-d3625726-0052-4fc5-adac-032e89177535-pM62hM7)](https://commerce.toshiba.com/wps/portal/marketing/newsmedia/!ut/p/z1/tZZde5owFIB_yy68THMSPoy7Q-sArSJd1cpNnwSCsik4wDr36xfb7unHVLpZuMlDcs57PnJyEhzgWxyk_D6Z8zLJUr5U_7PAvOu3dMthHRjZHjXAH-h03Jz4mu1QPMEBDtZhEuEZ0QSBODaQSXmEdAohYpERIlMaLcFEKwZu7KXDtFyXCzyTKdoUDVhkK9mAMFutebprQCq3xUpGCcfTR9sWWMQCOoTu0ALTtAi9afeJx3QcvHSNeW5XuebZff3qEsDU_-gfF9jruy1Cod8Hjw1sQ02Oej5zh9S34Un_hEBwOjVv7NsjqwO-ObZHzO1o-sR8nz68-ixoX9O2BqDE_0f_Jelf_f9LIDiNn-43uyIDBxivQ6wyElRVwUxF0byjtN9xWqqK7KF2CaZPOmw8HoNuNfH0PpFbPE6zfKUK_utzPUcaFyw0CeIUDKQTQyLebAoUE6K3gDFQBY0dqLDg62daqMCb9eKNM_G9x_05fohVh0m-_fgRWKoxZGkpf5b49nBnEMts3oAomSclXyKZc1RswlAWxVMMx04qheMxgNmKRDMGpDe1UMUQ6kiERCBDSBYxnQphiCo8rRdP6sVrteLdenPv1pt7t97cu-fmvld1hVUeriSNNkWZJ1LNFGsZJnxZ7nJZ8uTh7qf5oDOYK594uUBJGmf49q3UmxA9x9s34O540nWGFOwT3e9d74UKvFkv3vhYvH3p7PGTtjsiNtiEfCye3Qy_gN-dkEnbdlUDrhmv1Yr34Ex8r-p98_6b5_lNevhMPK8ro_NlJh5fzlYqNKYkcxnLXOYXm1xNL8pyXXxuQAO22-3FPMvmS3mhLDXgkMoiK5RXryXxerVi2i55-ND3a-dXe4jsjmDbm3ilhp22n5j17g8PV3J6ejEQu-2n35fBSKA!/)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/e1da48ef-dab8-4f9d-9544-5d043d0cf6ab/RISsoftwareLeaderboard24winner.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-e1da48ef-dab8-4f9d-9544-5d043d0cf6ab-pM62Ch1)](https://commerce.toshiba.com/wps/portal/marketing/newsmedia/!ut/p/z1/tZZde5owFIB_yy68THMSPoy7Q-sArSJd1cpNnwSCsik4wDr36xfb7unHVLpZuMlDcs57PnJyEhzgWxyk_D6Z8zLJUr5U_7PAvOu3dMthHRjZHjXAH-h03Jz4mu1QPMEBDtZhEuEZ0QSBODaQSXmEdAohYpERIlMaLcFEKwZu7KXDtFyXCzyTKdoUDVhkK9mAMFutebprQCq3xUpGCcfTR9sWWMQCOoTu0ALTtAi9afeJx3QcvHSNeW5XuebZff3qEsDU_-gfF9jruy1Cod8Hjw1sQ02Oej5zh9S34Un_hEBwOjVv7NsjqwO-ObZHzO1o-sR8nz68-ixoX9O2BqDE_0f_Jelf_f9LIDiNn-43uyIDBxivQ6wyElRVwUxF0byjtN9xWqqK7KF2CaZPOmw8HoNuNfH0PpFbPE6zfKUK_utzPUcaFyw0CeIUDKQTQyLebAoUE6K3gDFQBY0dqLDg62daqMCb9eKNM_G9x_05fohVh0m-_fgRWKoxZGkpf5b49nBnEMts3oAomSclXyKZc1RswlAWxVMMx04qheMxgNmKRDMGpDe1UMUQ6kiERCBDSBYxnQphiCo8rRdP6sVrteLdenPv1pt7t97cu-fmvld1hVUeriSNNkWZJ1LNFGsZJnxZ7nJZ8uTh7qf5oDOYK594uUBJGmf49q3UmxA9x9s34O540nWGFOwT3e9d74UKvFkv3vhYvH3p7PGTtjsiNtiEfCye3Qy_gN-dkEnbdlUDrhmv1Yr34Ex8r-p98_6b5_lNevhMPK8ro_NlJh5fzlYqNKYkcxnLXOYXm1xNL8pyXXxuQAO22-3FPMvmS3mhLDXgkMoiK5RXryXxerVi2i55-ND3a-dXe4jsjmDbm3ilhp22n5j17g8PV3J6ejEQu-2n35fBSKA!/)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/bac51c00-19e7-4f99-9080-c8b36b156559/RethinkRetailTopRetailExperts2025.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-bac51c00-19e7-4f99-9080-c8b36b156559-pM62qaW)](https://commerce.toshiba.com/wps/portal/marketing/newsmedia/!ut/p/z1/tZZde5owFIB_yy68THMSPoy7Q-sArSJd1cpNnwSCsik4wDr36xfb7unHVLpZuMlDcs57PnJyEhzgWxyk_D6Z8zLJUr5U_7PAvOu3dMthHRjZHjXAH-h03Jz4mu1QPMEBDtZhEuEZ0QSBODaQSXmEdAohYpERIlMaLcFEKwZu7KXDtFyXCzyTKdoUDVhkK9mAMFutebprQCq3xUpGCcfTR9sWWMQCOoTu0ALTtAi9afeJx3QcvHSNeW5XuebZff3qEsDU_-gfF9jruy1Cod8Hjw1sQ02Oej5zh9S34Un_hEBwOjVv7NsjqwO-ObZHzO1o-sR8nz68-ixoX9O2BqDE_0f_Jelf_f9LIDiNn-43uyIDBxivQ6wyElRVwUxF0byjtN9xWqqK7KF2CaZPOmw8HoNuNfH0PpFbPE6zfKUK_utzPUcaFyw0CeIUDKQTQyLebAoUE6K3gDFQBY0dqLDg62daqMCb9eKNM_G9x_05fohVh0m-_fgRWKoxZGkpf5b49nBnEMts3oAomSclXyKZc1RswlAWxVMMx04qheMxgNmKRDMGpDe1UMUQ6kiERCBDSBYxnQphiCo8rRdP6sVrteLdenPv1pt7t97cu-fmvld1hVUeriSNNkWZJ1LNFGsZJnxZ7nJZ8uTh7qf5oDOYK594uUBJGmf49q3UmxA9x9s34O540nWGFOwT3e9d74UKvFkv3vhYvH3p7PGTtjsiNtiEfCye3Qy_gN-dkEnbdlUDrhmv1Yr34Ex8r-p98_6b5_lNevhMPK8ro_NlJh5fzlYqNKYkcxnLXOYXm1xNL8pyXXxuQAO22-3FPMvmS3mhLDXgkMoiK5RXryXxerVi2i55-ND3a-dXe4jsjmDbm3ilhp22n5j17g8PV3J6ejEQu-2n35fBSKA!/)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/eb1f5365-05ca-413d-b829-9bca3c7c1358/RethinkRetailTopRetailExperts2026.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-eb1f5365-05ca-413d-b829-9bca3c7c1358-pM62wwK)](https://commerce.toshiba.com/wps/portal/marketing/newsmedia/!ut/p/z1/tZZde5owFIB_yy68THMSPoy7Q-sArSJd1cpNnwSCsik4wDr36xfb7unHVLpZuMlDcs57PnJyEhzgWxyk_D6Z8zLJUr5U_7PAvOu3dMthHRjZHjXAH-h03Jz4mu1QPMEBDtZhEuEZ0QSBODaQSXmEdAohYpERIlMaLcFEKwZu7KXDtFyXCzyTKdoUDVhkK9mAMFutebprQCq3xUpGCcfTR9sWWMQCOoTu0ALTtAi9afeJx3QcvHSNeW5XuebZff3qEsDU_-gfF9jruy1Cod8Hjw1sQ02Oej5zh9S34Un_hEBwOjVv7NsjqwO-ObZHzO1o-sR8nz68-ixoX9O2BqDE_0f_Jelf_f9LIDiNn-43uyIDBxivQ6wyElRVwUxF0byjtN9xWqqK7KF2CaZPOmw8HoNuNfH0PpFbPE6zfKUK_utzPUcaFyw0CeIUDKQTQyLebAoUE6K3gDFQBY0dqLDg62daqMCb9eKNM_G9x_05fohVh0m-_fgRWKoxZGkpf5b49nBnEMts3oAomSclXyKZc1RswlAWxVMMx04qheMxgNmKRDMGpDe1UMUQ6kiERCBDSBYxnQphiCo8rRdP6sVrteLdenPv1pt7t97cu-fmvld1hVUeriSNNkWZJ1LNFGsZJnxZ7nJZ8uTh7qf5oDOYK594uUBJGmf49q3UmxA9x9s34O540nWGFOwT3e9d74UKvFkv3vhYvH3p7PGTtjsiNtiEfCye3Qy_gN-dkEnbdlUDrhmv1Yr34Ex8r-p98_6b5_lNevhMPK8ro_NlJh5fzlYqNKYkcxnLXOYXm1xNL8pyXXxuQAO22-3FPMvmS3mhLDXgkMoiK5RXryXxerVi2i55-ND3a-dXe4jsjmDbm3ilhp22n5j17g8PV3J6ejEQu-2n35fBSKA!/)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/79ce6bf7-a775-46a7-bd4f-6bc9da6a7a6e/ToshibaStevieWinner2025.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-79ce6bf7-a775-46a7-bd4f-6bc9da6a7a6e-pM628XP)](https://commerce.toshiba.com/wps/portal/marketing/newsmedia/!ut/p/z1/tZZde5owFIB_yy68THMSPoy7Q-sArSJd1cpNnwSCsik4wDr36xfb7unHVLpZuMlDcs57PnJyEhzgWxyk_D6Z8zLJUr5U_7PAvOu3dMthHRjZHjXAH-h03Jz4mu1QPMEBDtZhEuEZ0QSBODaQSXmEdAohYpERIlMaLcFEKwZu7KXDtFyXCzyTKdoUDVhkK9mAMFutebprQCq3xUpGCcfTR9sWWMQCOoTu0ALTtAi9afeJx3QcvHSNeW5XuebZff3qEsDU_-gfF9jruy1Cod8Hjw1sQ02Oej5zh9S34Un_hEBwOjVv7NsjqwO-ObZHzO1o-sR8nz68-ixoX9O2BqDE_0f_Jelf_f9LIDiNn-43uyIDBxivQ6wyElRVwUxF0byjtN9xWqqK7KF2CaZPOmw8HoNuNfH0PpFbPE6zfKUK_utzPUcaFyw0CeIUDKQTQyLebAoUE6K3gDFQBY0dqLDg62daqMCb9eKNM_G9x_05fohVh0m-_fgRWKoxZGkpf5b49nBnEMts3oAomSclXyKZc1RswlAWxVMMx04qheMxgNmKRDMGpDe1UMUQ6kiERCBDSBYxnQphiCo8rRdP6sVrteLdenPv1pt7t97cu-fmvld1hVUeriSNNkWZJ1LNFGsZJnxZ7nJZ8uTh7qf5oDOYK594uUBJGmf49q3UmxA9x9s34O540nWGFOwT3e9d74UKvFkv3vhYvH3p7PGTtjsiNtiEfCye3Qy_gN-dkEnbdlUDrhmv1Yr34Ex8r-p98_6b5_lNevhMPK8ro_NlJh5fzlYqNKYkcxnLXOYXm1xNL8pyXXxuQAO22-3FPMvmS3mhLDXgkMoiK5RXryXxerVi2i55-ND3a-dXe4jsjmDbm3ilhp22n5j17g8PV3J6ejEQu-2n35fBSKA!/)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/6dc6d050-a432-43cf-ab0d-418433b3fd91/ToshibaAutomatedRetailAwards.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-6dc6d050-a432-43cf-ab0d-418433b3fd91-pM62.ox)](https://commerce.toshiba.com/wps/portal/marketing/newsmedia/!ut/p/z1/tZZde5owFIB_yy68THMSPoy7Q-sArSJd1cpNnwSCsik4wDr36xfb7unHVLpZuMlDcs57PnJyEhzgWxyk_D6Z8zLJUr5U_7PAvOu3dMthHRjZHjXAH-h03Jz4mu1QPMEBDtZhEuEZ0QSBODaQSXmEdAohYpERIlMaLcFEKwZu7KXDtFyXCzyTKdoUDVhkK9mAMFutebprQCq3xUpGCcfTR9sWWMQCOoTu0ALTtAi9afeJx3QcvHSNeW5XuebZff3qEsDU_-gfF9jruy1Cod8Hjw1sQ02Oej5zh9S34Un_hEBwOjVv7NsjqwO-ObZHzO1o-sR8nz68-ixoX9O2BqDE_0f_Jelf_f9LIDiNn-43uyIDBxivQ6wyElRVwUxF0byjtN9xWqqK7KF2CaZPOmw8HoNuNfH0PpFbPE6zfKUK_utzPUcaFyw0CeIUDKQTQyLebAoUE6K3gDFQBY0dqLDg62daqMCb9eKNM_G9x_05fohVh0m-_fgRWKoxZGkpf5b49nBnEMts3oAomSclXyKZc1RswlAWxVMMx04qheMxgNmKRDMGpDe1UMUQ6kiERCBDSBYxnQphiCo8rRdP6sVrteLdenPv1pt7t97cu-fmvld1hVUeriSNNkWZJ1LNFGsZJnxZ7nJZ8uTh7qf5oDOYK594uUBJGmf49q3UmxA9x9s34O540nWGFOwT3e9d74UKvFkv3vhYvH3p7PGTtjsiNtiEfCye3Qy_gN-dkEnbdlUDrhmv1Yr34Ex8r-p98_6b5_lNevhMPK8ro_NlJh5fzlYqNKYkcxnLXOYXm1xNL8pyXXxuQAO22-3FPMvmS3mhLDXgkMoiK5RXryXxerVi2i55-ND3a-dXe4jsjmDbm3ilhp22n5j17g8PV3J6ejEQu-2n35fBSKA!/)

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/4b7055a7-7453-488c-9266-4a14f32876d1/VIPbestMultiVendorCommercePlatform2026toshiba.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-4b7055a7-7453-488c-9266-4a14f32876d1-pM62Knc)](https://commerce.toshiba.com/wps/portal/marketing/newsmedia/!ut/p/z1/tZZde5owFIB_yy68THMSPoy7Q-sArSJd1cpNnwSCsik4wDr36xfb7unHVLpZuMlDcs57PnJyEhzgWxyk_D6Z8zLJUr5U_7PAvOu3dMthHRjZHjXAH-h03Jz4mu1QPMEBDtZhEuEZ0QSBODaQSXmEdAohYpERIlMaLcFEKwZu7KXDtFyXCzyTKdoUDVhkK9mAMFutebprQCq3xUpGCcfTR9sWWMQCOoTu0ALTtAi9afeJx3QcvHSNeW5XuebZff3qEsDU_-gfF9jruy1Cod8Hjw1sQ02Oej5zh9S34Un_hEBwOjVv7NsjqwO-ObZHzO1o-sR8nz68-ixoX9O2BqDE_0f_Jelf_f9LIDiNn-43uyIDBxivQ6wyElRVwUxF0byjtN9xWqqK7KF2CaZPOmw8HoNuNfH0PpFbPE6zfKUK_utzPUcaFyw0CeIUDKQTQyLebAoUE6K3gDFQBY0dqLDg62daqMCb9eKNM_G9x_05fohVh0m-_fgRWKoxZGkpf5b49nBnEMts3oAomSclXyKZc1RswlAWxVMMx04qheMxgNmKRDMGpDe1UMUQ6kiERCBDSBYxnQphiCo8rRdP6sVrteLdenPv1pt7t97cu-fmvld1hVUeriSNNkWZJ1LNFGsZJnxZ7nJZ8uTh7qf5oDOYK594uUBJGmf49q3UmxA9x9s34O540nWGFOwT3e9d74UKvFkv3vhYvH3p7PGTtjsiNtiEfCye3Qy_gN-dkEnbdlUDrhmv1Yr34Ex8r-p98_6b5_lNevhMPK8ro_NlJh5fzlYqNKYkcxnLXOYXm1xNL8pyXXxuQAO22-3FPMvmS3mhLDXgkMoiK5RXryXxerVi2i55-ND3a-dXe4jsjmDbm3ilhp22n5j17g8PV3J6ejEQu-2n35fBSKA!/)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

## Media Contact

Amy Gray

PR Program Manager

[amy.gray@toshibagcs.com](mailto:amy.gray@toshibagcs.com)

Elizabeth Romero

Executive Director, Corporate Marketing & Communications

[elizabeth.romero@toshibagcs.com](mailto:elizabeth.romero@toshibagcs.com)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

Start a conversation

First name

Last name

Email

Company

Country

Phone

I am a

Business PartnerOtherPress / AnalystRetailerSupplierToshiba Employee

- Business Partner

- Other

- Press / Analyst

- Retailer

- Supplier

- Toshiba Employee


My Retail Segment

Fashion & ApparelFood ServiceGas & ConvenienceGroceryMass MerchandiseOtherPharmacy / Drug StoreSpecialty

- Fashion & Apparel

- Food Service

- Gas & Convenience

- Grocery

- Mass Merchandise

- Other

- Pharmacy / Drug Store

- Specialty


I am interested in learning more about

Add me to Toshiba Global Commerce Solutions' email marketing list

I am allowing Toshiba to contact me in regards to the information on this form

Comments

By submitting this form I agree that Toshiba Global Commerce Solutions, Inc. and its affiliates, including all subsidiaries and branches, may process my data as indicated above and as described in the [Toshiba Global Commerce Solutions Privacy Declaration.](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/common-content/general-content/privacy-policy&mapping=tgcs_new.portal.generaldetails)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**

reCAPTCHA is changing its terms of service. [Take action.](https://google.com/recaptcha/admin/migrate)

![success](https://commerce.toshiba.com/wps/portal/marketing/newsmedia/!ut/p/z1/tZZde5owFIB_yy68THMSPoy7Q-sArSJd1cpNnwSCsik4wDr36xfb7unHVLpZuMlDcs57PnJyEhzgWxyk_D6Z8zLJUr5U_7PAvOu3dMthHRjZHjXAH-h03Jz4mu1QPMEBDtZhEuEZ0QSBODaQSXmEdAohYpERIlMaLcFEKwZu7KXDtFyXCzyTKdoUDVhkK9mAMFutebprQCq3xUpGCcfTR9sWWMQCOoTu0ALTtAi9afeJx3QcvHSNeW5XuebZff3qEsDU_-gfF9jruy1Cod8Hjw1sQ02Oej5zh9S34Un_hEBwOjVv7NsjqwO-ObZHzO1o-sR8nz68-ixoX9O2BqDE_0f_Jelf_f9LIDiNn-43uyIDBxivQ6wyElRVwUxF0byjtN9xWqqK7KF2CaZPOmw8HoNuNfH0PpFbPE6zfKUK_utzPUcaFyw0CeIUDKQTQyLebAoUE6K3gDFQBY0dqLDg62daqMCb9eKNM_G9x_05fohVh0m-_fgRWKoxZGkpf5b49nBnEMts3oAomSclXyKZc1RswlAWxVMMx04qheMxgNmKRDMGpDe1UMUQ6kiERCBDSBYxnQphiCo8rRdP6sVrteLdenPv1pt7t97cu-fmvld1hVUeriSNNkWZJ1LNFGsZJnxZ7nJZ8uTh7qf5oDOYK594uUBJGmf49q3UmxA9x9s34O540nWGFOwT3e9d74UKvFkv3vhYvH3p7PGTtjsiNtiEfCye3Qy_gN-dkEnbdlUDrhmv1Yr34Ex8r-p98_6b5_lNevhMPK8ro_NlJh5fzlYqNKYkcxnLXOYXm1xNL8pyXXxuQAO22-3FPMvmS3mhLDXgkMoiK5RXryXxerVi2i55-ND3a-dXe4jsjmDbm3ilhp22n5j17g8PV3J6ejEQu-2n35fBSKA!/images/tgcs/success.svg)

## Success!

Thank you for reaching out. One of our team members will be in contact soon. We hope you have a great day.

Close

Complementary
Content

[Deferred Modules](https://commerce.toshiba.com/wps/contenthandler/marketing/!ut/p/digest!M6zrA0PEiotCbddBEGnoVg/mashup/ra:collection?themeID=ZJ_K94AH8C0P87S30Q6935LL30881&locale=en&mime-type=text%2Fjavascript&lm=1778876784000&entry=st_skin__0.0%3Aconfig_js&entry=wp_liveobject_framework_core__0.0%3Aconfig_js&entry=wp_portal_ui_utils__0.0%3Aconfig_js&entry=wp_contextmenu_js__0.0%3Aconfig_js&entry=wp_skin_cam__0.0%3Aconfig_js&entry=wp_contextmenu_config_lof__0.0%3Aconfig_js&entry=wp_federated_documents_picker__0.0%3Aconfig_js&entry=wp_dnd_main__0.0%3Aconfig_js&entry=wp_movecontrols__0.0%3Aconfig_js&entry=wp_toolbar_controlactions__0.0%3Aconfig_js&entry=wp_content_targeting_cam__0.0%3Aconfig_js&deferred=true)

- ${title}${badge}

${loading}

[Deferred Modules](https://commerce.toshiba.com/wps/contenthandler/marketing/!ut/p/digest!SpZvrtUURDcRHYzcbiqg-Q/mashup/ra:collection?themeID=ZJ_K94AH8C0P87S30Q6935LL30881&locale=en&mime-type=text%2Fplain&entry=wp_contextmenu_templates__0.0%3Aconfig_markup&entry=wp_skin_cam__0.0%3Aconfig_markup&entry=wp_dnd_main__0.0%3Aconfig_markup&deferred=true)

reCAPTCHA

Select all squares with **motorcycles** If there are none, click skip

|     |     |     |     |
| --- | --- | --- | --- |
| ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA52uqcWWjQVElWQPGeDyuoL2fKyai7ww18LUruNkz7DkhWyyX4cBSTMAX9hDLWd6iv_ytKTackfzMee4lvHQfKP4zamAQiwhUil9kzLpp8beWQ36DfGbPh0_U9k3dac7KAweNuhSzBabrmkKZ3uCkqsaUQgzIROSM2iM_zJ-oT_VOVFh-EiDbf4lxwVlUUziS-7uCNz&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA52uqcWWjQVElWQPGeDyuoL2fKyai7ww18LUruNkz7DkhWyyX4cBSTMAX9hDLWd6iv_ytKTackfzMee4lvHQfKP4zamAQiwhUil9kzLpp8beWQ36DfGbPh0_U9k3dac7KAweNuhSzBabrmkKZ3uCkqsaUQgzIROSM2iM_zJ-oT_VOVFh-EiDbf4lxwVlUUziS-7uCNz&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA52uqcWWjQVElWQPGeDyuoL2fKyai7ww18LUruNkz7DkhWyyX4cBSTMAX9hDLWd6iv_ytKTackfzMee4lvHQfKP4zamAQiwhUil9kzLpp8beWQ36DfGbPh0_U9k3dac7KAweNuhSzBabrmkKZ3uCkqsaUQgzIROSM2iM_zJ-oT_VOVFh-EiDbf4lxwVlUUziS-7uCNz&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA52uqcWWjQVElWQPGeDyuoL2fKyai7ww18LUruNkz7DkhWyyX4cBSTMAX9hDLWd6iv_ytKTackfzMee4lvHQfKP4zamAQiwhUil9kzLpp8beWQ36DfGbPh0_U9k3dac7KAweNuhSzBabrmkKZ3uCkqsaUQgzIROSM2iM_zJ-oT_VOVFh-EiDbf4lxwVlUUziS-7uCNz&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) |
| ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA52uqcWWjQVElWQPGeDyuoL2fKyai7ww18LUruNkz7DkhWyyX4cBSTMAX9hDLWd6iv_ytKTackfzMee4lvHQfKP4zamAQiwhUil9kzLpp8beWQ36DfGbPh0_U9k3dac7KAweNuhSzBabrmkKZ3uCkqsaUQgzIROSM2iM_zJ-oT_VOVFh-EiDbf4lxwVlUUziS-7uCNz&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA52uqcWWjQVElWQPGeDyuoL2fKyai7ww18LUruNkz7DkhWyyX4cBSTMAX9hDLWd6iv_ytKTackfzMee4lvHQfKP4zamAQiwhUil9kzLpp8beWQ36DfGbPh0_U9k3dac7KAweNuhSzBabrmkKZ3uCkqsaUQgzIROSM2iM_zJ-oT_VOVFh-EiDbf4lxwVlUUziS-7uCNz&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA52uqcWWjQVElWQPGeDyuoL2fKyai7ww18LUruNkz7DkhWyyX4cBSTMAX9hDLWd6iv_ytKTackfzMee4lvHQfKP4zamAQiwhUil9kzLpp8beWQ36DfGbPh0_U9k3dac7KAweNuhSzBabrmkKZ3uCkqsaUQgzIROSM2iM_zJ-oT_VOVFh-EiDbf4lxwVlUUziS-7uCNz&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA52uqcWWjQVElWQPGeDyuoL2fKyai7ww18LUruNkz7DkhWyyX4cBSTMAX9hDLWd6iv_ytKTackfzMee4lvHQfKP4zamAQiwhUil9kzLpp8beWQ36DfGbPh0_U9k3dac7KAweNuhSzBabrmkKZ3uCkqsaUQgzIROSM2iM_zJ-oT_VOVFh-EiDbf4lxwVlUUziS-7uCNz&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) |
| ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA52uqcWWjQVElWQPGeDyuoL2fKyai7ww18LUruNkz7DkhWyyX4cBSTMAX9hDLWd6iv_ytKTackfzMee4lvHQfKP4zamAQiwhUil9kzLpp8beWQ36DfGbPh0_U9k3dac7KAweNuhSzBabrmkKZ3uCkqsaUQgzIROSM2iM_zJ-oT_VOVFh-EiDbf4lxwVlUUziS-7uCNz&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA52uqcWWjQVElWQPGeDyuoL2fKyai7ww18LUruNkz7DkhWyyX4cBSTMAX9hDLWd6iv_ytKTackfzMee4lvHQfKP4zamAQiwhUil9kzLpp8beWQ36DfGbPh0_U9k3dac7KAweNuhSzBabrmkKZ3uCkqsaUQgzIROSM2iM_zJ-oT_VOVFh-EiDbf4lxwVlUUziS-7uCNz&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA52uqcWWjQVElWQPGeDyuoL2fKyai7ww18LUruNkz7DkhWyyX4cBSTMAX9hDLWd6iv_ytKTackfzMee4lvHQfKP4zamAQiwhUil9kzLpp8beWQ36DfGbPh0_U9k3dac7KAweNuhSzBabrmkKZ3uCkqsaUQgzIROSM2iM_zJ-oT_VOVFh-EiDbf4lxwVlUUziS-7uCNz&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA52uqcWWjQVElWQPGeDyuoL2fKyai7ww18LUruNkz7DkhWyyX4cBSTMAX9hDLWd6iv_ytKTackfzMee4lvHQfKP4zamAQiwhUil9kzLpp8beWQ36DfGbPh0_U9k3dac7KAweNuhSzBabrmkKZ3uCkqsaUQgzIROSM2iM_zJ-oT_VOVFh-EiDbf4lxwVlUUziS-7uCNz&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) |
| ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA52uqcWWjQVElWQPGeDyuoL2fKyai7ww18LUruNkz7DkhWyyX4cBSTMAX9hDLWd6iv_ytKTackfzMee4lvHQfKP4zamAQiwhUil9kzLpp8beWQ36DfGbPh0_U9k3dac7KAweNuhSzBabrmkKZ3uCkqsaUQgzIROSM2iM_zJ-oT_VOVFh-EiDbf4lxwVlUUziS-7uCNz&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA52uqcWWjQVElWQPGeDyuoL2fKyai7ww18LUruNkz7DkhWyyX4cBSTMAX9hDLWd6iv_ytKTackfzMee4lvHQfKP4zamAQiwhUil9kzLpp8beWQ36DfGbPh0_U9k3dac7KAweNuhSzBabrmkKZ3uCkqsaUQgzIROSM2iM_zJ-oT_VOVFh-EiDbf4lxwVlUUziS-7uCNz&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA52uqcWWjQVElWQPGeDyuoL2fKyai7ww18LUruNkz7DkhWyyX4cBSTMAX9hDLWd6iv_ytKTackfzMee4lvHQfKP4zamAQiwhUil9kzLpp8beWQ36DfGbPh0_U9k3dac7KAweNuhSzBabrmkKZ3uCkqsaUQgzIROSM2iM_zJ-oT_VOVFh-EiDbf4lxwVlUUziS-7uCNz&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA52uqcWWjQVElWQPGeDyuoL2fKyai7ww18LUruNkz7DkhWyyX4cBSTMAX9hDLWd6iv_ytKTackfzMee4lvHQfKP4zamAQiwhUil9kzLpp8beWQ36DfGbPh0_U9k3dac7KAweNuhSzBabrmkKZ3uCkqsaUQgzIROSM2iM_zJ-oT_VOVFh-EiDbf4lxwVlUUziS-7uCNz&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) |

Please try again.

Please select all matching images.

Please also check the new images.

Please select around the object, or reload if there are none.

Skip