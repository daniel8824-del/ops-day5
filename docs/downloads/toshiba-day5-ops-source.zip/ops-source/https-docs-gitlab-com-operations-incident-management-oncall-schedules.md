<!-- source: https://docs.gitlab.com/operations/incident_management/oncall_schedules -->

/

* * *

# On-call Schedule Management

- Tier: Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

Use on-call schedule management to create schedules for responders to rotate on-call
responsibilities. Maintain the availability of your software services by putting your teams on-call.
With [escalation policies](https://docs.gitlab.com/operations/incident_management/escalation_policies/) and on-call schedules, your team is notified immediately
when things go wrong so they can quickly respond to service outages and disruptions.

To use on-call schedules:

1. [Create a schedule](https://docs.gitlab.com/operations/incident_management/oncall_schedules/#schedules).
2. [Add a rotation to the schedule](https://docs.gitlab.com/operations/incident_management/oncall_schedules/#rotations).

## Schedules [Permalink](https://docs.gitlab.com/operations/incident_management/oncall_schedules/\#schedules "Permalink")

Set up an on-call schedule for your team to add rotations to.

Prerequisites:

- You must have the Maintainer or Owner role.

To create an on-call schedule:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Monitor** \> **On-call Schedules**.
3. Select **Add a schedule**.
4. Enter the schedule’s name and description and select a time zone.
5. Select **Add schedule**.

You now have an empty schedule with no rotations. This renders as an empty state, prompting you to
create [rotations](https://docs.gitlab.com/operations/incident_management/oncall_schedules/#rotations) for your schedule.

![Schedule Empty Grid](https://docs.gitlab.com/operations/incident_management/img/oncall_schedule_empty_grid_v13_10.png)

### Edit a schedule [Permalink](https://docs.gitlab.com/operations/incident_management/oncall_schedules/\#edit-a-schedule "Permalink")

To update a schedule:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Monitor** \> **On-call Schedules**.
3. Select **Edit schedule** (pencil).
4. Edit the information.
5. Select **Save changes**.

If you change the schedule’s time zone, GitLab automatically updates the rotation’s restricted time
interval (if one is set) to the corresponding times in the new time zone.

### Delete a schedule [Permalink](https://docs.gitlab.com/operations/incident_management/oncall_schedules/\#delete-a-schedule "Permalink")

To delete a schedule:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Monitor** \> **On-call Schedules**.
3. Select **Delete escalation policy** (remove).
4. On the confirmation dialog, select **Delete schedule**.

## Rotations [Permalink](https://docs.gitlab.com/operations/incident_management/oncall_schedules/\#rotations "Permalink")

Add rotations to an existing schedule to put your team members on-call.

To create a rotation:

1. In the top bar, select **Search or go to** and find your project.

2. In the left sidebar, select **Monitor** \> **On-call Schedules**.

3. Select the **Add a rotation** link.

4. Enter the following information:

   - **Name**: Your rotation’s name.
   - **Participants**: The people you want in the rotation.
   - **Rotation length**: The rotation’s duration.
   - **Starts on**: The date and time the rotation begins.
   - **Enable end date**: With the toggle on, you can select the date and time your rotation
     ends.
   - **Restrict to time intervals**: With the toggle on, you can restrict your rotation to the
     time period you select.

### Edit a rotation [Permalink](https://docs.gitlab.com/operations/incident_management/oncall_schedules/\#edit-a-rotation "Permalink")

To edit a rotation:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Monitor** \> **On-call Schedules**.
3. In the **Rotations** section, select **Edit rotation** (pencil).
4. Edit the information.
5. Select **Save changes**.

### Delete a rotation [Permalink](https://docs.gitlab.com/operations/incident_management/oncall_schedules/\#delete-a-rotation "Permalink")

To delete a rotation:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Monitor** \> **On-call Schedules**.
3. In the **Rotations** section, select **Delete rotation** (remove).
4. On the confirmation dialog, select **Delete rotation**.

## View schedule rotations [Permalink](https://docs.gitlab.com/operations/incident_management/oncall_schedules/\#view-schedule-rotations "Permalink")

You can view the on-call schedules of a single day or two weeks. To switch between these time
periods, select the **1 day** or **2 weeks** buttons on the schedule. Two weeks is the default view.

Hover over any rotation shift participants in the schedule to view their individual shift details.

![1 Day Grid View](https://docs.gitlab.com/operations/incident_management/img/oncall_schedule_day_grid_v13_10.png)

## Page an on-call responder [Permalink](https://docs.gitlab.com/operations/incident_management/oncall_schedules/\#page-an-on-call-responder "Permalink")

See [Paging](https://docs.gitlab.com/operations/incident_management/paging/#paging) for more details.

## Removal or deletion of on-call user [Permalink](https://docs.gitlab.com/operations/incident_management/oncall_schedules/\#removal-or-deletion-of-on-call-user "Permalink")

If an on-call user is removed from the project or group, or their account is deleted, the
confirmation dialog displays the list of that user’s on-call schedules. If the user’s removal or
deletion is confirmed, GitLab recalculates the on-call rotation and sends an email to the project
owners and the rotation’s participants.

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**