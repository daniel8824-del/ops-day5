<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-attachment -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Last updated Oct 3, 2024

On This Page

- [acli jira workitem attachment](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-attachment/#acli-jira-workitem-attachment)


## acli jira workitem attachment

Work item attachments commands.

### Options

```
Copy
1
  -h, --help   Show help for command
```

### SEE ALSO

- [acli jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem) \- Jira work item commands.
- [acli jira workitem attachment delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-attachment-delete) \- Delete an attachment from a workitem.
- [acli jira workitem attachment list](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-attachment-list) \- List all the attachments of a workitem.

Rate this page:

Unusable

Poor

Okay

Good

Excellent