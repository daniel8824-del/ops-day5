<!-- source: https://docs.gitlab.com/user/project/merge_requests/approvals -->

/

* * *

# Merge request approvals

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

To set up a review process for changes in your project, configure merge request approvals.
They help to ensure that changes are reviewed before they’re merged into your project.
You can configure approvals to be optional or required, depending on your project’s needs and GitLab tier.

- [GitLab Free](https://about.gitlab.com/pricing/) allows
all users with at least the Developer [role](https://docs.gitlab.com/user/permissions/) to
approve merge requests. These approvals are optional and don’t prevent merging without approval.

- [GitLab Premium](https://about.gitlab.com/pricing/) and
[GitLab Ultimate](https://about.gitlab.com/pricing/) provide you with more
flexibility to:

  - Create required [rules](https://docs.gitlab.com/user/project/merge_requests/approvals/rules/) about the number and type of required approvals.

  - Create a list of [code owners](https://docs.gitlab.com/user/project/codeowners/) for specific files.

  - Configure approvals
    [for the entire instance](https://docs.gitlab.com/administration/merge_requests_approvals/).

  - Configure [group merge request approval settings](https://docs.gitlab.com/user/group/manage/#group-merge-request-approval-settings).









    Support for group merge request approval settings is tracked in
    [epic 4367](https://gitlab.com/groups/gitlab-org/-/epics/4367).

## Configure approval rules [Permalink](https://docs.gitlab.com/user/project/merge_requests/approvals/\#configure-approval-rules "Permalink")

Prerequisites:

- You must have the Developer, Maintainer, or Owner role for the project.

To configure approval rules:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Settings** \> **Merge requests**.
3. Go to the **Merge request approvals** section.
4. Set up your desired rules.

You can also configure:

- More [merge request approval settings](https://docs.gitlab.com/user/project/merge_requests/approvals/settings/) for more control of the
level of oversight and security your project needs.
- Merge request approval rules with the
[Merge request approvals API](https://docs.gitlab.com/api/merge_request_approvals/).

For more information on configuring rules, see [approval rules](https://docs.gitlab.com/user/project/merge_requests/approvals/rules/).

### Required approvals [Permalink](https://docs.gitlab.com/user/project/merge_requests/approvals/\#required-approvals "Permalink")

- Tier: Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

Required approvals enforce code reviews by specified users. Without these approvals, merging is not possible.

Use cases include:

- Enforce review of all code that gets merged into a repository.
- Specify reviewers and a minimum number of approvals.
- Specify categories of reviewers, such as backend, frontend, quality assurance, database, or documentation.
- Use the [`CODEOWNERS` file](https://docs.gitlab.com/user/project/codeowners/#codeowners-file) to determine reviewers.
- Require approval for [declining test coverage](https://docs.gitlab.com/ci/testing/code_coverage/#add-a-coverage-check-approval-rule).
- GitLab Ultimate: [Require security team approval](https://docs.gitlab.com/user/application_security/policies/merge_request_approval_policies/) for potential vulnerabilities.

## View approval status [Permalink](https://docs.gitlab.com/user/project/merge_requests/approvals/\#view-approval-status "Permalink")

History

- More granular approver display [generally available](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/183058) in GitLab 17.10. Feature flag `mr_approvers_filter_hidden_users` removed.

To view the approval status of a merge request, check the merge request itself, or the list of
merge requests for your project or group.

### For a single merge request [Permalink](https://docs.gitlab.com/user/project/merge_requests/approvals/\#for-a-single-merge-request "Permalink")

[Eligible approvers](https://docs.gitlab.com/user/project/merge_requests/approvals/rules/#eligible-approvers) can view the approval status on a single merge request.

To view the approval status:

1. In the top bar, select **Search or go to** and find your project.

2. In the left sidebar, select **Code** \> **Merge requests** and find your merge request.

3. To view the merge request, select its title.

4. Go to the merge request widget to see the approval status. In this example, you can approve the merge request:

![The approval status section where a reviewer can approve the merge request.](https://docs.gitlab.com/user/project/merge_requests/approvals/img/approval_and_merge_status_v17_3.png)


The widget displays one of these statuses:

- **Approve**: The merge request needs more approvals.
- **Approve additionally**: The merge request has the required approvals.
- **Revoke approval**: You have already approved the merge request.

To check if your approval satisfies Code Owner requirements, select **Expand eligible approvers** (chevron-lg-down).

Approver visibility depends on your project membership, and group privacy:

- Project members see all approvers.
- Project non-members see:
  - All approvers, if the approvers are all from public groups.
  - No information about approvers, if any of the approvers are from private groups.

### In the list of merge requests [Permalink](https://docs.gitlab.com/user/project/merge_requests/approvals/\#in-the-list-of-merge-requests "Permalink")

The list of merge requests for [your project or group](https://docs.gitlab.com/user/project/merge_requests/#view-merge-requests)
shows the approval status for each merge request:

| Example | Description |
| --- | --- |
| ![The indicator for missing approvals.](https://docs.gitlab.com/user/project/merge_requests/approvals/img/approvals_unsatisfied_v17_1.png) | Required approvals are missing. (approval) |
| ![The indicator for satisfied approvals.](https://docs.gitlab.com/user/project/merge_requests/approvals/img/approvals_satisfied_v17_1.png) | Approvals are satisfied. (check) |
| ![The indicator showing you have personally approved.](https://docs.gitlab.com/user/project/merge_requests/approvals/img/you_approvals_satisfied_v17_1.png) | Approvals are satisfied, and you are one of the approvers. (approval-solid) |

### Individual reviewer status [Permalink](https://docs.gitlab.com/user/project/merge_requests/approvals/\#individual-reviewer-status "Permalink")

To see the review and approval status for each reviewer:

1. Open the merge request.
2. Check the right sidebar.

Each reviewer’s status is shown next to their name.

- dash-circleAwaiting review

- status\_runningReview in progress

- check-circleApproved

- comment-linesReviewer commented

- status\_warningReviewer requested changes

![The warning status indicating a reviewer has requested changes.](https://docs.gitlab.com/user/project/merge_requests/approvals/img/reviewer_blocks_mr_v17_3.png)


To [re-request a review](https://docs.gitlab.com/user/project/merge_requests/reviews/#re-request-a-review), select the **Re-request a review** icon (redo) next to the user.

## Approve a merge request [Permalink](https://docs.gitlab.com/user/project/merge_requests/approvals/\#approve-a-merge-request "Permalink")

Eligible approvers can approve merge requests in two ways:

- In the merge request widget, select **Approve**.
- Use the [`/approve` quick action](https://docs.gitlab.com/user/project/quick_actions/#approve) in a comment.

Approved merge requests display a green check mark (check-circle-filled) next to the user’s name in the reviewer list.
After a merge request receives the required approvals, it is ready to merge, unless it’s blocked due to:

- [Merge conflicts](https://docs.gitlab.com/user/project/merge_requests/conflicts/)
- [Open threads](https://docs.gitlab.com/user/project/merge_requests/#prevent-merge-unless-all-threads-are-resolved)
- [Failed CI/CD pipeline](https://docs.gitlab.com/user/project/merge_requests/auto_merge/)

### Prevent merge request creator approval [Permalink](https://docs.gitlab.com/user/project/merge_requests/approvals/\#prevent-merge-request-creator-approval "Permalink")

To prevent merge request creators from approving their own work, enable the [**Prevent approval by merge request creator**](https://docs.gitlab.com/user/project/merge_requests/approvals/settings/#prevent-approval-by-merge-request-creator) setting.

### Approval rule changes [Permalink](https://docs.gitlab.com/user/project/merge_requests/approvals/\#approval-rule-changes "Permalink")

If you enable [approval rule overrides](https://docs.gitlab.com/user/project/merge_requests/approvals/settings/#prevent-editing-approval-rules-in-merge-requests), changes to default approval rules
don’t affect existing merge requests, except for [target branch](https://docs.gitlab.com/user/project/merge_requests/approvals/rules/#approvals-for-protected-branches) changes.

## Invalid rules [Permalink](https://docs.gitlab.com/user/project/merge_requests/approvals/\#invalid-rules "Permalink")

History

- [Generally available](https://gitlab.com/gitlab-org/gitlab/-/issues/405023) in GitLab 16.2. Feature flag `invalid_scan_result_policy_prevents_merge` removed.

GitLab marks approval rules as **Auto approved** when they’re impossible to satisfy, such as when:

- The only eligible approver is the merge request author.
- No eligible approvers are assigned to the rule.
- The required approvals exceed the number of eligible approvers.

These rules are automatically approved to unblock merge requests, unless you created rules through a
[merge request approval policy](https://docs.gitlab.com/user/application_security/policies/merge_request_approval_policies/).

Invalid policy-created rules:

- Display as **Action required**.
- Are not automatically approved.
- Block affected merge requests.

## Related topics [Permalink](https://docs.gitlab.com/user/project/merge_requests/approvals/\#related-topics "Permalink")

- [Merge request approvals API](https://docs.gitlab.com/api/merge_request_approvals/)
- [Instance approval rules](https://docs.gitlab.com/administration/merge_requests_approvals/) for GitLab Self-Managed instances
- [Enable approval permissions for users with the Planner or Reporter role](https://docs.gitlab.com/user/project/merge_requests/approvals/rules/#enable-approval-permissions-for-additional-users)
- [Edit or override merge request approval rules](https://docs.gitlab.com/user/project/merge_requests/approvals/rules/#edit-or-override-merge-request-approval-rules)

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**

| Example | Description |
| --- | --- |