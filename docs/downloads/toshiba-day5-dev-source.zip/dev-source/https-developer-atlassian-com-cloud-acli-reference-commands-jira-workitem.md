<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Filter by keyword

- [acli](https://developer.atlassian.com/cloud/acli/reference/commands/)
- [admin](https://developer.atlassian.com/cloud/acli/reference/commands/admin/)

[admin auth](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth/)

[admin user](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user/)

- [feedback](https://developer.atlassian.com/cloud/acli/reference/commands/feedback/)
- [jira](https://developer.atlassian.com/cloud/acli/reference/commands/jira/)

[jira auth](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth/)

[jira board](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board/)

[jira dashboard](https://developer.atlassian.com/cloud/acli/reference/commands/jira-dashboard/)

[jira field](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field/)

[jira filter](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter/)

[jira project](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project/)

[jira sprint](https://developer.atlassian.com/cloud/acli/reference/commands/jira-sprint/)

[jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem/)

- [archive](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-archive/)
- [assign](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-assign/)
- [attachment-delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-attachment-delete/)
- [attachment-list](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-attachment-list/)
- [clone](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-clone/)
- [comment-create](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-create/)
- [comment-delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-delete/)
- [comment-list](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-list/)
- [comment-update](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-update/)
- [comment-visibility](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-visibility/)
- [create](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-create/)
- [create-bulk](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-create-bulk/)
- [delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-delete/)
- [edit](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-edit/)
- [link](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-link/)
- [search](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-search/)
- [transition](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-transition/)
- [unarchive](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-unarchive/)
- [view](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-view/)
- [watcher-remove](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-watcher-remove/)

- [rovodev](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev/)

[rovodev auth](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev-auth/)

Last updated Oct 3, 2024

On This Page

- [acli jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem/#acli-jira-workitem)


## acli jira workitem

Jira work item commands.

### Options

```
Copy
1
  -h, --help   Show help for command
```

### SEE ALSO

- [acli jira](https://developer.atlassian.com/cloud/acli/reference/commands/jira) \- Jira Cloud commands.
- [acli jira workitem archive](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-archive) \- Archives a work item or multiple work items.
- [acli jira workitem assign](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-assign) \- Assign a work item(s) to an assignee(s).
- [acli jira workitem attachment](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-attachment) \- Work item attachments commands.
- [acli jira workitem clone](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-clone) \- Create a duplicate work item(s).
- [acli jira workitem comment](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment) \- Work item comments commands.
- [acli jira workitem create](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-create) \- Create a Jira work item.
- [acli jira workitem create-bulk](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-create-bulk) \- Bulk create Jira issues.
- [acli jira workitem delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-delete) \- Delete a work item or multiple work items.
- [acli jira workitem edit](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-edit) \- Edit a Jira work item or multiple work items.
- [acli jira workitem link](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-link) \- Link work items commands.
- [acli jira workitem search](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-search) \- Searches for work item or multiple work items.
- [acli jira workitem transition](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-transition) \- Transitioning a work item.
- [acli jira workitem unarchive](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-unarchive) \- Unarchives work item or multiple work items.
- [acli jira workitem view](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-view) \- Retrieve information about Jira work items.
- [acli jira workitem watcher](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-watcher) \- Work item watcher commands.

Rate this page:

Unusable

Poor

Okay

Good

Excellent