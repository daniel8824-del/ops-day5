<!-- source: https://docs.gitlab.com/ci/pipeline_editor -->

/

* * *

# Pipeline editor

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

The pipeline editor is the primary place to edit the GitLab CI/CD configuration in
the `.gitlab-ci.yml` file in the root of your repository. To access the editor, go to **Build** \> **Pipeline editor**.

From the pipeline editor page you can:

- Select the branch to work from.
- [Validate](https://docs.gitlab.com/ci/pipeline_editor/#validate-cicd-syntax) your configuration syntax while editing the file.
- Do a deeper [validation of your configuration](https://docs.gitlab.com/ci/pipeline_editor/#validate-cicd-configuration), that verifies it with any configuration
added with the [`include`](https://docs.gitlab.com/ci/yaml/#include) keyword.
- View a [list of the CI/CD configuration added with the `include` keyword](https://docs.gitlab.com/ci/pipeline_editor/#view-included-cicd-configuration).
- See a [visualization](https://docs.gitlab.com/ci/pipeline_editor/#visualize-ci-configuration) of the current configuration.
- View the [full configuration](https://docs.gitlab.com/ci/pipeline_editor/#view-full-configuration), which displays the configuration with any configuration from `include` added.
- [Commit](https://docs.gitlab.com/ci/pipeline_editor/#commit-changes-to-ci-configuration) the changes to a specific branch.

## Validate CI/CD syntax [Permalink](https://docs.gitlab.com/ci/pipeline_editor/\#validate-cicd-syntax "Permalink")

As you use the pipeline editor, the pipeline configuration syntax is continually validated against
the GitLab CI/CD pipeline schema. The syntax of your CI/CD YAML and also some basic logical validations
are checked.

The result of this validation is shown at the top of the editor page. If the validation fails,
this section displays a tip to help you fix the problem.

## Validate CI/CD configuration [Permalink](https://docs.gitlab.com/ci/pipeline_editor/\#validate-cicd-configuration "Permalink")

History

- Option to select different branches [introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/482676) in GitLab 18.4.

To test the validity of your GitLab CI/CD configuration before committing the changes,
use the pipeline editor validation tool. This tool simulates the creation of pipeline
due to a Git push event, and can help troubleshoot logic issues, including incorrect
`rules` and `needs` job dependencies:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Build** \> **Pipeline editor**.
3. Select the **Validate** tab.
4. Optional. Select a different branch to use for the simulated push event by using
the **Pipeline run source** dropdown list.
5. Select **Validate pipeline**.

The simulated pipeline uses the existing pipeline configuration from the **Edit** tab.

To validate a CI/CD YAML snippet without adding it to the **Edit** tab, use the
[CI Lint tool](https://docs.gitlab.com/ci/yaml/lint/#simulate-a-pipeline) instead.

## View included CI/CD configuration [Permalink](https://docs.gitlab.com/ci/pipeline_editor/\#view-included-cicd-configuration "Permalink")

History

- [Introduced](https://gitlab.com/groups/gitlab-org/-/epics/7064) in GitLab 15.0 [with a flag](https://docs.gitlab.com/administration/feature_flags/) named `pipeline_editor_file_tree`. Disabled by default.
- [Feature flag removed](https://gitlab.com/gitlab-org/gitlab/-/issues/357219) in GitLab 15.1.

You can review configuration added with the [`include`](https://docs.gitlab.com/ci/yaml/#include)
keyword in the pipeline editor. In the upper-right corner, select the file tree (file-tree)
to see a list of all included configuration files. Selected files open in a new tab
for review.

## Visualize CI configuration [Permalink](https://docs.gitlab.com/ci/pipeline_editor/\#visualize-ci-configuration "Permalink")

To view a visualization of your `.gitlab-ci.yml` configuration, in your project,
go to **Build** \> **Pipeline editor**, and then select the **Visualize** tab. The
visualization shows all stages and jobs. Any [`needs`](https://docs.gitlab.com/ci/yaml/#needs)
relationships are displayed as lines connecting jobs together, showing the
hierarchy of execution.

Hover over a job to highlight its `needs` relationships:

![CI/CD configuration visualization on hover](https://docs.gitlab.com/ci/pipeline_editor/img/ci_config_visualization_hover_v17_9.png)

If the configuration does not have any `needs` relationships, then no lines are drawn because
each job depends only on the previous stage being completed successfully.

## View full configuration [Permalink](https://docs.gitlab.com/ci/pipeline_editor/\#view-full-configuration "Permalink")

History

- **View merged YAML** tab [renamed to **Full configuration**](https://gitlab.com/gitlab-org/gitlab/-/issues/377404) in GitLab 16.0.

To view the fully expanded CI/CD configuration as one combined file, go to the
pipeline editor’s **Full configuration** tab. This tab displays an expanded configuration
where:

- Configuration imported with [`include`](https://docs.gitlab.com/ci/yaml/#include) is copied into the view.
- Jobs that use [`extends`](https://docs.gitlab.com/ci/yaml/#extends) display with the
[extended configuration merged into the job](https://docs.gitlab.com/ci/yaml/yaml_optimization/#merge-details).
- [YAML anchors](https://docs.gitlab.com/ci/yaml/yaml_optimization/#anchors) are replaced with the linked configuration.
- [YAML `!reference` tags](https://docs.gitlab.com/ci/yaml/yaml_optimization/#reference-tags) are also replaced
with the linked configuration.
- Conditional rules are evaluated assuming a default branch push event.

Using `!reference` tags can cause nested configuration that display with
multiple hyphens (`-`) at the start of the line in the expanded view. This behavior is expected, and the extra
hyphens do not affect the job’s execution. For example, this configuration and
fully expanded version are both valid:

- `.gitlab-ci.yml` file:





yaml







```yaml
.python-req:
    script:
    - pip install pyflakes

.rule-01:
rules:
    - if: $CI_MERGE_REQUEST_SOURCE_BRANCH_NAME =~ /^feature/
      when: manual
      allow_failure: true
    - if: $CI_MERGE_REQUEST_SOURCE_BRANCH_NAME

.rule-02:
rules:
    - if: $CI_COMMIT_BRANCH == "main"
      when: manual
      allow_failure: true

lint-python:
image: python:latest
script:
    - !reference [.python-req, script]
    - pyflakes python/
rules:
    - !reference [.rule-01, rules]
    - !reference [.rule-02, rules]
```

- Expanded configuration in **Full configuration** tab:





yaml







```yaml
".python-req":
    script:
  - pip install pyflakes
".rule-01":
rules:
  - if: "$CI_MERGE_REQUEST_SOURCE_BRANCH_NAME =~ /^feature/"
    when: manual
    allow_failure: true
  - if: "$CI_MERGE_REQUEST_SOURCE_BRANCH_NAME"
".rule-02":
rules:
  - if: $CI_COMMIT_BRANCH == "main"
    when: manual
    allow_failure: true
lint-python:
image: python:latest
script:
  - - pip install pyflakes                                     # <- The extra hyphens do not affect the job's execution.
  - pyflakes python/
rules:
  - - if: "$CI_MERGE_REQUEST_SOURCE_BRANCH_NAME =~ /^feature/" # <- The extra hyphens do not affect the job's execution.
      when: manual
      allow_failure: true
    - if: "$CI_MERGE_REQUEST_SOURCE_BRANCH_NAME"               # <- No extra hyphen but aligned with previous rule
  - - if: $CI_COMMIT_BRANCH == "main"                          # <- The extra hyphens do not affect the job's execution.
      when: manual
      allow_failure: true
```

## Commit changes to CI configuration [Permalink](https://docs.gitlab.com/ci/pipeline_editor/\#commit-changes-to-ci-configuration "Permalink")

The commit form appears at the bottom of each tab in the editor so you can commit
your changes at any time.

When you are satisfied with your changes, add a descriptive commit message and enter
a branch. The branch field defaults to your project’s default branch.

If you enter a new branch name, the **Start a new merge request with these changes**
checkbox appears. Select it to start a new merge request after you commit the changes.

![The commit form, showing a commit message, branch, and merge request checkmark.](https://docs.gitlab.com/ci/pipeline_editor/img/pipeline_editor_commit_v18_8.png)

## Editor accessibility options [Permalink](https://docs.gitlab.com/ci/pipeline_editor/\#editor-accessibility-options "Permalink")

The pipeline editor is based on the [Monaco Editor](https://github.com/microsoft/monaco-editor)
which has several [accessibility features](https://github.com/microsoft/monaco-editor/wiki/Monaco-Editor-Accessibility-Guide),
including:

| Feature | Shortcut on Windows or Linux | Shortcut on macOS | Details |
| --- | --- | --- | --- |
| Keyboard navigation command list | `F1` | `F1` | A [list of commands](https://github.com/microsoft/monaco-editor/wiki/Monaco-Editor-Accessibility-Guide#keyboard-navigation) that make the editor easier to use without a mouse. |
| Tab trapping | `Control` + `m` | `Control` + `Shift` + `m` | Enable [tab trapping](https://github.com/microsoft/monaco-editor/wiki/Monaco-Editor-Accessibility-Guide#tab-trapping) to go to the next focusable element on the page instead of inserting a tab character. |

## Troubleshooting [Permalink](https://docs.gitlab.com/ci/pipeline_editor/\#troubleshooting "Permalink")

### `Unable to validate CI/CD configuration.` message [Permalink](https://docs.gitlab.com/ci/pipeline_editor/\#unable-to-validate-cicd-configuration-message "Permalink")

This message is caused by a problem validating the syntax in the pipeline editor.
It can happen when GitLab is unable to communicate with the service that validates the syntax.

The information in these sections may not display properly:

- The syntax status on the **Edit** tab (valid or invalid).
- The **Visualize** tab.
- The **Lint** tab.
- The **Full configuration** tab.

You can still work on your CI/CD configuration and commit the changes you made without
any issues. As soon as the service becomes available again, the syntax validation
should display immediately.

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**

| Feature | Shortcut on Windows or Linux | Shortcut on macOS | Details |
| --- | --- | --- | --- |

![Company Logo](https://cdn.cookielaw.org/logos/aa14a5c8-79e3-442a-8177-464ad850b19d/e46c1d0d-1f66-481f-bc06-5427671431da/253e6fee-c4c0-4b60-bc35-79cdae5dda32/gitlab-logo-100.png)

## Privacy Preference Center

## Privacy Preference Center

- ### Your Privacy

- ### Strictly Necessary Cookies

- ### Functionality Cookies

- ### Performance and Analytics Cookies

- ### Targeting and Advertising Cookies

- ### Ad User Data

- ### Ad Personalization


#### Your Privacy

When you visit any website, it may store or retrieve information on your browser, mostly in the form of cookies. This information might be about you, your preferences or your device and is mostly used to make the site work as you expect it to. The information does not usually directly identify you, but it can give you a more personalized web experience. Because we respect your right to privacy, you can choose not to allow some types of cookies. Click on the different category headings to find out more and change our default settings. However, blocking some types of cookies may impact your experience of the site and the services we are able to offer.


[Cookie Policy](https://about.gitlab.com/privacy/cookies/)

**User ID:** 458d9dfe-8b78-4842-b1d9-451285537891

_This User ID will be used as a unique identifier while storing and accessing your preferences for future._

**Timestamp:** --

#### Strictly Necessary Cookies

Always Active

These cookies are necessary for the website to function and cannot be switched off in our systems. They are usually only set in response to actions made by you which amount to a request for services, such as setting your privacy preferences, enabling you to securely log into the site, filling in forms, or using the customer checkout. GitLab processes any personal data collected through these cookies on the basis of our legitimate interest.

Cookies Details

#### Functionality Cookies

Functionality Cookies

These cookies enable helpful but non-essential website functions that improve your website experience. By recognizing you when you return to our website, they may, for example, allow us to personalize our content for you or remember your preferences. If you do not allow these cookies then some or all of these services may not function properly. GitLab processes any personal data collected through these cookies on the basis of your consent

Cookies Details

#### Performance and Analytics Cookies

Performance and Analytics Cookies

These cookies allow us and our third-party service providers to recognize and count the number of visitors on our websites and to see how visitors move around our websites when they are using it. This helps us improve our products and ensures that users can easily find what they need on our websites. These cookies usually generate aggregate statistics that are not associated with an individual. To the extent any personal data is collected through these cookies, GitLab processes that data on the basis of your consent.

Cookies Details

#### Targeting and Advertising Cookies

Targeting and Advertising Cookies

These cookies enable different advertising related functions. They may allow us to record information about your visit to our websites, such as pages visited, links followed, and videos viewed so we can make our websites and the advertising displayed on it more relevant to your interests. They may be set through our website by our advertising partners. They may be used by those companies to build a profile of your interests and show you relevant advertisements on other websites. GitLab processes any personal data collected through these cookies on the basis of your consent.

Cookies Details

#### Ad User Data

Ad User Data

Sets consent for sending user data to Google for advertising purposes.

Cookies Details

#### Ad Personalization

Ad Personalization

Sets consent for personalized advertising.

Cookies Details

Back Button

### Cookie List

Filter Button

ConsentLeg.Interest

checkbox labellabel

checkbox labellabel

checkbox labellabel

Clear

- checkbox labellabel


ApplyCancel

Confirm My Choices

Allow All

[![Powered by Onetrust](https://cdn.cookielaw.org/logos/static/powered_by_logo.svg)](https://www.onetrust.com/products/cookie-consent/)