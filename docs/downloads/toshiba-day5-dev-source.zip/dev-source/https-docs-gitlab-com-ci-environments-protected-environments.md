<!-- source: https://docs.gitlab.com/ci/environments/protected_environments -->

/

* * *

# Protected environments

- Tier: Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

[Environments](https://docs.gitlab.com/ci/environments/) can be used for both testing and
production reasons.

Because deploy jobs can be raised by different users with different roles, it’s
important to be able to protect specific environments from the effects of
unauthorized users.

By default, a protected environment ensures that only people with the
appropriate privileges can deploy to it, keeping the environment safe.

GitLab administrators can use all environments, including protected environments.

To protect or unprotect an environment, you need at least the Maintainer role.
Additionally, to update environment attributes such as `external_url`, `tier`, or `description`,
you must also be in the **Allowed to deploy** list.

## Protecting environments [Permalink](https://docs.gitlab.com/ci/environments/protected_environments/\#protecting-environments "Permalink")

Prerequisites:

- When granting the **Allowed to deploy** permission to an approver group, the user configuring the protected environment must be a **direct member** of the approver group to be added. Otherwise, the group or subgroup does not show up in the dropdown list. For more information see [issue #345140](https://gitlab.com/gitlab-org/gitlab/-/issues/345140).
- When granting **Approvers** permissions to an approver group or project, by default only direct members of the approver group or project receive these permissions. To also grant these permissions to inherited members of the approver group or project:
  - Select the **Enable group inheritance** checkbox.
  - [Use the API](https://docs.gitlab.com/api/protected_environments/#group-inheritance-types).

To protect an environment:

1. In the top bar, select **Search or go to** and find your project.

2. In the left sidebar, select **Settings** \> **CI/CD**.

3. Expand **Protected environments**.

4. Select **Protect an environment**.

5. From the **Environment** list, select the environment you want to protect.

6. In the **Allowed to deploy** list, select the role, users, or groups you
want to give deploy access to. Keep in mind that:

   - There are two roles to choose from:
     - **Maintainers**: Allows access to all of the project’s users with the Maintainer role.
     - **Developers**: Allows access to all of the project’s users with the Maintainer and Developer role.
   - You can also select groups that are already [invited](https://docs.gitlab.com/user/project/members/sharing_projects_groups/#invite-a-group-to-a-project) to the project. Invited groups added to the project with the Reporter role appear in the dropdown list for [deployment-only access](https://docs.gitlab.com/ci/environments/protected_environments/#deployment-only-access-to-protected-environments).
   - You can also select specific users. The users must have the Developer, Maintainer, or Owner role to appear in
     the **Allowed to deploy** list.
7. In the **Approvers** list, select the role, users, or groups you
want to give deploy access to. Keep in mind that:

   - There are two roles to choose from:
     - **Maintainers**: Allows access to all of the project’s users with the Maintainer role.
     - **Developers**: Allows access to all of the project’s users with the Maintainer and Developer role.
   - You can only select groups that are already [invited](https://docs.gitlab.com/user/project/members/sharing_projects_groups/#invite-a-group-to-a-project) to the project.
   - Users must have the Developer, Maintainer, or Owner role to appear in
     the **Approvers** list.
8. In the **Approval rules** section:

   - Ensure that this number is less than or equal to the number of members in
     the rule.
   - See [Deployment Approvals](https://docs.gitlab.com/ci/environments/deployment_approvals/) for more information about this feature.
9. Select **Protect**.


The protected environment now appears in the list of protected environments.

### Use the API to protect an environment [Permalink](https://docs.gitlab.com/ci/environments/protected_environments/\#use-the-api-to-protect-an-environment "Permalink")

Alternatively, you can use the API to protect an environment:

1. Use a project with a CI that creates an environment. For example:





yaml







```yaml
stages:
  - test
  - deploy

test:
stage: test
script:
    - 'echo "Testing Application: ${CI_PROJECT_NAME}"'

production:
stage: deploy
when: manual
script:
    - 'echo "Deploying to ${CI_ENVIRONMENT_NAME}"'
environment:
    name: ${CI_JOB_NAME}
```

2. Use the UI to [create a new group](https://docs.gitlab.com/user/group/#create-a-group).
For example, this group is called `protected-access-group` and has the group ID `9899826`. Note
that the rest of the examples in these steps use this group.

![Protected access group interface with the New project button highlighted.](https://docs.gitlab.com/ci/environments/img/protected_access_group_v13_6.png)

3. Use the API to add a user to the group as a reporter:





shell







```shell
$ curl --request POST --header "PRIVATE-TOKEN: <your_access_token>" \
          --data "user_id=3222377&access_level=20" "https://gitlab.com/api/v4/groups/9899826/members"

{"id":3222377,"name":"Sean Carroll","username":"sfcarroll","state":"active","avatar_url":"https://gitlab.com/uploads/-/system/user/avatar/3222377/avatar.png","web_url":"https://gitlab.com/sfcarroll","access_level":20,"created_at":"2020-10-26T17:37:50.309Z","expires_at":null}
```

4. Use the API to add the group to the project as a reporter:





shell







```shell
$ curl --request POST --header "PRIVATE-TOKEN: <your_access_token>" \
          --request POST "https://gitlab.com/api/v4/projects/22034114/share?group_id=9899826&group_access=20"

{"id":1233335,"project_id":22034114,"group_id":9899826,"group_access":20,"expires_at":null}
```

5. Use the API to add the group with protected environment access:





shell







```shell
curl --header 'Content-Type: application/json' --request POST --data '{"name": "production", "deploy_access_levels": [{"group_id": 9899826}]}' \
        --header "PRIVATE-TOKEN: <your_access_token>" "https://gitlab.com/api/v4/projects/22034114/protected_environments"
```


The group now has access and can be seen in the UI.

## Environment access by group membership [Permalink](https://docs.gitlab.com/ci/environments/protected_environments/\#environment-access-by-group-membership "Permalink")

A user may be granted access to protected environments as part of [group membership](https://docs.gitlab.com/user/group/). Users
with the Reporter role can only be granted access to protected environments with this
method.

## Deployment branch access [Permalink](https://docs.gitlab.com/ci/environments/protected_environments/\#deployment-branch-access "Permalink")

Users with the Developer role can be granted
access to a protected environment through any of these methods:

- As an individual contributor, through a role.
- Through a group membership.

If the user also has push or merge access to the branch deployed on production,
they have the following privileges:

- [Stop an environment](https://docs.gitlab.com/ci/environments/#stopping-an-environment).
- [Delete an environment](https://docs.gitlab.com/ci/environments/#delete-an-environment).
- [Create an environment terminal](https://docs.gitlab.com/ci/environments/#web-terminals-deprecated).

## Deployment-only access to protected environments [Permalink](https://docs.gitlab.com/ci/environments/protected_environments/\#deployment-only-access-to-protected-environments "Permalink")

Users granted access to a protected environment, but not push or merge access
to the branch deployed to it, are only granted access to deploy the environment.
[Invited groups](https://docs.gitlab.com/user/project/members/sharing_projects_groups/#invite-a-group-to-a-project) added
to the project with [Reporter role](https://docs.gitlab.com/user/permissions/#project-permissions), appear in the dropdown list for deployment-only access.

To add deployment-only access:

1. Create a group with members who are granted to access to the protected environment, if it doesn’t exist yet.
2. [Invite the group](https://docs.gitlab.com/user/project/members/sharing_projects_groups/#invite-a-group-to-a-project) to the project with the Reporter role.
3. Follow the steps in [Protecting Environments](https://docs.gitlab.com/ci/environments/protected_environments/#protecting-environments).

## Modifying and unprotecting environments [Permalink](https://docs.gitlab.com/ci/environments/protected_environments/\#modifying-and-unprotecting-environments "Permalink")

Maintainers can:

- Update protection settings, including the **Allowed to deploy** list and approval rules, at any time.
- Unprotect a protected environment by selecting **Unprotect** for that environment.

To update environment attributes such as `external_url`, `tier`, or `description` on a protected
environment, the user must also be in the **Allowed to deploy** list.

After an environment is unprotected, all access entries are deleted and must
be re-entered if the environment is re-protected.

After an approval rule is deleted, previously approved deployments do not show who approved the deployment.
Information on who approved a deployment is still available in the [project audit events](https://docs.gitlab.com/user/compliance/audit_events/#project-audit-events).
If a new rule is added, previous deployments show the new rules without the option to approve the deployment. [Issue 506687](https://gitlab.com/gitlab-org/gitlab/-/issues/506687) proposes to show the full approval history of deployments, even if an approval rule is deleted.

For more information, see [Deployment safety](https://docs.gitlab.com/ci/environments/deployment_safety/).

## Group-level protected environments [Permalink](https://docs.gitlab.com/ci/environments/protected_environments/\#group-level-protected-environments "Permalink")

Typically, large enterprise organizations have an explicit permission boundary
between [developers and operators](https://about.gitlab.com/topics/devops/).
Developers build and test their code, and operators deploy and monitor the
application. With group-level protected environments, operators can
restrict access to critical environments from developers. Group-level protected environments
extend the [project-level protected environments](https://docs.gitlab.com/ci/environments/protected_environments/#protecting-environments)
to the group-level.

The permissions of deployments can be illustrated in the following table:

| Environment | Developer | Operator | Category |
| --- | --- | --- | --- |
| Development | Allowed | Allowed | Lower environment |
| Testing | Allowed | Allowed | Lower environment |
| Staging | Disallowed | Allowed | Higher environment |
| Production | Disallowed | Allowed | Higher environment |

_(Reference: [Deployment environments on Wikipedia](https://en.wikipedia.org/wiki/Deployment_environment))_

### Group-level protected environments names [Permalink](https://docs.gitlab.com/ci/environments/protected_environments/\#group-level-protected-environments-names "Permalink")

Contrary to project-level protected environments, group-level protected
environments use the [deployment tier](https://docs.gitlab.com/ci/environments/#deployment-tier-of-environments)
as their name.

A group may consist of many project environments that have unique names.
For example, Project-A has a `gprd` environment and Project-B has a `Production`
environment, so protecting a specific environment name doesn’t scale well.
By using deployment tiers, both are recognized as `production` deployment tier
and are protected at the same time.

### Configure group-level memberships [Permalink](https://docs.gitlab.com/ci/environments/protected_environments/\#configure-group-level-memberships "Permalink")

History

- Operators are required to have Owner+ role from the original Maintainer+ role and this role change is introduced from GitLab 15.3 [with a flag](https://gitlab.com/gitlab-org/gitlab/-/issues/369873) named `group_level_protected_environment_settings_permission`. Enabled by default.
- [Feature flag removed](https://gitlab.com/gitlab-org/gitlab/-/issues/369873) in GitLab 15.4.

To maximize the effectiveness of group-level protected environments,
[group-level memberships](https://docs.gitlab.com/user/group/) must be correctly
configured:

- Operators should be given the Owner role
for the top-level group. They can maintain CI/CD configurations for
the higher environments (such as production) in the group-level settings page,
which includes group-level protected environments,
[group-level runners](https://docs.gitlab.com/ci/runners/runners_scope/#group-runners), and
[group-level clusters](https://docs.gitlab.com/user/group/clusters/). Those
configurations are inherited to the child projects as read-only entries.
This ensures that only operators can configure the organization-wide
deployment ruleset.
- Developers should be given no more than the Developer role
for the top-level group, or explicitly given the Owner role for a child project.
They do not have access to the CI/CD configurations in the
top-level group, so operators can ensure that the critical configuration won’t
be accidentally changed by the developers.
- For subgroups and child projects:
  - Regarding [subgroups](https://docs.gitlab.com/user/group/subgroups/), if a higher
    group has configured the group-level protected environment, the lower groups
    cannot override it.
  - [Project-level protected environments](https://docs.gitlab.com/ci/environments/protected_environments/#protecting-environments) can be
    combined with the group-level setting. If both group-level and project-level
    environment configurations exist, to run a deployment job, the user must be allowed in **both**
    rulesets.
  - In a project or a subgroup of the top-level group, developers can be
    safely assigned the Maintainer role to tune their lower environments (such
    as `testing`).

Having this configuration in place:

- If a user is about to run a deployment job in a project and allowed to deploy
to the environment, the deployment job proceeds.
- If a user is about to run a deployment job in a project but disallowed to
deploy to the environment, the deployment job fails with an error message.

### Protect critical environments under a group [Permalink](https://docs.gitlab.com/ci/environments/protected_environments/\#protect-critical-environments-under-a-group "Permalink")

To protect a group-level environment, make sure your environments have the correct
[`deployment_tier`](https://docs.gitlab.com/ci/environments/#deployment-tier-of-environments) defined in `.gitlab-ci.yml`.

#### Using the UI [Permalink](https://docs.gitlab.com/ci/environments/protected_environments/\#using-the-ui "Permalink")

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/325249) in GitLab 15.1.

1. In the top bar, select **Search or go to** and find your group.
2. In the left sidebar, select **Settings** \> **CI/CD**.
3. Expand **Protected environments**.
4. From the **Environment** list, select the [deployment tier of environments](https://docs.gitlab.com/ci/environments/#deployment-tier-of-environments) you want to protect.
5. In the **Allowed to deploy** list, select the [subgroups](https://docs.gitlab.com/user/group/subgroups/) you want to give deploy access to.
6. Select **Protect**.

#### Using the API [Permalink](https://docs.gitlab.com/ci/environments/protected_environments/\#using-the-api "Permalink")

Configure the group-level protected environments by using the [REST API](https://docs.gitlab.com/api/group_protected_environments/).

## Deployment approvals [Permalink](https://docs.gitlab.com/ci/environments/protected_environments/\#deployment-approvals "Permalink")

Protected environments can also be used to require manual approvals before deployments. See [Deployment approvals](https://docs.gitlab.com/ci/environments/deployment_approvals/) for more information.

## Troubleshooting [Permalink](https://docs.gitlab.com/ci/environments/protected_environments/\#troubleshooting "Permalink")

### Reporter can’t run a trigger job that deploys to a protected environment in downstream pipeline [Permalink](https://docs.gitlab.com/ci/environments/protected_environments/\#reporter-cant-run-a-trigger-job-that-deploys-to-a-protected-environment-in-downstream-pipeline "Permalink")

A user who has [deployment-only access to protected environments](https://docs.gitlab.com/ci/environments/protected_environments/#deployment-only-access-to-protected-environments) might **not** be able to run a job if it’s with a [`trigger`](https://docs.gitlab.com/ci/yaml/#trigger) keyword. This is because the job is missing the [`environment`](https://docs.gitlab.com/ci/yaml/#environment) keyword definition to associate the job with the protected environment, therefore the job is recognized as a standard job that uses [regular CI/CD permission model](https://docs.gitlab.com/user/permissions/#project-cicd).

See [this issue](https://gitlab.com/groups/gitlab-org/-/epics/8483) for more information about supporting `environment` keyword with `trigger` keyword.

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**

| Environment | Developer | Operator | Category |
| --- | --- | --- | --- |