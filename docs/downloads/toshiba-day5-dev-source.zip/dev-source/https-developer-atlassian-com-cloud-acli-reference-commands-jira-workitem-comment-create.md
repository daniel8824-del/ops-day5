<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-create -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Filter by keyword

- [acli](https://developer.atlassian.com/cloud/acli/reference/commands/)
- [admin](https://developer.atlassian.com/cloud/acli/reference/commands/admin/)

[admin auth](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth/)

[admin user](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user/)

- [feedback](https://developer.atlassian.com/cloud/acli/reference/commands/feedback/)
- [jira](https://developer.atlassian.com/cloud/acli/reference/commands/jira/)

[jira auth](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth/)

[jira board](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board/)

[jira dashboard](https://developer.atlassian.com/cloud/acli/reference/commands/jira-dashboard/)

[jira field](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field/)

[jira filter](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter/)

[jira project](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project/)

[jira sprint](https://developer.atlassian.com/cloud/acli/reference/commands/jira-sprint/)

[jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem/)

- [archive](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-archive/)
- [assign](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-assign/)
- [attachment-delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-attachment-delete/)
- [attachment-list](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-attachment-list/)
- [clone](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-clone/)
- [comment-create](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-create/)
- [comment-delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-delete/)
- [comment-list](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-list/)
- [comment-update](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-update/)
- [comment-visibility](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-visibility/)
- [create](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-create/)
- [create-bulk](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-create-bulk/)
- [delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-delete/)
- [edit](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-edit/)
- [link](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-link/)
- [search](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-search/)
- [transition](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-transition/)
- [unarchive](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-unarchive/)
- [view](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-view/)
- [watcher-remove](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-watcher-remove/)

- [rovodev](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev/)

[rovodev auth](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev-auth/)

Last updated Oct 3, 2024

On This Page

- [acli jira workitem comment create](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-create/#acli-jira-workitem-comment-create)


## acli jira workitem comment create

Create a comment on work items

### Synopsis

Add a comment to a work item or multiple work items using the default visibility for the project.

```
Copy
1
acli jira workitem comment create [flags]
```

### Examples

```
Copy
1
2
3
4
5
6
7
8
# Comment on work item with work item keys
$ acli jira workitem comment --key "KEY-1" --body "This is a comment"

# Comment on work item with JQL query and plain text file
$ acli jira workitem comment --jql "project = TEAM" --body-file "comment.txt" --edit-last

# Comment on work item with JQL query
$ acli jira workitem comment --jql "project = TEAM" --editor
```

### Options

```
Copy
1
2
3
4
5
6
7
8
9
10
  -b, --body string        Comment body in plain text or Atlassian Document Format (ADF)
  -F, --body-file string   Plain text file with text or Atlassian Document Format (ADF)
  -e, --edit-last          Edit the last comment from the same author
      --editor             Skip prompts and open the text editor to write the body
      --filter string      Filter ID of work items to comment
  -h, --help               Show help for command
      --ignore-errors      Ignore the errors and continue
      --jql string         JQL query for work items to comment
      --json               Generate a JSON output
  -k, --key string         A list of work item keys to comment
```

### SEE ALSO

- [acli jira workitem comment](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment) \- Work item comments commands.

Rate this page:

Unusable

Poor

Okay

Good

Excellent