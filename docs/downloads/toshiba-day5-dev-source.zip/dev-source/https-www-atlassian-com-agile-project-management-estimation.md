<!-- source: https://www.atlassian.com/agile/project-management/estimation -->

Get it free

Sign in

# Story points and estimation

Good estimation helps product owners optimize for efficiency and impact. That's why it's so important.

![](https://images.ctfassets.net/xjcz23wx147q/2uNEtaB8azod7exGiL9Obf/b34e5b81e9176b0dfc38880a173994e0/Dan_Radigan_200x200.png)

By Dan Radigan, Atlassian Head of Technical Product Marketing

Agile has had a huge impact on me both professionally and personally as I've learned the best experiences are agile, both in code and in life. You'll often find me at the intersection of technology, photography, and motorcycling.

Get started with the free Jira scrum template

Streamline your project and easily plan, track, and manage work across sprints. This template includes boards, backlogs, roadmaps, reports, and more!

[Use template](https://www.atlassian.com/software/jira/templates/scrum)

**Key Takeaways**

- Story points are a relative estimation method in Agile that helps teams assess effort, complexity, and risk for backlog items.

- Using story points instead of hours encourages team collaboration, reduces emotional bias, and improves forecasting.

- Estimation techniques like planning poker and retrospectives help teams calibrate and refine their process over time.

- Practice regular estimation and review past estimates to improve accuracy and team alignment on future work.


Estimation is hard. For software developers, it's among the most difficult — if not the most difficult — aspects of the job. It must take into account a slew of factors that help product owners make decisions that affect the entire team — and the business. With all that at stake, it's no wonder everyone from developers to upper management is prone to getting their undies in a bunch about it. But that's a mistake. Agile story points estimation is just that: an estimate. Not a blood-oath.

There's no requirement to work weekends in order to compensate for under-estimating a piece of work. That said, let's look at some ways to make agile estimates as accurate as possible.

## What is a story point?

A story point is a unit of measure used in [Agile](https://www.atlassian.com/agile) estimation to express the relative effort required to complete a user story or task. Story points consider complexity, risk, and the amount of work, rather than specific hours or days.

Teams assign story points based on collective experience and comparison to other stories, often using techniques like [planning poker](https://www.atlassian.com/blog/platform/scrum-poker-for-agile-projects). For example, a simple bug fix might be 1 point, while a complex feature could be 8 points. This approach helps teams estimate work consistently and plan sprints more effectively.

### What factors influence story points?

Factors that influence story points include the complexity of the work, the amount of effort required, potential risks, and any dependencies or unknowns. Teams also consider how similar tasks have been estimated and completed in the past.

For example, integrating with a new API might have a higher story point value due to unfamiliarity and potential technical challenges. Regularly reviewing and calibrating story point estimates helps teams maintain consistency and improve forecasting accuracy over time.

## Collaborating with the product owner

In agile development, the [product owner](https://www.atlassian.com/agile/product-management) is tasked with prioritizing the [backlog](https://www.atlassian.com/agile/scrum/backlogs) — the ordered list of work that contains short descriptions of all desired features and fixes for a product. Product owners capture [requirements](https://www.atlassian.com/agile/product-management/requirements) from the business, but they don’t always understand the details of implementation. So good estimation can give the product owner new insight into the level of effort for each work item, which then feeds back into their assessment of each item's relative priority.

When the engineering team begins its estimation process, questions usually arise about requirements and user stories. And that's good: those questions help the entire team understand the work more fully. For product owners specifically, breaking down work items into granular pieces and estimates via story points helps them prioritize all (and potentially hidden!) areas of work. And once they have estimates from the dev team, it's not uncommon for a product owner to reorder items on the backlog.

## Agile story points estimation is a team sport

Involving everyone (developers, designers, testers, deployers... everyone) on the team is key. Each team member brings a different perspective on the product and the work required to deliver a user story. For example, if product management wants to do something that seems simple, like support a new web browser, development and QA need to weigh in because their experience has taught them what dragons may be lurking beneath the surface.

Likewise, design changes require not only the design team's input, but that of development and QA as well. Leaving part of the broader product team out of the estimation process creates lower quality estimates, lowers morale because key contributors don't feel included, and compromises the quality of the software.

So don’t let your team fall victim to estimates made in a vacuum. It’s a fast track to failure!

**Want to give story points a try?** [First, sign up or log into Jira](https://www.atlassian.com/software/jira/free)

- [Try this interactive tutorial to set up your first scrum project](https://www.atlassian.com/agile/tutorials/how-to-do-scrum-with-jira)

- [Learn how to configure story point estimations and track your user stories](https://support.atlassian.com/jira-software-cloud/docs/configure-estimation-and-tracking/)


## Story points vs. hours

![Atlassian Roundtable video poster](<Base64-Image-Removed>)

Traditional software teams give estimates in a time format: days, weeks, months. Many agile teams, however, have transitioned to story points. Story points are units of measure for expressing an estimate of the overall effort required to fully implement a product backlog item or any other piece of work. Teams assign story points relative to work complexity, the amount of work, and risk or uncertainty. Values are assigned to more effectively break down work into smaller pieces, so they can address uncertainty. Over time, this helps teams understand how much they can achieve in a period of time and builds consensus and commitment to the solution.  It may sound counter-intuitive, but this abstraction is actually helpful because it pushes the team to make tougher decisions around the difficulty of work. Here are few reasons to use story points:

- Dates don’t account for the non-project related work that inevitably creeps into our days: emails, meetings, and interviews that a team member may be involved in.

- Dates have an emotional attachment to them. Relative estimation removes the emotional attachment.

- Each team will estimate work on a slightly different scale, which means their velocity (measured in points) will naturally be different. This, in turn, makes it impossible to play politics using velocity as a weapon.

- Once you agree on the relative effort of each story point value, you can assign points quickly without much debate.

- Story points reward team members for solving problems based on difficulty, not time spent. This keeps team members focused on shipping value, not spending time.


Unfortunately, story points are often misused. Story points go wrong when they’re used to judge people, assign detailed timelines and resources, and when they’re mistaken for a measure of productivity. Instead, teams should use story points to understand the size of the work and the prioritization of the work. For an in-depth discussion on story points and estimation practices, check out this [roundtable with industry experts](https://community.atlassian.com/t5/Agile-articles/Six-experts-sound-off-on-story-points-the-evolution-of-agile/ba-p/1553590), and read on for more agile estimation tips.

### Why use story points instead of hours?

Story points are used instead of hours because they focus on the relative size and complexity of work, reducing debates over exact time estimates and accounting for uncertainty. This method encourages teams to think about effort and risk, rather than just duration.

By using story points, teams can better accommodate differences in skill levels and avoid the pitfalls of underestimating or overcommitting. For example, two developers might complete the same story in different amounts of time, but the story point value remains consistent, supporting more predictable [sprint planning](https://www.atlassian.com/agile/scrum/sprint-planning).

## Story points and planning poker

Teams starting out with story points use an exercise called [planning poker](https://www.atlassian.com/blog/platform/a-brief-overview-of-planning-poker). At Atlassian, planning poker is a common practice across the company. The team will take an item from the backlog, discuss it briefly, and each member will mentally formulate an estimate. Then everyone holds up a card with the number that reflects their estimate. If everyone is in agreement, great! If not, take some time (but not too much time–just couple minutes) to understand the rationale behind different estimates. Remember though, estimation should be a high level activity. If the team is too far into the weeds, take a breath, and up-level the discussion.

**Ready to give it a try?**

- Install this [Planning Poker App](https://marketplace.atlassian.com/apps/1212495/planning-poker?hosting=cloud&tab=overview)

- Learn more about [Planning Poker](https://www.atlassian.com/blog/agile/planning-poker-sane-healthy)


## Estimate smarter, not harder

No individual task should be more than 16 hours of work. (If you're using story points, you may decide that, say, 20 points is the upper limit.) It’s simply too hard to estimate individual work items larger than that with a high degree of confidence. And that confidence is especially important for items at the top of the backlog. When something is estimated above your team's 16-hour (or 20-point) threshold, that's a signal to break it down into more granular pieces and re-estimate.

For items deeper in the backlog, give a rough estimate. By the time the team actually begins to work on those items, the requirements may change, and your application certainly will have changed. So prior estimates won’t be as accurate. Don’t waste time estimating work that is likely to shift. Just give the product owner a ballpark figure she can use to prioritize the product roadmap appropriately.

## Learn from past estimates

Retrospectives are a time for the team to incorporate insights from past iterations–including the accuracy of their estimates. Many agile tools (like [Jira](https://www.atlassian.com/software/jira)) track story points, which makes reflecting on and re-calibrating estimates a lot easier. Try, for example, pulling up the last 5 user stories the team delivered with the story point value 8. Discuss whether each of those work items had a similar level of effort. If not, discuss why. Use that insight in future estimation discussions.

Like [everything else in agile](https://www.atlassian.com/agile/project-management), estimation is a practice. You'll get better and better with time.

### Related resources

- [Project Management Resources](https://www.atlassian.com/project-management)

  - [Project Planning Resources](https://www.atlassian.com/project-management/project-planning)

  - [Product Launch Resources](https://www.atlassian.com/project-management/build-launch-products-services)

  - [Project Management Go-To-Market Strategies](https://www.atlassian.com/project-management/go-to-market-strategy)

  - [Resource Management Resources](https://www.atlassian.com/project-management/resource-management)

  - [Task-Tracking Resources](https://www.atlassian.com/project-management/task-tracking)

  - [Software Project Management](https://www.atlassian.com/project-management/software-teams)

## Recommended for you

### Ready-made Jira templates

Browse our library of custom Jira templates for various teams, departments, and workflows.

[Go to Jira templates](https://www.atlassian.com/software/jira/templates)

### A comprehensive introduction to Jira

Use this step-by-step guide to discover essential features and the best practices to maximize your productivity.

[Go to Jira Product guide](https://www.atlassian.com/software/jira/guides/getting-started/introduction#what-is-jira-software)

### Understanding the Basics of Git

From beginners to advanced experts, use this guide to Git to learn the basics with helpful tutorials and tips.

[Learn more](https://www.atlassian.com/git)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**