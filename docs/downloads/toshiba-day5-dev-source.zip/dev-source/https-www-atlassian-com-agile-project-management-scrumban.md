<!-- source: https://www.atlassian.com/agile/project-management/scrumban -->

Get it free

Sign in

# Scrumban: Mastering two Agile methodologies

![](https://images.ctfassets.net/xjcz23wx147q/7uCft5A1c4TtuE5qgaaY61/b2ff4f03e46c373fa9e67965c5c4680a/logos-atlassian-icon-contained-gradient-blue.svg)

By Atlassian

Get started with the free Jira Kanban template

Maximize efficiency by seeing and moving forward the work that matters most.

[Use template](https://www.atlassian.com/software/jira/templates/kanban)

**Key Takeaways**

- Scrumban is a hybrid Agile methodology that combines Scrum’s structure with Kanban’s visual workflow and WIP limits.

- It offers flexibility, continuous delivery, and incremental improvement for teams managing complex or evolving projects.

- Scrumban supports simultaneous initiatives, evolving requirements, and efficient resource allocation.

- Adopt Scrumban to balance structure and flexibility, enabling your team to adapt and deliver value continuously.


Scrumban combines two leading Agile methodologies—Scrum and Kanban—into a single process for getting work done. But what is scrumban? And why should you consider its unique approach?

In this guide, we'll explain what Scrumban is, the types of projects it's suitable for, and who can make the most of its hybrid approach to [Agile project management](https://www.atlassian.com/agile/project-management).

## What is Scrumban?

The Scrumban methodology combines the best features of Scrum and Kanban into a hybrid project management framework. It uses Scrum's stable structure of sprints, standups, and retrospectives. Then it adds Kanban's visual workflow and work-in-progress limitations. The result is a truly flexible method for managing projects of any size.

Scrumban initially started as a way for teams to easily transition from Scrum to Kanban (or vice-versa) but has evolved into a mature system that allows teams to tackle complex, ongoing projects. It's flexible due to its hybrid approach and because it gives teams a wide range of [Agile tools](https://www.atlassian.com/software/jira/agile#scrum).

But is Scrumban an Agile approach? Yes. It combines Scrum and Kanban—both Agile methodologies—and draws elements from their [Agile workflows](https://www.atlassian.com/agile/project-management/workflow) to create a hybrid process.

## Understanding Scrum

[Scrum](https://www.atlassian.com/agile/scrum) is an Agile framework that allows teams to continuously complete work in fixed-length periods called sprints. With each sprint, a Scrum team delivers a working iteration of the product—the minimum viable product (MVP).

![Sprints](https://dam-cdn.atl.orangelogic.com/AssetLink/6asksr4j4llyfm3w6636wywy4p1x27qo.png)

With reviews and retrospectives at the end of every sprint, the team continuously improves the project and its processes. Scrum teams consist of members with specific roles and a Scrum Master, whose job is to lead the team and clear project roadblocks.

Like Kanban, Scrum utilizes a board to track project progress. However, the [Scrum board](https://www.atlassian.com/agile/project-management/scrum-board) differs from Kanban in that it utilizes a backlog that lives separately from the board. The board displays work that the team is focused on during a single sprint, and the backlog includes all other work items related to the project. Teams pull work from this backlog when they decide what they’ll work on for upcoming sprints.

Teams can easily start building their Scrum board and backlog with Jira’s [Scrum template](https://www.atlassian.com/software/jira/templates/scrum).

Which parts of Scrum live on in the Scrumban methodology?

For one, Scrumban uses the Scrum structure. With the time-boxed sprints and planning and reviewing events, it's clear what needs completing and by when. In addition, Scrumban projects continue Scrum's tradition of regularly reviewing the MVP and adapting to its changing requirements.

### How Scrum contributes to Scrumban

Scrum contributes three vital ingredients to the Scrumban framework, including:

- **Sprints**: Teams complete all work in a Scrumban project within a defined period called a sprint. Sprints typically last two weeks, though teams may opt for shorter (or longer) periods. Once the team agrees on what tasks to work on within the sprint, they can't receive new tasks until the sprint ends.

- **Daily standups**: To clarify who does what, Scrumban teams meet for a daily standup—a meeting of no more than 10 minutes. There, participants briefly answer three questions:

  - What tasks did I complete?

  - What tasks am I working on?

  - What are my roadblocks?
- **Retrospectives**: At the end of every sprint, the team meets to analyze their performance. What processes went well and what should they repeat? What didn't work and what should they stop? The team documents the wisdom they glean from each retrospective and uses it to inform future sprints.


#### Scrum and Agile: not interchangeable terms

A quick clarification: Scrum is not the same as Agile, so don't mix them up. While Scrum is a framework for completing tasks, Agile is the set of principles or mindset you need to allow the Scrum process to succeed.

In short, you can't use Agile without a framework (such as Scrum, Kanban, or Scrumban). And you can't use Scrum without [cultivating an Agile mindset](https://www.atlassian.com/agile/advantage/agile-mindset).

## Understanding Kanban

[Kanban](https://www.atlassian.com/agile/kanban), a combination of the Japanese words for "sign" and "board," is a way to visualize work and limit the amount of work in progress so a team can achieve an efficient flow. Toyota introduced this method of using [visual cards in 1953](https://www.the-center.org/Blog/October-2015/Recognize-the-Signs-Power-of-Kanban) to improve production and unify teams. Today, it's much more about productivity, as the methodology is perfect for teams that require continuous improvement.

![swimlanes](https://dam-cdn.atl.orangelogic.com/AssetLink/504my70y63x84njeq36024h51027unw6.png)

Jira makes it easy for teams to get started on their next project with the [Kanban board template](https://www.atlassian.com/software/jira/templates/kanban). Visualize and track work on a powerful board and manage a continuous delivery of work. Which parts of Kanban live on in the Scrumban methodology?

Which parts of Kanban live on in the Scrumban methodology?

Scrumban uses Kanban's workflow visualization as the heart of its process. Alongside the board and cards, Scrumban benefits from the work-in-progress limits, the pull system for its tasks, and the continuous flow of work. This means teams can complete projects even midway through a sprint.

### How Kanban contributes to Scrumban

Kanban has three main elements that bring value to the Scrumban methodology:

- **The board**: A [Kanban board](https://www.atlassian.com/agile/kanban/boards) typically has columns denoting each phase of a project: a "to do" column, an "in progress" column, and a "done" column.

- **The cards**: The board holds the project's tasks, or cards (since historically teams used index cards or sticky notes on whiteboards). As each member begins work on a card, they move it from "to do" to "in progress" and, once finished, into the "done" column.

- **The work-in-progress limits**: For a team to work efficiently, they must know what they can realistically handle within a defined work period. How many cards can a team member work on within a day? By defining this limit, the team prevents overwork (and burnout) while showing stakeholders exactly what they're accomplishing.


## At a glance: Scrum, Kanban, and Scrumban

|  | Scrum | Kanban | Scrumban |
| --- | --- | --- | --- |
| Methodology | Fixed length sprints <br>Fixed roles<br>Consistent delivery | Limit work in progress<br>Track tasks visually<br>Continuous flow of work | Fixed length sprints<br>Limit work in progress<br>Track tasks visually<br>Continuous flow of work |
| Roles | Product Owner<br>Scrum Master<br>Development team | None | None |
| Artifacts | Product backlog<br>Sprint backlog<br>Increment finished | Kanban board<br>Kanban cards | Scrumban board<br>Scrumban cards |
| Events | Sprint planning<br>Daily standup<br>Sprint review<br>Sprint retrospective | Kanban meeting | Sprint planning<br>Daily standup<br>Sprint retrospective |
| Process flow | Product backlog<br>Sprint backlog<br>In progress<br>Review<br>Done | To Do<br>In Progress<br>Done | To Do<br>In Progress<br>Done |

## Benefits of the Scrumban methodology

Why choose the Scrumban methodology over just Scrum or Kanban? The power lies in its combination of the best parts of both methodologies:

- **Increased flexibility**: Because Scrumban delivers incremental work with every sprint, it allows for project changes even in the middle of the process. Meanwhile, there's progress toward project completion.

- **Continuous delivery**: With a board and a continuous flow of work, teams can deliver features as they complete them—no need to wait for a sprint to end.

- **Reduced overloading**: Limiting work in progress to the team's capabilities allows for progress without burnout.

- **Faster issue resolution**: Laying out cards on a board gives Scrumban the transparency teams need for better collaboration while quickly identifying problems and solutions.

- **Ability to tackle large-scale projects**: Because both Scrum and Kanban are about continuous and incremental improvement, Scrumban allows teams to work toward the completion of even the most complex projects.


## Limitations of the Scrumban methodology

While there are many advantages of the Scrumban methodology, there are also some limitations to be aware of, including:

- **Ambiguity**: Scrumban is relatively new, so there isn't much documentation on its implementation. As such, there could be some difficulty in finding guidance or best practices.

- **Less control**: Since Scrumban forgoes traditional Scrum roles, team members self-manage their sprints. The absence of a clear leader may lead to confusion over responsibilities.

- **Complexity**: Taking elements from two methodologies may be confusing to team members who are familiar with another system or who have never used an Agile system.


## When to use Scrumban

Scrumban is perfect for specific use cases where Scrum or Kanban alone aren't sufficient. Some examples of this include:

### Software development projects with evolving requirements

Software projects with scope creep is the perfect opportunity to use the Scrumban methodology. Scrumban allows for this with sprints and continual development. Even as requirements change, teams can continue to complete work incrementally.

### Projects with multiple, concurrent initiatives

In larger companies, it's not uncommon to have simultaneous ongoing projects. Sometimes, they even involve the same teams. Because of its flexibility, Scrumban allows for simultaneous initiatives, so even small teams can tackle multiple requirements.

### Startups or rapidly changing environments

Startups often have constantly changing environments and projects. Every day brings a new challenge, and there are rarely any resources. Scrumban brings capability into that environment and allows even small teams to thrive with its flexible framework for doing work.

In the end, it's not [Kanban vs. Scrum](https://www.atlassian.com/agile/kanban/kanban-vs-scrum). Taking the principles that work best for your team from each methodology makes for a more efficient way to tackle any project.

## Start your next Scrumban project with Jira

Scrumban is a flexible Agile methodology that helps project teams balance their capacity with a project's complexity. The strength of Scrumban lies in combining the best parts of Scrum and Kanban.

If you're ready to experience the benefits of Scrumban's hybrid approach to [project management](https://www.atlassian.com/work-management/project-management), [Jira](https://www.atlassian.com/software/jira) makes it as easy as setting up your next project. Start with one of Jira's dozens of pre-configured templates, and customize your Jira space for any project, team structure, workflow, or agile metholodology. Jira makes it easy to organize work, stay aligned, and build better products.

[Jira](https://www.atlassian.com/software/jira) also enables business teams, such as marketing, HR or finance, to take advantage of Scrumban principles. In addition to the board view, Jira offers Calendar and Timeline views to give these teams a clear and easy way to visualize work. Jira is the shared platform of collaboration across an organization, allowing software development and business teams to stay connected while using tools curated for their own use cases.

[Try the Jira Kanban template today](https://www.atlassian.com/software/jira/templates/kanban)

## Scrumban: Frequently asked questions

### How does Scrumban handle prioritization?

Because Scrumban doesn't require a Scrum Master, the team has balanced input into how they handle priorities on the Scrumban board. Typically, teams agree on assigning either a values-based ranking to each task (the higher the value, the higher the priority) or a risk-based system (the more impact it has on the deadline, the more crucial).

### Is Scrumban suitable for large-scale projects?

Absolutely. Since Scrumban delivers incremental progress, it allows teams to tackle large-scale projects whose scope naturally changes over time. The consistent delivery of output ensures teams complete increments of the large-scale project with every sprint.

### What are some common challenges teams face when adopting Scrumban?

The biggest challenge is always cultural. As with any organizational change, there will be resistance from those who are used to a different way of doing things. Getting the team to commit to the principles and structure of Scrumban will be the main challenge.

## Recommended for you

### Ready-made Jira templates

Browse our library of custom Jira templates for various teams, departments, and workflows.

[Go to Jira templates](https://www.atlassian.com/software/jira/templates)

### A comprehensive introduction to Jira

Use this step-by-step guide to discover essential features and the best practices to maximize your productivity.

[Go to Jira Product guide](https://www.atlassian.com/software/jira/guides/getting-started/introduction#what-is-jira-software)

### Understanding the Basics of Git

From beginners to advanced experts, use this guide to Git to learn the basics with helpful tutorials and tips.

[Learn more](https://www.atlassian.com/git)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**