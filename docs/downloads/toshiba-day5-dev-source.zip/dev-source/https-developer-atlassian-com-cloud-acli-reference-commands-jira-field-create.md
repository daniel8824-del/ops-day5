<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/jira-field-create -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Filter by keyword

- [acli](https://developer.atlassian.com/cloud/acli/reference/commands/)
- [admin](https://developer.atlassian.com/cloud/acli/reference/commands/admin/)

[admin auth](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth/)

[admin user](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user/)

- [feedback](https://developer.atlassian.com/cloud/acli/reference/commands/feedback/)
- [jira](https://developer.atlassian.com/cloud/acli/reference/commands/jira/)

[jira auth](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth/)

[jira board](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board/)

[jira dashboard](https://developer.atlassian.com/cloud/acli/reference/commands/jira-dashboard/)

[jira field](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field/)

- [jira-field-cancel-delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field-cancel-delete/)
- [create](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field-create/)
- [delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field-delete/)

[jira filter](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter/)

[jira project](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project/)

[jira sprint](https://developer.atlassian.com/cloud/acli/reference/commands/jira-sprint/)

[jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem/)

- [rovodev](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev/)

[rovodev auth](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev-auth/)

Last updated Oct 3, 2024

On This Page

- [acli jira field create](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field-create/#acli-jira-field-create)


## acli jira field create

Create a custom field in Jira.

```
Copy
1
acli jira field create [flags]
```

### Examples

```
Copy
1
2
3
4
5
6
7
8
9
# Create a text field
$ acli jira field create --name "Customer Name" --type "com.atlassian.jira.plugin.system.customfieldtypes:textfield"

# Create a select field with searcher
$ acli jira field create --name "Priority Level" --type "com.atlassian.jira.plugin.system.customfieldtypes:select" --searcherKey "com.atlassian.jira.plugin.system.customfieldtypes:multiselectsearcher"

# Create a field with description
$ acli jira field create --name "Release Date" --type "com.atlassian.jira.plugin.system.customfieldtypes:datepicker" --description "The planned release date for this feature"
```

### Options

```
Copy
1
2
3
4
5
6
      --description string   Description of the custom field
  -h, --help                 Show help for command
      --json                 Output in JSON format
      --name string          Name of the custom field
      --searcherKey string   Searcher key for the custom field
      --type string          Type of the custom field
```

### SEE ALSO

- [acli jira field](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field) \- Jira field commands.

Rate this page:

Unusable

Poor

Okay

Good

Excellent