<!-- source: https://docs.gitlab.com/ci/pipelines/downstream_pipelines_troubleshooting -->

/

* * *

# Troubleshooting downstream pipelines

## Trigger job fails and does not create multi-project pipeline [Permalink](https://docs.gitlab.com/ci/pipelines/downstream_pipelines_troubleshooting/\#trigger-job-fails-and-does-not-create-multi-project-pipeline "Permalink")

With multi-project pipelines, the trigger job fails and does not create the downstream pipeline if:

- The downstream project is not found.
- The user that creates the upstream pipeline does not have [permission](https://docs.gitlab.com/user/permissions/)
to create pipelines in the downstream project.
- The downstream pipeline targets a protected branch and the user does not have permission
to run pipelines against the protected branch. See [pipeline security for protected branches](https://docs.gitlab.com/ci/pipelines/#pipeline-security-on-protected-branches)
for more information.

To identify which user is having permission issues in the downstream project, you can check the trigger job using the following command in the [Rails console](https://docs.gitlab.com/administration/operations/rails_console/) and look at the `user_id` attribute.

ruby

```ruby
Ci::Bridge.find(<job_id>)
```

## Job in child pipeline is not created when the pipeline runs [Permalink](https://docs.gitlab.com/ci/pipelines/downstream_pipelines_troubleshooting/\#job-in-child-pipeline-is-not-created-when-the-pipeline-runs "Permalink")

If the parent pipeline is a [merge request pipeline](https://docs.gitlab.com/ci/pipelines/merge_request_pipelines/),
the child pipeline must [use `workflow:rules` or `rules` to ensure the jobs run](https://docs.gitlab.com/ci/pipelines/downstream_pipelines/#run-child-pipelines-with-merge-request-pipelines).

If no jobs in the child pipeline can run due to missing or incorrect `rules` configuration:

- The child pipeline fails to start.
- The parent pipeline’s trigger job fails with: `downstream pipeline can not be created, the resulting pipeline would have been empty. Review the` [`rules`](https://docs.gitlab.com/ci/yaml/#rules)`configuration for the relevant jobs.`

## Variable with `$` character does not get passed to a downstream pipeline properly [Permalink](https://docs.gitlab.com/ci/pipelines/downstream_pipelines_troubleshooting/\#variable-with--character-does-not-get-passed-to-a-downstream-pipeline-properly "Permalink")

You cannot use [`$$` to escape the `$` character in a CI/CD variable](https://docs.gitlab.com/ci/variables/job_scripts/#use-the--character-in-cicd-variables),
when [passing a CI/CD variable to a downstream pipeline](https://docs.gitlab.com/ci/pipelines/downstream_pipelines/#pass-cicd-variables-to-a-downstream-pipeline).
The downstream pipeline still treats the `$` as the start of a variable reference.

You can [Prevent CI/CD variable expansion](https://docs.gitlab.com/ci/variables/#allow-cicd-variable-expansion) when configuring
a variable in the UI, or use the [`variables:expand` keyword](https://docs.gitlab.com/ci/yaml/#variablesexpand) to
set a variable value to not be expanded. This variable can then be passed to the downstream pipeline
without the `$` being interpreted as a variable reference.

## `Ref is ambiguous` [Permalink](https://docs.gitlab.com/ci/pipelines/downstream_pipelines_troubleshooting/\#ref-is-ambiguous "Permalink")

You cannot trigger a multi-project pipeline with a tag when a branch exists with the same
name. The downstream pipeline fails to create with the error: `downstream pipeline can not be created, Ref is ambiguous`.

Only trigger multi-project pipelines with tag names that do not match branch names.

## `403 Forbidden` error when downloading a job artifact from an upstream pipeline [Permalink](https://docs.gitlab.com/ci/pipelines/downstream_pipelines_troubleshooting/\#403-forbidden-error-when-downloading-a-job-artifact-from-an-upstream-pipeline "Permalink")

In GitLab 15.9 and later, CI/CD job tokens are scoped to the project that the pipeline executes under. Therefore, the job token in a downstream pipeline cannot be used to access an upstream project by default.

To resolve this, [add the downstream project to the job token scope allowlist](https://docs.gitlab.com/ci/jobs/ci_job_token/#add-a-group-or-project-to-the-job-token-allowlist).

## Error: `needs:need pipeline should be a string` [Permalink](https://docs.gitlab.com/ci/pipelines/downstream_pipelines_troubleshooting/\#error-needsneed-pipeline-should-be-a-string "Permalink")

When using [`needs:pipeline:job`](https://docs.gitlab.com/ci/yaml/#needspipelinejob) with dynamic child pipelines,
you might receive this error:

```plaintext
Unable to run pipeline
- jobs:<job_name>:needs:need pipeline should be a string
```

This error occurs when a pipeline ID is parsed as an integer instead of a string.
To fix this, enclose the pipeline ID in quotes:

yaml

```yaml
rspec:
  needs:
    - pipeline: "$UPSTREAM_PIPELINE_ID"
      job: dependency-job
      artifacts: true
```

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**