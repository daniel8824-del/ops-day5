<!-- source: https://support.atlassian.com/atlassian-rovo-mcp-server/docs/connect-rovo-to-gemini-via-google-cloud-marketplace -->

[Skip to main content](https://support.atlassian.com/atlassian-rovo-mcp-server/docs/connect-rovo-to-gemini-via-google-cloud-marketplace#maincontent)

# Connect Rovo to Gemini via Google Cloud Marketplace

The recommended way to connect Rovo to Google Gemini is through the [Atlassian Rovo Agent listing on Google Cloud Marketplace](https://console.cloud.google.com/marketplace/product/gcp-ec12b440/atlassian-rovo-agent "https://console.cloud.google.com/marketplace/product/gcp-ec12b440/atlassian-rovo-agent"). This uses the A2A (Agent-to-Agent) protocol that lets external AI clients of agents (like Google Gemini) securely connect to Rovo and act on a user’s behalf. The marketplace handles client registration and authentication setup automatically - you do not need to configure OAuth credentials manually.

### Before you begin

- Make sure you have an Atlassian Cloud site with Rovo.

- Make sure your organization admin has enabled A2A connections in Admin Hub.

- Make sure you have access to Google Gemini Enterprise.


### Step 1: Open the marketplace listing

Go to the [Atlassian Rovo Agent on Google Cloud Marketplace](https://console.cloud.google.com/marketplace/product/gcp-ec12b440/atlassian-rovo-agent "https://console.cloud.google.com/marketplace/product/gcp-ec12b440/atlassian-rovo-agent").

### Step 2: Install the Atlassian Rovo Agent

Select the option to install or activate the Atlassian Rovo Agent from the marketplace listing. The marketplace handles Dynamic Client Registration (DCR) automatically.

### Step 3: Authorize with Atlassian

When prompted, sign in with your Atlassian account and complete the OAuth consent flow. You will be asked to grant the following permissions:

- `read:me` — Read your basic profile information

- `offline_access` — Maintain access when you are not actively using Gemini

- `full_access:chat:rovo` — Allow Gemini to interact with Rovo on your behalf


A2A connections respect your organization's AI-enabled apps policy. If Rovo is disabled for an app or product in Admin Hub, A2A clients (including Gemini) will be blocked from accessing that data.

### Step 4: Start using Rovo in Gemini

Once authorized, you can interact with Rovo directly from Gemini Enterprise. For example, you can:

- Ask about project status, blockers, and ownership across Jira and Confluence.

- Create, update, and manage Jira issues directly from Gemini.

- Search for Confluence pages, decisions, and documentation.

- Get sprint summaries, reports, and executive updates.


### What about other agents?

A2A is an open protocol. Gemini is currently the only supported A2A launch partner. Support for additional A2A-compatible agents will be announced separately.

Was this helpful?

Yes

No

It wasn't accurateIt wasn't clearIt wasn't relevant

Provide feedback about this article

## Still need help?

The Atlassian Community is here for you.

[Ask the Community](https://community.atlassian.com/t5/custom/page/page-id/create-post-step-1?add-tags=atlassian-rovo-mcp-server,Cloud)