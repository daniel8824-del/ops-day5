<!-- source: https://docs.gitlab.com/user/project/merge_requests/revert_changes -->

/

* * *

# Revert changes

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

Mistakes happen in code. Version control makes it possible to fix those mistakes by reverting them.

When you revert a commit, you create a new commit (a revert commit) that reverses the
bad change, rather than erasing the existence of the problem from your project’s history. Revert commits
provide a clear audit trail, rather than a gap where the previous commit was. The revert commit
follows your project’s access controls and processes, and:

- Removes the lines added in the original commit.
- Restores the lines removed in the original commit.
- Restores the lines modified in the original commit to their previous state.

Reverts are not limited to just commits. If the bad change spans more than one commit, consider
reverting all changes from the merge request, rather than reverting commit by commit. This approach
provides a cleaner audit trail.

## Revert a merge request [Permalink](https://docs.gitlab.com/user/project/merge_requests/revert_changes/\#revert-a-merge-request "Permalink")

After a merge request merges, you can revert all changes in the merge request.

Prerequisites:

- You must have a role for the project that allows you to edit merge requests, and add
code to the repository.

- Your project must use the [merge method](https://docs.gitlab.com/user/project/merge_requests/methods/#fast-forward-merge) **Merge Commit**,
set in your project’s **Settings** \> **Merge requests**.

In GitLab 16.9 and later, you can revert fast-forwarded commits from the GitLab UI if either:

  - The commits are squashed, or
  - The merge request contains a single commit.

For more information, see [issue 22236](https://gitlab.com/gitlab-org/gitlab/-/issues/22236).

To revert merge request `Example`:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Code** \> **Merge requests**.
3. From the secondary menu, select **Merged**, and select your merge request (here, `Example`).
4. Scroll to the merge request reports area, and find the report showing the
**Merged by** information.
5. Select **Revert**.
6. In **Revert in branch**, select the branch to revert your changes into.
7. To revert immediately, without a merge request:
1. Clear **Start a new merge request**.
2. Select **Revert**, and the revert of `Example` is complete.
8. To review the revert in a new merge request instead of reverting immediately,
select **Start a new merge request**, then:
1. Fill in the fields for your revert merge request, then select **Create merge request**.
2. When the merge request merges, the revert of `Example` is complete.

## Revert a commit [Permalink](https://docs.gitlab.com/user/project/merge_requests/revert_changes/\#revert-a-commit "Permalink")

You can revert any commit in a repository into either:

- The current branch.
- A new merge request.

Prerequisites:

- Your role for the project must allow you to edit merge requests, and add
code to the repository.
- The commit must not have already been reverted, as the **Revert** option is not
shown in this case.

To do this:

1. In the top bar, select **Search or go to** and find your project.
2. If you know the merge request that contains the commit:
1. In the left sidebar, select **Code** \> **Merge requests**, then select your merge request.
2. Select **Commits**, then select the title of the commit you want to revert.
      This displays the commit in the context of your merge request.
3. Below the secondary menu, GitLab shows the message **Viewing commit `00001111`**,
      where `00001111` is the hash of the commit. Select the commit hash to show
      the commit’s page.
3. If you don’t know the merge request the commit originated from:
1. In the left sidebar, select **Code** \> **Commits**.
2. Select the title of the commit to display full information about the commit.
4. In the upper-right corner, select **Options**, then select **Revert**.
5. In **Revert in branch**, select the branch to revert your changes into.
6. To revert immediately, without a merge request:
1. Clear **Start a new merge request**.
2. Select **Revert**.
7. To review the revert in a new merge request instead of reverting immediately,
select **Start a new merge request**, then:
1. Fill in the fields for your revert merge request, then select **Create merge request**.
2. When the merge request merges, the commit revert is complete.

### Revert a merge commit to a different parent commit [Permalink](https://docs.gitlab.com/user/project/merge_requests/revert_changes/\#revert-a-merge-commit-to-a-different-parent-commit "Permalink")

When you revert a merge commit, the branch you merged to (often `main`) is always the
first parent. To revert a merge commit to a different parent, you must revert the commit from
the command line, see [revert and undo changes with Git](https://docs.gitlab.com/topics/git/undo/#revert-a-merge-commit-to-a-different-parent).

## Redact text from repository [Permalink](https://docs.gitlab.com/user/project/merge_requests/revert_changes/\#redact-text-from-repository "Permalink")

For more information on [redacting text](https://docs.gitlab.com/user/project/repository/repository_size/#redact-text-from-repository) from a repository and other techniques to remove data, see
[repository size](https://docs.gitlab.com/user/project/repository/repository_size/).

## Related topics [Permalink](https://docs.gitlab.com/user/project/merge_requests/revert_changes/\#related-topics "Permalink")

- [Official `git revert` documentation](https://git-scm.com/docs/git-revert)
- [Undo changes by using Git](https://docs.gitlab.com/topics/git/undo/)
- [Revert a commit](https://docs.gitlab.com/api/commits/#revert-a-commit) with the Commits API
- How changelogs [handle reverted commits](https://docs.gitlab.com/user/project/changelogs/#reverted-commit-handling)

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**