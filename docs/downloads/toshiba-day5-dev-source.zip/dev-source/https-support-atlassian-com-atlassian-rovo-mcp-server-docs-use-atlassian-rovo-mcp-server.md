<!-- source: https://support.atlassian.com/atlassian-rovo-mcp-server/docs/use-atlassian-rovo-mcp-server -->

[Skip to main content](https://support.atlassian.com/atlassian-rovo-mcp-server/docs/use-atlassian-rovo-mcp-server/#maincontent)

# Use Atlassian Rovo MCP Server

The Atlassian Rovo Model Context Protocol (MCP) Server is a cloud-hosted gateway that allows tools like AI assistants and developer environments to securely access Jira, Compass, and Confluence Cloud data. It enables supported clients to perform both read and write operations, such as searching for issues, summarizing pages, or bulk-creating new content, all via natural language commands.

* * *

## Disclaimer

MCP clients can perform actions in Jira, Confluence, and Compass with your existing permissions. Use least privilege, review high‑impact changes before confirming, and monitor audit logs for unusual activity.

Learn more: [MCP Clients - Understanding the potential security risks](https://www.atlassian.com/blog/artificial-intelligence/mcp-risk-awareness "https://www.atlassian.com/blog/artificial-intelligence/mcp-risk-awareness")

* * *

Need help? [Contact Atlassian Support](http://support.atlassian.com/ "http://support.atlassian.com/") or visit the [getting started guide](https://support.atlassian.com/rovo/docs/getting-started-with-the-atlassian-remote-mcp-server/ "https://support.atlassian.com/rovo/docs/getting-started-with-the-atlassian-remote-mcp-server/").

- [Learn about Atlassian's Rovo MCP Server beta, supported clients, setup, access, data security, and more. \\
\\
View topic](https://support.atlassian.com/atlassian-rovo-mcp-server/docs/getting-started-with-the-atlassian-remote-mcp-server/)
- [Secure access to Atlassian cloud data with Rovo MCP Server using OAuth 2.1 tokens.\\
\\
View topic](https://support.atlassian.com/atlassian-rovo-mcp-server/docs/authentication-and-authorization/)
- [Secure access to Atlassian cloud data with Rovo MCP Server using OAuth 2.1 tokens.\\
\\
View topic](https://support.atlassian.com/atlassian-rovo-mcp-server/docs/configuring-oauth-2-1/)
- [Secure access to Atlassian cloud data with Rovo MCP Server using personal API tokens.\\
\\
View topic](https://support.atlassian.com/atlassian-rovo-mcp-server/docs/configuring-authentication-via-api-token/)
- [Learn more about the tools that the Atlassian Rovo MCP Server supports across Atlassian apps.\\
\\
View topic](https://support.atlassian.com/atlassian-rovo-mcp-server/docs/supported-tools/)
- [Learn about Atlassian's Rovo MCP Server's supported clients, as well as the setup requirements for your environment.\\
\\
View topic](https://support.atlassian.com/atlassian-rovo-mcp-server/docs/setting-up-clients/)
- [Connect IDEs like VS Code to the Atlassian Remote MCP Server using the mcp-remote tool.\\
\\
View topic](https://support.atlassian.com/atlassian-rovo-mcp-server/docs/setting-up-ides/)
- [Setup steps for smooth integration with various tools.\\
\\
View topic](https://support.atlassian.com/atlassian-rovo-mcp-server/docs/using-with-other-supported-mcp-clients/)
- [Find and retrieve info from Jira and Confluence efficiently with Atlassian Remote MCP Server and Rovo's search and fetch features. \\
\\
View topic](https://support.atlassian.com/atlassian-rovo-mcp-server/docs/using-rovo-search-and-fetch-in-the-atlassian-remote-mcp-server/)
- [Troubleshoot your MCP client setup with Atlassian. Validate connections, resolve issues, and get back on track.\\
\\
View topic](https://support.atlassian.com/atlassian-rovo-mcp-server/docs/troubleshooting-and-verifying-your-setup/)
- [Connect Google Gemini to Atlassian Rovo using secure A2A integration, so Gemini can search, summarize, and act on your Jira and Confluence work.\\
\\
View topic](https://support.atlassian.com/atlassian-rovo-mcp-server/docs/connect-rovo-to-gemini-via-google-cloud-marketplace/)

Was this helpful?

Yes

No

It wasn't accurateIt wasn't clearIt wasn't relevant

Provide feedback about this article

## Still need help?

The Atlassian Community is here for you.

[Ask the Community](https://community.atlassian.com/t5/custom/page/page-id/create-post-step-1?add-tags=atlassian-rovo-mcp-server,Cloud)