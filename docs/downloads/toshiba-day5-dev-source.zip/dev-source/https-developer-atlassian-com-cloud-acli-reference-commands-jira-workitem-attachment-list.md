<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-attachment-list -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Filter by keyword

- [acli](https://developer.atlassian.com/cloud/acli/reference/commands/)
- [admin](https://developer.atlassian.com/cloud/acli/reference/commands/admin/)

[admin auth](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth/)

[admin user](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user/)

- [feedback](https://developer.atlassian.com/cloud/acli/reference/commands/feedback/)
- [jira](https://developer.atlassian.com/cloud/acli/reference/commands/jira/)

[jira auth](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth/)

[jira board](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board/)

[jira dashboard](https://developer.atlassian.com/cloud/acli/reference/commands/jira-dashboard/)

[jira field](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field/)

[jira filter](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter/)

[jira project](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project/)

[jira sprint](https://developer.atlassian.com/cloud/acli/reference/commands/jira-sprint/)

[jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem/)

- [archive](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-archive/)
- [assign](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-assign/)
- [attachment-delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-attachment-delete/)
- [attachment-list](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-attachment-list/)
- [clone](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-clone/)
- [comment-create](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-create/)
- [comment-delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-delete/)
- [comment-list](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-list/)
- [comment-update](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-update/)
- [comment-visibility](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-visibility/)
- [create](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-create/)
- [create-bulk](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-create-bulk/)
- [delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-delete/)
- [edit](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-edit/)
- [link](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-link/)
- [search](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-search/)
- [transition](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-transition/)
- [unarchive](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-unarchive/)
- [view](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-view/)
- [watcher-remove](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-watcher-remove/)

- [rovodev](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev/)

[rovodev auth](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev-auth/)

Last updated Oct 3, 2024

On This Page

- [acli jira workitem attachment list](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-attachment-list/#acli-jira-workitem-attachment-list)


## acli jira workitem attachment list

List all the attachments of a workitem.

```
Copy
1
acli jira workitem attachment list [flags]
```

### Examples

```
Copy
1
2
3
# List work item attachment
$ acli jira workitem attachment list --key TEST-123
```

### Options

```
Copy
1
2
3
  -h, --help         Show help for command
      --json         Output in JSON format
      --key string   Workitem key to list the attachments for
```

### SEE ALSO

- [acli jira workitem attachment](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-attachment) \- Work item attachments commands.

Rate this page:

Unusable

Poor

Okay

Good

Excellent