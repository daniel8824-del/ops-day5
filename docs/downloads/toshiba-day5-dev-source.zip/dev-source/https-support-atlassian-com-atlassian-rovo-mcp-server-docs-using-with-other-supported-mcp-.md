<!-- source: https://support.atlassian.com/atlassian-rovo-mcp-server/docs/using-with-other-supported-mcp-clients -->

[Skip to main content](https://support.atlassian.com/atlassian-rovo-mcp-server/docs/using-with-other-supported-mcp-clients/#maincontent)

# Using with other supported MCP clients

[← Back to the getting started guide](https://support.atlassian.com/rovo/docs/getting-started-with-the-atlassian-remote-mcp-server/ "https://support.atlassian.com/rovo/docs/getting-started-with-the-atlassian-remote-mcp-server/")

After **30th June 2026**, usage of `https://mcp.atlassian.com/v1/sse` as a server endpoint will no longer be supported.

We recommend updating any configured custom clients to point to `/mcp`: `https://mcp.atlassian.com/v1/mcp/authv2`

The Atlassian Rovo MCP Server also supports other MCP-compatible tools that offer automation and workflow integrations. These may include CRM platforms, automation services, or custom-built tools that implement the MCP protocol and support OAuth 2.1 authentication.

## Before you begin

Make sure your client:

- Can connect to a remote MCP server

- Supports OAuth 2.1 authentication

- Allows configuration of custom MCP server URLs


## Configuration steps

1. In your client, configure the server URL:









`https://mcp.atlassian.com/v1/mcp/authv2`

2. Begin the connection process and complete the OAuth login when prompted

3. Authorize the client to access your Atlassian cloud site (Jira and/or Confluence)

4. Enable the specific Atlassian apps (for example, Jira or Confluence) that you want the client to access

5. Follow any additional setup steps specific to your client’s interface or documentation


## Tips for a successful setup

- Site admins might need to install the Atlassian MCP App first if “User Installed Apps“ is blocked

[Manage your organization's Marketplace and third-party apps](https://support.atlassian.com/security-and-access-policies/docs/manage-your-users-third-party-apps/)

- Ensure that any localhost-based redirect URIs used in the OAuth process are supported by your environment

- If you encounter issues with a third-party client, refer to its documentation for OAuth or proxy configuration guidance


## Example actions you can try

- Search Jira: “Find all issues assigned to me in the last 7 days”

- Create a Confluence page: “Create a page titled ‘Engineering Roadmap Q4’”

- Cross-reference: “Link the two most recent bugs to the 'Sprint 45' page”


* * *

## Disclaimer

MCP clients can perform actions in Jira, Confluence, and Compass with your existing permissions. Use least privilege, review high‑impact changes before confirming, and monitor audit logs for unusual activity.

Learn more: [MCP Clients - Understanding the potential security risks](https://www.atlassian.com/blog/artificial-intelligence/mcp-risk-awareness "https://www.atlassian.com/blog/artificial-intelligence/mcp-risk-awareness")

* * *

Need help? [Contact Atlassian Support](http://support.atlassian.com/ "http://support.atlassian.com/") or visit the [getting started guide](https://support.atlassian.com/rovo/docs/getting-started-with-the-atlassian-remote-mcp-server/ "https://support.atlassian.com/rovo/docs/getting-started-with-the-atlassian-remote-mcp-server/").

Was this helpful?

Yes

No

It wasn't accurateIt wasn't clearIt wasn't relevant

Provide feedback about this article

## Still need help?

The Atlassian Community is here for you.

[Ask the Community](https://community.atlassian.com/t5/custom/page/page-id/create-post-step-1?add-tags=atlassian-rovo-mcp-server,Cloud)