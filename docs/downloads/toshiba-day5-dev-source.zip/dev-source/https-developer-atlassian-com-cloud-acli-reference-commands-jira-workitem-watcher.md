<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-watcher -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Last updated Oct 3, 2024

On This Page

- [acli jira workitem watcher](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-watcher/#acli-jira-workitem-watcher)


## acli jira workitem watcher

Work item watcher commands.

### Options

```
Copy
1
  -h, --help   Show help for command
```

### SEE ALSO

- [acli jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem) \- Jira work item commands.
- [acli jira workitem watcher remove](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-watcher-remove) \- Remove a watcher from an issue

Rate this page:

Unusable

Poor

Okay

Good

Excellent