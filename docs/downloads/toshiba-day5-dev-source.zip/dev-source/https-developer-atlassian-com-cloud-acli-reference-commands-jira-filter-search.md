<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter-search -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Filter by keyword

- [acli](https://developer.atlassian.com/cloud/acli/reference/commands/)
- [admin](https://developer.atlassian.com/cloud/acli/reference/commands/admin/)

[admin auth](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth/)

[admin user](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user/)

- [feedback](https://developer.atlassian.com/cloud/acli/reference/commands/feedback/)
- [jira](https://developer.atlassian.com/cloud/acli/reference/commands/jira/)

[jira auth](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth/)

[jira board](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board/)

[jira dashboard](https://developer.atlassian.com/cloud/acli/reference/commands/jira-dashboard/)

[jira field](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field/)

[jira filter](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter/)

- [add-favourite](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter-add-favourite/)
- [change-owner](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter-change-owner/)
- [list](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter-list/)
- [search](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter-search/)

[jira project](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project/)

[jira sprint](https://developer.atlassian.com/cloud/acli/reference/commands/jira-sprint/)

[jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem/)

- [rovodev](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev/)

[rovodev auth](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev-auth/)

Last updated Oct 3, 2024

On This Page

- [acli jira filter search](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter-search/#acli-jira-filter-search)


## acli jira filter search

Searches for Jira filters.

### Synopsis

Searches for Jira filters. When multiple search parameters are present, the search ensures that all the parameters are satisfied.

```
Copy
1
acli jira filter search [flags]
```

### Examples

```
Copy
1
2
3
4
5
6
7
# Searches for the Jira filters
$ acli jira filter search
$ acli jira filter search --paginate --csv
$ acli jira filter search --limit 5 --json

# Filter dashboards by owner and project name
$ acli jira filter search --owner user@atlassian.com --name 'report'
```

### Options

```
Copy
1
2
3
4
5
6
7
      --csv            Generate a CSV output
  -h, --help           Show help for command
      --json           Generate a JSON output
  -l, --limit int      Maximum number of filters to fetch (default 30)
  -n, --name string    String used to perform a case-insensitive partial match with the filter name
  -e, --owner string   Searches for the filters that are owned by the provided email
      --paginate       Fetch all filters by paginating through the results
```

### SEE ALSO

- [acli jira filter](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter) \- Jira filter commands.

Rate this page:

Unusable

Poor

Okay

Good

Excellent