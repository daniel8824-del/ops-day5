<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/jira-board-search -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Filter by keyword

- [acli](https://developer.atlassian.com/cloud/acli/reference/commands/)
- [admin](https://developer.atlassian.com/cloud/acli/reference/commands/admin/)

[admin auth](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth/)

[admin user](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user/)

- [feedback](https://developer.atlassian.com/cloud/acli/reference/commands/feedback/)
- [jira](https://developer.atlassian.com/cloud/acli/reference/commands/jira/)

[jira auth](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth/)

[jira board](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board/)

- [list-sprints](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board-list-sprints/)
- [search](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board-search/)

[jira dashboard](https://developer.atlassian.com/cloud/acli/reference/commands/jira-dashboard/)

[jira field](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field/)

[jira filter](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter/)

[jira project](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project/)

[jira sprint](https://developer.atlassian.com/cloud/acli/reference/commands/jira-sprint/)

[jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem/)

- [rovodev](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev/)

[rovodev auth](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev-auth/)

Last updated Oct 3, 2024

On This Page

- [acli jira board search](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board-search/#acli-jira-board-search)


## acli jira board search

Search through all the boards

```
Copy
1
acli jira board search [flags]
```

### Options

```
Copy
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
      --csv              Output in CSV format
      --filter string    Filter ID. Filters results to boards that are relevant to a filter. Not supported for next-gen boards.

  -h, --help             Show help for command
      --json             Output in JSON format
      --limit int        Limit the number of boards, if the limit is > than the page size apply pagination. (default 50)
      --name string      Filters results to boards that match or partially match the specified name.

      --orderBy string   Ordering of the results by a given field. If not provided, values will not be sorted. Valid values: name, -name, +name

      --paginate         Loads all boards and output as they become available.
      --private          Boolean. Appends private boards to the end of the list. The name and type fields are excluded for security reasons. Default is false.

      --project string   Project key. Filters results to boards that are relevant to a project. Relevance means that the jql filter defined in the board contains a reference to a project.

      --type string      Filters results to boards of the specified types. Valid values: scrum, kanban, simple.

```

### SEE ALSO

- [acli jira board](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board) \- Jira board commands.

Rate this page:

Unusable

Poor

Okay

Good

Excellent