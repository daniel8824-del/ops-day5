<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/jira-board-list-sprints -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Filter by keyword

- [acli](https://developer.atlassian.com/cloud/acli/reference/commands/)
- [admin](https://developer.atlassian.com/cloud/acli/reference/commands/admin/)

[admin auth](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth/)

[admin user](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user/)

- [feedback](https://developer.atlassian.com/cloud/acli/reference/commands/feedback/)
- [jira](https://developer.atlassian.com/cloud/acli/reference/commands/jira/)

[jira auth](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth/)

[jira board](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board/)

- [list-sprints](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board-list-sprints/)
- [search](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board-search/)

[jira dashboard](https://developer.atlassian.com/cloud/acli/reference/commands/jira-dashboard/)

[jira field](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field/)

[jira filter](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter/)

[jira project](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project/)

[jira sprint](https://developer.atlassian.com/cloud/acli/reference/commands/jira-sprint/)

[jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem/)

- [rovodev](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev/)

[rovodev auth](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev-auth/)

Last updated Oct 3, 2024

On This Page

- [acli jira board list-sprints](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board-list-sprints/#acli-jira-board-list-sprints)


## acli jira board list-sprints

Get all sprints

```
Copy
1
acli jira board list-sprints [flags]
```

### Examples

```
Copy
1
2
3
4
5
6
7
8
9
10
11
12
# Get all sprints
$ acli jira board list-sprints --id 123

# Get all sprints with state filters
$ acli jira board list-sprints --id 123 --state active,closed

# Get all sprints and output in JSON format
$ acli jira board list-sprints --id 123 --json

# Get all sprints and output in CSV format
$ acli jira board list-sprints --id 123 --csv
```

### Options

```
Copy
1
2
3
4
5
6
7
8
      --csv            Output in CSV format
  -h, --help           Show help for command
      --id string      The ID of the board that contains the requested sprints.
      --json           Output in JSON format
      --limit int      Limit the number of sprints, if the limit is > than the page size apply pagination. (default 50)
      --paginate       Loads all sprints and output as they become available.
      --state string   Filters results to sprints in specified states. Valid values: future, active, closed. You can define multiple states separated by commas, e.g. active,closed

```

### SEE ALSO

- [acli jira board](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board) \- Jira board commands.

Rate this page:

Unusable

Poor

Okay

Good

Excellent