<!-- source: https://support.atlassian.com/atlassian-rovo-mcp-server/docs/setting-up-clients -->

[Skip to main content](https://support.atlassian.com/atlassian-rovo-mcp-server/docs/setting-up-clients/#maincontent)

# Setting up clients

[← Back to the getting started guide](https://support.atlassian.com/rovo/docs/getting-started-with-the-atlassian-remote-mcp-server/ "https://support.atlassian.com/rovo/docs/getting-started-with-the-atlassian-remote-mcp-server/")

After **30th June 2026**, usage of `https://mcp.atlassian.com/v1/sse` as a server endpoint will no longer be supported.

We recommend updating any configured custom clients to point to `/mcp`: `https://mcp.atlassian.com/v1/mcp/authv2`

## Before you begin

Before connecting to the Atlassian Rovo MCP Server, review the setup requirements for your environment:

- An **Atlassian Cloud site** with Jira, Compass, and/or Confluence

- Access to **the client of choice**

- A modern browser to complete the authorization flow, if using OAuth 2.1

- An [API token](https://id.atlassian.com/manage-profile/security/api-tokens?autofillToken&expiryDays=max&appId=mcp&selectedScopes=all "https://id.atlassian.com/manage-profile/security/api-tokens?autofillToken&expiryDays=max&appId=mcp&selectedScopes=all"), if your admin has [enabled authentication via API tokens](https://support.atlassian.com/security-and-access-policies/docs/control-atlassian-rovo-mcp-server-settings/ "https://support.atlassian.com/security-and-access-policies/docs/control-atlassian-rovo-mcp-server-settings/")


If your organization admin has disabled authentication via API token, MCP clients won’t be able to connect and will need to use OAuth 2.1 instead.

## Supported clients

The Atlassian Rovo MCP Server supports several clients, including:

- [OpenAI ChatGPT](https://platform.openai.com/docs/overview "https://platform.openai.com/docs/overview")

- [Claude](https://www.anthropic.com/claude "https://www.anthropic.com/claude")

- [Docker](http://mcp.docker.com/ "http://mcp.docker.com")

- [Google Gemini](https://github.com/google-gemini/gemini-cli/blob/main/docs/tools/mcp-server.md "https://github.com/google-gemini/gemini-cli/blob/main/docs/tools/mcp-server.md")

- [Amazon Quick Suite](https://docs.aws.amazon.com/quicksuite/latest/userguide/mcp-integration.html "https://docs.aws.amazon.com/quicksuite/latest/userguide/mcp-integration.html")


Depending on the client you're using, the setup process may vary. We recommending checking the setup procedure of your client of choice, or even use the client’s AI capabilities, to set up Atlassian Rovo MCP server.

* * *

## Disclaimer

MCP clients can perform actions in Jira, Confluence, and Compass with your existing permissions. Use least privilege, review high‑impact changes before confirming, and monitor audit logs for unusual activity.

Learn more: [MCP Clients - Understanding the potential security risks](https://www.atlassian.com/blog/artificial-intelligence/mcp-risk-awareness "https://www.atlassian.com/blog/artificial-intelligence/mcp-risk-awareness")

* * *

Need help? [Contact Atlassian Support](http://support.atlassian.com/ "http://support.atlassian.com/") or visit the [getting started guide](https://support.atlassian.com/rovo/docs/getting-started-with-the-atlassian-remote-mcp-server/ "https://support.atlassian.com/rovo/docs/getting-started-with-the-atlassian-remote-mcp-server/").

Was this helpful?

Yes

No

It wasn't accurateIt wasn't clearIt wasn't relevant

Provide feedback about this article

## Still need help?

The Atlassian Community is here for you.

[Ask the Community](https://community.atlassian.com/t5/custom/page/page-id/create-post-step-1?add-tags=atlassian-rovo-mcp-server,Cloud)