<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-link-create -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Last updated Oct 3, 2024

On This Page

- [acli jira workitem link create](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-link-create/#acli-jira-workitem-link-create)


## acli jira workitem link create

Create links between work items.

```
Copy
1
acli jira workitem link create [flags]
```

### Examples

```
Copy
1
2
3
4
5
6
7
8
9
# Create a link between two work items
$ acli jira workitem link create --out KEY-123 --in KEY-456 --type Blocks

# Create multiple links from a JSON file
$ acli jira workitem link create --from-json links.json

# Generate an example JSON input structure
$ acli jira workitem link create --generate-json
```

### Options

```
Copy
1
2
3
4
5
6
7
8
9
      --from-csv string    Provide the input as a comma-separated table, where the first column is outward work item IDs, the second column is inward work item IDs, and the third column is linking type. The first row is ignored being the description.
      --from-json string   Read a JSON file for mapping work items, linking work items, and linking types
      --generate-json      Prints an example JSON structure to be used with --from-json
  -h, --help               Show help for command
      --ignore-errors      Ignore the errors and continue with the next work item
      --in string          Inward work item ID.
      --out string         Outward work item ID.
      --type string        Work items linking type. Accepts outward descriptions
      --yes                Confirm link creation without prompting
```

### SEE ALSO

- [acli jira workitem link](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-link) \- Link work items commands.

Rate this page:

Unusable

Poor

Okay

Good

Excellent