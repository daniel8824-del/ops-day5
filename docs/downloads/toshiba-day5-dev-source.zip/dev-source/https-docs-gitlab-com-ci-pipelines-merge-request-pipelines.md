<!-- source: https://docs.gitlab.com/ci/pipelines/merge_request_pipelines -->

/

* * *

# Merge request pipelines

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

You can configure your pipeline to run every time you make changes to the
source branch in a merge request. This type of pipeline is called a merge request pipeline.

These pipelines run when you:

- Create a new merge request from a source branch that has one or more commits.
- Push a new commit to the source branch for a merge request.
- Go to the **Pipelines** tab in a merge request and select **Run pipeline**.

Merge request pipelines:

- Run on the contents of the source branch only and ignore the content of the target branch.
- Display a `merge request` label in pipeline lists.

To run a pipeline that tests the result of merging the source and target branches together,
use [merged results pipelines](https://docs.gitlab.com/ci/pipelines/merged_results_pipelines/).

## Prerequisites [Permalink](https://docs.gitlab.com/ci/pipelines/merge_request_pipelines/\#prerequisites "Permalink")

To use merge request pipelines:

- Your project’s `.gitlab-ci.yml` file must include job rules or workflow rules that match `CI_PIPELINE_SOURCE == "merge_request_event"`.
- You must have the Developer, Maintainer, or Owner role for the source project to run a merge request pipeline.
- Your repository must be a GitLab repository, not an [external repository](https://docs.gitlab.com/ci/ci_cd_for_external_repos/).

## Configure merge request pipelines [Permalink](https://docs.gitlab.com/ci/pipelines/merge_request_pipelines/\#configure-merge-request-pipelines "Permalink")

To configure merge request pipelines, you must configure jobs in your
`.gitlab-ci.yml` file to run when `CI_PIPELINE_SOURCE` equals `merge_request_event`.

Rules defined in `include:` (for example, with `include:component`) do not satisfy
this requirement. You must define matching `rules:` or `workflow: rules` directly
in `.gitlab-ci.yml`.

You can configure individual jobs with `rules`,
or use `workflow: rules` to control the entire pipeline.

### Configure individual jobs [Permalink](https://docs.gitlab.com/ci/pipelines/merge_request_pipelines/\#configure-individual-jobs "Permalink")

Use the [`rules`](https://docs.gitlab.com/ci/yaml/#rules) keyword to configure individual jobs to run in
merge request pipelines. For example:

yaml

```yaml
job1:
  script:
    - echo "This job runs in merge request pipelines"
  rules:
    - if: $CI_PIPELINE_SOURCE == "merge_request_event"
```

You can also control when jobs run based on file changes:

yaml

```yaml
test:
  script:
    - echo "This job always runs in merge request pipelines"
  rules:
    - if: $CI_PIPELINE_SOURCE == "merge_request_event"

lint:
  script:
    - echo "This job runs only when JavaScript files change"
  rules:
    - if: $CI_PIPELINE_SOURCE == "merge_request_event"
      changes:
        - "*.js"
```

### Configure the entire pipeline [Permalink](https://docs.gitlab.com/ci/pipelines/merge_request_pipelines/\#configure-the-entire-pipeline "Permalink")

Use the [`workflow: rules`](https://docs.gitlab.com/ci/yaml/#workflowrules) keyword
to configure all jobs in a pipeline to run in merge request pipelines.
For example:

yaml

```yaml
workflow:
  rules:
    - if: $CI_PIPELINE_SOURCE == "merge_request_event"

job1:
  script:
    - echo "This job runs in merge request pipelines"
```

For more `workflow` examples, see:

- [Switch between branch pipelines and merge request pipelines](https://docs.gitlab.com/ci/yaml/workflow/#switch-between-branch-pipelines-and-merge-request-pipelines)
- [Git Flow with merge request pipelines](https://docs.gitlab.com/ci/yaml/workflow/#git-flow-with-merge-request-pipelines)

To [use security scanning tools with merge request pipelines](https://docs.gitlab.com/user/application_security/detect/security_configuration/#use-security-scanning-tools-with-merge-request-pipelines),
use the CI/CD variable `AST_ENABLE_MR_PIPELINES` or the `latest` template edition.

## Run a merge request pipeline with custom inputs [Permalink](https://docs.gitlab.com/ci/pipelines/merge_request_pipelines/\#run-a-merge-request-pipeline-with-custom-inputs "Permalink")

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/547861) in GitLab 18.11.

If your `.gitlab-ci.yml` defines [pipeline inputs](https://docs.gitlab.com/ci/inputs/), you can customize input values when
you manually run a new merge request pipeline. You can also set [CI/CD variables](https://docs.gitlab.com/ci/variables/) in the same form.

Prerequisites:

- Your `.gitlab-ci.yml` file must be [configured for merge request pipelines](https://docs.gitlab.com/ci/pipelines/merge_request_pipelines/#configure-merge-request-pipelines).
- Your `.gitlab-ci.yml` file must also define a `spec: inputs` section.
- You must have at least the Developer role for the source project.

To run a merge request pipeline with custom inputs:

1. In the left sidebar, select **Search or go to** and find your project.
2. Select **Code** \> **Merge requests** and open your merge request.
3. Select the **Pipelines** tab.
4. Select the **Run pipeline** dropdown list (chevron-down) and
choose **Run pipeline with modified values**.
5. The new pipeline form opens and is pre-filled with the merge request’s source branch.
Modify the input values and set any CI/CD variables as needed.
6. Select **Run pipeline**.

## Use with forked projects [Permalink](https://docs.gitlab.com/ci/pipelines/merge_request_pipelines/\#use-with-forked-projects "Permalink")

External contributors who work in forks can’t create pipelines in the parent project.

A merge request from a fork that is submitted to the parent project triggers a
pipeline that:

- Is created and runs in the fork (source) project, not the parent (target) project.
- Uses the fork project’s CI/CD configuration, resources, and project CI/CD variables.

Pipelines for forks display with the **fork** badge in the parent project.

### Run pipelines in the parent project [Permalink](https://docs.gitlab.com/ci/pipelines/merge_request_pipelines/\#run-pipelines-in-the-parent-project "Permalink")

Project members in the parent project can trigger a merge request pipeline
for a merge request submitted from a fork project. This pipeline:

- Is created and runs in the parent (target) project, not the fork (source) project.
- Uses the CI/CD configuration present in the fork project’s branch.
- Uses the parent project’s CI/CD settings, resources, and project CI/CD variables.
- Uses the permissions of the parent project member that triggers the pipeline.

Run pipelines in fork project MRs to ensure that the post-merge pipeline passes in
the parent project. Additionally, if you do not trust the fork project’s runner,
running the pipeline in the parent project uses the parent project’s trusted runners.

Fork merge requests can contain malicious code that tries to steal secrets in the parent project
when the pipeline runs, even before merge. As a reviewer, carefully check the changes
in the merge request before triggering the pipeline. Unless you trigger the pipeline
through the API or the [`/rebase` quick action](https://docs.gitlab.com/user/project/quick_actions/#rebase),
GitLab shows a warning that you must accept before the pipeline runs. Otherwise, **no warning displays**.

Prerequisites:

- The parent project’s `.gitlab-ci.yml` file must be configured to
[run jobs in merge request pipelines](https://docs.gitlab.com/ci/pipelines/merge_request_pipelines/#prerequisites).
- You must be a member of the parent project with [permissions to run CI/CD pipelines](https://docs.gitlab.com/user/permissions/#project-cicd).
You might need additional permissions if the branch is protected.
- The fork project must be [visible](https://docs.gitlab.com/user/public_access/) to the
user running the pipeline. Otherwise, the **Pipelines** tab does not display
in the merge request.

To use the UI to run a pipeline in the parent project for a merge request from a fork project:

1. In the merge request, go to the **Pipelines** tab.
2. Select **Run pipeline**. You must read and accept the warning, or the pipeline does not run.

### Prevent pipelines from fork projects [Permalink](https://docs.gitlab.com/ci/pipelines/merge_request_pipelines/\#prevent-pipelines-from-fork-projects "Permalink")

To prevent users from running new pipelines for fork projects in the parent project
use [the projects API](https://docs.gitlab.com/api/projects/#update-a-project) to disable the `ci_allow_fork_pipelines_to_run_in_parent_project`
setting.

Pipelines created before the setting was disabled are not affected and continue to run.
If you rerun a job in an older pipeline, the job uses the same context as when the
pipeline was originally created.

## Available predefined variables [Permalink](https://docs.gitlab.com/ci/pipelines/merge_request_pipelines/\#available-predefined-variables "Permalink")

When you use merge request pipelines, you can use:

- All the same [predefined variables](https://docs.gitlab.com/ci/variables/predefined_variables/) that are
available in branch pipelines.
- [Additional predefined variables](https://docs.gitlab.com/ci/variables/predefined_variables/#predefined-variables-for-merge-request-pipelines)
available only to jobs in merge request pipelines.

## Control access to protected variables and runners [Permalink](https://docs.gitlab.com/ci/pipelines/merge_request_pipelines/\#control-access-to-protected-variables-and-runners "Permalink")

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/188008) in GitLab 18.1

You can control access to [protected CI/CD variables](https://docs.gitlab.com/ci/variables/#protect-a-cicd-variable)
and [protected runners](https://docs.gitlab.com/ci/runners/configure_runners/#prevent-runners-from-revealing-sensitive-information)
from merge request pipelines.

Merge request pipelines can only access these protected resources when:

- Both the source and target branches are [protected](https://docs.gitlab.com/user/project/repository/branches/protected/).
- The user triggering the pipeline has push/merge access to the target branch.
- Both source and target branches belong to the same project.

Merge request pipelines from forked repositories cannot access these protected resources.

Prerequisites:

- Have the Maintainer or Owner role in the project.

To control access to protected variables and runners:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Settings** \> **CI/CD**.
3. Expand **Variables**.
4. Under **Access protected resources in merge request pipelines**, select or clear
the **Allow merge request pipelines to access protected variables and runners** checkbox.

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**