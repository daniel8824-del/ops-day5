<!-- source: https://docs.gitlab.com/user/project/merge_requests/manage -->

/

* * *

# Manage merge requests

GitLab provides tools for managing merge requests for your project and group.

## Delete a merge request [Permalink](https://docs.gitlab.com/user/project/merge_requests/manage/\#delete-a-merge-request "Permalink")

In most cases you should close, rather than delete, merge requests.
You cannot undo the deletion of a merge request.

Prerequisites:

- You must have the Owner role for the project.

To delete a merge request:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Code** \> **Merge requests** and find the merge request you want to delete.
3. Select **Edit**.
4. Scroll to the bottom of the page, and select **Delete merge request**.

Deleting a merge request does not completely erase all data.
Some information persists to maintain project history and to support recovery processes.
For more information, see [handle sensitive information](https://docs.gitlab.com/topics/git/undo/#handle-sensitive-information).

## Bulk edit merge requests in a project [Permalink](https://docs.gitlab.com/user/project/merge_requests/manage/\#bulk-edit-merge-requests-in-a-project "Permalink")

These attributes are editable when bulk editing merge requests:

- Status (open/closed)
- Assignee
- Milestone
- Labels
- Subscriptions

Prerequisites:

- You must have the Developer, Maintainer, or Owner role.

To do this:

1. In a project, go to **Code** \> **Merge requests**.
2. Select **Bulk edit**. A sidebar on the right-hand side of your screen appears with
editable fields.
3. Select the checkboxes next to each merge request you want to edit.
4. Select the appropriate fields and their values from the sidebar.
5. Select **Update selected**.

## Bulk edit merge requests in a group [Permalink](https://docs.gitlab.com/user/project/merge_requests/manage/\#bulk-edit-merge-requests-in-a-group "Permalink")

- Tier: Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

These attributes are editable when you bulk edit merge requests for a group:

- Milestone
- Labels

Prerequisites:

- You must have the Developer, Maintainer, or Owner role for the project.

To update multiple group merge requests at the same time:

1. In a group, go to **Code** \> **Merge requests**.
2. Select **Bulk edit**. A sidebar on the right-hand side of your screen appears with
editable fields.
3. Select the checkboxes next to each merge request you want to edit.
4. Select the appropriate fields and their values from the sidebar.
5. Select **Update selected**.

## Related topics [Permalink](https://docs.gitlab.com/user/project/merge_requests/manage/\#related-topics "Permalink")

- [Bulk edit issues](https://docs.gitlab.com/user/project/issues/managing_issues/#bulk-edit-issues)

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**