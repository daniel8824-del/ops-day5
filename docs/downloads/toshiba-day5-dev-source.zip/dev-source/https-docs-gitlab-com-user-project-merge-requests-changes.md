<!-- source: https://docs.gitlab.com/user/project/merge_requests/changes -->

/

* * *

# Changes in merge requests

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

A [merge request](https://docs.gitlab.com/user/project/merge_requests/) proposes a set of changes to files in a branch in your repository. GitLab
shows these changes as a _diff_ (difference) between the current state and the proposed
changes. By default, the diff compares your proposed changes (the source branch) with
the target branch. By default, GitLab shows only the changed portions of the files.

This example shows changes to a text file. In the default syntax highlighting theme:

- The _current_ version is shown in red, with a minus (`-`) sign before the line.
- The _proposed_ version is shown in green with a plus (`+`) sign before the line.

![A merge request diff showing added and removed lines of code.](https://docs.gitlab.com/user/project/merge_requests/img/mr_diff_example_v16_9.png)

The header for each file in the diff contains:

- **Hide file contents** (chevron-down) to hide all changes to this file.
- **Path**: The full path to this file. To copy this path, select
**Copy file path** (copy-to-clipboard).
- **Lines changed**: The number of lines added and removed in this file, in the format `+2 -2`.
- **Viewed**: Select this checkbox to [mark the file as viewed](https://docs.gitlab.com/user/project/merge_requests/changes/#mark-files-as-viewed)
until it changes again.
- **Comment on this file** (comment) to leave a general comment on the file, without
pinning the comment to a specific line.
- **Options**: Select (ellipsis\_v) to display more file viewing options.

The diff also includes navigation and comment aids to the left of the file, in the gutter:

- Show more context: Select **Previous 20 lines** (expand-up) to display
the previous 20 unchanged lines, or **Next 20 lines** (expand-down) to
show the next 20 unchanged lines.
- Line numbers are shown in two columns. Previous line numbers are shown on
the left, and proposed line numbers on the right. To interact with a line:
  - To show [comment options](https://docs.gitlab.com/user/project/merge_requests/changes/#add-a-comment-to-a-merge-request-file), hover over a line number.
  - To copy a link to the line, press `Command` and select (or right-click)
    a line number, then select **Copy link address**.
  - To highlight a line, select the line number.

## Show a list of changed files [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#show-a-list-of-changed-files "Permalink")

Use the file browser to view a list of files changed in a merge request:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Code** \> **Merge requests** and find your merge request.
3. Below the merge request title, select **Changes**.
4. Select **Show file browser** (file-tree) or press `F` to show
the file tree.
   - For a tree view that shows nesting, select **Tree view** (file-tree).
   - For a file list without nesting, select **List view** (list-bulleted).

## Show all changes in a merge request [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#show-all-changes-in-a-merge-request "Permalink")

To view the diff of changes included in a merge request:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Code** \> **Merge requests** and find your merge request.
3. Below the merge request title, select **Changes**.
4. If the merge request changes many files, you can jump directly to a specific file:
1. Select **Show file browser** (file-tree) or press `F` to show the file tree.
2. Select the file you want to view.
3. To hide the file browser, select **Show file browser** or press `F` again.

GitLab collapses files with many changes to improve performance, and displays the message:
**Some changes are not shown**. To view the changes for that file, select **Expand file**.

### Show a linked file first [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#show-a-linked-file-first "Permalink")

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/387246) in GitLab 16.9 [with a flag](https://docs.gitlab.com/administration/feature_flags/) named `pinned_file`. Disabled by default.
- [Generally available](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/162503) in GitLab 17.4. Feature flag `pinned_file` removed.

When you share a merge request link with a team member, you might want to show a specific file
first in the list of changed files. To copy a merge request link that shows your desired file first:

1. In the top bar, select **Search or go to** and find your project.

2. In the left sidebar, select **Code** \> **Merge requests** and find your merge request.

3. Below the merge request title, select **Changes**.

4. Find the file you want to show first. Right-click the name of the file to copy the link to it.

5. When you visit that link, your chosen file is shown at the top of the list. The file browser
shows a link icon (link) next to the filename:

![A merge request listing files, with the selected YAML file at the top.](https://docs.gitlab.com/user/project/merge_requests/img/linked_file_v17_4.png)


## Collapse generated files [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#collapse-generated-files "Permalink")

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/140180) in GitLab 16.8 [with a flag](https://docs.gitlab.com/administration/feature_flags/) named `collapse_generated_diff_files`. Disabled by default.
- [Enabled on GitLab.com and GitLab Self-Managed](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/145100) in GitLab 16.10.
- `generated_file` [generally available](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/148478) in GitLab 16.11. Feature flag `collapse_generated_diff_files` removed.

To help reviewers focus on the files needed to perform a code review, GitLab collapses
several common types of generated files. GitLab collapses these files by default, because
they rarely require code reviews:

1. Files with `.nib`, `.xcworkspacedata`, or `.xcurserstate` extensions.
2. Package lock files such as `package-lock.json` or `Gopkg.lock`.
3. Files in the `node_modules` folder.
4. Minified `js` or `css` files.
5. Source map reference files.
6. Generated Go files, including the generated files by protocol buffer compiler.

To mark a file or path as generated, set the `gitlab-generated` attribute for it
in your [`.gitattributes` file](https://docs.gitlab.com/user/project/repository/files/git_attributes/).

### View a collapsed file [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#view-a-collapsed-file "Permalink")

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Code** \> **Merge requests** and find your merge request.
3. Below the merge request title, select **Changes**.
4. Find the file you want to view, and select **Expand file**.

### Configure collapse behavior for a file type [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#configure-collapse-behavior-for-a-file-type "Permalink")

To change the default collapse behavior for a file type:

1. If a `.gitattributes` file does not exist in the root directory of your project,
create a blank file with this name.

2. For each file type you want to modify, add a line to the `.gitattributes` file
declaring the file extension and your desired behavior:





config





```conf
# Collapse all files with a .txt extension
*.txt gitlab-generated

# Collapse all files within the docs directory
docs/** gitlab-generated

# Do not collapse package-lock.json
package-lock.json -gitlab-generated
```

3. Commit, push, and merge your changes into your default branch.


After the changes merge into your [default branch](https://docs.gitlab.com/user/project/repository/branches/default/),
all files of this type in your project use this behavior in merge requests.

For technical details about how GitLab detects generated files, see the
[`go-enry`](https://github.com/go-enry/go-enry/blob/master/data/generated.go) repository.

## Show one file at a time [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#show-one-file-at-a-time "Permalink")

For larger merge requests, you can review one file at a time. You can change this
setting in your user preferences, or when you review a merge request. If you change this
setting in a merge request, it updates your user settings as well.

- [In a merge request](https://docs.gitlab.com/user/project/merge_requests/changes/#)
- [In your user preferences](https://docs.gitlab.com/user/project/merge_requests/changes/#)

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Code** \> **Merge requests** and find your merge request.
3. Below the merge request title, select **Changes**.
4. Select **Preferences** (preferences).
5. Select or clear **Show one file at a time**.

1. In the upper-right corner, select your avatar.
2. Select **Preferences**.
3. Scroll to the **Behavior** section and select the **Show one file at a time on merge request’s Changes tab** checkbox.
4. Select **Save changes**.

To select another file to view when this setting is enabled, either:

- Scroll to the end of the file and select either **Prev** or **Next**.
- If [keyboard shortcuts are enabled](https://docs.gitlab.com/user/shortcuts/#enable-keyboard-shortcuts),
press `[`, `]`, `k`, or `j`.
- Select **Show file browser** (file-tree) and select another file to view.

## Compare changes [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#compare-changes "Permalink")

You can view the changes in a merge request either:

- Inline, which shows the changes vertically. The old version of a line is shown
first, with the new version shown directly below it.
Inline mode is often better for changes to single lines.
- Side-by-side, which shows the old and new versions of lines in separate columns.
Side-by-side mode is often better for changes affecting large numbers of sequential lines.

To change how a merge request shows changed lines:

1. In the top bar, select **Search or go to** and find your project.

2. In the left sidebar, select **Code** \> **Merge requests** and find your merge request.

3. Below the title, select **Changes**.

4. Select **Preferences** (preferences). Select either **Side-by-side** or **Inline**.
This example shows how GitLab renders the same change in both inline and side-by-side mode:









   - [Inline changes](https://docs.gitlab.com/user/project/merge_requests/changes/#)
   - [Side-by-side changes](https://docs.gitlab.com/user/project/merge_requests/changes/#)

![Merge request code changes in inline mode.](https://docs.gitlab.com/user/project/merge_requests/img/changes-inline_v17_10.png)

![Merge request code changes in side-by-side mode.](https://docs.gitlab.com/user/project/merge_requests/img/changes-sidebyside_v17_10.png)

## Rapid Diffs [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#rapid-diffs "Permalink")

- Status: Beta

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/590833) in GitLab 18.0 [with a flag](https://docs.gitlab.com/administration/feature_flags/) named `rapid_diffs_on_mr_show`. Disabled by default.
- [Enabled on GitLab.com and GitLab Self-Managed](https://gitlab.com/gitlab-org/gitlab/-/issues/539581) in GitLab 19.0.

The availability of this feature is controlled by a feature flag.
For more information, see the history.

Rapid Diffs is a faster way to load and interact with code changes in merge requests.
It reduces the time before you see the first file when reviewing a diff.

Rapid Diffs is in beta. Some features from the classic diff experience are not available.
For the list of known limitations, see [feedback issue 596236](https://gitlab.com/gitlab-org/gitlab/-/issues/596236).
For the feature parity roadmap, see [epic 19380](https://gitlab.com/groups/gitlab-org/-/epics/19380).

### Turn on Rapid Diffs [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#turn-on-rapid-diffs "Permalink")

To turn on Rapid Diffs for all merge requests:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Code** \> **Merge requests** and find your merge request.
3. Below the merge request title, select **Changes**.
4. Select **Try Rapid Diffs**.

The page reloads with the new experience. Your preference persists across sessions.

To share feedback about Rapid Diffs, select **Rapid Diffs** \> **Leave feedback**.

### Turn off Rapid Diffs [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#turn-off-rapid-diffs "Permalink")

To turn off Rapid Diffs and switch back to the classic diff loading experience:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Code** \> **Merge requests** and find your merge request.
3. Below the merge request title, select **Changes**.
4. Select **Rapid Diffs** to open the dropdown list.
5. Select **Switch to classic loading**.

## Explain code in a merge request [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#explain-code-in-a-merge-request "Permalink")

- Tier: Premium, Ultimate
- Add-on: GitLab Duo Pro or Enterprise, GitLab Duo with Amazon Q
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

Model information

- [Default LLM](https://docs.gitlab.com/user/gitlab_duo/model_selection/#default-models)
- LLM for Amazon Q: Amazon Q Developer

History

- [Generally available](https://gitlab.com/gitlab-org/gitlab/-/issues/429915) in GitLab 16.8.
- Changed to require GitLab Duo add-on in GitLab 17.6 and later.
- [Updated default LLM](https://gitlab.com/gitlab-org/modelops/applied-ml/code-suggestions/ai-assist/-/issues/1541) to Claude Sonnet 4.5 in GitLab 18.6.

If you spend a lot of time trying to understand code that others have created, or
you struggle to understand code written in a language you are not familiar with,
you can ask GitLab Duo to explain the code to you.

- [Watch an overview](https://youtu.be/1izKaLmmaCA?si=O2HDokLLujRro_3O)

Prerequisites:

- You must belong to at least one group with the
[experiment and beta features setting](https://docs.gitlab.com/user/gitlab_duo/turn_on_off/#turn-on-beta-and-experimental-features) enabled.
- You must have access to view the project.

To explain the code in a merge request:

1. In the top bar, select **Search or go to** and find your project.

2. In the left sidebar, select **Code** \> **Merge requests**, then select your merge request.

3. Select **Changes**.

4. On the file you would like explained, select the three dots (ellipsis\_v) and select **View File @ $SHA**.

A separate browser tab opens and shows the full file with the latest changes.

5. On the new tab, select the lines you want to have explained.

6. On the left side, select the question mark (question). You might have to scroll to the first line of your selection to view it.

![Icon to explain the selected code snippet using GitLab Duo in a merge request.](https://docs.gitlab.com/user/project/merge_requests/img/explain_code_v17_1.png)


GitLab Duo Chat explains the code. It might take a moment for the explanation to be generated.

If you’d like, you can provide feedback about the quality of the explanation.

GitLab cannot guarantee that the large language model produces results that are correct. Use the explanation with caution.

You can also explain code in:

- A [file](https://docs.gitlab.com/user/project/repository/code_explain/).
- The [IDE](https://docs.gitlab.com/user/gitlab_duo_chat/examples/#explain-selected-code).

## Expand or collapse comments [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#expand-or-collapse-comments "Permalink")

When reviewing code changes, you can hide inline comments:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Code** \> **Merge requests** and find your merge request.
3. Below the title, select **Changes**.
4. Scroll to the file that contains the comments you want to hide.
5. Scroll to the line the comment is attached to. In the gutter margin, select **Collapse** (collapse):
![Icon to collapse a comment in a merge request diff.](https://docs.gitlab.com/user/project/merge_requests/img/collapse-comment_v17_1.png)

To expand inline comments and show them again:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Code** \> **Merge requests** and find your merge request.
3. Below the title, select **Changes**.
4. Scroll to the file that contains the collapsed comments you want to show.
5. Scroll to the line the comment is attached to. In the gutter margin, select the user avatar:
![Icon to expand a comment in a merge request diff.](https://docs.gitlab.com/user/project/merge_requests/img/expand-comment_v17_10.png)

## Ignore whitespace changes [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#ignore-whitespace-changes "Permalink")

Whitespace changes can make it more difficult to see the substantive changes in
a merge request. You can choose to hide or show whitespace changes:

1. In the top bar, select **Search or go to** and find your project.

2. In the left sidebar, select **Code** \> **Merge requests** and find your merge request.

3. Below the title, select **Changes**.

4. Before the list of changed files, select **Preferences** (preferences).

5. Select or clear **Show whitespace changes**:

![A merge request diff with Preferences menu expanded and ‘Show whitespace changes’ option selected.](https://docs.gitlab.com/user/project/merge_requests/img/merge_request_diff_v17_10.png)


## Mark files as viewed [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#mark-files-as-viewed "Permalink")

When reviewing a merge request with many files multiple times, you can ignore files
you’ve already reviewed. To hide files that haven’t changed after your last review:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Code** \> **Merge requests** and find your merge request.
3. Below the title, select **Changes**.
4. In the file’s header, select the **Viewed** checkbox.

Files marked as viewed are not shown to you again unless either:

- The contents of the file change.
- You clear the **Viewed** checkbox.

## Show merge request conflicts in diff [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#show-merge-request-conflicts-in-diff "Permalink")

To avoid displaying changes already on target branch, GitLab compares the merge request’s
source branch with the `HEAD` of the target branch.

When the source and target branch conflict, GitLab show an alert
per conflicted file on the merge request diff:

![A conflict alert in a merge request diff.](https://docs.gitlab.com/user/project/merge_requests/img/conflict_ui_v15_6.png)

## Show scanner findings in diff [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#show-scanner-findings-in-diff "Permalink")

- Tier: Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

You can show scanner findings in the diff. For details, see:

- [Code quality findings](https://docs.gitlab.com/ci/testing/code_quality/#merge-request-changes-view)
- [Static analysis findings](https://docs.gitlab.com/user/application_security/sast/#merge-request-changes-view)

## Download merge request changes [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#download-merge-request-changes "Permalink")

You can download the changes included in a merge request for use outside of GitLab.

### As a diff [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#as-a-diff "Permalink")

To download the changes as a diff:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Code** \> **Merge requests** and find your merge request.
3. Select the merge request.
4. In the upper-right corner, select **Code** \> **Plain diff**.

If you know the URL of the merge request, you can also download the diff from
the command line by appending `.diff` to the URL. This example downloads the diff
for merge request `000000`:

```plaintext
https://gitlab.com/gitlab-org/gitlab/-/merge_requests/000000.diff
```

To download and apply the diff in a one-line CLI command:

shell

```shell
curl "https://gitlab.com/gitlab-org/gitlab/-/merge_requests/000000.diff" | git apply
```

### As a patch file [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#as-a-patch-file "Permalink")

To download the changes as a patch file:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Code** \> **Merge requests** and find your merge request.
3. Select the merge request.
4. In the upper-right corner, select **Code** \> **Patches**.

If you know the URL of the merge request, you can also download the patch from
the command line by appending `.patch` to the URL. This example downloads the patch
file for merge request `000000`:

```plaintext
https://gitlab.com/gitlab-org/gitlab/-/merge_requests/000000.patch
```

To download and apply the patch using [`git am`](https://git-scm.com/docs/git-am):

shell

```shell
# Download and preview the patch
curl "https://gitlab.com/gitlab-org/gitlab/-/merge_requests/000000.patch" > changes.patch
git apply --check changes.patch

# Apply the patch
git am changes.patch
```

You can also download and apply the patch in a single command:

shell

```shell
curl "https://gitlab.com/gitlab-org/gitlab/-/merge_requests/000000.patch" | git am
```

The `git am` uses the `-p1` option by default. For more information, see [`git-apply`](https://git-scm.com/docs/git-apply).

### Download older diff versions [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#download-older-diff-versions "Permalink")

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/373246) in GitLab 18.7.

To download older diff versions as a patch or diff file:

1. [Compare the diff versions](https://docs.gitlab.com/user/project/merge_requests/versions/#compare-diff-versions) you want to download.
2. Append `.diff` or `.patch` to the URL path.

For example:

```plaintext
# As a diff file:
https://gitlab.com/gitlab-org/gitlab/-/merge_requests/123456/diffs.diff?diff_id=525410&start_sha=a1b2c3d4

# As a patch file:
https://gitlab.com/gitlab-org/gitlab/-/merge_requests/123456/diffs.patch?diff_id=525410&start_sha=a1b2c3d4
```

## Add a comment to a merge request file [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#add-a-comment-to-a-merge-request-file "Permalink")

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/123515) in GitLab 16.1 [with a flag](https://docs.gitlab.com/administration/feature_flags/) named `comment_on_files`. Enabled by default.
- [Feature flag removed](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/125130) in GitLab 16.2.

You can add comments to a merge request diff file. These comments persist across
rebases and file changes.

To add a comment to a merge request file:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Code** \> **Merge requests** and find your merge request.
3. Select **Changes**.
4. In the header for the file you want to comment on, select **Comment on this file** (comment).

## Add a comment to an image [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#add-a-comment-to-an-image "Permalink")

In merge requests and commit detail views, you can add a comment to an image.
This comment can also be a thread.

1. Hover your mouse over the image.
2. Select the location where you want to comment.

GitLab shows an icon and a comment field on the image.

## Related topics [Permalink](https://docs.gitlab.com/user/project/merge_requests/changes/\#related-topics "Permalink")

- [Compare revisions](https://docs.gitlab.com/user/project/repository/compare_revisions/)
- [Download branch comparisons](https://docs.gitlab.com/user/project/repository/branches/#download-branch-comparisons)
- [Merge request reviews](https://docs.gitlab.com/user/project/merge_requests/reviews/)
- [Merge request versions](https://docs.gitlab.com/user/project/merge_requests/versions/)

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**