<!-- source: https://www.atlassian.com/agile/project-management/epics-stories-themes -->

Get it free

Search

Sign in

# Epics, stories, and initiatives

These simple structures help agile teams gracefully manage scope and structure work.

![](https://dam-cdn.atl.orangelogic.com/AssetLink/6te2t4t6c276x748n44j24tcxj312jo1.jpg)

By Max Rehkopf, Atlassian Product Marketing Manager

As a self-proclaimed “chaos muppet” I look to agile practices and lean principles to bring order to my everyday. It’s a joy of mine to share these lessons with others through the many articles, talks, and videos I make for Atlassian

Get the free project roadmap template

Align your team with a project roadmap template to strategically define milestones, connect with business goals, and achieve project success.

[Use template](https://www.atlassian.com/software/jira/templates/project-roadmap)

**Key Takeaways**

- Epic and user stories are hierarchical structures in Agile that organize work from high-level objectives to actionable tasks.

- Stories are small, sprint-sized tasks, while epics group related stories under a larger goal, and initiatives encompass multiple epics.

- This structure enables teams to balance flexibility with strategic alignment and clear reporting.

- Learn to break down large goals into epics and stories to improve tracking, communication, and delivery.


Let’s say you and your team want to do something ambitious, like launch a rocket into space. To do so, you’ll need to structure your work: from the largest objectives down to the minute details. You’ll want to be able to respond to change, report your progress, _and_ stick to a plan. Epics, stories, and initiatives are precisely the tools you’ll need to do so.

By understanding how these popular [Agile](https://www.atlassian.com/agile) and [DevOps](https://www.atlassian.com/devops/what-is-devops) methodologies help organize work, your team can strike a healthy balance between structure, flexibility, and launching rockets into space.

**What are stories, epics, and initiatives?**

- [**Stories**](https://www.atlassian.com/agile/project-management/user-stories), also called “user stories,” are short requirements or requests written from the perspective of an end user.

- [**Epics**](https://www.atlassian.com/agile/project-management/epics) are large bodies of work that can be broken down into a number of smaller tasks (called stories).

- **Initiatives** are collections of epics that drive toward a common goal.


## Agile epic vs. story

In a sense, stories and epics in agile are similar to stories and epics in film or literature. A story is one simple narrative; a series of related and interdependent stories makes up an epic.

The same is true for your work management, where the completion of related stories leads to the completion of an epic. The stories tell the arc of the work completed while the epic shares a high-level view of the unifying objective.

On an agile team, stories are something the team can commit to finish within a one- or two-week sprint. Oftentimes, developers would work on dozens of stories a month.

Epics, in contrast, are few in number and take longer to complete. Teams often have two or three epics they work to complete each quarter. If your company was launching rockets into space, and wanted to improve the streaming service for your launches, you might structure your stories like the ones below.

### Examples of an agile story:

Here's an example where the stories are all related and could all be considered individual tasks that drive toward the completion of a larger body of work (an epic). In this case, the epic might be **“Improve Streaming Service for Q1 Launch.”**

- iPhone users need access to a vertical view of the live feed when using the mobile app.

- Desktop users need a “view fullscreen” button in the lower right hand corner of the video player.

- Android users need to be linked to apple store.


_Want to learn how to configure stories (called issues) in Jira? Check out our latest_ [_Issues tutorial_](https://www.atlassian.com/agile/tutorials/issues) _for more!_

Organizing work into stories and epics also helps you and your team communicate effectively within the organization. If you were reporting your team’s progress to the Head of Engineering, you’d be speaking in epics.

On the other hand, if you were talking to a colleague on your development team, you’d speak at the story level.

**For complete definitions, examples and best practices, see:**

- [The Agile Coach: Epics](https://www.atlassian.com/agile/project-management/epics)

- [The Agile Coach: Stories](https://www.atlassian.com/agile/project-management/user-stories)


![What is Agile Video Thumbnail](<Base64-Image-Removed>)

## Does every user story need an epic?

Not every user story needs to be part of an epic; some stories are small enough to stand alone and deliver value independently. [Epics](https://www.atlassian.com/agile/project-management/epics) are best used for grouping related stories that contribute to a larger goal or feature.

For example, a quick bug fix or a minor UI update might be a standalone user story, while a new checkout process would be an epic containing multiple stories. Using epics selectively helps teams avoid unnecessary complexity and keeps the backlog organized.

## Agile epic vs. initiative

In the same way that epics are made up of stories, initiatives are made up of epics. Initiatives offer another level of organization above epics. In many cases, an initiative compiles epics from multiple teams to achieve a much broader, bigger goal than any of the epics themselves. While an epic is something you might complete in a month or a quarter, initiatives are often completed in multiple quarters to a year.

![Example user stories | Atlassian agile coach](https://dam-cdn.atl.orangelogic.com/AssetLink/1bw0xel84278wce3kmc238gc4710mam8.png)

**Example of epics in an initiative:**

Let’s say your rocket ship company wants to decrease the cost per launch by 5% this year. That’s a great fit for an initiative, as no single epic could likely achieve that big of a goal. Within that initiative, there would be epics such as, “Decrease launch-phase fuel consumption by 1%,” “Increase launches per quarter from 3 to 4,” and “Turn all thermostats down from 71 to 69 degrees #Dadmode.”

**At Atlassian:**

Internally, we call our initiatives “PC Tickets.” Project Central tickets are configured in Jira just like our epics. Each team takes their four or five most important goals for the year and makes PC tickets for each one. These PC tickets are used by the founders and management to understand all the work being done in the company. Check out our free [Jira project management template](https://www.atlassian.com/software/jira/templates/project-management-templates), inspired by our own agile practices.

NEXT: [Learn how to configure Agile Epics](https://www.atlassian.com/agile/tutorials/epics)

## Beyond initiatives

In many organizations, the founders or leadership team encourage the pursuit of some aspirational destination. These are the (sometimes super corny) goals announced each year or quarter. Initiatives are typically collections of epics, but you can also use custom fields or labels to categorize by team, strategic pillar, or timeframe, and create a custom hierarchy to better align work to higher-level organizational goals.

Many Atlassian customers leverage Plans, an advanced planning feature in Jira, to introduce five levels above agile epics to define and guide projects, which are shown below.

See how Twitter unified projects and teamwork with Jira: [Read the full story](https://www.atlassian.com/agile/teams/jira-twitter-unified-projects-teamwork)

![Example user stories | Atlassian agile coach](https://dam-cdn.atl.orangelogic.com/AssetLink/y07f3021t74dfjkwfl0pn4mw2x3a7e3a.png)

**At Atlassian:** When the Cloud Foundations division needed visibility of work across a division with hundreds of engineers, they turned to [Jira’s advanced planning feature](https://www.atlassian.com/software/jira/features/roadmaps) to solve a key challenge that organizations face with distributed teams. Connecting their projects together within a shared delivery plan in Jira, they could see the big picture, track progress, and easily share data with stakeholders.

This is what advanced planning with Jira looks like for the Atlassian Cloud Foundations division. [Read more](https://www.atlassian.com/agile/teams/advanced-roadmaps-teams)

![Example of a sprint | Atlassian agile coach](https://dam-cdn.atl.orangelogic.com/AssetLink/2lhf00c13ff4a851f287ymepu8bn5g8h.png)

## Structuring work

Being agile and embracing structure are not mutually exclusive, and the structure laid out here is not one size fits all. Success is when you and your team understand these concepts and adapt them to your needs. For us, that's stories, epics, and initiatives.

You can get started by learning [how to set up Epics in Jira](https://www.atlassian.com/agile/tutorials/epics) and then learn more about how to strategically plan and track work across multiple teams with [Plans in Jira](https://www.atlassian.com/software/jira/guides/advanced-roadmaps/overview).

## How do epics, stories, and tasks function within Jira?

In Jira, epics, stories, and tasks are hierarchical issue types that help teams organize and track work. [Jira's epics](https://www.atlassian.com/agile/tutorials/epics) represent large initiatives, stories capture user requirements, and tasks are used for specific actions or technical work.

Jira allows teams to link stories and tasks to epics, visualize progress on boards, and report on completion across multiple sprints. This structure supports agile planning by making it easy to break down complex work, assign responsibilities, and monitor delivery from high-level goals to day-to-day activities.

### Related resources

- [Project Management Resources](https://www.atlassian.com/project-management)

  - [Project Planning Resources](https://www.atlassian.com/project-management/project-planning)

  - [Product Launch Resources](https://www.atlassian.com/project-management/build-launch-products-services)

  - [Project Management Go-To-Market Strategies](https://www.atlassian.com/project-management/go-to-market-strategy)

  - [Resource Management Resources](https://www.atlassian.com/project-management/resource-management)

  - [Task-Tracking Resources](https://www.atlassian.com/project-management/task-tracking)

  - [Software Project Management](https://www.atlassian.com/project-management/software-teams)

## Recommended for you

### Ready-made Jira templates

Browse our library of custom Jira templates for various teams, departments, and workflows.

[Go to Jira templates](https://www.atlassian.com/software/jira/templates)

### A comprehensive introduction to Jira

Use this step-by-step guide to discover essential features and the best practices to maximize your productivity.

[Go to Jira Product guide](https://www.atlassian.com/software/jira/guides/getting-started/introduction#what-is-jira-software)

### Understanding the Basics of Git

From beginners to advanced experts, use this guide to Git to learn the basics with helpful tutorials and tips.

[Learn more](https://www.atlassian.com/git)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**