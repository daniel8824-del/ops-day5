<!-- source: https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tZbbcqJAEIafxsup6TnBcIlEEYko2RgjNykOg2E3HKIk2eTpF9ekancrSmWt4aY5dP_d_VU3gCN8i6Mqfi42cVvUVfzQXa8j4863uD2RDizk3BtBOJu7Pr-8ADA4vsERjpq0yPCa89wEQjkiIhWIA2MolikgwyRKKZnlSab23mnVNu09XqsKPe0GcF-XagBpXTZx9TqA5KHeDCAuUKO2u30NxVtRbdDuvm6a7gSvDhXZYBMbaACjwAbDsAm9HvpkLjmOusdw5LDhI_54R9Fp-UO8ZxEKvg9zOXNFF7WYhtILaOjC7_hp6I4mPpDAvZAmGMPJ7MoWjivMj_wnHKLT5a32CP90cRe2A6GxdBfScxi_Md4d_u18eEWHDMCd008d_oIU9VVxcDhBYd21ad5R6jsTq-PoBuwCjJA4crlcArdNvHou1AteVvW27Obs2xfHaNKXIeRnZuiRN_TKizPlp31j3C128f3xMbK7fayrVv1s8e3_LeShk2OjQOF4J5QJkCxJkGIZQVzmCkmRmijhQhqJRS2QVp881StP9MozrfKeXvaeXvaeXvbeueynfa_A3hUrquxp124LtXuv9ehX4UStmRBEGjRGIHiKeMYkkswClORxnEueZlZMe-QD0CtP9coTvfJ62Y_1sh_rZT_Wy358Lvtp39_YF3Z0AJttnartK27KUrLXoijQj6tRPhsxvp4-vw0DtDeX-xtiU959blr5cp2XTnLcrOxfyzPR5g!!/ -->

![logo](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tVbbcpswEP0aHhUtQoDoGyY2xsTYpHEc85LhIjCtuQRIHOfrC3U603RiM6kHXgSaPWf3nNlFwh5-wF7uv6SJ36RF7u_a742nPNoa1afMgCVbWGNw5wvTpjfXAArF99jDXhmmEd5QGqsgEopEOZQRBUlCPgsBKarIOWdRHES8iw7zpmy2eMNz9FwLsC0yLkBYZKWfHwQIdkUigJ-ikld1V0P6luYJqrdFWbYveH2sSAdd1IE4MHZ0UBRdJHcjW1wwir3zBa_7FHV4OPHo8I63NJGAbcOCzU25RS1nLrMc4prwGz9zzfHUBtExr5kKymg6v9Vlw5TVP_gzAd55eevOwr8VmEvdAFdZmUtmGRK9V94D_q18dEtGEoC5IJ8GfBDp9bl4DDjjwqaVqT4SYhtTrdVhOtI1KK5osNVqBVRX8fol5Xu8yosqa_vs-xfbaNqXwaUXZuihV4ally-kn_W1UTvY6Y-nJ09v57HIG_7a4If_G8ijklOtQOC0EiLJwKQgQFyKRERZzBGTQxUFVGZKoBENmNZHT4alF4ellwalt4b13hrWe2tY761LvZ_1_QJ7RyzNo-e6qVJev9d68lQ4U2skyyJTiI9ApiGikcQQkzRAQez7MaNhpPmkh96BYenJsPTisPTDej8Z1vvJsN5PhvV-cqn3s77b2BdmVICkKkJeHTrWZFcEx-uxngcSS7BX8ZhXvLp6rtrtbdOU9TcBBNjv91dJUSQ7ftWeqAJ8BtkWdZv2YyQus4xJhzRN0c_bcTwfS3Qze3kbOahbbroNOckeP18atr-LMyM4vayRFxz2vwD1wDsC/images/logo.png)X

Sign in to your Toshiba account

For optimum experience,
please log in on your desktop computer

UserName

Password

Sign In [Forgot password?](https://www.toshibacommerce.com/tgcs109/tsim/forgotpassword.do) [Enterprise Login](https://www.toshibacommerce.com/mga/sps/authsvc?PolicyId=urn:ibm:security:authentication:asf:externalIDPLogin&target=https%3A%2F%2Ftoshibacommerce.com%2Fwps%2Fmyportal)

Don't have an ID? [Request one here](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/faqs)

{"Z7\_22KCH902NGN3D06Q1C8UUU04A7":{"windowState":"normal","portletMode":"view"},"Z7\_22KCH902NGN3D06Q1C8UUU04Q4":{"windowState":"normal","portletMode":"view"},"Z7\_22KCH902NGN3D06Q1C8UUU04Q6":{"windowState":"normal","portletMode":"view"},"Z7\_22KCH902NGN3D06Q1C8UUU04Q5":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2Q20":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2Q22":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2Q21":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2Q23":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2QI0":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2QI2":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2QI1":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0O8MG5064PJQ8IN2QI3":{"windowState":"normal","portletMode":"view"},"Z7\_JQGEHK01NGD8706BHMRA5CG573":{"windowState":"normal","portletMode":"view"},"Z7\_JQGEHK01NGD8706BHMRA5CG5N0":{"windowState":"normal","portletMode":"view"},"Z7\_JQGEHK01NGD8706BHMRA5CG5N2":{"windowState":"normal","portletMode":"view"},"Z7\_JQGEHK01NGD8706BHMRA5CG5N1":{"windowState":"normal","portletMode":"view"},"Z7\_JQGEHK01NGD8706BHMRA5CG5N3":{"windowState":"normal","portletMode":"view"},"Z7\_JQGEHK01NGD8706BHMRA5CG5F0":{"windowState":"normal","portletMode":"view"},"Z7\_JQGEHK01NGD8706BHMRA5CG5F2":{"windowState":"normal","portletMode":"view"},"Z7\_JQGEHK01NGD8706BHMRA5CG5F1":{"windowState":"normal","portletMode":"view"},"Z7\_JQGEHK01NGD8706BHMRA5CG5F3":{"windowState":"normal","portletMode":"view"}}

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

# Shaping the Future of Retail

Building Innovative Retail Solutions for a Thriving Future

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/ae536a09-25b3-452a-b02c-6b0ba1262533/Web_Banner_Branding.svg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-ae536a09-25b3-452a-b02c-6b0ba1262533-pQ8.Jiu)

Pause VideoPlay Video

**Craft Unique Journeys**

Create memorable shopping experiences for your customers online, in-store, or on the go.

**Innovate with Confidence**

Experiment with new technologies, address labor challenges, and enhance security by embracing modular, adaptable solutions.

**Be Agile & Secure**

Adapt to changing market needs and chart your path to ensure operational excellence.

**Sustain Your Success**

Drive your business success with intentional solutions and efficient operations.

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/5a2ed37b-9177-44ca-86a0-e64afc64dc6e/retail-journey-squares+%281%29.svg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-5a2ed37b-9177-44ca-86a0-e64afc64dc6e-pKvEpfg)

### Your Retail Journey to Excellence

With our deep retail expertise, advisory services, and cutting-edge technologies, we enable you to design personalized, flexible shopping experiences that resonate and delight at every touchpoint.

[![](https://commerce.toshiba.com/wps/wcm/connect/marketing/f9fde7eb-e86f-404b-8748-2cad8e39e2aa/convenience-fuel-card.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-f9fde7eb-e86f-404b-8748-2cad8e39e2aa-pLXQ8lF)\\
**Convenience & Fuel** \\
\\
Accelerating transactions and maximizing efficiency for high-velocity retail.](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tVbbcpswEP0aHhUtQoDoGyY2xsTYpHEc85LhIjCtuQRIHOfrC3U603RiM6kHXgSaPWf3nNlFwh5-wF7uv6SJ36RF7u_a742nPNoa1afMgCVbWGNw5wvTpjfXAArF99jDXhmmEd5QGqsgEopEOZQRBUlCPgsBKarIOWdRHES8iw7zpmy2eMNz9FwLsC0yLkBYZKWfHwQIdkUigJ-ikld1V0P6luYJqrdFWbYveH2sSAdd1IE4MHZ0UBRdJHcjW1wwir3zBa_7FHV4OPHo8I63NJGAbcOCzU25RS1nLrMc4prwGz9zzfHUBtExr5kKymg6v9Vlw5TVP_gzAd55eevOwr8VmEvdAFdZmUtmGRK9V94D_q18dEtGEoC5IJ8GfBDp9bl4DDjjwqaVqT4SYhtTrdVhOtI1KK5osNVqBVRX8fol5Xu8yosqa_vs-xfbaNqXwaUXZuihV4ally-kn_W1UTvY6Y-nJ09v57HIG_7a4If_G8ijklOtQOC0EiLJwKQgQFyKRERZzBGTQxUFVGZKoBENmNZHT4alF4ellwalt4b13hrWe2tY761LvZ_1_QJ7RyzNo-e6qVJev9d68lQ4U2skyyJTiI9ApiGikcQQkzRAQez7MaNhpPmkh96BYenJsPTisPTDej8Z1vvJsN5PhvV-cqn3s77b2BdmVICkKkJeHTrWZFcEx-uxngcSS7BX8ZhXvLp6rtrtbdOU9TcBBNjv91dJUSQ7ftWeqAJ8BtkWdZv2YyQus4xJhzRN0c_bcTwfS3Qze3kbOahbbroNOckeP18atr-LMyM4vayRFxz2vwD1wDsC/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Findustries%2Fconvenienceandfuel) [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/d78acf52-2cbf-41db-8463-0f5ead37e091/grocery-general-merchandise-card.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-d78acf52-2cbf-41db-8463-0f5ead37e091-pLY0iZ2)\\
**Grocery & General Merchandise** \\
\\
Crafting Frictionless Experiences and Maximizing Operational Agility for modern Grocery retail solutions.](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tVbbcpswEP0aHhUtQoDoGyY2xsTYpHEc85LhIjCtuQRIHOfrC3U603RiM6kHXgSaPWf3nNlFwh5-wF7uv6SJ36RF7u_a742nPNoa1afMgCVbWGNw5wvTpjfXAArF99jDXhmmEd5QGqsgEopEOZQRBUlCPgsBKarIOWdRHES8iw7zpmy2eMNz9FwLsC0yLkBYZKWfHwQIdkUigJ-ikld1V0P6luYJqrdFWbYveH2sSAdd1IE4MHZ0UBRdJHcjW1wwir3zBa_7FHV4OPHo8I63NJGAbcOCzU25RS1nLrMc4prwGz9zzfHUBtExr5kKymg6v9Vlw5TVP_gzAd55eevOwr8VmEvdAFdZmUtmGRK9V94D_q18dEtGEoC5IJ8GfBDp9bl4DDjjwqaVqT4SYhtTrdVhOtI1KK5osNVqBVRX8fol5Xu8yosqa_vs-xfbaNqXwaUXZuihV4ally-kn_W1UTvY6Y-nJ09v57HIG_7a4If_G8ijklOtQOC0EiLJwKQgQFyKRERZzBGTQxUFVGZKoBENmNZHT4alF4ellwalt4b13hrWe2tY761LvZ_1_QJ7RyzNo-e6qVJev9d68lQ4U2skyyJTiI9ApiGikcQQkzRAQez7MaNhpPmkh96BYenJsPTisPTDej8Z1vvJsN5PhvV-cqn3s77b2BdmVICkKkJeHTrWZFcEx-uxngcSS7BX8ZhXvLp6rtrtbdOU9TcBBNjv91dJUSQ7ftWeqAJ8BtkWdZv2YyQus4xJhzRN0c_bcTwfS3Qze3kbOahbbroNOckeP18atr-LMyM4vayRFxz2vwD1wDsC/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Findustries%2Fgrocery) [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/18dd4d96-a62b-4248-8291-6f24848c8c6f/hospitality-entertainment-card.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-18dd4d96-a62b-4248-8291-6f24848c8c6f-pLY0tpG)\\
**Hospitality & Entertainment** \\
\\
At Toshiba, we partner with you to craft unique adventures for your customers, whether they're checking in, ordering concessions, or enjoying a show.](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tVbbcpswEP0aHhUtQoDoGyY2xsTYpHEc85LhIjCtuQRIHOfrC3U603RiM6kHXgSaPWf3nNlFwh5-wF7uv6SJ36RF7u_a742nPNoa1afMgCVbWGNw5wvTpjfXAArF99jDXhmmEd5QGqsgEopEOZQRBUlCPgsBKarIOWdRHES8iw7zpmy2eMNz9FwLsC0yLkBYZKWfHwQIdkUigJ-ikld1V0P6luYJqrdFWbYveH2sSAdd1IE4MHZ0UBRdJHcjW1wwir3zBa_7FHV4OPHo8I63NJGAbcOCzU25RS1nLrMc4prwGz9zzfHUBtExr5kKymg6v9Vlw5TVP_gzAd55eevOwr8VmEvdAFdZmUtmGRK9V94D_q18dEtGEoC5IJ8GfBDp9bl4DDjjwqaVqT4SYhtTrdVhOtI1KK5osNVqBVRX8fol5Xu8yosqa_vs-xfbaNqXwaUXZuihV4ally-kn_W1UTvY6Y-nJ09v57HIG_7a4If_G8ijklOtQOC0EiLJwKQgQFyKRERZzBGTQxUFVGZKoBENmNZHT4alF4ellwalt4b13hrWe2tY761LvZ_1_QJ7RyzNo-e6qVJev9d68lQ4U2skyyJTiI9ApiGikcQQkzRAQez7MaNhpPmkh96BYenJsPTisPTDej8Z1vvJsN5PhvV-cqn3s77b2BdmVICkKkJeHTrWZFcEx-uxngcSS7BX8ZhXvLp6rtrtbdOU9TcBBNjv91dJUSQ7ftWeqAJ8BtkWdZv2YyQus4xJhzRN0c_bcTwfS3Qze3kbOahbbroNOckeP18atr-LMyM4vayRFxz2vwD1wDsC/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Findustries%2Fhospitalityentertainment) [![](https://commerce.toshiba.com/wps/wcm/connect/marketing/4383bcfb-98c6-4e94-b99d-18397e6980ab/specialty-retail-card.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-4383bcfb-98c6-4e94-b99d-18397e6980ab-pLY0wXR)\\
**Specialty Retail** \\
\\
With our deep retail expertise, advisory services, and cutting edge technologies, we enable you to transform challenges into opportunities.](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tVbbcpswEP0aHhUtQoDoGyY2xsTYpHEc85LhIjCtuQRIHOfrC3U603RiM6kHXgSaPWf3nNlFwh5-wF7uv6SJ36RF7u_a742nPNoa1afMgCVbWGNw5wvTpjfXAArF99jDXhmmEd5QGqsgEopEOZQRBUlCPgsBKarIOWdRHES8iw7zpmy2eMNz9FwLsC0yLkBYZKWfHwQIdkUigJ-ikld1V0P6luYJqrdFWbYveH2sSAdd1IE4MHZ0UBRdJHcjW1wwir3zBa_7FHV4OPHo8I63NJGAbcOCzU25RS1nLrMc4prwGz9zzfHUBtExr5kKymg6v9Vlw5TVP_gzAd55eevOwr8VmEvdAFdZmUtmGRK9V94D_q18dEtGEoC5IJ8GfBDp9bl4DDjjwqaVqT4SYhtTrdVhOtI1KK5osNVqBVRX8fol5Xu8yosqa_vs-xfbaNqXwaUXZuihV4ally-kn_W1UTvY6Y-nJ09v57HIG_7a4If_G8ijklOtQOC0EiLJwKQgQFyKRERZzBGTQxUFVGZKoBENmNZHT4alF4ellwalt4b13hrWe2tY761LvZ_1_QJ7RyzNo-e6qVJev9d68lQ4U2skyyJTiI9ApiGikcQQkzRAQez7MaNhpPmkh96BYenJsPTisPTDej8Z1vvJsN5PhvV-cqn3s77b2BdmVICkKkJeHTrWZFcEx-uxngcSS7BX8ZhXvLp6rtrtbdOU9TcBBNjv91dJUSQ7ftWeqAJ8BtkWdZv2YyQus4xJhzRN0c_bcTwfS3Qze3kbOahbbroNOckeP18atr-LMyM4vayRFxz2vwD1wDsC/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Findustries%2Fspecialtyretail)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

## Understanding Toshiba's Offerings

### Your Path to a Smarter, More Unified Retail Future

![](https://commerce.toshiba.com/wps/contenthandler/dav/fs-type1/themes/TGCSMarketingThemeV3/css/images/dotted-corner--orange.svg)

![](https://commerce.toshiba.com/wps/contenthandler/dav/fs-type1/themes/TGCSMarketingThemeV3/css/images/dotted-corner--lavender.svg)

#### Modularity

Adaptable solutions designed to grow with your business. Our modular hardware and software allow you to configure, upgrade, and expand systems without disruption, ensuring your technology evolves alongside your retail needs.

##### Products:

[MxP](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tVbbcpswEP0aHhUtQoDoGyY2xsTYpHEc85LhIjCtuQRIHOfrC3U603RiM6kHXgSaPWf3nNlFwh5-wF7uv6SJ36RF7u_a742nPNoa1afMgCVbWGNw5wvTpjfXAArF99jDXhmmEd5QGqsgEopEOZQRBUlCPgsBKarIOWdRHES8iw7zpmy2eMNz9FwLsC0yLkBYZKWfHwQIdkUigJ-ikld1V0P6luYJqrdFWbYveH2sSAdd1IE4MHZ0UBRdJHcjW1wwir3zBa_7FHV4OPHo8I63NJGAbcOCzU25RS1nLrMc4prwGz9zzfHUBtExr5kKymg6v9Vlw5TVP_gzAd55eevOwr8VmEvdAFdZmUtmGRK9V94D_q18dEtGEoC5IJ8GfBDp9bl4DDjjwqaVqT4SYhtTrdVhOtI1KK5osNVqBVRX8fol5Xu8yosqa_vs-xfbaNqXwaUXZuihV4ally-kn_W1UTvY6Y-nJ09v57HIG_7a4If_G8ijklOtQOC0EiLJwKQgQFyKRERZzBGTQxUFVGZKoBENmNZHT4alF4ellwalt4b13hrWe2tY761LvZ_1_QJ7RyzNo-e6qVJev9d68lQ4U2skyyJTiI9ApiGikcQQkzRAQez7MaNhpPmkh96BYenJsPTisPTDej8Z1vvJsN5PhvV-cqn3s77b2BdmVICkKkJeHTrWZFcEx-uxngcSS7BX8ZhXvLp6rtrtbdOU9TcBBNjv91dJUSQ7ftWeqAJ8BtkWdZv2YyQus4xJhzRN0c_bcTwfS3Qze3kbOahbbroNOckeP18atr-LMyM4vayRFxz2vwD1wDsC/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fhardware%2Fmxp)

, [ELERA](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tVbbcpswEP0aHhUtQoDoGyY2xsTYpHEc85LhIjCtuQRIHOfrC3U603RiM6kHXgSaPWf3nNlFwh5-wF7uv6SJ36RF7u_a742nPNoa1afMgCVbWGNw5wvTpjfXAArF99jDXhmmEd5QGqsgEopEOZQRBUlCPgsBKarIOWdRHES8iw7zpmy2eMNz9FwLsC0yLkBYZKWfHwQIdkUigJ-ikld1V0P6luYJqrdFWbYveH2sSAdd1IE4MHZ0UBRdJHcjW1wwir3zBa_7FHV4OPHo8I63NJGAbcOCzU25RS1nLrMc4prwGz9zzfHUBtExr5kKymg6v9Vlw5TVP_gzAd55eevOwr8VmEvdAFdZmUtmGRK9V94D_q18dEtGEoC5IJ8GfBDp9bl4DDjjwqaVqT4SYhtTrdVhOtI1KK5osNVqBVRX8fol5Xu8yosqa_vs-xfbaNqXwaUXZuihV4ally-kn_W1UTvY6Y-nJ09v57HIG_7a4If_G8ijklOtQOC0EiLJwKQgQFyKRERZzBGTQxUFVGZKoBENmNZHT4alF4ellwalt4b13hrWe2tY761LvZ_1_QJ7RyzNo-e6qVJev9d68lQ4U2skyyJTiI9ApiGikcQQkzRAQez7MaNhpPmkh96BYenJsPTisPTDej8Z1vvJsN5PhvV-cqn3s77b2BdmVICkKkJeHTrWZFcEx-uxngcSS7BX8ZhXvLp6rtrtbdOU9TcBBNjv91dJUSQ7ftWeqAJ8BtkWdZv2YyQus4xJhzRN0c_bcTwfS3Qze3kbOahbbroNOckeP18atr-LMyM4vayRFxz2vwD1wDsC/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fsoftware%2Fsolutions-platform%2Felera)

#### Security

Built-in protection you can trust. Our solutions safeguard your data, transactions, and devices against evolving threats, giving you peace of mind while keeping customer trust and compliance intact.

##### Products:

[MxP](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tVbbcpswEP0aHhUtQoDoGyY2xsTYpHEc85LhIjCtuQRIHOfrC3U603RiM6kHXgSaPWf3nNlFwh5-wF7uv6SJ36RF7u_a742nPNoa1afMgCVbWGNw5wvTpjfXAArF99jDXhmmEd5QGqsgEopEOZQRBUlCPgsBKarIOWdRHES8iw7zpmy2eMNz9FwLsC0yLkBYZKWfHwQIdkUigJ-ikld1V0P6luYJqrdFWbYveH2sSAdd1IE4MHZ0UBRdJHcjW1wwir3zBa_7FHV4OPHo8I63NJGAbcOCzU25RS1nLrMc4prwGz9zzfHUBtExr5kKymg6v9Vlw5TVP_gzAd55eevOwr8VmEvdAFdZmUtmGRK9V94D_q18dEtGEoC5IJ8GfBDp9bl4DDjjwqaVqT4SYhtTrdVhOtI1KK5osNVqBVRX8fol5Xu8yosqa_vs-xfbaNqXwaUXZuihV4ally-kn_W1UTvY6Y-nJ09v57HIG_7a4If_G8ijklOtQOC0EiLJwKQgQFyKRERZzBGTQxUFVGZKoBENmNZHT4alF4ellwalt4b13hrWe2tY761LvZ_1_QJ7RyzNo-e6qVJev9d68lQ4U2skyyJTiI9ApiGikcQQkzRAQez7MaNhpPmkh96BYenJsPTisPTDej8Z1vvJsN5PhvV-cqn3s77b2BdmVICkKkJeHTrWZFcEx-uxngcSS7BX8ZhXvLp6rtrtbdOU9TcBBNjv91dJUSQ7ftWeqAJ8BtkWdZv2YyQus4xJhzRN0c_bcTwfS3Qze3kbOahbbroNOckeP18atr-LMyM4vayRFxz2vwD1wDsC/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fhardware%2Fmxp)

, [ELERA](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tVbbcpswEP0aHhUtQoDoGyY2xsTYpHEc85LhIjCtuQRIHOfrC3U603RiM6kHXgSaPWf3nNlFwh5-wF7uv6SJ36RF7u_a742nPNoa1afMgCVbWGNw5wvTpjfXAArF99jDXhmmEd5QGqsgEopEOZQRBUlCPgsBKarIOWdRHES8iw7zpmy2eMNz9FwLsC0yLkBYZKWfHwQIdkUigJ-ikld1V0P6luYJqrdFWbYveH2sSAdd1IE4MHZ0UBRdJHcjW1wwir3zBa_7FHV4OPHo8I63NJGAbcOCzU25RS1nLrMc4prwGz9zzfHUBtExr5kKymg6v9Vlw5TVP_gzAd55eevOwr8VmEvdAFdZmUtmGRK9V94D_q18dEtGEoC5IJ8GfBDp9bl4DDjjwqaVqT4SYhtTrdVhOtI1KK5osNVqBVRX8fol5Xu8yosqa_vs-xfbaNqXwaUXZuihV4ally-kn_W1UTvY6Y-nJ09v57HIG_7a4If_G8ijklOtQOC0EiLJwKQgQFyKRERZzBGTQxUFVGZKoBENmNZHT4alF4ellwalt4b13hrWe2tY761LvZ_1_QJ7RyzNo-e6qVJev9d68lQ4U2skyyJTiI9ApiGikcQQkzRAQez7MaNhpPmkh96BYenJsPTisPTDej8Z1vvJsN5PhvV-cqn3s77b2BdmVICkKkJeHTrWZFcEx-uxngcSS7BX8ZhXvLp6rtrtbdOU9TcBBNjv91dJUSQ7ftWeqAJ8BtkWdZv2YyQus4xJhzRN0c_bcTwfS3Qze3kbOahbbroNOckeP18atr-LMyM4vayRFxz2vwD1wDsC/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fsoftware%2Fsolutions-platform%2Felera)

#### Mobility

Empowering staff on the move. Our mobile-ready solutions provide seamless access to tools, inventory, and customer data anytime, anywhere, driving efficiency and enhancing the in-store experience.

##### Products:

[IoT Suite](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tVbbcpswEP0aHhUtQoDoGyY2xsTYpHEc85LhIjCtuQRIHOfrC3U603RiM6kHXgSaPWf3nNlFwh5-wF7uv6SJ36RF7u_a742nPNoa1afMgCVbWGNw5wvTpjfXAArF99jDXhmmEd5QGqsgEopEOZQRBUlCPgsBKarIOWdRHES8iw7zpmy2eMNz9FwLsC0yLkBYZKWfHwQIdkUigJ-ikld1V0P6luYJqrdFWbYveH2sSAdd1IE4MHZ0UBRdJHcjW1wwir3zBa_7FHV4OPHo8I63NJGAbcOCzU25RS1nLrMc4prwGz9zzfHUBtExr5kKymg6v9Vlw5TVP_gzAd55eevOwr8VmEvdAFdZmUtmGRK9V94D_q18dEtGEoC5IJ8GfBDp9bl4DDjjwqaVqT4SYhtTrdVhOtI1KK5osNVqBVRX8fol5Xu8yosqa_vs-xfbaNqXwaUXZuihV4ally-kn_W1UTvY6Y-nJ09v57HIG_7a4If_G8ijklOtQOC0EiLJwKQgQFyKRERZzBGTQxUFVGZKoBENmNZHT4alF4ellwalt4b13hrWe2tY761LvZ_1_QJ7RyzNo-e6qVJev9d68lQ4U2skyyJTiI9ApiGikcQQkzRAQez7MaNhpPmkh96BYenJsPTisPTDej8Z1vvJsN5PhvV-cqn3s77b2BdmVICkKkJeHTrWZFcEx-uxngcSS7BX8ZhXvLp6rtrtbdOU9TcBBNjv91dJUSQ7ftWeqAJ8BtkWdZv2YyQus4xJhzRN0c_bcTwfS3Qze3kbOahbbroNOckeP18atr-LMyM4vayRFxz2vwD1wDsC/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fsoftware%2Fiot-suite)

, [ELERA® Loss Prevention](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tVbbcpswEP0aHhUtQoDoGyY2xsTYpHEc85LhIjCtuQRIHOfrC3U603RiM6kHXgSaPWf3nNlFwh5-wF7uv6SJ36RF7u_a742nPNoa1afMgCVbWGNw5wvTpjfXAArF99jDXhmmEd5QGqsgEopEOZQRBUlCPgsBKarIOWdRHES8iw7zpmy2eMNz9FwLsC0yLkBYZKWfHwQIdkUigJ-ikld1V0P6luYJqrdFWbYveH2sSAdd1IE4MHZ0UBRdJHcjW1wwir3zBa_7FHV4OPHo8I63NJGAbcOCzU25RS1nLrMc4prwGz9zzfHUBtExr5kKymg6v9Vlw5TVP_gzAd55eevOwr8VmEvdAFdZmUtmGRK9V94D_q18dEtGEoC5IJ8GfBDp9bl4DDjjwqaVqT4SYhtTrdVhOtI1KK5osNVqBVRX8fol5Xu8yosqa_vs-xfbaNqXwaUXZuihV4ally-kn_W1UTvY6Y-nJ09v57HIG_7a4If_G8ijklOtQOC0EiLJwKQgQFyKRERZzBGTQxUFVGZKoBENmNZHT4alF4ellwalt4b13hrWe2tY761LvZ_1_QJ7RyzNo-e6qVJev9d68lQ4U2skyyJTiI9ApiGikcQQkzRAQez7MaNhpPmkh96BYenJsPTisPTDej8Z1vvJsN5PhvV-cqn3s77b2BdmVICkKkJeHTrWZFcEx-uxngcSS7BX8ZhXvLp6rtrtbdOU9TcBBNjv91dJUSQ7ftWeqAJ8BtkWdZv2YyQus4xJhzRN0c_bcTwfS3Qze3kbOahbbroNOckeP18atr-LMyM4vayRFxz2vwD1wDsC/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fsoftware%2Fiot-suite%2Floss-prevention)

#### Servicability

Maximizing uptime, minimizing effort. Our solutions are designed for easy maintenance, quick repairs, and hassle-free updates, keeping your systems running smoothly and your business productive.

##### Products:

[Retail Transformation Services](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tVbbcpswEP0aHhUtQoDoGyY2xsTYpHEc85LhIjCtuQRIHOfrC3U603RiM6kHXgSaPWf3nNlFwh5-wF7uv6SJ36RF7u_a742nPNoa1afMgCVbWGNw5wvTpjfXAArF99jDXhmmEd5QGqsgEopEOZQRBUlCPgsBKarIOWdRHES8iw7zpmy2eMNz9FwLsC0yLkBYZKWfHwQIdkUigJ-ikld1V0P6luYJqrdFWbYveH2sSAdd1IE4MHZ0UBRdJHcjW1wwir3zBa_7FHV4OPHo8I63NJGAbcOCzU25RS1nLrMc4prwGz9zzfHUBtExr5kKymg6v9Vlw5TVP_gzAd55eevOwr8VmEvdAFdZmUtmGRK9V94D_q18dEtGEoC5IJ8GfBDp9bl4DDjjwqaVqT4SYhtTrdVhOtI1KK5osNVqBVRX8fol5Xu8yosqa_vs-xfbaNqXwaUXZuihV4ally-kn_W1UTvY6Y-nJ09v57HIG_7a4If_G8ijklOtQOC0EiLJwKQgQFyKRERZzBGTQxUFVGZKoBENmNZHT4alF4ellwalt4b13hrWe2tY761LvZ_1_QJ7RyzNo-e6qVJev9d68lQ4U2skyyJTiI9ApiGikcQQkzRAQez7MaNhpPmkh96BYenJsPTisPTDej8Z1vvJsN5PhvV-cqn3s77b2BdmVICkKkJeHTrWZFcEx-uxngcSS7BX8ZhXvLp6rtrtbdOU9TcBBNjv91dJUSQ7ftWeqAJ8BtkWdZv2YyQus4xJhzRN0c_bcTwfS3Qze3kbOahbbroNOckeP18atr-LMyM4vayRFxz2vwD1wDsC/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fservices%2Fimplement%2Fretail-services)

, [ELERA® Loss Prevention](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tVbbcpswEP0aHhUtQoDoGyY2xsTYpHEc85LhIjCtuQRIHOfrC3U603RiM6kHXgSaPWf3nNlFwh5-wF7uv6SJ36RF7u_a742nPNoa1afMgCVbWGNw5wvTpjfXAArF99jDXhmmEd5QGqsgEopEOZQRBUlCPgsBKarIOWdRHES8iw7zpmy2eMNz9FwLsC0yLkBYZKWfHwQIdkUigJ-ikld1V0P6luYJqrdFWbYveH2sSAdd1IE4MHZ0UBRdJHcjW1wwir3zBa_7FHV4OPHo8I63NJGAbcOCzU25RS1nLrMc4prwGz9zzfHUBtExr5kKymg6v9Vlw5TVP_gzAd55eevOwr8VmEvdAFdZmUtmGRK9V94D_q18dEtGEoC5IJ8GfBDp9bl4DDjjwqaVqT4SYhtTrdVhOtI1KK5osNVqBVRX8fol5Xu8yosqa_vs-xfbaNqXwaUXZuihV4ally-kn_W1UTvY6Y-nJ09v57HIG_7a4If_G8ijklOtQOC0EiLJwKQgQFyKRERZzBGTQxUFVGZKoBENmNZHT4alF4ellwalt4b13hrWe2tY761LvZ_1_QJ7RyzNo-e6qVJev9d68lQ4U2skyyJTiI9ApiGikcQQkzRAQez7MaNhpPmkh96BYenJsPTisPTDej8Z1vvJsN5PhvV-cqn3s77b2BdmVICkKkJeHTrWZFcEx-uxngcSS7BX8ZhXvLp6rtrtbdOU9TcBBNjv91dJUSQ7ftWeqAJ8BtkWdZv2YyQus4xJhzRN0c_bcTwfS3Qze3kbOahbbroNOckeP18atr-LMyM4vayRFxz2vwD1wDsC/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fsoftware%2Fiot-suite%2Floss-prevention)

![](https://commerce.toshiba.com/wps/contenthandler/dav/fs-type1/themes/TGCSMarketingThemeV3/css/images/dotted-corner--teal.svg?)

![](https://commerce.toshiba.com/wps/contenthandler/dav/fs-type1/themes/TGCSMarketingThemeV3/css/images/dotted-corner--cyan.svg)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

### The Trusted Partner to Accelerate Your Commerce Experiences

## \#1

Worldwide share of EPOS installations

## 205k +

POS and self-checkout units shipped in 2024

## 2.8 mil +

POS and self-checkout units installed worldwide

## \#2

Worldwide self-checkout installations

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/03258336-c87f-41c6-b451-d393938eb186/g_connecting.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-03258336-c87f-41c6-b451-d393938eb186-pKvEpjq)

## Connecting You to Our Marketplace

Toshiba Commerce’s Marketplace connects you with top retailers, providing a robust platform to present your solutions. It equips you with the necessary tools and partnerships to foster growth and success.

[Learn more about our Marketplace](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tVbbcpswEP0aHhUtQoDoGyY2xsTYpHEc85LhIjCtuQRIHOfrC3U603RiM6kHXgSaPWf3nNlFwh5-wF7uv6SJ36RF7u_a742nPNoa1afMgCVbWGNw5wvTpjfXAArF99jDXhmmEd5QGqsgEopEOZQRBUlCPgsBKarIOWdRHES8iw7zpmy2eMNz9FwLsC0yLkBYZKWfHwQIdkUigJ-ikld1V0P6luYJqrdFWbYveH2sSAdd1IE4MHZ0UBRdJHcjW1wwir3zBa_7FHV4OPHo8I63NJGAbcOCzU25RS1nLrMc4prwGz9zzfHUBtExr5kKymg6v9Vlw5TVP_gzAd55eevOwr8VmEvdAFdZmUtmGRK9V94D_q18dEtGEoC5IJ8GfBDp9bl4DDjjwqaVqT4SYhtTrdVhOtI1KK5osNVqBVRX8fol5Xu8yosqa_vs-xfbaNqXwaUXZuihV4ally-kn_W1UTvY6Y-nJ09v57HIG_7a4If_G8ijklOtQOC0EiLJwKQgQFyKRERZzBGTQxUFVGZKoBENmNZHT4alF4ellwalt4b13hrWe2tY761LvZ_1_QJ7RyzNo-e6qVJev9d68lQ4U2skyyJTiI9ApiGikcQQkzRAQez7MaNhpPmkh96BYenJsPTisPTDej8Z1vvJsN5PhvV-cqn3s77b2BdmVICkKkJeHTrWZFcEx-uxngcSS7BX8ZhXvLp6rtrtbdOU9TcBBNjv91dJUSQ7ftWeqAJ8BtkWdZv2YyQus4xJhzRN0c_bcTwfS3Qze3kbOahbbroNOckeP18atr-LMyM4vayRFxz2vwD1wDsC/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fmarketplace)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

## Stay Up to Date With the Latest on Toshiba

Latest company announcements, industry trends, and Toshiba’s role in shaping the future of retail.

[Explore Latest News](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tVbbcpswEP0aHhUtQoDoGyY2xsTYpHEc85LhIjCtuQRIHOfrC3U603RiM6kHXgSaPWf3nNlFwh5-wF7uv6SJ36RF7u_a742nPNoa1afMgCVbWGNw5wvTpjfXAArF99jDXhmmEd5QGqsgEopEOZQRBUlCPgsBKarIOWdRHES8iw7zpmy2eMNz9FwLsC0yLkBYZKWfHwQIdkUigJ-ikld1V0P6luYJqrdFWbYveH2sSAdd1IE4MHZ0UBRdJHcjW1wwir3zBa_7FHV4OPHo8I63NJGAbcOCzU25RS1nLrMc4prwGz9zzfHUBtExr5kKymg6v9Vlw5TVP_gzAd55eevOwr8VmEvdAFdZmUtmGRK9V94D_q18dEtGEoC5IJ8GfBDp9bl4DDjjwqaVqT4SYhtTrdVhOtI1KK5osNVqBVRX8fol5Xu8yosqa_vs-xfbaNqXwaUXZuihV4ally-kn_W1UTvY6Y-nJ09v57HIG_7a4If_G8ijklOtQOC0EiLJwKQgQFyKRERZzBGTQxUFVGZKoBENmNZHT4alF4ellwalt4b13hrWe2tY761LvZ_1_QJ7RyzNo-e6qVJev9d68lQ4U2skyyJTiI9ApiGikcQQkzRAQez7MaNhpPmkh96BYenJsPTisPTDej8Z1vvJsN5PhvV-cqn3s77b2BdmVICkKkJeHTrWZFcEx-uxngcSS7BX8ZhXvLp6rtrtbdOU9TcBBNjv91dJUSQ7ftWeqAJ8BtkWdZv2YyQus4xJhzRN0c_bcTwfS3Qze3kbOahbbroNOckeP18atr-LMyM4vayRFxz2vwD1wDsC/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fcompany%2Fnewsmedia)

[**NRF 2026 Retail’s Big Show At Javits Convention Center, New York City**\\
\\
January 11, 2026\\
\\
Event Article\\
\\
Retail’s rapid revolution is here! In a world brimming with possibilities, the journey you take is as important as the destination. Each uncharted path you explore, each challenge you overcome, earns you a badge – a tangible reminder of your journey and growth.\\
View Event](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tVbbcpswEP0aHhUtQoDoGyY2xsTYpHEc85LhIjCtuQRIHOfrC3U603RiM6kHXgSaPWf3nNlFwh5-wF7uv6SJ36RF7u_a742nPNoa1afMgCVbWGNw5wvTpjfXAArF99jDXhmmEd5QGqsgEopEOZQRBUlCPgsBKarIOWdRHES8iw7zpmy2eMNz9FwLsC0yLkBYZKWfHwQIdkUigJ-ikld1V0P6luYJqrdFWbYveH2sSAdd1IE4MHZ0UBRdJHcjW1wwir3zBa_7FHV4OPHo8I63NJGAbcOCzU25RS1nLrMc4prwGz9zzfHUBtExr5kKymg6v9Vlw5TVP_gzAd55eevOwr8VmEvdAFdZmUtmGRK9V94D_q18dEtGEoC5IJ8GfBDp9bl4DDjjwqaVqT4SYhtTrdVhOtI1KK5osNVqBVRX8fol5Xu8yosqa_vs-xfbaNqXwaUXZuihV4ally-kn_W1UTvY6Y-nJ09v57HIG_7a4If_G8ijklOtQOC0EiLJwKQgQFyKRERZzBGTQxUFVGZKoBENmNZHT4alF4ellwalt4b13hrWe2tY761LvZ_1_QJ7RyzNo-e6qVJev9d68lQ4U2skyyJTiI9ApiGikcQQkzRAQez7MaNhpPmkh96BYenJsPTisPTDej8Z1vvJsN5PhvV-cqn3s77b2BdmVICkKkJeHTrWZFcEx-uxngcSS7BX8ZhXvLp6rtrtbdOU9TcBBNjv91dJUSQ7ftWeqAJ8BtkWdZv2YyQus4xJhzRN0c_bcTwfS3Qze3kbOahbbroNOckeP18atr-LMyM4vayRFxz2vwD1wDsC/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fcompany%2Fevents%2Fnrf-2026&mapping=tgcs_new.portal.company.eventdetails) [**Toshiba Named a Leader in the IDC MarketScape: Worldwide Point-of-Sale Software in Grocery and Food Store Retail 2026 Vendor Assessment**\\
\\
May 06, 2026\\
\\
Insight Article\\
\\
In the report, IDC covers the evolution of POS systems from transaction terminals to comprehensive commerce hubs, along with the movement toward cloud-native, API-first, microservices architectures that support retailer extension, configuration, and self-enablement.\\
View News](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tVbbcpswEP0aHhUtQoDoGyY2xsTYpHEc85LhIjCtuQRIHOfrC3U603RiM6kHXgSaPWf3nNlFwh5-wF7uv6SJ36RF7u_a742nPNoa1afMgCVbWGNw5wvTpjfXAArF99jDXhmmEd5QGqsgEopEOZQRBUlCPgsBKarIOWdRHES8iw7zpmy2eMNz9FwLsC0yLkBYZKWfHwQIdkUigJ-ikld1V0P6luYJqrdFWbYveH2sSAdd1IE4MHZ0UBRdJHcjW1wwir3zBa_7FHV4OPHo8I63NJGAbcOCzU25RS1nLrMc4prwGz9zzfHUBtExr5kKymg6v9Vlw5TVP_gzAd55eevOwr8VmEvdAFdZmUtmGRK9V94D_q18dEtGEoC5IJ8GfBDp9bl4DDjjwqaVqT4SYhtTrdVhOtI1KK5osNVqBVRX8fol5Xu8yosqa_vs-xfbaNqXwaUXZuihV4ally-kn_W1UTvY6Y-nJ09v57HIG_7a4If_G8ijklOtQOC0EiLJwKQgQFyKRERZzBGTQxUFVGZKoBENmNZHT4alF4ellwalt4b13hrWe2tY761LvZ_1_QJ7RyzNo-e6qVJev9d68lQ4U2skyyJTiI9ApiGikcQQkzRAQez7MaNhpPmkh96BYenJsPTisPTDej8Z1vvJsN5PhvV-cqn3s77b2BdmVICkKkJeHTrWZFcEx-uxngcSS7BX8ZhXvLp6rtrtbdOU9TcBBNjv91dJUSQ7ftWeqAJ8BtkWdZv2YyQus4xJhzRN0c_bcTwfS3Qze3kbOahbbroNOckeP18atr-LMyM4vayRFxz2vwD1wDsC/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fcompany%2Finsights%2Fidc-marketscape-grocery-pos-software-2026&mapping=tgcs_new.portal.company.newsdetails.new) [**NRF Video Spotlight – Google: Developing a Modern Edge Strategy**\\
\\
April 28, 2026\\
\\
Insight Article\\
\\
In this video discussion, Keswani and Lakoski explore how retailers can build a modern edge strategy that supports both operational stability and long-term innovation. Edge computing allows retailers to process critical information directly within store environments while maintaining integration with cloud infrastructure. The combination of Google Distributed Cloud and the ELERA® Commerce Platform extends cloud-native capabilities into physical stores and creates a flexible foundation that allows retailers to deploy new solutions more quickly.\\
View Blog](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tVbbcpswEP0aHhUtQoDoGyY2xsTYpHEc85LhIjCtuQRIHOfrC3U603RiM6kHXgSaPWf3nNlFwh5-wF7uv6SJ36RF7u_a742nPNoa1afMgCVbWGNw5wvTpjfXAArF99jDXhmmEd5QGqsgEopEOZQRBUlCPgsBKarIOWdRHES8iw7zpmy2eMNz9FwLsC0yLkBYZKWfHwQIdkUigJ-ikld1V0P6luYJqrdFWbYveH2sSAdd1IE4MHZ0UBRdJHcjW1wwir3zBa_7FHV4OPHo8I63NJGAbcOCzU25RS1nLrMc4prwGz9zzfHUBtExr5kKymg6v9Vlw5TVP_gzAd55eevOwr8VmEvdAFdZmUtmGRK9V94D_q18dEtGEoC5IJ8GfBDp9bl4DDjjwqaVqT4SYhtTrdVhOtI1KK5osNVqBVRX8fol5Xu8yosqa_vs-xfbaNqXwaUXZuihV4ally-kn_W1UTvY6Y-nJ09v57HIG_7a4If_G8ijklOtQOC0EiLJwKQgQFyKRERZzBGTQxUFVGZKoBENmNZHT4alF4ellwalt4b13hrWe2tY761LvZ_1_QJ7RyzNo-e6qVJev9d68lQ4U2skyyJTiI9ApiGikcQQkzRAQez7MaNhpPmkh96BYenJsPTisPTDej8Z1vvJsN5PhvV-cqn3s77b2BdmVICkKkJeHTrWZFcEx-uxngcSS7BX8ZhXvLp6rtrtbdOU9TcBBNjv91dJUSQ7ftWeqAJ8BtkWdZv2YyQus4xJhzRN0c_bcTwfS3Qze3kbOahbbroNOckeP18atr-LMyM4vayRFxz2vwD1wDsC/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fcompany%2Finsights%2Fnrf-video-google-modern-edge-strategy&mapping=tgcs_new.portal.company.newsdetails.new) [**Toshiba Global Commerce Solutions Sponsors Retailers Lounge at the Retail Technology Show 2024**\\
\\
March 07, 2026\\
\\
News Article\\
\\
Toshiba Global Commerce Solutions is proud to announce its continued partnership as the sponsor of the Retailers Lounge at the Retail Technology Show for the third consecutive year. The event, set to take place on April 24-25 at Olympia London, will bring together retail trailblazers, uniting the region’s foremost retailers and tech innovators.\\
View News](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tVbbcpswEP0aHhUtQoDoGyY2xsTYpHEc85LhIjCtuQRIHOfrC3U603RiM6kHXgSaPWf3nNlFwh5-wF7uv6SJ36RF7u_a742nPNoa1afMgCVbWGNw5wvTpjfXAArF99jDXhmmEd5QGqsgEopEOZQRBUlCPgsBKarIOWdRHES8iw7zpmy2eMNz9FwLsC0yLkBYZKWfHwQIdkUigJ-ikld1V0P6luYJqrdFWbYveH2sSAdd1IE4MHZ0UBRdJHcjW1wwir3zBa_7FHV4OPHo8I63NJGAbcOCzU25RS1nLrMc4prwGz9zzfHUBtExr5kKymg6v9Vlw5TVP_gzAd55eevOwr8VmEvdAFdZmUtmGRK9V94D_q18dEtGEoC5IJ8GfBDp9bl4DDjjwqaVqT4SYhtTrdVhOtI1KK5osNVqBVRX8fol5Xu8yosqa_vs-xfbaNqXwaUXZuihV4ally-kn_W1UTvY6Y-nJ09v57HIG_7a4If_G8ijklOtQOC0EiLJwKQgQFyKRERZzBGTQxUFVGZKoBENmNZHT4alF4ellwalt4b13hrWe2tY761LvZ_1_QJ7RyzNo-e6qVJev9d68lQ4U2skyyJTiI9ApiGikcQQkzRAQez7MaNhpPmkh96BYenJsPTisPTDej8Z1vvJsN5PhvV-cqn3s77b2BdmVICkKkJeHTrWZFcEx-uxngcSS7BX8ZhXvLp6rtrtbdOU9TcBBNjv91dJUSQ7ftWeqAJ8BtkWdZv2YyQus4xJhzRN0c_bcTwfS3Qze3kbOahbbroNOckeP18atr-LMyM4vayRFxz2vwD1wDsC/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fcompany%2Fnewsmedia%2Fnews%2Ftoshiba-unveils-next-generation-retail-solutions-at-nrf-2026&mapping=tgcs_new.portal.company.newsdetails.new) [**No Man's Land of Innovation: Overcoming Hesitations in Embracing Innovation**\\
\\
May 07, 2026\\
\\
Blog Article\\
\\
Over recent years, innovation has become more important than ever for retailers looking to keep up with customer expectations and get ahead of their competitors. However, there is a gap between the idea and implementation of innovation strategies.\\
View Blog](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tVbbcpswEP0aHhUtQoDoGyY2xsTYpHEc85LhIjCtuQRIHOfrC3U603RiM6kHXgSaPWf3nNlFwh5-wF7uv6SJ36RF7u_a742nPNoa1afMgCVbWGNw5wvTpjfXAArF99jDXhmmEd5QGqsgEopEOZQRBUlCPgsBKarIOWdRHES8iw7zpmy2eMNz9FwLsC0yLkBYZKWfHwQIdkUigJ-ikld1V0P6luYJqrdFWbYveH2sSAdd1IE4MHZ0UBRdJHcjW1wwir3zBa_7FHV4OPHo8I63NJGAbcOCzU25RS1nLrMc4prwGz9zzfHUBtExr5kKymg6v9Vlw5TVP_gzAd55eevOwr8VmEvdAFdZmUtmGRK9V94D_q18dEtGEoC5IJ8GfBDp9bl4DDjjwqaVqT4SYhtTrdVhOtI1KK5osNVqBVRX8fol5Xu8yosqa_vs-xfbaNqXwaUXZuihV4ally-kn_W1UTvY6Y-nJ09v57HIG_7a4If_G8ijklOtQOC0EiLJwKQgQFyKRERZzBGTQxUFVGZKoBENmNZHT4alF4ellwalt4b13hrWe2tY761LvZ_1_QJ7RyzNo-e6qVJev9d68lQ4U2skyyJTiI9ApiGikcQQkzRAQez7MaNhpPmkh96BYenJsPTisPTDej8Z1vvJsN5PhvV-cqn3s77b2BdmVICkKkJeHTrWZFcEx-uxngcSS7BX8ZhXvLp6rtrtbdOU9TcBBNjv91dJUSQ7ftWeqAJ8BtkWdZv2YyQus4xJhzRN0c_bcTwfS3Qze3kbOahbbroNOckeP18atr-LMyM4vayRFxz2vwD1wDsC/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Fcompany%2Fblog%2Fovercoming-hesitation-innovation&mapping=tgcs_new.portal.company.newsdetails.new)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/a920d64a-369f-4018-89bf-39fca4fb1928/footer-cta.jpg?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-a920d64a-369f-4018-89bf-39fca4fb1928-pKvEptf)

## The Future of Retail Starts Here

Latest company announcements, industry trends, and Toshiba’s role in shaping the future of retail.

[Work With Us Today](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tVbbcpswEP0aHhUtQoDoGyY2xsTYpHEc85LhIjCtuQRIHOfrC3U603RiM6kHXgSaPWf3nNlFwh5-wF7uv6SJ36RF7u_a742nPNoa1afMgCVbWGNw5wvTpjfXAArF99jDXhmmEd5QGqsgEopEOZQRBUlCPgsBKarIOWdRHES8iw7zpmy2eMNz9FwLsC0yLkBYZKWfHwQIdkUigJ-ikld1V0P6luYJqrdFWbYveH2sSAdd1IE4MHZ0UBRdJHcjW1wwir3zBa_7FHV4OPHo8I63NJGAbcOCzU25RS1nLrMc4prwGz9zzfHUBtExr5kKymg6v9Vlw5TVP_gzAd55eevOwr8VmEvdAFdZmUtmGRK9V94D_q18dEtGEoC5IJ8GfBDp9bl4DDjjwqaVqT4SYhtTrdVhOtI1KK5osNVqBVRX8fol5Xu8yosqa_vs-xfbaNqXwaUXZuihV4ally-kn_W1UTvY6Y-nJ09v57HIG_7a4If_G8ijklOtQOC0EiLJwKQgQFyKRERZzBGTQxUFVGZKoBENmNZHT4alF4ellwalt4b13hrWe2tY761LvZ_1_QJ7RyzNo-e6qVJev9d68lQ4U2skyyJTiI9ApiGikcQQkzRAQez7MaNhpPmkh96BYenJsPTisPTDej8Z1vvJsN5PhvV-cqn3s77b2BdmVICkKkJeHTrWZFcEx-uxngcSS7BX8ZhXvLp6rtrtbdOU9TcBBNjv91dJUSQ7ftWeqAJ8BtkWdZv2YyQus4xJhzRN0c_bcTwfS3Qze3kbOahbbroNOckeP18atr-LMyM4vayRFxz2vwD1wDsC/?1dmy&urile=wcm%3apath%3a%2Fen-us%2Fhome%2Findustries)

![](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tVbbcpswEP0aHhUtQoDoGyY2xsTYpHEc85LhIjCtuQRIHOfrC3U603RiM6kHXgSaPWf3nNlFwh5-wF7uv6SJ36RF7u_a742nPNoa1afMgCVbWGNw5wvTpjfXAArF99jDXhmmEd5QGqsgEopEOZQRBUlCPgsBKarIOWdRHES8iw7zpmy2eMNz9FwLsC0yLkBYZKWfHwQIdkUigJ-ikld1V0P6luYJqrdFWbYveH2sSAdd1IE4MHZ0UBRdJHcjW1wwir3zBa_7FHV4OPHo8I63NJGAbcOCzU25RS1nLrMc4prwGz9zzfHUBtExr5kKymg6v9Vlw5TVP_gzAd55eevOwr8VmEvdAFdZmUtmGRK9V94D_q18dEtGEoC5IJ8GfBDp9bl4DDjjwqaVqT4SYhtTrdVhOtI1KK5osNVqBVRX8fol5Xu8yosqa_vs-xfbaNqXwaUXZuihV4ally-kn_W1UTvY6Y-nJ09v57HIG_7a4If_G8ijklOtQOC0EiLJwKQgQFyKRERZzBGTQxUFVGZKoBENmNZHT4alF4ellwalt4b13hrWe2tY761LvZ_1_QJ7RyzNo-e6qVJev9d68lQ4U2skyyJTiI9ApiGikcQQkzRAQez7MaNhpPmkh96BYenJsPTisPTDej8Z1vvJsN5PhvV-cqn3s77b2BdmVICkKkJeHTrWZFcEx-uxngcSS7BX8ZhXvLp6rtrtbdOU9TcBBNjv91dJUSQ7ftWeqAJ8BtkWdZv2YyQus4xJhzRN0c_bcTwfS3Qze3kbOahbbroNOckeP18atr-LMyM4vayRFxz2vwD1wDsC/)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

Start a conversation

First name

Last name

Email

Company

Country

Phone

I am a

Business PartnerOtherPress / AnalystRetailerSupplierToshiba Employee

- Business Partner

- Other

- Press / Analyst

- Retailer

- Supplier

- Toshiba Employee


My Retail Segment

Fashion & ApparelFood ServiceGas & ConvenienceGroceryMass MerchandiseOtherPharmacy / Drug StoreSpecialty

- Fashion & Apparel

- Food Service

- Gas & Convenience

- Grocery

- Mass Merchandise

- Other

- Pharmacy / Drug Store

- Specialty


I am interested in learning more about

Add me to Toshiba Global Commerce Solutions' email marketing list

I am allowing Toshiba to contact me in regards to the information on this form

Comments

By submitting this form I agree that Toshiba Global Commerce Solutions, Inc. and its affiliates, including all subsidiaries and branches, may process my data as indicated above and as described in the [Toshiba Global Commerce Solutions Privacy Declaration.](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/common-content/general-content/privacy-policy&mapping=tgcs_new.portal.generaldetails)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**

reCAPTCHA is changing its terms of service. [Take action.](https://google.com/recaptcha/admin/migrate)

![success](https://commerce.toshiba.com/wps/portal/marketing/Home/tgcs/home/!ut/p/z1/tVbbcpswEP0aHhUtQoDoGyY2xsTYpHEc85LhIjCtuQRIHOfrC3U603RiM6kHXgSaPWf3nNlFwh5-wF7uv6SJ36RF7u_a742nPNoa1afMgCVbWGNw5wvTpjfXAArF99jDXhmmEd5QGqsgEopEOZQRBUlCPgsBKarIOWdRHES8iw7zpmy2eMNz9FwLsC0yLkBYZKWfHwQIdkUigJ-ikld1V0P6luYJqrdFWbYveH2sSAdd1IE4MHZ0UBRdJHcjW1wwir3zBa_7FHV4OPHo8I63NJGAbcOCzU25RS1nLrMc4prwGz9zzfHUBtExr5kKymg6v9Vlw5TVP_gzAd55eevOwr8VmEvdAFdZmUtmGRK9V94D_q18dEtGEoC5IJ8GfBDp9bl4DDjjwqaVqT4SYhtTrdVhOtI1KK5osNVqBVRX8fol5Xu8yosqa_vs-xfbaNqXwaUXZuihV4ally-kn_W1UTvY6Y-nJ09v57HIG_7a4If_G8ijklOtQOC0EiLJwKQgQFyKRERZzBGTQxUFVGZKoBENmNZHT4alF4ellwalt4b13hrWe2tY761LvZ_1_QJ7RyzNo-e6qVJev9d68lQ4U2skyyJTiI9ApiGikcQQkzRAQez7MaNhpPmkh96BYenJsPTisPTDej8Z1vvJsN5PhvV-cqn3s77b2BdmVICkKkJeHTrWZFcEx-uxngcSS7BX8ZhXvLp6rtrtbdOU9TcBBNjv91dJUSQ7ftWeqAJ8BtkWdZv2YyQus4xJhzRN0c_bcTwfS3Qze3kbOahbbroNOckeP18atr-LMyM4vayRFxz2vwD1wDsC/images/tgcs/success.svg)

## Success!

Thank you for reaching out. One of our team members will be in contact soon. We hope you have a great day.

Close

Complementary
Content

[Deferred Modules](https://commerce.toshiba.com/wps/contenthandler/marketing/!ut/p/digest!M6zrA0PEiotCbddBEGnoVg/mashup/ra:collection?themeID=ZJ_KA0A1A02NONK906RHNLDBR2AS4&locale=en&mime-type=text%2Fjavascript&lm=1778876784000&entry=st_skin__0.0%3Aconfig_js&entry=wp_liveobject_framework_core__0.0%3Aconfig_js&entry=wp_portal_ui_utils__0.0%3Aconfig_js&entry=wp_contextmenu_js__0.0%3Aconfig_js&entry=wp_skin_cam__0.0%3Aconfig_js&entry=wp_contextmenu_config_lof__0.0%3Aconfig_js&entry=wp_federated_documents_picker__0.0%3Aconfig_js&entry=wp_dnd_main__0.0%3Aconfig_js&entry=wp_movecontrols__0.0%3Aconfig_js&entry=wp_toolbar_controlactions__0.0%3Aconfig_js&entry=wp_content_targeting_cam__0.0%3Aconfig_js&deferred=true)

- ${title}${badge}

${loading}

[Deferred Modules](https://commerce.toshiba.com/wps/contenthandler/marketing/!ut/p/digest!SpZvrtUURDcRHYzcbiqg-Q/mashup/ra:collection?themeID=ZJ_KA0A1A02NONK906RHNLDBR2AS4&locale=en&mime-type=text%2Fplain&entry=wp_contextmenu_templates__0.0%3Aconfig_markup&entry=wp_skin_cam__0.0%3Aconfig_markup&entry=wp_dnd_main__0.0%3Aconfig_markup&deferred=true)

reCAPTCHA