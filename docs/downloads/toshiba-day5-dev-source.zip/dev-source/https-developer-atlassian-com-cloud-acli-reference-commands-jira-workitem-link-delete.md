<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-link-delete -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Last updated Oct 3, 2024

On This Page

- [acli jira workitem link delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-link-delete/#acli-jira-workitem-link-delete)


## acli jira workitem link delete

Delete links between work items.

```
Copy
1
acli jira workitem link delete [flags]
```

### Examples

```
Copy
1
2
3
4
5
6
7
8
9
# Delete a link between two work items
$ acli jira workitem link delete --id 10001

# Delete multiple links from a JSON file
$ acli jira workitem link delete --from-json links.json

# Delete multiple links from a CSV file
$ acli jira workitem link delete --from-csv links.csv
```

### Options

```
Copy
1
2
3
4
5
6
      --from-csv string    Read a CSV file for Link IDs to delete
      --from-json string   Read a JSON file for Link IDs to delete
  -h, --help               Show help for command
      --id string          Link IDs to delete
      --ignore-errors      Ignore the errors and continue with the next link
      --yes                Confirm link deletion without prompting
```

### SEE ALSO

- [acli jira workitem link](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-link) \- Link work items commands.

Rate this page:

Unusable

Poor

Okay

Good

Excellent