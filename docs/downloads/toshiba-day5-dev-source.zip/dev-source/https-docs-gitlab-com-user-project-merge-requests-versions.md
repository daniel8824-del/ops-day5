<!-- source: https://docs.gitlab.com/user/project/merge_requests/versions -->

/

* * *

# Merge request diff versions

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

When you create a merge request, you select two branches to compare. The differences
between the two branches are shown as a diff in the merge request. Each time
you push commits to a branch connected to a merge request, GitLab updates the
merge request diff to a new diff version.

Diff versions are updated on each push, not each commit. If a push contains multiple
commits, only one new diff version is created.

By default, GitLab compares the latest push in your source branch (`feature`)
against the most recent commit in the target branch, often `main`.

## Compare diff versions [Permalink](https://docs.gitlab.com/user/project/merge_requests/versions/\#compare-diff-versions "Permalink")

If you’ve pushed to your branch multiple times, the diff version from each previous push
is available for comparison. When your merge request contains many changes or
sequential changes to the same file, you might want to compare a smaller number of changes.

Prerequisites:

- The merge request branch must contain commits from multiple pushes. Individual commits
in the same push do not generate new diff versions.

To compare diff versions:

1. In the top bar, select **Search or go to** and find your project.

2. In the left sidebar, select **Code** \> **Merge requests**.

3. Select a merge request.

4. To view the current diff version for this merge request, select **Changes**.

5. Next to **Compare** (file-tree), select the pushes to compare. This example
compares `main` to the most recent push (latest diff version) of the branch:

![Merge request versions dropdown list](https://docs.gitlab.com/user/project/merge_requests/img/versions_dropdown_v16_6.png)

This example branch has four commits, but the branch contains only three diff versions
because two commits were pushed at the same time.


## View diff versions from a system note [Permalink](https://docs.gitlab.com/user/project/merge_requests/versions/\#view-diff-versions-from-a-system-note "Permalink")

GitLab adds a system note to a merge request each time you push new changes to
the merge request’s branch. In this example, a single push added two commits:

![Merge request versions system note](https://docs.gitlab.com/user/project/merge_requests/img/versions_system_note_v16_6.png)

To view the diff for that commit, select the commit SHA.

For more information, see how to [show or filter system notes on a merge request](https://docs.gitlab.com/user/project/system_notes/#on-a-merge-request).

## Related topics [Permalink](https://docs.gitlab.com/user/project/merge_requests/versions/\#related-topics "Permalink")

- [Merge request diff storage for administrators](https://docs.gitlab.com/administration/merge_request_diffs/)

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**