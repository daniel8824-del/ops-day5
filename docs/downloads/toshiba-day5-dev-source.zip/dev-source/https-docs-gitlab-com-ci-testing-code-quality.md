<!-- source: https://docs.gitlab.com/ci/testing/code_quality -->

/

* * *

# Code Quality

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

Code Quality identifies maintainability issues before they become technical debt.
The automated feedback that occurs during code reviews can help your team write better code.
The findings appear directly in merge requests, making problems visible when they’re most cost-effective to fix.

Code Quality works with multiple programming languages and integrates with common linters, style
checkers, and complexity analyzers. Your existing tools can feed into the Code Quality workflow,
preserving your team’s preferences while standardizing how results are displayed.

## Features per tier [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#features-per-tier "Permalink")

Different features are available in different [GitLab tiers](https://about.gitlab.com/pricing/),
as shown in the following table:

| Feature | In Free | In Premium | In Ultimate |
| --- | --- | --- | --- |
| [Import Code Quality results from CI/CD jobs](https://docs.gitlab.com/ci/testing/code_quality/#import-code-quality-results-from-a-cicd-job) | check-sm | check-sm | check-sm |
| [Use CodeClimate-based scanning](https://docs.gitlab.com/ci/testing/code_quality/#use-the-built-in-code-quality-cicd-template-deprecated) | check-sm | check-sm | check-sm |
| [See findings in a merge request widget](https://docs.gitlab.com/ci/testing/code_quality/#merge-request-widget) | check-sm | check-sm | check-sm |
| [See findings in a pipeline report](https://docs.gitlab.com/ci/testing/code_quality/#pipeline-details-view) | No | check-sm | check-sm |
| [See findings in the merge request changes view](https://docs.gitlab.com/ci/testing/code_quality/#merge-request-changes-view) | No | No | check-sm |
| [Analyze overall health in a project quality summary view](https://docs.gitlab.com/ci/testing/code_quality/#project-quality-view) | No | No | check-sm |

## Scan code for quality violations [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#scan-code-for-quality-violations "Permalink")

Code Quality is an open system that supports importing results from many scanning tools.
To find violations and surface them, you can:

- Directly use a scanning tool and [import its results](https://docs.gitlab.com/ci/testing/code_quality/#import-code-quality-results-from-a-cicd-job). _(Preferred.)_
- [Use a built-in CI/CD template](https://docs.gitlab.com/ci/testing/code_quality/#use-the-built-in-code-quality-cicd-template-deprecated) to enable scanning. The template uses the CodeClimate engine, which wraps common open source tools. _(Deprecated.)_

You can capture results from multiple tools in a single pipeline.
For example, you can run a code linter to scan your code along with a language linter to scan your documentation, or you can use a standalone tool along with CodeClimate-based scanning.
Code Quality combines all of the reports so you see all of them when you [view results](https://docs.gitlab.com/ci/testing/code_quality/#view-code-quality-results).

### Import Code Quality results from a CI/CD job [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#import-code-quality-results-from-a-cicd-job "Permalink")

Many development teams already use linters, style checkers, or other tools in their CI/CD pipelines to automatically detect violations of coding standards.
You can make the findings from these tools easier to see and fix by integrating them with Code Quality.

To see if your tool already has a documented integration, see [Integrate common tools with Code Quality](https://docs.gitlab.com/ci/testing/code_quality/#integrate-common-tools-with-code-quality).

To integrate a different tool with Code Quality:

1. Add the tool to your CI/CD pipeline.
2. Configure the tool to output a report as a file.
   - This file must use a [specific JSON format](https://docs.gitlab.com/ci/testing/code_quality/#code-quality-report-format).
   - Many tools support this output format natively. They may call it a “CodeClimate report”, “GitLab Code Quality report”, or another similar name.
   - Other tools can sometimes create JSON output using a custom JSON format or template. Because the [report format](https://docs.gitlab.com/ci/testing/code_quality/#code-quality-report-format) has only a few required fields, you may be able to use this output type to create a report for Code Quality.
3. Declare a [`codequality` report artifact](https://docs.gitlab.com/ci/yaml/artifacts_reports/#artifactsreportscodequality) that matches this file.

Now, after the pipeline runs, the quality tool’s results are [processed and displayed](https://docs.gitlab.com/ci/testing/code_quality/#view-code-quality-results).

### Use the built-in Code Quality CI/CD template (deprecated) [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#use-the-built-in-code-quality-cicd-template-deprecated "Permalink")

This feature was [deprecated](https://docs.gitlab.com/update/deprecations/#codeclimate-based-code-quality-scanning-will-be-removed) in GitLab 17.3 and is planned for removal in 19.0.
[Integrate the results from a supported tool directly](https://docs.gitlab.com/ci/testing/code_quality/#import-code-quality-results-from-a-cicd-job) instead.

Code Quality also includes a built-in CI/CD template, `Code-Quality.gitlab-ci.yaml`.
This template runs a scan based on the open source CodeClimate scanning engine.

The CodeClimate engine runs:

- Basic maintainability checks for a [set of supported languages](https://docs.codeclimate.com/docs/supported-languages-for-maintainability).
- A configurable set of [plugins](https://docs.codeclimate.com/docs/list-of-engines), which wrap open source scanners, to analyze your source code.

For more details, see [Configure CodeClimate-based Code Quality scanning](https://docs.gitlab.com/ci/testing/code_quality_codeclimate_scanning/).

#### Migrate from CodeClimate-based scanning [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#migrate-from-codeclimate-based-scanning "Permalink")

The CodeClimate engine uses a customizable set of [analysis plugins](https://docs.gitlab.com/ci/testing/code_quality_codeclimate_scanning/#configure-codeclimate-analysis-plugins).
Some are on by default; others must be explicitly enabled.
The following integrations are available to replace the built-in plugins:

| Plugin | On by default | Replacement |
| --- | --- | --- |
| Duplication | check-sm | [Integrate PMD Copy/Paste Detector](https://docs.gitlab.com/ci/testing/code_quality/#pmd-copypaste-detector). |
| ESLint | check-sm | [Integrate ESLint](https://docs.gitlab.com/ci/testing/code_quality/#eslint). |
| gofmt | No | [Integrate golangci-lint](https://docs.gitlab.com/ci/testing/code_quality/#golangci-lint) and enable the [gofmt linter](https://golangci-lint.run/usage/linters#gofmt). |
| golint | No | [Integrate golangci-lint](https://docs.gitlab.com/ci/testing/code_quality/#golangci-lint) and enable one of the included linters that replaces golint. golint is [deprecated and frozen](https://github.com/golang/go/issues/38968). |
| govet | No | [Integrate golangci-lint](https://docs.gitlab.com/ci/testing/code_quality/#golangci-lint). golangci-lint [includes govet by default](https://golangci-lint.run/usage/linters#enabled-by-default). |
| markdownlint | No<br>(community-supported) | [Integrate markdownlint-cli2](https://docs.gitlab.com/ci/testing/code_quality/#markdownlint-cli2). |
| pep8 | No | Integrate an alternative Python linter like [Flake8](https://docs.gitlab.com/ci/testing/code_quality/#flake8), [Pylint](https://docs.gitlab.com/ci/testing/code_quality/#pylint), or [Ruff](https://docs.gitlab.com/ci/testing/code_quality/#ruff). |
| RuboCop | check-sm | [Integrate RuboCop](https://docs.gitlab.com/ci/testing/code_quality/#rubocop). |
| SonarPython | No | Integrate an alternative Python linter like [Flake8](https://docs.gitlab.com/ci/testing/code_quality/#flake8), [Pylint](https://docs.gitlab.com/ci/testing/code_quality/#pylint), or [Ruff](https://docs.gitlab.com/ci/testing/code_quality/#ruff). |
| Stylelint | No<br>(community-supported) | [Integrate Stylelint](https://docs.gitlab.com/ci/testing/code_quality/#stylelint). |
| SwiftLint | No | [Integrate SwiftLint](https://docs.gitlab.com/ci/testing/code_quality/#swiftlint). |

## View Code Quality results [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#view-code-quality-results "Permalink")

Code Quality results are shown in the:

- [Merge request widget](https://docs.gitlab.com/ci/testing/code_quality/#merge-request-widget)
- [Merge request changes view](https://docs.gitlab.com/ci/testing/code_quality/#merge-request-changes-view)
- [Pipeline details view](https://docs.gitlab.com/ci/testing/code_quality/#pipeline-details-view)
- [Project quality view](https://docs.gitlab.com/ci/testing/code_quality/#project-quality-view)

### Merge request widget [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#merge-request-widget "Permalink")

Code Quality analysis results display in the merge request widget area if a report from the target
branch is available for comparison. The merge request widget displays Code Quality findings and resolutions that
were introduced by the changes made in the merge request. Multiple Code Quality findings with identical
fingerprints display as a single entry in the merge request widget. Each individual finding is available in the
full report available in the **Pipeline** details view.

![List of code quality issues in the merge request, ordered by decreasing severity](https://docs.gitlab.com/ci/testing/img/code_quality_merge_request_widget_v18_2.png)

### Merge request changes view [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#merge-request-changes-view "Permalink")

- Tier: Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

Code Quality results display in the merge request **Changes** view. Lines containing Code Quality
issues are marked by a symbol beside the gutter. Select the symbol to see the list of issues, then select an issue to see its details.

![Lines in a merge request’s changes tab marked with a symbol to indicate code quality issues](https://docs.gitlab.com/ci/testing/img/code_quality_changes_view_v18_2.png)

### Pipeline details view [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#pipeline-details-view "Permalink")

- Tier: Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

The full list of Code Quality violations generated by a pipeline is shown in the **Code Quality**
tab of the pipeline’s details page. The pipeline details view displays all Code Quality findings
that were found on the branch it was run on.

![List of all issues in the branch, ordered by decreasing severity](https://docs.gitlab.com/ci/testing/img/code_quality_pipeline_details_view_v18_2.png)

### Project quality view [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#project-quality-view "Permalink")

- Tier: Ultimate
- Offering: GitLab.com, GitLab Self-Managed
- Status: Beta

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/72724) in GitLab 14.5 [with a flag](https://docs.gitlab.com/administration/feature_flags/) named `project_quality_summary_page`. This feature is in [beta](https://docs.gitlab.com/policy/development_stages_support/). Disabled by default.

The project quality view displays an overview of the code quality findings. The view can be found under **Analyze** \> **CI/CD analytics**, and requires [`project_quality_summary_page`](https://docs.gitlab.com/administration/feature_flags/) feature flag to be enabled for this particular project.

![Total number of issues, called violations, followed by the number of issues of each severity](https://docs.gitlab.com/ci/testing/img/code_quality_summary_v15_9.png)

## Code Quality report format [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#code-quality-report-format "Permalink")

You can [import Code Quality results](https://docs.gitlab.com/ci/testing/code_quality/#import-code-quality-results-from-a-cicd-job) from any tool that can output a report in the following format.
This format is a version of the [CodeClimate report format](https://github.com/codeclimate/platform/blob/master/spec/analyzers/SPEC.md#data-types) that includes a smaller number of fields.

The file you provide as [Code Quality report artifact](https://docs.gitlab.com/ci/yaml/artifacts_reports/#artifactsreportscodequality) must contain a single JSON array.
Each object in that array must have at least the following properties:

| Name | Type | Description |
| --- | --- | --- |
| `description` | String | A human-readable description of the code quality violation. |
| `check_name` | String | A unique name representing the check, or rule, associated with this violation. |
| `fingerprint` | String | A unique fingerprint to identify this specific code quality violation, such as a hash of its contents. |
| `location.path` | String | The file containing the code quality violation, expressed as a relative path in the repository. Do not prefix with `./`. |
| `location.lines.begin` or `location.positions.begin.line` | Integer | The line on which the code quality violation occurred. |
| `severity` | String | The severity of the violation, can be one of `info`, `minor`, `major`, `critical`, or `blocker`. |

The format is different from the [CodeClimate report format](https://github.com/codeclimate/platform/blob/master/spec/analyzers/SPEC.md#data-types) in the following ways:

- Although the [CodeClimate report format](https://github.com/codeclimate/platform/blob/master/spec/analyzers/SPEC.md#data-types) supports more properties, Code Quality only processes the fields listed previously.
- The GitLab parser does not allow a [byte order mark](https://en.wikipedia.org/wiki/Byte_order_mark) at the beginning of the file.

For example, this is a compliant report:

json

```json
[\
  {\
    "description": "'unused' is assigned a value but never used.",\
    "check_name": "no-unused-vars",\
    "fingerprint": "7815696ecbf1c96e6894b779456d330e",\
    "severity": "minor",\
    "location": {\
      "path": "lib/index.js",\
      "lines": {\
        "begin": 42\
      }\
    }\
  }\
]
```

## Integrate common tools with Code Quality [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#integrate-common-tools-with-code-quality "Permalink")

Many tools natively support the required [report format](https://docs.gitlab.com/ci/testing/code_quality/#code-quality-report-format) to integrate their results with Code Quality.
They may call it a “CodeClimate report”, “GitLab Code Quality report”, or another similar name.

Other tools can be configured to create JSON output by providing a custom template or format specification.
Because the [report format](https://docs.gitlab.com/ci/testing/code_quality/#code-quality-report-format) has only a few required fields, you may be able to use this output type to create a report for Code Quality.

If you already use a tool in your CI/CD pipeline, you should adapt the existing job to add a Code Quality report.
Adapting the existing job prevents you from running a separate job that may confuse developers and make your pipelines take longer to run.

If you don’t already use a tool, you can write a CI/CD job from scratch or adopt the tool by using a component from [the CI/CD Catalog](https://docs.gitlab.com/ci/components/#cicd-catalog).

### Code scanning tools [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#code-scanning-tools "Permalink")

#### ESLint [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#eslint "Permalink")

If you already have an [ESLint](https://eslint.org/) job in your CI/CD pipelines, you should add a report to send its output to Code Quality.
To integrate its output:

1. Add [`eslint-formatter-gitlab`](https://www.npmjs.com/package/eslint-formatter-gitlab) as a development dependency in your project.
2. Add the `--format gitlab` option to the command you use to run ESLint.
3. Declare a [`codequality` report artifact](https://docs.gitlab.com/ci/yaml/artifacts_reports/#artifactsreportscodequality) that points to the location of the report file.
   - By default, the formatter reads your CI/CD configuration and infers the filename where it should save the report.
     If the formatter can’t infer the filename you used in your artifact declaration, set the CI/CD variable `ESLINT_CODE_QUALITY_REPORT` to the filename specified for your artifact, such as `gl-code-quality-report.json`.

You can also use or adapt the [ESLint CI/CD component](https://gitlab.com/explore/catalog/components/code-quality-oss/codequality-os-scanners-integration) to run the scan and integrate its output with Code Quality.

#### Stylelint [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#stylelint "Permalink")

If you already have a [Stylelint](https://stylelint.io/) job in your CI/CD pipelines, you should add a report to send its output to Code Quality.
To integrate its output:

1. Add [`@studiometa/stylelint-formatter-gitlab`](https://www.npmjs.com/package/@studiometa/stylelint-formatter-gitlab) as a development dependency in your project.
2. Add the `--custom-formatter=@studiometa/stylelint-formatter-gitlab` option to the command you use to run Stylelint.
3. Declare a [`codequality` report artifact](https://docs.gitlab.com/ci/yaml/artifacts_reports/#artifactsreportscodequality) that points to the location of the report file.
   - By default, the formatter reads your CI/CD configuration and infers the filename where it should save the report.
     If the formatter can’t infer the filename you used in your artifact declaration, set the CI/CD variable `STYLELINT_CODE_QUALITY_REPORT` to the filename specified for your artifact, such as `gl-code-quality-report.json`.

For more details and an example CI/CD job definition, see the [documentation for `@studiometa/stylelint-formatter-gitlab`](https://www.npmjs.com/package/@studiometa/stylelint-formatter-gitlab#usage).

#### MyPy [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#mypy "Permalink")

If you already have a [MyPy](https://mypy-lang.org/) job in your CI/CD pipelines, you should add a report to send its output to Code Quality.
To integrate its output:

1. Install [`mypy-gitlab-code-quality`](https://pypi.org/project/mypy-gitlab-code-quality/) as a dependency in your project.

2. Change your `mypy` command to send its output to a file.

3. Add a step to your job `script` to reprocess the file into the required format by using `mypy-gitlab-code-quality`. For example:





yaml







```yaml
- mypy $(find -type f -name "*.py" ! -path "**/.venv/**") --no-error-summary > mypy-out.txt || true  # "|| true" is used for preventing job failure when mypy find errors
- mypy-gitlab-code-quality < mypy-out.txt > gl-code-quality-report.json
```

4. Declare a [`codequality` report artifact](https://docs.gitlab.com/ci/yaml/artifacts_reports/#artifactsreportscodequality) that points to the location of the report file.


You can also use or adapt the [MyPy CI/CD component](https://gitlab.com/explore/catalog/components/code-quality-oss/codequality-os-scanners-integration) to run the scan and integrate its output with Code Quality.

#### Flake8 [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#flake8 "Permalink")

If you already have a [Flake8](https://flake8.pycqa.org/) job in your CI/CD pipelines, you should add a report to send its output to Code Quality.
To integrate its output:

1. Install [`flake8-gl-codeclimate`](https://github.com/awelzel/flake8-gl-codeclimate) as a dependency in your project.
2. Add the arguments `--format gl-codeclimate --output-file gl-code-quality-report.json` to the command you use to run Flake8.
3. Declare a [`codequality` report artifact](https://docs.gitlab.com/ci/yaml/artifacts_reports/#artifactsreportscodequality) that points to the location of the report file.

You can also use or adapt the [Flake8 CI/CD component](https://gitlab.com/explore/catalog/components/code-quality-oss/codequality-os-scanners-integration) to run the scan and integrate its output with Code Quality.

#### Pylint [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#pylint "Permalink")

If you already have a [Pylint](https://pypi.org/project/pylint/) job in your CI/CD pipelines, you should add a report to send its output to Code Quality.
To integrate its output:

1. Install [`pylint-gitlab`](https://pypi.org/project/pylint-gitlab/) as a dependency in your project.
2. Add the argument `--output-format=pylint_gitlab.GitlabCodeClimateReporter` to the command you use to run Pylint.
3. Change your `pylint` command to send its output to a file.
4. Declare a [`codequality` report artifact](https://docs.gitlab.com/ci/yaml/artifacts_reports/#artifactsreportscodequality) that points to the location of the report file.

You can also use or adapt the [Pylint CI/CD component](https://gitlab.com/explore/catalog/components/code-quality-oss/codequality-os-scanners-integration) to run the scan and integrate its output with Code Quality.

#### Ruff [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#ruff "Permalink")

If you already have a [Ruff](https://docs.astral.sh/ruff/) job in your CI/CD pipelines, you should add a report to send its output to Code Quality.
To integrate its output:

1. Add the argument `--output-format=gitlab` to the command you use to run Ruff.
2. Change your `ruff check` command to send its output to a file.
3. Declare a [`codequality` report artifact](https://docs.gitlab.com/ci/yaml/artifacts_reports/#artifactsreportscodequality) that points to the location of the report file.

You can also use or adapt the [documented Ruff GitLab CI/CD integration](https://docs.astral.sh/ruff/integrations/#gitlab-cicd) to run the scan and integrate its output with Code Quality.

#### golangci-lint [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#golangci-lint "Permalink")

If you already have a [`golangci-lint`](https://golangci-lint.run/) job in your CI/CD pipelines, you should add a report to send its output to Code Quality.
To integrate its output:

1. Add the arguments to the command you use to run `golangci-lint`.

   - For v1 add `--out-format code-climate:gl-code-quality-report.json,line-number`.
   - For v2 add `--output.code-climate.path=gl-code-quality-report.json`.
2. Declare a [`codequality` report artifact](https://docs.gitlab.com/ci/yaml/artifacts_reports/#artifactsreportscodequality) that points to the location of the report file.


You can also use or adapt the [golangci-lint CI/CD component](https://gitlab.com/explore/catalog/components/code-quality-oss/codequality-os-scanners-integration) to run the scan and integrate its output with Code Quality.

#### PMD Copy/Paste Detector [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#pmd-copypaste-detector "Permalink")

The [PMD Copy/Paste Detector (CPD)](https://pmd.github.io/pmd/pmd_userdocs_cpd.html) requires additional configuration because its default output doesn’t conform to the required format.

You can use or adapt the [PMD CI/CD component](https://gitlab.com/explore/catalog/components/code-quality-oss/codequality-os-scanners-integration) to run the scan and integrate its output with Code Quality.

#### SwiftLint [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#swiftlint "Permalink")

Using [SwiftLint](https://realm.github.io/SwiftLint/) requires additional configuration because its default output doesn’t conform to the required format.

You can use or adapt the [Swiftlint CI/CD component](https://gitlab.com/explore/catalog/components/code-quality-oss/codequality-os-scanners-integration) to run the scan and integrate its output with Code Quality.

#### RuboCop [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#rubocop "Permalink")

Using [RuboCop](https://rubocop.org/) requires additional configuration because its default output doesn’t conform to the required format.

You can use or adapt the [RuboCop CI/CD component](https://gitlab.com/explore/catalog/components/code-quality-oss/codequality-os-scanners-integration) to run the scan and integrate its output with Code Quality.

#### Roslynator [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#roslynator "Permalink")

Using [Roslynator](https://josefpihrt.github.io/docs/roslynator/) requires additional configuration because its default output doesn’t conform to the required format.

You can use or adapt the [Roslynator CI/CD component](https://gitlab.com/explore/catalog/components/code-quality-oss/codequality-os-scanners-integration) to run the scan and integrate its output with Code Quality.

### Documentation scanning tools [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#documentation-scanning-tools "Permalink")

You can use Code Quality to scan any file stored in a repository, even if it isn’t code.

#### Vale [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#vale "Permalink")

If you already have a [Vale](https://vale.sh/) job in your CI/CD pipelines, you should add a report to send its output to Code Quality.
To integrate its output:

1. Create a Vale template file in your repository that defines the required format.
   - You can copy the open source [template used to check GitLab documentation](https://gitlab.com/gitlab-org/gitlab/-/blob/master/doc/.vale/vale-json.tmpl).
   - You can also use another open source variant like the one used in the community [`gitlab-ci-utils` Vale project](https://gitlab.com/gitlab-ci-utils/container-images/vale/-/blob/main/vale/vale-glcq.tmpl). This community project also provides [a pre-made container image](https://gitlab.com/gitlab-ci-utils/container-images/vale) that includes the same template so you can use it directly in your pipelines.
2. Add the arguments `--output="$VALE_TEMPLATE_PATH" --no-exit` to the command you use to run Vale.
3. Change your `vale` command to send its output to a file.
4. Declare a [`codequality` report artifact](https://docs.gitlab.com/ci/yaml/artifacts_reports/#artifactsreportscodequality) that points to the location of the report file.

You can also use or adapt an open source job definition to run the scan and integrate its output with Code Quality, for example:

- The [Vale linting step](https://gitlab.com/gitlab-org/gitlab/-/blob/94f870b8e4b965a41dd2ad576d50f7eeb271f117/.gitlab/ci/docs.gitlab-ci.yml#L71-87) used to check GitLab documentation.
- The community [`gitlab-ci-utils` Vale project](https://gitlab.com/gitlab-ci-utils/container-images/vale#usage).

#### markdownlint-cli2 [Permalink](https://docs.gitlab.com/ci/testing/code_quality/\#markdownlint-cli2 "Permalink")

If you already have a [markdownlint-cli2](https://github.com/DavidAnson/markdownlint-cli2) job in your CI/CD pipelines, you should add a report to send its output to Code Quality.
To integrate its output:

1. Add [`markdownlint-cli2-formatter-codequality`](https://www.npmjs.com/package/markdownlint-cli2-formatter-codequality) as a development dependency in your project.

2. If you don’t already have one, create a `.markdownlint-cli2.jsonc` file at the top level of your repository.

3. Add an `outputFormatters` directive to `.markdownlint-cli2.jsonc`:





json







```json
{
     "outputFormatters": [\
       [ "markdownlint-cli2-formatter-codequality" ]\
     ]
}
```

4. Declare a [`codequality` report artifact](https://docs.gitlab.com/ci/yaml/artifacts_reports/#artifactsreportscodequality) that points to the location of the report file.
By default, the report file is named `markdownlint-cli2-codequality.json`.

1. Recommended. Add the report’s filename to the repository’s `.gitignore` file.

For more details and an example CI/CD job definition, see the [documentation for `markdownlint-cli2-formatter-codequality`](https://www.npmjs.com/package/markdownlint-cli2-formatter-codequality).

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**

| Feature | In Free | In Premium | In Ultimate |
| --- | --- | --- | --- |

| Plugin | On by default | Replacement |
| --- | --- | --- |

| Name | Type | Description |
| --- | --- | --- |