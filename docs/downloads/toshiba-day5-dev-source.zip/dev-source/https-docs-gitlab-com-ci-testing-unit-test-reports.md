<!-- source: https://docs.gitlab.com/ci/testing/unit_test_reports -->

/

* * *

# Unit test reports

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

Unit test reports display test results directly in merge requests and pipeline details,
so you can identify failures without searching through job logs.

Use unit test reports when you want to:

- See test failures immediately in merge requests.
- Compare test results between branches.
- Debug failing tests with error details and screenshots.
- Track test failure patterns over time.

Unit test reports require the JUnit XML format and do not affect job status.
To make a job fail when tests fail, your job’s [script](https://docs.gitlab.com/ci/yaml/#script) must exit with a non-zero status.

GitLab Runner uploads your test results in JUnit XML format as [artifacts](https://docs.gitlab.com/ci/yaml/artifacts_reports/#artifactsreportsjunit).
When you go to a merge request, your test results are compared between the source branch (head) and target branch (base) to show what changed.

## File format and size limits [Permalink](https://docs.gitlab.com/ci/testing/unit_test_reports/\#file-format-and-size-limits "Permalink")

Unit test reports must use JUnit XML format with specific requirements to ensure proper parsing and display.

### File requirements [Permalink](https://docs.gitlab.com/ci/testing/unit_test_reports/\#file-requirements "Permalink")

Your test report files must:

- Use JUnit XML format with `.xml` file extension.
- Be smaller than 30 MB per individual file.
- Have a total size under 100 MB for all JUnit files in a job.

If you have duplicate test names, only the first test is used and others with the same name are ignored.

For test case limits, see [Maximum test cases per unit test report](https://docs.gitlab.com/user/gitlab_com/#cicd).

### JUnit XML format specification [Permalink](https://docs.gitlab.com/ci/testing/unit_test_reports/\#junit-xml-format-specification "Permalink")

GitLab parses a subset of JUnit XML elements and attributes to display test results in the UI.

| XML Element | XML Attribute | Description |
| --- | --- | --- |
| `testsuites` | `time` | Total execution time for all test suites. Used for test execution time calculations. |
| `testsuite` | `name` | Test suite name. Parsed for internal grouping. |
| `testsuite` | `time` | Execution time for an individual test suite. Used for test execution time calculations. |
| `testcase` | `classname` | Test class or category name. Displayed as the suite name in UI. |
| `testcase` | `name` | Individual test name. |
| `testcase` | `file` | File path where the test is defined. |
| `testcase` | `time` | Test execution time in seconds. |
| `failure` | Element content | Failure message and stack trace. |
| `error` | Element content | Error message and stack trace. |
| `skipped` | Element content | Reason for skipping the test. |
| `system-out` | Element content | System output and attachment tags. Only parsed from `testcase` elements. |
| `system-err` | Element content | System error output. Only parsed from `testcase` elements. |

The following elements and attributes are not parsed:

- `testsuite` attributes (tests, failures, errors, timestamp)
- `testcase` attributes (assertions, line, status)
- `properties` elements
- `system-out` and `system-err` at the `testsuite` level

#### XML structure example [Permalink](https://docs.gitlab.com/ci/testing/unit_test_reports/\#xml-structure-example "Permalink")

xml

```xml
<testsuites>
  <testsuite name="Authentication Tests" tests="1" failures="1">
    <testcase classname="LoginTest" name="test_invalid_password" file="spec/auth_spec.rb" time="0.23">
      <failure>Expected authentication to fail</failure>
      <system-out>[[ATTACHMENT|screenshots/failure.png]]</system-out>
    </testcase>
  </testsuite>
</testsuites>
```

This XML displays in GitLab as:

- Suite: `LoginTest` (from `testcase classname`)
- Name: `test_invalid_password` (from `testcase name`)
- File: `spec/auth_spec.rb` (from `testcase file`)
- Time: `0.23s` (from `testcase time`)
- Screenshot: Available in test details dialog (from `testcase system-out`)
- Not displayed: “Authentication Tests” (from `testsuite name`)

## Test result types [Permalink](https://docs.gitlab.com/ci/testing/unit_test_reports/\#test-result-types "Permalink")

Test results are compared between the merge request’s source and target branches to show what changed:

- Newly failed tests: Tests that passed on the target branch but failed on your branch.
- Newly encountered errors: Tests that passed on the target branch but had errors on your branch.
- Existing failures: Tests that failed on both branches.
- Resolved failures: Tests that failed on the target branch but passed on your branch.

If branches cannot be compared, for example when there is no target branch data yet, only the failed tests from your branch are shown.

For tests that failed in the default branch in the last 14 days,
you see a message like `Failed {n} time(s) in {default_branch} in the last 14 days`.
This count includes failed tests from completed pipelines, but not [blocked pipelines](https://docs.gitlab.com/ci/jobs/job_control/#types-of-manual-jobs).
Support for blocked pipelines is proposed in [issue 431265](https://gitlab.com/gitlab-org/gitlab/-/issues/431265).

## Configure unit test reports [Permalink](https://docs.gitlab.com/ci/testing/unit_test_reports/\#configure-unit-test-reports "Permalink")

Configure unit test reports to display test results in merge requests and pipelines.

To configure unit test reports:

1. Configure your test job to output JUnit XML format test reports.
For configuration details, review your testing framework’s documentation.

2. In your `.gitlab-ci.yml` file, add
[`artifacts:reports:junit`](https://docs.gitlab.com/ci/yaml/artifacts_reports/#artifactsreportsjunit) to your test job.

3. Specify the path to your XML test report files. The `junit` property accepts:


   - A single filename: `junit: report.xml`
   - A filename pattern: `junit: test-results/**/*.xml`
   - An array of filenames: `junit: [rspec-1.xml, rspec-2.xml, rspec-3.xml]`
   - A combination of both: `junit: [rspec.xml, test-results/TEST-*.xml]`

Directories are not supported (for example, `junit: test-results` or `junit: test-results/**`).

4. Optional. To make report files browsable, include them with [`artifacts:paths`](https://docs.gitlab.com/ci/yaml/#artifactspaths).

5. Optional. To upload reports even when jobs fail, use [`artifacts:when:always`](https://docs.gitlab.com/ci/yaml/#artifactswhen).


Example configuration for Ruby with RSpec:

yaml

```yaml
ruby:
  stage: test
  script:
    - bundle install
    - bundle exec rspec --format progress --format RspecJunitFormatter --out rspec.xml
  artifacts:
    when: always
    paths:
      - rspec.xml
    reports:
      junit: rspec.xml
```

You can view test results:

- In the **Tests** tab of pipeline details after your test job completes.
- In the **Test summary** panel of merge requests after your pipeline completes.

## View test results in merge requests [Permalink](https://docs.gitlab.com/ci/testing/unit_test_reports/\#view-test-results-in-merge-requests "Permalink")

View detailed information about test failures in merge requests.

The **Test summary** panel shows an overview of your test results,
including how many tests failed and passed.

![Expanded Test summary panel that shows one failed test with the View details link](https://docs.gitlab.com/ci/testing/img/test_summary_panel_expanded_v18_1.png)

To view test failure details:

1. In a merge request, go to the **Test summary** panel.
2. To expand the **Test summary** panel, select **Show details** (chevron-lg-down).
3. Select **View details** next to a failed test.

The dialog displays the test name, file path, execution time, screenshot attachment (if configured),
and error output.

To view all test results:

- From the **Test summary** panel, select **Full report**
to go to the **Tests** tab in the pipeline details.

### Copy failed test names [Permalink](https://docs.gitlab.com/ci/testing/unit_test_reports/\#copy-failed-test-names "Permalink")

Copy test names to rerun them locally for debugging.

Prerequisites:

- Your JUnit report must include `<file>` attributes for failed tests.

To copy all failed test names:

- From the **Test summary** panel, select **Copy failed tests** (copy-to-clipboard).

The failed tests are copied as a space-separated string.

To copy a single failed test name:

1. To expand the **Test summary** panel, select **Show details** (chevron-lg-down).
2. Select **View details** next to the test you want to copy.
3. In the dialog, select **Copy test name to rerun locally** (copy-to-clipboard).

The test name is copied to your clipboard.

## View test results in pipelines [Permalink](https://docs.gitlab.com/ci/testing/unit_test_reports/\#view-test-results-in-pipelines "Permalink")

View all test suites and cases in pipeline details, including results from child pipelines.

To view pipeline test results:

1. Go to your pipeline details page.
2. Select the **Tests** tab.
3. Select any test suite to see individual test cases.

![Test results showing 1671 tests with 1 minute 11 seconds total execution time and individual job execution times.](https://docs.gitlab.com/ci/testing/img/pipelines_junit_test_report_v18_3.png)

You can also retrieve test reports with the [Pipelines API](https://docs.gitlab.com/api/pipelines/#retrieve-a-test-report-for-a-pipeline).

### Test timing metrics [Permalink](https://docs.gitlab.com/ci/testing/unit_test_reports/\#test-timing-metrics "Permalink")

Test results display different timing metrics:

Pipeline durationElapsed time from when the pipeline starts until it completes.Test execution timeTotal time spent running all tests across all jobs, added together.Queue timeTime jobs spent waiting for available runners.

When jobs run in parallel, cumulative test execution time can exceed pipeline duration.

Pipeline duration shows how long you wait for results, while test execution time shows compute resources used.

For example, a pipeline that completes in 81 minutes might show 9 hours 10 minutes of test execution time if many test jobs run in parallel across multiple runners.

## Add screenshots to test reports [Permalink](https://docs.gitlab.com/ci/testing/unit_test_reports/\#add-screenshots-to-test-reports "Permalink")

Add screenshots to test reports to help debug test failures.

To add screenshots to test reports:

1. In your JUnit XML file, add attachment tags with screenshot paths relative to `$CI_PROJECT_DIR`:





xml







```xml
<testcase time="1.00" name="Test">
     <system-out>[[ATTACHMENT|/path/to/some/file]]</system-out>
</testcase>
```

2. In your `.gitlab-ci.yml` file, configure your job to upload screenshots as artifacts:


   - Specify the path to your screenshot files.
   - Optional. Use [`artifacts:when: always`](https://docs.gitlab.com/ci/yaml/#artifactswhen) to upload screenshots when tests fail.

For example:

yaml

```yaml
ruby:
  stage: test
  script:
    - bundle install
    - bundle exec rspec --format progress --format RspecJunitFormatter --out rspec.xml
    - # Your test framework should save screenshots to a directory
  artifacts:
    when: always
    paths:
      - rspec.xml
      - screenshots/
    reports:
      junit: rspec.xml
```

3. Run your pipeline.


You can access the screenshot link in the test details dialog
when you select **View details** for a failed test in the **Test summary** panel.

![A failed unit test report with test details and screenshot attachment](https://docs.gitlab.com/ci/testing/img/unit_test_report_screenshot_v18_1.png)

## Troubleshooting [Permalink](https://docs.gitlab.com/ci/testing/unit_test_reports/\#troubleshooting "Permalink")

### Test report appears empty [Permalink](https://docs.gitlab.com/ci/testing/unit_test_reports/\#test-report-appears-empty "Permalink")

You might see an empty **Test summary** panel in merge requests.

This issue occurs when:

- Report artifacts have expired.
- JUnit files exceed size limits.

To resolve this issue, set a longer [`expire_in`](https://docs.gitlab.com/ci/yaml/#artifactsexpire_in) value for the report artifact,
or run a new pipeline to generate a new report.

If JUnit files exceed size limits, ensure:

- Individual JUnit files are less than 30 MB.
- The total size of all JUnit files for the job is less than 100 MB.

Support for custom limits is proposed in [epic 16374](https://gitlab.com/groups/gitlab-org/-/epics/16374).

### Test results are missing [Permalink](https://docs.gitlab.com/ci/testing/unit_test_reports/\#test-results-are-missing "Permalink")

You might see fewer test results than expected in your reports.

This can happen when you have duplicate test names in your JUnit XML file.
Only the first test for each name is used and duplicates are ignored.

To resolve this issue, ensure all test names and classes are unique.

### No test reports appear in merge requests [Permalink](https://docs.gitlab.com/ci/testing/unit_test_reports/\#no-test-reports-appear-in-merge-requests "Permalink")

You might not see the **Test summary** panel at all in merge requests.

This issue can happen when the target branch has no test data for comparison.

To resolve this issue, run a pipeline on your target branch to generate baseline test data.

### JUnit XML parsing errors [Permalink](https://docs.gitlab.com/ci/testing/unit_test_reports/\#junit-xml-parsing-errors "Permalink")

You might see parsing error indicators next to job names in your pipeline.

This can happen when JUnit XML files contain formatting errors or invalid elements.

To resolve this issue:

- Verify your JUnit XML files follow the standard format.
- Check that all XML elements are properly closed.
- Ensure attribute names and values are correctly formatted.

For [grouped jobs](https://docs.gitlab.com/ci/jobs/#group-similar-jobs-together-in-pipeline-views),
only the first parsing error from the group is displayed.

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**

| XML Element | XML Attribute | Description |
| --- | --- | --- |