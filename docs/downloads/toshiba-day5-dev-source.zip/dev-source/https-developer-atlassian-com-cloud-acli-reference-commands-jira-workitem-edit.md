<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-edit -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Filter by keyword

- [acli](https://developer.atlassian.com/cloud/acli/reference/commands/)
- [admin](https://developer.atlassian.com/cloud/acli/reference/commands/admin/)

[admin auth](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth/)

[admin user](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user/)

- [feedback](https://developer.atlassian.com/cloud/acli/reference/commands/feedback/)
- [jira](https://developer.atlassian.com/cloud/acli/reference/commands/jira/)

[jira auth](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth/)

[jira board](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board/)

[jira dashboard](https://developer.atlassian.com/cloud/acli/reference/commands/jira-dashboard/)

[jira field](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field/)

[jira filter](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter/)

[jira project](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project/)

[jira sprint](https://developer.atlassian.com/cloud/acli/reference/commands/jira-sprint/)

[jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem/)

- [archive](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-archive/)
- [assign](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-assign/)
- [attachment-delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-attachment-delete/)
- [attachment-list](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-attachment-list/)
- [clone](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-clone/)
- [comment-create](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-create/)
- [comment-delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-delete/)
- [comment-list](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-list/)
- [comment-update](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-update/)
- [comment-visibility](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-visibility/)
- [create](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-create/)
- [create-bulk](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-create-bulk/)
- [delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-delete/)
- [edit](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-edit/)
- [link](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-link/)
- [search](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-search/)
- [transition](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-transition/)
- [unarchive](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-unarchive/)
- [view](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-view/)
- [watcher-remove](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-watcher-remove/)

- [rovodev](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev/)

[rovodev auth](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev-auth/)

Last updated Oct 3, 2024

On This Page

- [acli jira workitem edit](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-edit/#acli-jira-workitem-edit)


## acli jira workitem edit

Edit a Jira work item or multiple work items.

```
Copy
1
acli jira workitem edit [flags]
```

### Examples

```
Copy
1
2
3
4
5
6
7
8
9
10
11
12
13
14
# Edit work item with work item keys
$ acli jira workitem edit --key "KEY-1,KEY-2" --summary "New Summary"

# Edit work item with JQL query
$ acli jira workitem edit --jql "project = TEAM" --assignee "user@atlassian.com"

# Edit work item with Filter ID
$ acli jira workitem edit --filter 10001 --description "Updated description" --yes

# Generate a JSON file that could be used for workitem edit via --from-json flag
$ acli jira workitem edit --generate-json

# Edit work item from a JSON file
$ acli jira workitem edit --from-json "workitem.json"
```

### Options

```
Copy
1
2
3
4
5
6
7
8
9
10
11
12
13
14
15
16
17
  -a, --assignee string           Assign work item with email or account ID. Use '@me' to self-assign, 'default' to assign to the project's default assignee
  -d, --description string        Edit the description in plain text or Atlassian Document Format (ADF)
      --description-file string   Read the description in plain text or Atlassian Document Format (ADF) from the file
      --filter string             Filter ID of work items to be edited
      --from-json string          Read the work item definition from a JSON file
      --generate-json             Generates a JSON file that could be used for work item editing
  -h, --help                      Show help for command
      --ignore-errors             Ignore the errors and continue
      --jql string                JQL query for work items to be edited
      --json                      Generate a JSON output
  -k, --key string                A list of work item keys to be edited
  -l, --labels string             Edit the labels
      --remove-assignee           Remove the assignee
      --remove-labels string      Remove the labels
  -s, --summary string            Edit the summary
  -t, --type string               Edit the work item type
  -y, --yes                       Confirm edit without prompting
```

### SEE ALSO

- [acli jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem) \- Jira work item commands.

Rate this page:

Unusable

Poor

Okay

Good

Excellent