<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/jira-sprint-list-workitems -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Filter by keyword

- [acli](https://developer.atlassian.com/cloud/acli/reference/commands/)
- [admin](https://developer.atlassian.com/cloud/acli/reference/commands/admin/)

[admin auth](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth/)

[admin user](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user/)

- [feedback](https://developer.atlassian.com/cloud/acli/reference/commands/feedback/)
- [jira](https://developer.atlassian.com/cloud/acli/reference/commands/jira/)

[jira auth](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth/)

[jira board](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board/)

[jira dashboard](https://developer.atlassian.com/cloud/acli/reference/commands/jira-dashboard/)

[jira field](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field/)

[jira filter](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter/)

[jira project](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project/)

[jira sprint](https://developer.atlassian.com/cloud/acli/reference/commands/jira-sprint/)

- [list-workitems](https://developer.atlassian.com/cloud/acli/reference/commands/jira-sprint-list-workitems/)

[jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem/)

- [rovodev](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev/)

[rovodev auth](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev-auth/)

Last updated Oct 3, 2024

On This Page

- [acli jira sprint list-workitems](https://developer.atlassian.com/cloud/acli/reference/commands/jira-sprint-list-workitems/#acli-jira-sprint-list-workitems)


## acli jira sprint list-workitems

List work items in a sprint.

```
Copy
1
acli jira sprint list-workitems [flags]
```

### Examples

```
Copy
1
2
3
# List work items in sprint
$ acli jira sprint list-workitems --sprint 1 --board 6
```

### Options

```
Copy
1
2
3
4
5
6
7
8
9
      --board int       Id of the board to list work items from (required)
      --csv             Output in CSV format
      --fields string   Comma-separated list of fields to include in the response (default "key,issuetype,summary,assignee,priority,status")
  -h, --help            Show help for command
      --jql string      JQL query to filter work items in the sprint
      --json            Output in JSON format
      --limit int       Maximum number of issues to return per page (default 50)
      --paginate        Continue paginating to fetch all pages of results or up to the provided limit.
      --sprint int      Id of the sprint to list work items from (required)
```

### SEE ALSO

- [acli jira sprint](https://developer.atlassian.com/cloud/acli/reference/commands/jira-sprint) \- Jira sprint commands.

Rate this page:

Unusable

Poor

Okay

Good

Excellent