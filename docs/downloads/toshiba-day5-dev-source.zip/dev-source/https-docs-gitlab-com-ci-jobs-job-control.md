<!-- source: https://docs.gitlab.com/ci/jobs/job_control -->

/

* * *

# Control how jobs run

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

Before a new pipeline starts, GitLab checks the pipeline configuration to determine
which jobs can run in that pipeline. You can configure jobs to run depending on
conditions like the value of variables or the pipeline type with [`rules`](https://docs.gitlab.com/ci/jobs/job_rules/).
When using job rules, learn how to [avoid duplicate pipelines](https://docs.gitlab.com/ci/jobs/job_rules/#avoid-duplicate-pipelines). To control pipeline creation, use [`workflow:rules`](https://docs.gitlab.com/ci/yaml/workflow/).

## Create a job that must be run manually [Permalink](https://docs.gitlab.com/ci/jobs/job_control/\#create-a-job-that-must-be-run-manually "Permalink")

You can require that a job doesn’t run unless a user starts it. This is called a **manual job**.
You might want to use a manual job for something like deploying to production.

To specify a job as manual, add [`when: manual`](https://docs.gitlab.com/ci/yaml/#when) to the job
in the `.gitlab-ci.yml` file.

By default, manual jobs display as skipped when the pipeline starts.

You can use [protected branches](https://docs.gitlab.com/user/project/repository/branches/protected/) to more strictly
[protect manual deployments](https://docs.gitlab.com/ci/jobs/job_control/#protect-manual-jobs) from being run by unauthorized users.

Manual jobs that are [archived](https://docs.gitlab.com/administration/settings/continuous_integration/#archive-pipelines) do not run.

### Types of manual jobs [Permalink](https://docs.gitlab.com/ci/jobs/job_control/\#types-of-manual-jobs "Permalink")

Manual jobs can be either optional or blocking.

In optional manual jobs:

- [`allow_failure`](https://docs.gitlab.com/ci/yaml/#allow_failure) is `true`, which is the default
setting for jobs that have `when: manual` defined outside of `rules`.
- The status does not contribute to the overall pipeline status. A pipeline can
succeed even if all of its manual jobs fail.

In blocking manual jobs:

- `allow_failure` is `false`, which is the default setting for jobs that have `when: manual`
defined inside [`rules`](https://docs.gitlab.com/ci/yaml/#rules).
- The pipeline stops at the stage where the job is defined. To let the pipeline
continue running, [run the manual job](https://docs.gitlab.com/ci/jobs/job_control/#run-a-manual-job).
- Merge requests in projects with [**Pipelines must succeed**](https://docs.gitlab.com/user/project/merge_requests/auto_merge/#require-a-successful-pipeline-for-merge)
enabled can’t be merged with a blocked pipeline.
- The pipeline shows a status of **blocked**.

When using manual jobs in downstream pipelines with a [`trigger:strategy`](https://docs.gitlab.com/ci/yaml/#triggerstrategy),
the type of manual job can affect the trigger job’s status while the pipeline runs.

### Run a manual job [Permalink](https://docs.gitlab.com/ci/jobs/job_control/\#run-a-manual-job "Permalink")

To run a manual job, you must have permission to merge to the assigned branch:

1. Go to the pipeline, job, [environment](https://docs.gitlab.com/ci/environments/deployments/#configure-manual-deployments),
or deployment view.
2. Next to the manual job, select **Run** (play).

### Specify variables when running manual jobs [Permalink](https://docs.gitlab.com/ci/jobs/job_control/\#specify-variables-when-running-manual-jobs "Permalink")

When running manual jobs you can supply additional job specific CI/CD variables.
Specify variables here when you want to alter the execution of a job that uses
[CI/CD variables](https://docs.gitlab.com/ci/variables/).

For typed, validated parameters that can be overridden when both running and retrying manual jobs,
use [job inputs](https://docs.gitlab.com/ci/jobs/job_inputs/) instead.

To run a manual job and specify additional variables:

- Select the **name** of the manual job in the pipeline view, not **Run** (play).
- In the form, add variable key and value pairs.
- Select **Run job**.

Any project member with permissions to run a manual job can retry the job and view the variables
that were provided when the job was initially run. This includes:

- In public projects: Users with the Developer, Maintainer, or Owner role.
- In private or internal projects: Users with the Guest, Planner, Reporter, Developer, Maintainer, or Owner role.

Consider this visibility when entering sensitive information as manual job variables.

If you add a variable that is already defined in the CI/CD settings or `.gitlab-ci.yml` file,
the [variable is overridden](https://docs.gitlab.com/ci/variables/#use-pipeline-variables) with the new value.
Any variables overridden by using this process are [expanded](https://docs.gitlab.com/ci/variables/#allow-cicd-variable-expansion)
and not [masked](https://docs.gitlab.com/ci/variables/#mask-a-cicd-variable).

#### Retry a manual job with updated variables [Permalink](https://docs.gitlab.com/ci/jobs/job_control/\#retry-a-manual-job-with-updated-variables "Permalink")

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/96199) in GitLab 15.7.

When you retry a manual job that was previously run with manually-specified variables,
you can update the variables or use the same variables.

To retry manual jobs with typed, validated parameters, use [job inputs](https://docs.gitlab.com/ci/jobs/job_inputs/) instead.

To retry a manual job with previously-specified variables:

- With the same variables:
  - From the job details page, select **Retry** (retry).
- With updated variables:
  - From the job details page, select **Retry job with modified values** in dropdown.
  - The variables that were specified in the previous run are prefilled in the form.
    You can add, modify, or delete CI/CD variables from this form.
  - Select **Run job again**.

### Require confirmation for manual jobs [Permalink](https://docs.gitlab.com/ci/jobs/job_control/\#require-confirmation-for-manual-jobs "Permalink")

Use [`manual_confirmation`](https://docs.gitlab.com/ci/yaml/#manual_confirmation) with `when: manual` to require confirmation for manual jobs.
This helps prevent accidental deployments or deletions for sensitive jobs like those that deploy to production.

When you run the job, you must confirm the action before it runs.

### Protect manual jobs [Permalink](https://docs.gitlab.com/ci/jobs/job_control/\#protect-manual-jobs "Permalink")

- Tier: Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

Use [protected environments](https://docs.gitlab.com/ci/environments/protected_environments/)
to define a list of users authorized to run a manual job. You can authorize only
the users associated with a protected environment to run manual jobs, which can:

- More precisely limit who can deploy to an environment.
- Block a pipeline until an approved user “approves” it.

To protect a manual job:

1. Add an `environment` to the job. For example:





yaml







```yaml
deploy_prod:
     stage: deploy
     script:
    - echo "Deploy to production server"
environment:
    name: production
    url: https://example.com
when: manual
rules:
    - if: $CI_COMMIT_BRANCH == $CI_DEFAULT_BRANCH
```

2. In the [protected environments settings](https://docs.gitlab.com/ci/environments/protected_environments/#protecting-environments),
select the environment (`production` in this example) and add the users, roles or groups
that are authorized to run the manual job to the **Allowed to Deploy** list. Only those in
this list can run this manual job, and GitLab administrators
who are always able to use protected environments.


You can use protected environments with blocking manual jobs to have a list of users
allowed to approve later pipeline stages. Add `allow_failure: false` to the protected
manual job and the pipeline’s next stages only run after the manual job is triggered
by authorized users.

## Run a job after a delay [Permalink](https://docs.gitlab.com/ci/jobs/job_control/\#run-a-job-after-a-delay "Permalink")

Use [`when: delayed`](https://docs.gitlab.com/ci/yaml/#when) to execute scripts after a waiting period, or if you want to avoid
jobs immediately entering the `pending` state.

You can set the period with `start_in` keyword. The value of `start_in` is an elapsed time
in seconds, unless a unit is provided. The minimum is one second, and the maximum is one week.
Examples of valid values include:

- `'5'` (a value with no unit must be surrounded by single quotes)
- `5 seconds`
- `30 minutes`
- `1 day`
- `1 week`

When a stage includes a delayed job, the pipeline doesn’t progress until the delayed job finishes.
You can use this keyword to insert delays between different stages.

The timer of a delayed job starts immediately after the previous stage completes.
Similar to other types of jobs, a delayed job’s timer doesn’t start unless the previous stage passes.

The following example creates a job named `timed rollout 10%` that is executed 30 minutes after the previous stage completes:

yaml

```yaml
timed rollout 10%:
stage: deploy
script: echo 'Rolling out 10% ...'
when: delayed
start_in: 30 minutes
environment: production
```

To stop the active timer of a delayed job, select **Unschedule** (time-out).
This job can no longer be scheduled to run automatically. You can, however, execute the job manually.

To start a delayed job manually, select **Unschedule** (time-out) to stop the delay timer and then select **Run** (play).
Soon GitLab Runner starts the job.

Delayed jobs that are [archived](https://docs.gitlab.com/administration/settings/continuous_integration/#archive-pipelines)
do not run.

## Parallelize large jobs [Permalink](https://docs.gitlab.com/ci/jobs/job_control/\#parallelize-large-jobs "Permalink")

To split a large job into multiple smaller jobs that run in parallel, use the
[`parallel`](https://docs.gitlab.com/ci/yaml/#parallel) keyword in your `.gitlab-ci.yml` file.

Different languages and test suites have different methods to enable parallelization.
For example, use [Semaphore Test Boosters](https://github.com/renderedtext/test-boosters)
and RSpec to run Ruby tests in parallel:

ruby

```ruby
# Gemfile
source 'https://rubygems.org'

gem 'rspec'
gem 'semaphore_test_boosters'
```

yaml

```yaml
test:
parallel: 3
script:
    - bundle
    - bundle exec rspec_booster --job $CI_NODE_INDEX/$CI_NODE_TOTAL
```

You can then go to the **Jobs** tab of a new pipeline build and see your RSpec
job split into three separate jobs.

Test Boosters reports usage statistics to the author.

### Run a one-dimensional matrix of parallel jobs [Permalink](https://docs.gitlab.com/ci/jobs/job_control/\#run-a-one-dimensional-matrix-of-parallel-jobs "Permalink")

To run a job multiple times in parallel in a single pipeline, but with different values for each instance of the job,
use the [`parallel:matrix`](https://docs.gitlab.com/ci/yaml/#parallelmatrix) keyword:

yaml

```yaml
deploystacks:
stage: deploy
script:
    - bin/deploy
parallel:
    matrix:
      - PROVIDER: [aws, ovh, gcp, vultr]
environment: production/$PROVIDER
```

In this example, 4 `deploystacks` jobs are created, and `PROVIDER` becomes a CI/CD variable
with a different value in each:

- `deploystacks: [aws]`
- `deploystacks: [ovh]`
- `deploystacks: [gcp]`
- `deploystacks: [vultr]`

### Run a matrix of parallel trigger jobs [Permalink](https://docs.gitlab.com/ci/jobs/job_control/\#run-a-matrix-of-parallel-trigger-jobs "Permalink")

You can run a [trigger](https://docs.gitlab.com/ci/yaml/#trigger) job multiple times in parallel in a single pipeline,
but with different variables available for each instance of the job.

For example:

yaml

```yaml
deploystacks:
stage: deploy
trigger:
    include: path/to/child-pipeline.yml
parallel:
    matrix:
      - PROVIDER: aws
        STACK: [monitoring, app1]
      - PROVIDER: ovh
        STACK: [monitoring, backup]
      - PROVIDER: [gcp, vultr]
        STACK: [data]
```

This example generates 6 parallel `deploystacks` trigger jobs, each with different values
for `PROVIDER` and `STACK`, and they create 6 different child pipelines with those variables.

```plaintext
deploystacks: [aws, monitoring]
deploystacks: [aws, app1]
deploystacks: [ovh, monitoring]
deploystacks: [ovh, backup]
deploystacks: [gcp, data]
deploystacks: [vultr, data]
```

### Select different runner tags for each parallel matrix job [Permalink](https://docs.gitlab.com/ci/jobs/job_control/\#select-different-runner-tags-for-each-parallel-matrix-job "Permalink")

You can use values defined in `parallel: matrix` with the [`tags`](https://docs.gitlab.com/ci/yaml/#tags)
keyword for dynamic runner selection:

yaml

```yaml
deploystacks:
stage: deploy
script:
    - bin/deploy
parallel:
    matrix:
      - PROVIDER: aws
        STACK: [monitoring, app1]
      - PROVIDER: gcp
        STACK: [data]
tags:
    - ${PROVIDER}-${STACK}
environment: $PROVIDER/$STACK
```

### Use matrix variables in rules [Permalink](https://docs.gitlab.com/ci/jobs/job_control/\#use-matrix-variables-in-rules "Permalink")

GitLab evaluates rules separately for each individual matrix job,
using that job’s variable values.

#### Use matrix variables in `rules:if` [Permalink](https://docs.gitlab.com/ci/jobs/job_control/\#use-matrix-variables-in-rulesif "Permalink")

Use matrix variables in [`rules:if`](https://docs.gitlab.com/ci/yaml/#rulesif) expressions
to include or exclude individual matrix jobs based on their variable values.

For example, to skip jobs when the matrix variable `SKIP` is set to `"true"`:

yaml

```yaml
test:
script: echo "Building $ARCH"
parallel:
    matrix:
      - ARCH: [amd64, arm64]
        SKIP: ["false", "true"]
rules:
    - if: $SKIP == "true"
      when: never
    - when: on_success
```

Only the jobs where `SKIP` is `"false"` are included in the pipeline.

Matrix variables in `rules:if` do not support nested expansion. If a matrix variable value
references another CI/CD variable (for example, `FILE: $GLOBAL_FILE`), the reference is not
resolved. The expression uses the literal string value, so `$FILE` evaluates to `"$GLOBAL_FILE"`
rather than the value of `GLOBAL_FILE`.

#### Use matrix variables in `rules:changes` [Permalink](https://docs.gitlab.com/ci/jobs/job_control/\#use-matrix-variables-in-ruleschanges "Permalink")

Use matrix variables in [`rules:changes`](https://docs.gitlab.com/ci/yaml/#ruleschanges)
paths to include a matrix job only when files relevant to that job have changed.
This pattern is useful in monorepos where each matrix value corresponds to a
component or service with its own directory.

For example, to run a test job only for the component whose files changed:

yaml

```yaml
test:
script: echo "Testing $COMPONENT"
parallel:
    matrix:
      - COMPONENT: [frontend, backend, database]
rules:
    - if: $CI_PIPELINE_SOURCE == "push"
      changes:
        - components/$COMPONENT/**/*
```

In this example:

- Three `test` jobs are evaluated, one for each `COMPONENT` value.
- Each job checks `rules:changes` with its own `$COMPONENT` value substituted into the path.
- Only jobs where matching files changed are added to the pipeline.

For example, if only `components/frontend/npm.lock` changed, only the `frontend` job runs.

You can use multiple matrix variables in the same path:

yaml

```yaml
test:
script: echo "Testing $SERVICE in $ENV"
parallel:
    matrix:
      - SERVICE: [api, web]
        ENV: [dev, prod]
rules:
    - changes:
        - config/$SERVICE/$ENV/**/*
```

#### Use matrix variables in `rules:exists` [Permalink](https://docs.gitlab.com/ci/jobs/job_control/\#use-matrix-variables-in-rulesexists "Permalink")

Use matrix variables in [`rules:exists`](https://docs.gitlab.com/ci/yaml/#rulesexists)
paths to include a matrix job only when a specific file exists.

For example:

yaml

```yaml
test:
script: echo "Testing $TYPE"
parallel:
    matrix:
      - TYPE: [go, ruby, python]
rules:
    - exists:
        - "**/*.$TYPE"
```

### Fetch artifacts from a `parallel:matrix` job [Permalink](https://docs.gitlab.com/ci/jobs/job_control/\#fetch-artifacts-from-a-parallelmatrix-job "Permalink")

You can fetch artifacts from a job created with [`parallel:matrix`](https://docs.gitlab.com/ci/yaml/#parallelmatrix)
by using the [`dependencies`](https://docs.gitlab.com/ci/yaml/#dependencies) keyword. Use the job name
as the value for `dependencies` as a string in the form:

```plaintext
<job_name> [<matrix argument 1>, <matrix argument 2>, ... <matrix argument N>]
```

For example, to fetch the artifacts from the job with a `RUBY_VERSION` of `2.7` and
a `PROVIDER` of `aws`:

yaml

```yaml
ruby:
image: ruby:${RUBY_VERSION}
parallel:
    matrix:
      - RUBY_VERSION: ["2.5", "2.6", "2.7", "3.0", "3.1"]
        PROVIDER: [aws, gcp]
script: bundle install

deploy:
image: ruby:2.7
stage: deploy
dependencies:
    - "ruby: [2.7, aws]"
script: echo hello
environment: production
```

Quotes around the `dependencies` entry are required.

### Specify a parallelized job using needs with multiple parallelized jobs [Permalink](https://docs.gitlab.com/ci/jobs/job_control/\#specify-a-parallelized-job-using-needs-with-multiple-parallelized-jobs "Permalink")

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/254821) in GitLab 16.3.

Use [`needs:parallel:matrix`](https://docs.gitlab.com/ci/yaml/#needsparallelmatrix) to create
[job dependencies](https://docs.gitlab.com/ci/yaml/needs/) between multiple parallelized jobs.

You can use two techniques for configuration:

- Automatically with [`matrix.` expressions](https://docs.gitlab.com/ci/yaml/matrix_expressions/).
- Manually, as demonstrated below.

For example:

yaml

```yaml
linux:build:
stage: build
script: echo "Building linux..."
parallel:
    matrix:
      - PROVIDER: aws
        STACK:
          - monitoring
          - app1
          - app2

mac:build:
stage: build
script: echo "Building mac..."
parallel:
    matrix:
      - PROVIDER: [gcp, vultr]
        STACK: [data, processing]

linux:rspec:
stage: test
needs:
    - job: linux:build
      parallel:
        matrix:
          - PROVIDER: aws
            STACK: app1
script: echo "Running rspec on linux..."

mac:rspec:
stage: test
needs:
    - job: mac:build
      parallel:
        matrix:
          - PROVIDER: [gcp, vultr]
            STACK: [data]
script: echo "Running rspec on mac..."

production:
stage: deploy
script: echo "Running production..."
environment: production
```

This example generates several jobs. The parallel jobs each have different values
for `PROVIDER` and `STACK`.

- 3 parallel `linux:build` jobs:
  - `linux:build: [aws, monitoring]`
  - `linux:build: [aws, app1]`
  - `linux:build: [aws, app2]`
- 4 parallel `mac:build` jobs:
  - `mac:build: [gcp, data]`
  - `mac:build: [gcp, processing]`
  - `mac:build: [vultr, data]`
  - `mac:build: [vultr, processing]`
- A `linux:rspec` job.
- A `production` job.

The jobs have three paths of execution:

- Linux path: The `linux:rspec` job runs as soon as the `linux:build: [aws, app1]`
job finishes, without waiting for `mac:build` to finish.
- macOS path: The `mac:rspec` job runs as soon as the `mac:build: [gcp, data]` and
`mac:build: [vultr, data]` jobs finish, without waiting for `linux:build` to finish.
- The `production` job runs as soon as all previous jobs finish.

#### Specify needs between parallelized jobs [Permalink](https://docs.gitlab.com/ci/jobs/job_control/\#specify-needs-between-parallelized-jobs "Permalink")

You can further define the order of each parallel matrix job using [`needs:parallel:matrix`](https://docs.gitlab.com/ci/yaml/#needsparallelmatrix).

For example:

yaml

```yaml
build_job:
stage: build
script:
    # ensure that other parallel job other than build_job [1, A] runs longer
    - '[[ "$VERSION" == "1" && "$MODE" == "A" ]] || sleep 30'
    - echo build $VERSION $MODE
parallel:
    matrix:
      - VERSION: [1,2]
        MODE: [A, B]

deploy_job:
stage: deploy
script: echo deploy $VERSION $MODE
parallel:
    matrix:
      - VERSION: [3,4]
        MODE: [C, D]

'deploy_job: [3, D]':
stage: deploy
script: echo something
needs:
  - 'build_job: [1, A]'
```

This example generates several jobs. The parallel jobs each have different values
for `VERSION` and `MODE`.

- 4 parallel `build_job` jobs:
  - `build_job: [1, A]`
  - `build_job: [1, B]`
  - `build_job: [2, A]`
  - `build_job: [2, B]`
- 4 parallel `deploy_job` jobs:
  - `deploy_job: [3, C]`
  - `deploy_job: [3, D]`
  - `deploy_job: [4, C]`
  - `deploy_job: [4, D]`

The `deploy_job: [3, D]` job runs as soon as `build_job: [1, A]` job finishes,
without waiting for the other `build_job` jobs to finish.

## Troubleshooting [Permalink](https://docs.gitlab.com/ci/jobs/job_control/\#troubleshooting "Permalink")

### Inconsistent user assignment when running manual jobs [Permalink](https://docs.gitlab.com/ci/jobs/job_control/\#inconsistent-user-assignment-when-running-manual-jobs "Permalink")

In some edge cases, the user that runs a manual job does not get assigned as the user for later jobs
that depend on the manual job.

If you need strict security over who is assigned as the user for jobs that depend on a manual job,
you should [protect the manual job](https://docs.gitlab.com/ci/jobs/job_control/#protect-manual-jobs).

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**