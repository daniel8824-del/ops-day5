<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/admin-user-delete -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Filter by keyword

- [acli](https://developer.atlassian.com/cloud/acli/reference/commands/)
- [admin](https://developer.atlassian.com/cloud/acli/reference/commands/admin/)

[admin auth](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth/)

[admin user](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user/)

- [activate](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user-activate/)
- [cancel-delete](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user-cancel-delete/)
- [deactivate](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user-deactivate/)
- [delete](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user-delete/)

- [feedback](https://developer.atlassian.com/cloud/acli/reference/commands/feedback/)
- [jira](https://developer.atlassian.com/cloud/acli/reference/commands/jira/)

[jira auth](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth/)

[jira board](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board/)

[jira dashboard](https://developer.atlassian.com/cloud/acli/reference/commands/jira-dashboard/)

[jira field](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field/)

[jira filter](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter/)

[jira project](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project/)

[jira sprint](https://developer.atlassian.com/cloud/acli/reference/commands/jira-sprint/)

[jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem/)

- [rovodev](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev/)

[rovodev auth](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev-auth/)

Last updated Oct 3, 2024

On This Page

- [acli admin user delete](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user-delete/#acli-admin-user-delete)


## acli admin user delete

Delete a managed account.

### Synopsis

Delete a managed account from Atlassian Administration.

```
Copy
1
acli admin user delete [flags]
```

### Examples

```
Copy
1
2
3
4
# Delete a managed account from Atlassian
$ acli admin user delete --email abc@atlassian.com
$ acli admin user delete --id 721217379117310973
$ acli admin user delete --from-file listofmails.txt
```

### Options

```
Copy
1
2
3
4
5
6
      --email string       List of emails to be deleted
      --from-file string   Read list of emails or account IDs from the file
  -h, --help               Show help for command
      --id string          List of Atlassian account IDs to be deleted
      --ignore-errors      Ignore the errors and continue
      --json               Generate a JSON output
```

### SEE ALSO

- [acli admin user](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user) \- Manage a user within your Atlassian organization.

Rate this page:

Unusable

Poor

Okay

Good

Excellent