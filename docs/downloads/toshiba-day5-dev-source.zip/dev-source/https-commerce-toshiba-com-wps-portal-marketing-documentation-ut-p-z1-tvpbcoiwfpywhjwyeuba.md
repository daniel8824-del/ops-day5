<!-- source: https://commerce.toshiba.com/wps/portal/marketing/documentation/!ut/p/z1/tVPBcoIwFPyWHjwyeUBAOCI6YBlGtBUlFwciEdoSUKO2f290eqidqu1Y3yXJZN_uzpt9iKApIjzdlotUlDVP3-Q7Ieasb6saBAEMvK7fg2EYd_qR6oEsFCOCSEPLOUosyEzGsK1kNm4rmMqbjWmuZDq1GGXMgHl2QFMuGlGgJOfKZt2Coq7yFqw3TVOvRAvmNd1UORdHB2hyTZ_IbzhTDsh-coQENnZ8y4XIixwXhubYi6y-q-PY_AR87-yMtI4O4A20HwEnIok02T5v0kCTbZnv0JjXq0rO9OmPI_OvKrRvVLhM7-H70pv_Sz_o-l0Y9sJx7ASqesjIXem1G-kfj-m6kHC5guXLckkcuTk1F_m7QNPfrI7s01ahGy6knVQUSslZjaanmKaqLP1DeR1Zu2dWLKpZ2NONL4cwkoc9ApzvNA!! -->

![logo](https://commerce.toshiba.com/wps/portal/marketing/documentation/!ut/p/z1/tVRbU6MwFP41PNKcQqTBN0odqGylVXvjxSk0QNySIKRl3V9vrM44dbR4zUtu3y2ZMwdFaIEivtqxbCWZ4KuN2i8j62Zodw0IAgi9gX8Gk9GsPxx3PVADzVCEojJha7QkEFtpim09tnFPx4la2TihemwmJE3S9ATW8SM64bKUOVpSrm9rDXJRUA3qbVmKSmqwFsm2oFzuE6B5m3-kruGd4cAzP7Cx4xMXxt7YcWFiTb0xGbomnll7_hH5J_5r2f6l0TcBvND4Cv8gYCs_2kOOveCNPziM2PZJryxIOHxMEXoB_jMAsDBaqlf03o95guY7Rhs05aIqVNFcfbImfGhz6H3T4bi8h39X3vpZ-XDgD2ByNprOnKDb3VfJb8ob35Q_b6tx1WPY7d1d5KjWILik_yRafKQ3KJ5RjdxRpuKsZK4zngq0OMQo82wj4qdO5vDYJApd0ZRWtOpsK3WcS1nWpxpo0DRNJxMi29BOIgoN3qLkolbpDpGoLApi3jPG9L-X_v_-he65MWmu0-Jlujc3u2JOaucBE0jLuw!!/images/logo.png)X

Sign in to your Toshiba account

For optimum experience,
please log in on your desktop computer

UserName

Password

Sign In [Forgot password?](https://www.toshibacommerce.com/tgcs109/tsim/forgotpassword.do) [Enterprise Login](https://www.toshibacommerce.com/mga/sps/authsvc?PolicyId=urn:ibm:security:authentication:asf:externalIDPLogin&target=https%3A%2F%2Ftoshibacommerce.com%2Fwps%2Fmyportal)

Don't have an ID? [Request one here](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/faqs)

{"Z7\_I9120KK0OGDHE0QMVBIP1G0005":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OGDHE0QMVBIP1G0007":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OGDHE0QMVBIP1G00G4":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OGDHE0QMVBIP1G00G6":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OODHD0QEMUVAK11000":{"windowState":"normal","portletMode":"view"},"Z7\_I9120KK0OODHD0QEMUVAK11002":{"windowState":"normal","portletMode":"view"}}

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

# Documentation

![](https://commerce.toshiba.com/wps/wcm/connect/marketing/1f6bc3d9-f47d-4635-9213-ab94135f2efd/documentation-banner.png?MOD=AJPERES&CACHEID=ROOTWORKSPACE.Z18_KA0A1A02NGL3D0AVS7NACQ0000-1f6bc3d9-f47d-4635-9213-ab94135f2efd-pOhoBqp)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

###### General

Read these two first:

[Toshiba Safety Information\\
\\
Toshiba Kiosk Safety Information](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/dg9z/njy5/~edisp/prod.tos669252.pdf)

[Software Licensing](https://www.toshibacommerce.com/wps/portal/marketing/publications/!ut/p/z1/tZRdb4IwFIZ_ixdekh6oQLkEdDgnisxN6Y2BDqSbfKio279fZ5Yl7kOzmPamac57nvfkpHkRRXNEy3jPl3HDqzJeiXdEjYXf7xLV8mDkjYkJdugEvTDQVVBN9IgoojXjTyjScMYSq0MUbLJE6ZAsUeIkjhUGJsEZsQzGyIealU3d5ChKyzbkVZG2Ybur62rTtKHeJSvOjuZbNLvkTUUZ_jg2iH56lHwRiBvcCEJ3ao1GEwwEfwq-dzqh5mAAb6z9KjgxicSQ5sIKCPTHoA084rpgE3-Ke0NNvbvV0WzP0wN6KKtNIfZ5_8919S86mFc6nMfbmly8KhePpeInIBcvd_cTXS5e7sc0OnLxxpX4wWn0_Awvkaz8eb2mtgjEqmzS1wbNLyWi6NE2vusvxShxkyu8zCo0P5HURUHwm_ISksM0y5fFwu9h_dy12g9tu9V6B7vToxM!/?1dmy&urile=wcm%3apath%3a%2Fen%2Fhome%2Fsupport%2Flicenses-warranties%2Fsoftware-licensing)

[End of Life Disposal Information](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/dg9z/njy5/~edisp/prod.tos669258.pdf)

[Environmental Notices](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/dg9z/njy5/~edisp/prod.tos669250.pdf)

[Uninterruptible Power Supply Statement](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/dg9z/njy5/~edisp/prod.tos669254.pdf)

[Warranty Information](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/dg9z/njy5/~edisp/prod.tos669256.pdf)

The section below provides general setup instructions and information:

[General Hardware Systems](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/dg9z/oduw/~edisp/prod.tos850722.pdf)

[Hardware Cleaning Instructions](https://tgcs04.toshibacommerce.com/cs/groups/allusers/documents/document/b3my/mdq4/~edisp/prod.tos2048301.pdf)[French](https://tgcs04.toshibacommerce.com/cs/groups/allusers/documents/document/b3my/mdq5/~edisp/prod.tos2049957.pdf)

[4610-1xR POS Printer](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/bw9k/zwxf/~edisp/4610_hw_guide_model_1nr.pdf)[French](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/zwxf/mw5y/~edisp/4610_hw_guide_model_1nr_fr.pdf)

[4610-2xR-POS Printer](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/b2rl/bhnf/~edisp/4610_hw_guide_models_2xr.pdf)[French](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/bhnf/mnhy/~edisp/4610_hw_guide_models_2xr_fr.pdf)

[6145 Single Station Printer](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/x3fp/z191/~edisp/6145_sst_qig_usen.pdf)[French](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/x3fp/z19m/~edisp/6145_sst_qig_frfr.pdf)

[6145 Dual Station Printer](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/x3fp/z191/~edisp/6145_dual_qig_usen.pdf)[French](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/x3fp/z19m/~edisp/6145_dual_qig_frfr.pdf)

###### Hardware

[POS Drivers & Common Packages](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-commonpackages-sitearea)

[Flat Panel Displays](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-displays)

[I/O Devices](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-peripheral)

[Self Checkout & self-service](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-selfcheckout)

[Handheld & mobile devices](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-mobile)

[TCx 900](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-tcx900-sitearea)

[TCx 820](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-tcx820-sitearea)

[TCx 800 & TCx 810/810 Essential](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-tcx800-sitearea)

[TCx 700 & SurePOS 700](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-tcx700-sitearea)

[TCx 620](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-tcx620-sitearea)

[TCx 300 & SurePOS 300](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-tcx300)

[TCxWave](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-hardware/support-tcxwave)

###### Software

[TCx Sky & 4690 OS](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-software/support-4690os)

[TCx OS for Android](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-software/support-android)

[Checkout Environment for Consumer Service (CHEC)](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-software/sco-chec-support)

[SurePOS ACE & EPS](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-software/surepos-ace-eps-support)

[ELERA](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-software/elera-support)

[Retail Management (REMS & RMA)](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-software/support-remote-management-agent)

[Store & Data Integration Framework](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-software/support-si-dif)

[TCx Elevate](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/home/support/product-support/support-software/tcxelevate-support)

[TCx Amplify](https://commerce.toshiba.com/?urile=wcm:path:/en-us/home/support/product-support/support-software/tcxamplify-support)

###### Regulatory

EU 617/2013 compliance documents

Commission Regulation (EU) No 617/2013 sets ecodesign requirements for computers and computer servers under Directive 2009/125/EC. It obliges manufacturers to produce technical documentation demonstrating compliance with energy‑efficiency and environmental requirements.

[4810-xx1](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzq4/mtat/~edisp/eu_617-2013_4810-xx1.pdf) [4810-36x / 37x](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/mtat/edz4/~edisp/eu_617-2013_4810-x6xx7x.pdf) [4810-38x](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzq4/mtat/~edisp/eu_617-2013_4810-x80.pdf) [4818-T10 & ET1](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/oc10/mtau/~edisp/eu_617-2013_4818-t10.et1.pdf) [4825-x4x](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzq4/mjut/~edisp/eu617-2013_4825-x4x.pdf) [4828-x2x](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzq4/mjgt/~edisp/eu_617-2013_4828-x2x.pdf) [4852-58x](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzq4/ntit/~edisp/eu_617-2013_4852-x8x.pdf) [4900-xx7](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzq5/mdat/~edisp/eu_617-2013_4900-xx7.pdf) [4900-xx6](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzq5/mdat/~edisp/eu_617-2013_4900-7x6.pdf) [4901-x1x](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzq5/mdet/~edisp/eu_617-2013_4901-x1x.pdf) [6140-x4x](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzyx/ndat/~edisp/eu_617-2013_6140-x4x.pdf) [6140-x5x](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzyx/ndat/~edisp/eu_617-2013_6140-x5x.pdf) [6200-1xx](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzyy/mdat/~edisp/eu_617-2013_6200-1xx.pdf) [6201-2xx / Exx](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzyy/mdet/~edisp/eu_617-2013_6201-2xx.pdf) [6225-3xx](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/b3mz/nzk2/~edisp/prod.tos3796317.pdf)

Taiwanese Bureau of Standards, Metrology and Inspection compliance documents

A BSMI Restriction of Hazardous Substances (RoHS) report shows whether an electronic product follows Taiwan regulation CNS 15663, which limits six hazardous substance (lead, mercury, cadmium, hexavalent chromium, PBB, and& PBDE).

_Flat panel displays_

[4820-xxB / xxD Touch Display](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/mjat/ehhi/~edisp/taiwan_4820-xxbxxd.pdf) [4820-2Lx / 2Nx Touch Display](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/mjat/mmx4/~edisp/taiwan_4820-2lx2nx.pdf) [4820-5Lx Touch Display](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzq4/mjat/~edisp/taiwan_4820-5lx.pdf) [4820-21x / 51x Touch Display](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/mjat/mjf4/~edisp/taiwan_4820-21x51x.pdf) [4852 6.5" Display](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/ef9k/axnw/~edisp/taiwan_4852-xxx_display.pdf) [6149-5Cx Touch Display](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzyx/ndkt/~edisp/taiwan_6149-5cx.pdf) [6149-5Nx / 5Sx Display](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/ndkt/nw54/~edisp/taiwan_6149-5nx5sx.pdf) [6149-x1T Display](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzyx/ndkt/~edisp/taiwan_6149-x1t.pdf) [6150-Bxx/Pxx Display](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/ntat/ynh4/~edisp/taiwan_6150-bxxpxx.pdf)

_System Units_

[4900-xx7](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzq5/mdat/~edisp/taiwan_4900-xx7.pdf) [4810-34x / 35x / 36x / 37x / 38x / 3x1](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzq4/mtat/~edisp/taiwan_4810-38x.pdf) [4852-x7x / x8x](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzq4/ntit/~edisp/taiwan_4852-x7x.pdf) [4900-xx6](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzq5/mdat/~edisp/taiwan_4900-xx6.pdf) [6140-x3x / x4x / x5x](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzyx/ndat/~edisp/taiwan_6140-x3x.pdf) [6201-xxx](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzyy/mdet/~edisp/taiwan_6201-xxx.pdf) [4828-x2x](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzq4/mjgt/~edisp/taiwan_4828-x2x.pdf) [4901-x1x](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzq5/mdat/~edisp/taiwan_4900-xx7.pdf) [6225-3xx](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzyy/mjut/~edisp/taiwan_6225-3xx.pdf) [4825-x4x](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzq4/mjut/~edisp/taiwan_4825-x4x~1.pdf)

_I/O peripherals_

[4610-xxR POS printer](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzq2/mtat/~edisp/taiwan_4610-xxr.pdf) [Keypad for 4820 flat panel display](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/mjbf/a2v5/~edisp/taiwan_4820_keypad.pdf) [Legacy speaker for 4820 flat panel display](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/z2fj/ev9z/~edisp/taiwan_4820_legacy_spkr.pdf) [Speaker for 4820 flat panel display](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/ndgy/mf9z/~edisp/taiwan_4820_spkr.pdf) [MSR for 4820 flat panel display](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzq4/mjbf/~edisp/taiwan_4820_msr.pdf) [Modular POS keyboard](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/axdh/bl9t/~edisp/taiwan_mkbd.pdf) [Modular POS keyboard (MSR attachment)](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/x21r/ymrf/~edisp/taiwan_mkbd_msr.pdf) [Modular POS keyboard (touchpad attachment)](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/bwti/zf90/~edisp/taiwan_mkbd_tpad.pdf) [Fingerprint reader](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/aw50/x3jl/~edisp/taiwan_fingerprint_readr.pdf) [iButton for 6140 (TCxWave) & 6149 (TCx Display)](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/ef9p/ynv0/~edisp/taiwan_614x_ibutton.pdf) [MSR for 4852 (SurePOS 500)](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzq4/mjbf/~edisp/taiwan_4820_msr.pdf) [MSR for 6140 (TCxWave)](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzyx/ndbf/~edisp/taiwan_6140_msr.pdf) [Keypad for 6149 (TCx Display)](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/ndlf/a2v5/~edisp/taiwan_6149_keypad.pdf) [MSR for 6149 (TCx Display)](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzyx/ndlf/~edisp/taiwan_6149_msr.pdf) [6145-1Tx POS printer](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzyx/ndut/~edisp/taiwan_6145-1tx.pdf) [6145-2Tx POS printer](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzyx/ndut/~edisp/taiwan_6145-2tx.pdf) [6180-S10 printer](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/xzyx/odbf/~edisp/taiwan_6180_s10.pdf)

UN38.3 lithium battery compliance documents

Section 38.3 of the UN Manual of Tests and Criteria governs the safe shipment of lithium‑ion and lithium metal batteries as Class 9 dangerous goods. These rules apply to batteries shipped individually (e.g., spare batteries), packed with equipment or installed in equipment.

[DBV CR2032](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/ynzf/y3iy/~edisp/un383_dbv_cr2032.pdf) [JHT CR2032](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/ahrf/y3iy/~edisp/un383_jht_cr2032.pdf) [Mitsubishi CR2032](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/aglf/y3iy/~edisp/un383_mitsubishi_cr2032.pdf) [Panasonic CR2032](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/awnf/y3iy/~edisp/un383_panasonic_cr2032.pdf) [Renata CR2032](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/dgff/y3iy/~edisp/un383_renata_cr2032.pdf) [Sony CR2032](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/bnlf/y3iy/~edisp/un383_sony_cr2032.pdf) [Murata CR2032](https://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/dgff/y3iy/~edisp/un383_murata_cr2032.pdf)

Turkiye EPREL

EPREL (European Product Registry for Energy Labelling) is a comprehensive database set up and operated by the European Commission. Its primary purpose is to make information about the energy and environmental performance of all models of products bearing the "energy label" readily available

EPREL (Enerji Etiketlemesi için Avrupa Ürün Kaydı), Avrupa Komisyonu tarafından oluşturulan ve işletilen kapsamlı bir veri tabanıdır. Temel amacı, "enerji etiketi" taşıyan tüm ürün modellerinin enerji ve çevresel performanslarına ilişkin bilgileri kolayca erişilebilir kılmaktır.

[Özellik kodu 2114, 10 inç ekran, birden fazla sistem birimi için](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/b3m0/mtyw/~edisp/prod.tos4160067.pdf) [Özellik kodu 3377, 7 inç ekran, birden çok sistem birimi için](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/b3m0/mjaz/~edisp/prod.tos4203524.pdf) [TCx Dokunmatik Ekran 6150-B15](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/b3m0/mjaz/~edisp/prod.tos4203566.pdf) [TCx Dokunmatik Ekran 6150-B19](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/b3m0/mjaz/~edisp/prod.tos4203567.pdf) [TCx Dokunmatik Ekran 6150-B24](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/b3m0/mjaz/~edisp/prod.tos4203568.pdf) [TCx Dokunmatik Ekran 6150-P15](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/b3m0/mjaz/~edisp/prod.tos4203569.pdf) [TCx Dokunmatik Ekran 6150-P16](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/b3m0/mjaz/~edisp/prod.tos4203570.pdf) [TCx Dokunmatik Ekran 6150-P19](http://tgcs04.toshibacommerce.com/cs/groups/internet/documents/document/b3m0/mjaz/~edisp/prod.tos4203571.pdf)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

![start portlet menu bar](<Base64-Image-Removed>)

## Web Content Viewer

Display content menuDisplay portlet menu

![end portlet menu bar](<Base64-Image-Removed>)

Start a conversation

First name

Last name

Email

Company

Country

Phone

I am a

Business PartnerOtherPress / AnalystRetailerSupplierToshiba Employee

- Business Partner

- Other

- Press / Analyst

- Retailer

- Supplier

- Toshiba Employee


My Retail Segment

Fashion & ApparelFood ServiceGas & ConvenienceGroceryMass MerchandiseOtherPharmacy / Drug StoreSpecialty

- Fashion & Apparel

- Food Service

- Gas & Convenience

- Grocery

- Mass Merchandise

- Other

- Pharmacy / Drug Store

- Specialty


I am interested in learning more about

Add me to Toshiba Global Commerce Solutions' email marketing list

I am allowing Toshiba to contact me in regards to the information on this form

Comments

By submitting this form I agree that Toshiba Global Commerce Solutions, Inc. and its affiliates, including all subsidiaries and branches, may process my data as indicated above and as described in the [Toshiba Global Commerce Solutions Privacy Declaration.](https://commerce.toshiba.com/wps/portal/marketing/?urile=wcm:path:/en-us/common-content/general-content/privacy-policy&mapping=tgcs_new.portal.generaldetails)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**

reCAPTCHA is changing its terms of service. [Take action.](https://google.com/recaptcha/admin/migrate)

![success](https://commerce.toshiba.com/wps/portal/marketing/documentation/!ut/p/z1/tVRbU6MwFP41PNKcQqTBN0odqGylVXvjxSk0QNySIKRl3V9vrM44dbR4zUtu3y2ZMwdFaIEivtqxbCWZ4KuN2i8j62Zodw0IAgi9gX8Gk9GsPxx3PVADzVCEojJha7QkEFtpim09tnFPx4la2TihemwmJE3S9ATW8SM64bKUOVpSrm9rDXJRUA3qbVmKSmqwFsm2oFzuE6B5m3-kruGd4cAzP7Cx4xMXxt7YcWFiTb0xGbomnll7_hH5J_5r2f6l0TcBvND4Cv8gYCs_2kOOveCNPziM2PZJryxIOHxMEXoB_jMAsDBaqlf03o95guY7Rhs05aIqVNFcfbImfGhz6H3T4bi8h39X3vpZ-XDgD2ByNprOnKDb3VfJb8ob35Q_b6tx1WPY7d1d5KjWILik_yRafKQ3KJ5RjdxRpuKsZK4zngq0OMQo82wj4qdO5vDYJApd0ZRWtOpsK3WcS1nWpxpo0DRNJxMi29BOIgoN3qLkolbpDpGoLApi3jPG9L-X_v_-he65MWmu0-Jlujc3u2JOaucBE0jLuw!!/images/tgcs/success.svg)

## Success!

Thank you for reaching out. One of our team members will be in contact soon. We hope you have a great day.

Close

Complementary
Content

[Deferred Modules](https://commerce.toshiba.com/wps/contenthandler/marketing/!ut/p/digest!M6zrA0PEiotCbddBEGnoVg/mashup/ra:collection?themeID=ZJ_JQGEHK01N0LM806KGPAKPA0UO0&locale=en&mime-type=text%2Fjavascript&lm=1778876784000&entry=st_skin__0.0%3Aconfig_js&entry=wp_liveobject_framework_core__0.0%3Aconfig_js&entry=wp_portal_ui_utils__0.0%3Aconfig_js&entry=wp_contextmenu_js__0.0%3Aconfig_js&entry=wp_skin_cam__0.0%3Aconfig_js&entry=wp_contextmenu_config_lof__0.0%3Aconfig_js&entry=wp_federated_documents_picker__0.0%3Aconfig_js&entry=wp_dnd_main__0.0%3Aconfig_js&entry=wp_movecontrols__0.0%3Aconfig_js&entry=wp_toolbar_controlactions__0.0%3Aconfig_js&entry=wp_content_targeting_cam__0.0%3Aconfig_js&deferred=true)

- ${title}${badge}

${loading}

[Deferred Modules](https://commerce.toshiba.com/wps/contenthandler/marketing/!ut/p/digest!SpZvrtUURDcRHYzcbiqg-Q/mashup/ra:collection?themeID=ZJ_JQGEHK01N0LM806KGPAKPA0UO0&locale=en&mime-type=text%2Fplain&entry=wp_contextmenu_templates__0.0%3Aconfig_markup&entry=wp_skin_cam__0.0%3Aconfig_markup&entry=wp_dnd_main__0.0%3Aconfig_markup&deferred=true)

reCAPTCHA

Select all images with **bicycles** Click verify once there are none left

|     |     |     |
| --- | --- | --- |
| ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7r043pIRBDZZyXTvBqRlfrvL0_vYFTnYyqNwFC23EvfYgkAIJjpzEeSMNDs2GOZdmsQBGCzO2FC9ZoUlqW4L-5_EktutqltRntcPWqY3_YfBZQPmxkjqG6duu3ihRLAB7uY7-_9uTr9J-inJpTDY9HMwGeHGtAZpx1KHIi7KOaAYu6Knj_KY5xZGUfcpoLuzW-RCeR&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7r043pIRBDZZyXTvBqRlfrvL0_vYFTnYyqNwFC23EvfYgkAIJjpzEeSMNDs2GOZdmsQBGCzO2FC9ZoUlqW4L-5_EktutqltRntcPWqY3_YfBZQPmxkjqG6duu3ihRLAB7uY7-_9uTr9J-inJpTDY9HMwGeHGtAZpx1KHIi7KOaAYu6Knj_KY5xZGUfcpoLuzW-RCeR&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7r043pIRBDZZyXTvBqRlfrvL0_vYFTnYyqNwFC23EvfYgkAIJjpzEeSMNDs2GOZdmsQBGCzO2FC9ZoUlqW4L-5_EktutqltRntcPWqY3_YfBZQPmxkjqG6duu3ihRLAB7uY7-_9uTr9J-inJpTDY9HMwGeHGtAZpx1KHIi7KOaAYu6Knj_KY5xZGUfcpoLuzW-RCeR&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) |
| ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7r043pIRBDZZyXTvBqRlfrvL0_vYFTnYyqNwFC23EvfYgkAIJjpzEeSMNDs2GOZdmsQBGCzO2FC9ZoUlqW4L-5_EktutqltRntcPWqY3_YfBZQPmxkjqG6duu3ihRLAB7uY7-_9uTr9J-inJpTDY9HMwGeHGtAZpx1KHIi7KOaAYu6Knj_KY5xZGUfcpoLuzW-RCeR&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7r043pIRBDZZyXTvBqRlfrvL0_vYFTnYyqNwFC23EvfYgkAIJjpzEeSMNDs2GOZdmsQBGCzO2FC9ZoUlqW4L-5_EktutqltRntcPWqY3_YfBZQPmxkjqG6duu3ihRLAB7uY7-_9uTr9J-inJpTDY9HMwGeHGtAZpx1KHIi7KOaAYu6Knj_KY5xZGUfcpoLuzW-RCeR&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7r043pIRBDZZyXTvBqRlfrvL0_vYFTnYyqNwFC23EvfYgkAIJjpzEeSMNDs2GOZdmsQBGCzO2FC9ZoUlqW4L-5_EktutqltRntcPWqY3_YfBZQPmxkjqG6duu3ihRLAB7uY7-_9uTr9J-inJpTDY9HMwGeHGtAZpx1KHIi7KOaAYu6Knj_KY5xZGUfcpoLuzW-RCeR&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) |
| ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7r043pIRBDZZyXTvBqRlfrvL0_vYFTnYyqNwFC23EvfYgkAIJjpzEeSMNDs2GOZdmsQBGCzO2FC9ZoUlqW4L-5_EktutqltRntcPWqY3_YfBZQPmxkjqG6duu3ihRLAB7uY7-_9uTr9J-inJpTDY9HMwGeHGtAZpx1KHIi7KOaAYu6Knj_KY5xZGUfcpoLuzW-RCeR&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7r043pIRBDZZyXTvBqRlfrvL0_vYFTnYyqNwFC23EvfYgkAIJjpzEeSMNDs2GOZdmsQBGCzO2FC9ZoUlqW4L-5_EktutqltRntcPWqY3_YfBZQPmxkjqG6duu3ihRLAB7uY7-_9uTr9J-inJpTDY9HMwGeHGtAZpx1KHIi7KOaAYu6Knj_KY5xZGUfcpoLuzW-RCeR&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) | ![](https://www.google.com/recaptcha/api2/payload?p=06AFcWeA7r043pIRBDZZyXTvBqRlfrvL0_vYFTnYyqNwFC23EvfYgkAIJjpzEeSMNDs2GOZdmsQBGCzO2FC9ZoUlqW4L-5_EktutqltRntcPWqY3_YfBZQPmxkjqG6duu3ihRLAB7uY7-_9uTr9J-inJpTDY9HMwGeHGtAZpx1KHIi7KOaAYu6Knj_KY5xZGUfcpoLuzW-RCeR&k=6LfEPr0ZAAAAAKeWnaDdJplumzeVbvrxPPSSSQ92) |

Please try again.

Please select all matching images.

Please also check the new images.

Please select around the object, or reload if there are none.

Verify