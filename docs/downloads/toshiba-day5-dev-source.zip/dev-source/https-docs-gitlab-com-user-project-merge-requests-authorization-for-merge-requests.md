<!-- source: https://docs.gitlab.com/user/project/merge_requests/authorization_for_merge_requests -->

/

* * *

# Merge request workflows

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

GitLab merge requests commonly follow one of these flows:

- Working with [protected branches](https://docs.gitlab.com/user/project/repository/branches/protected/) in a single repository.
- Working with forks of an authoritative project.

## Protected branch flow [Permalink](https://docs.gitlab.com/user/project/merge_requests/authorization_for_merge_requests/\#protected-branch-flow "Permalink")

With the protected branch flow, everybody works in the same GitLab project, instead of forks.

The project maintainers get the Maintainer role and the regular developers
get the Developer role.

Maintainers mark the authoritative branches as ‘Protected’.

Developers push feature branches to the project and create merge requests
to have their feature branches reviewed and merged into one of the protected
branches.

By default, only users with the Maintainer role can merge changes into a
protected branch.

- Advantages:
  - Fewer projects means less clutter.
  - Developers need to consider only one remote repository.
- Disadvantages:
  - Manual setup of protected branch required for each new project

To set up a protected branch flow:

1. Start with ensuring that your default branch is protected with [default branch protections](https://docs.gitlab.com/user/project/repository/branches/default/).

2. If your team has multiple branches, and you would like to manage who can merge changes and who
explicitly has the option to push or force push, consider making those branches protected:

   - [Manage and protect branches](https://docs.gitlab.com/user/project/repository/branches/#manage-and-protect-branches)
   - [Protected Branches](https://docs.gitlab.com/user/project/repository/branches/protected/)
3. Each change to the code comes through as a commit.
You can specify the format and security measures such as requiring SSH key signing for changes
coming into your codebase with push rules:

   - [Push rules](https://docs.gitlab.com/user/project/repository/push_rules/)
4. To ensure that the code is reviewed and checked by the right people in your team, use:

   - [Code Owners](https://docs.gitlab.com/user/project/codeowners/)
   - [Merge request approval rules](https://docs.gitlab.com/user/project/merge_requests/approvals/rules/)

Also available in the Ultimate tier:

- [Status checks](https://docs.gitlab.com/user/project/merge_requests/status_checks/)
- [Security approvals](https://docs.gitlab.com/user/project/merge_requests/approvals/rules/#security-approvals)

## Forking workflow [Permalink](https://docs.gitlab.com/user/project/merge_requests/authorization_for_merge_requests/\#forking-workflow "Permalink")

With the forking workflow, maintainers get the Maintainer role and regular
developers get the Reporter role on the authoritative repository, which prohibits
them from pushing any changes to it.

Developers create forks of the authoritative project and push their feature
branches to their own forks.

To get their changes into the default branch, they need to create a merge request across
forks.

- Advantages:
  - In an appropriately configured GitLab group, new projects automatically get
    the required access restrictions for regular developers: fewer manual steps
    to configure authorization for new projects.
- Disadvantages:
  - The project need to keep their forks up to date, which requires more advanced
    Git skills (managing multiple remotes).

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**