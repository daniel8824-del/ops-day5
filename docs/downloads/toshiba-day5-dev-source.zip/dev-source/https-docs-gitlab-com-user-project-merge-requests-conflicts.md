<!-- source: https://docs.gitlab.com/user/project/merge_requests/conflicts -->

/

* * *

# Merge conflicts

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

Merge conflicts occur when two branches in a merge request, the source and target,
have different changes to the same lines of code. In most cases, GitLab can merge changes together,
but when conflicts arise, you must decide which changes to keep.

![A merge request blocked due to a merge conflict](https://docs.gitlab.com/user/project/merge_requests/img/conflicts_v16_7.png)

To resolve a merge request with conflicts, you must either:

- Create a merge commit.
- Resolve the conflict through a rebase.

GitLab resolves conflicts by creating a merge commit in the source branch without merging it
into the target branch. You can then review and test the merge commit to verify it contains
no unintended changes and doesn’t break your build.

## Understand conflict blocks [Permalink](https://docs.gitlab.com/user/project/merge_requests/conflicts/\#understand-conflict-blocks "Permalink")

When Git detects a conflict that requires a decision on your part, it marks the
beginning and end of the conflict block with conflict markers:

- `<<<<<<< HEAD` marks the beginning of the conflict block.
- Your changes are shown.
- `=======` marks the end of your changes.
- The latest changes in the target branch are shown.
- `>>>>>>>` marks the end of the conflict.

To resolve a conflict, delete:

1. The version of the conflicted lines you don’t want to keep.
2. The three conflict markers: the beginning, the end, and the `=======` line between
the two versions.

## Conflicts you can resolve in the user interface [Permalink](https://docs.gitlab.com/user/project/merge_requests/conflicts/\#conflicts-you-can-resolve-in-the-user-interface "Permalink")

You can resolve merge conflicts in the GitLab UI if the conflicting file:

- Is a non binary text file.
- Is less than 200 KB in size with conflict markers added.
- Uses UTF-8 compatible encoding.
- Doesn’t contain conflict markers.
- Exists under the same path in both branches.

If a file doesn’t meet these criteria, you must resolve the conflict manually.

## Conflict resolution methods [Permalink](https://docs.gitlab.com/user/project/merge_requests/conflicts/\#conflict-resolution-methods "Permalink")

GitLab shows [conflicts available for resolution](https://docs.gitlab.com/user/project/merge_requests/conflicts/#conflicts-you-can-resolve-in-the-user-interface)
in the user interface, and you can also resolve conflicts using the following methods:

- GitLab Duo: Best for automatic, end-to-end conflict resolution.
- Interactive mode: Best for conflicts where you only need to select which version of a line to keep.
- Inline editor: Suitable for complex conflicts requiring manual edits to blend changes.
- Command line: Provides complete control over complex conflicts.
For more information, see [resolve conflicts from the command line](https://docs.gitlab.com/topics/git/git_rebase/#resolve-conflicts-from-the-command-line).

### Resolve conflicts with GitLab Duo [Permalink](https://docs.gitlab.com/user/project/merge_requests/conflicts/\#resolve-conflicts-with-gitlab-duo "Permalink")

- Tier: Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated
- Status: Beta

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/235919) in GitLab 19.0
[with a feature flag](https://docs.gitlab.com/administration/feature_flags/) named `mr_ai_resolve_conflicts`. Enabled by default.

The availability of this feature is controlled by a feature flag.
For more information, see the history.

GitLab Duo can autonomously analyze merge conflicts, edit the conflicting files,
create a commit, and push to the source branch.

Prerequisites:

- The Developer, Maintainer, or Owner role.
- Push access to the source branch.
- [GitLab Duo Agent Platform prerequisites](https://docs.gitlab.com/user/duo_agent_platform/#prerequisites).
- [Beta and experimental features](https://docs.gitlab.com/user/duo_agent_platform/turn_on_off/#turn-on-beta-and-experimental-features)
turned on.
- A merge request with conflicts that
[can be resolved in the user interface](https://docs.gitlab.com/user/project/merge_requests/conflicts/#conflicts-you-can-resolve-in-the-user-interface).

To resolve conflicts with GitLab Duo:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Code** \> **Merge requests** and find the merge request.
3. Select **Overview**.
4. Find the merge conflict details and instruct GitLab Duo to resolve the conflicts:
   - In the merge request reports section, select **Resolve conflicts**, then select **Resolve with GitLab Duo**.
   - In the merge widget, find the conflict check row and select **Resolve with GitLab Duo**.

GitLab Duo analyzes the conflicts, resolves them, commits the changes, and pushes to the source branch.
When complete, GitLab Duo posts a summary comment on the merge request.

GitLab Duo respects branch protection rules and does not force-push to protected branches.

### Interactive mode [Permalink](https://docs.gitlab.com/user/project/merge_requests/conflicts/\#interactive-mode "Permalink")

Interactive mode merges the target branch into the source branch with your chosen changes.

To resolve merge conflicts with interactive mode:

1. In the top bar, select **Search or go to** and find your project.

2. In the left sidebar, select **Code** \> **Merge requests** and find the merge request.

3. Select **Overview**, and scroll to the merge request reports section.

4. Find the merge conflicts message, and select **Resolve conflicts**.
GitLab shows a list of files with merge conflicts. The lines that conflict are
highlighted.

5. For each conflict, select **Use ours** or **Use theirs** to mark the version
of the conflicted lines you want to keep. This decision is known as
“resolving the conflict.”

6. When you’ve resolved all the conflicts, enter a **Commit message**.

7. Select **Commit to source branch**.


### Inline editor [Permalink](https://docs.gitlab.com/user/project/merge_requests/conflicts/\#inline-editor "Permalink")

Some merge conflicts are more complex, and you must manually edit lines to
resolve them.

The merge conflict resolution editor helps you resolve these conflicts in GitLab:

1. In the top bar, select **Search or go to** and find your project.

2. In the left sidebar, select **Code** \> **Merge requests** and find the merge request.

3. Select **Overview**, and scroll to the merge request reports section.

4. Find the merge conflicts message, and select **Resolve conflicts**.
GitLab shows a list of files with merge conflicts.

5. Find the file to edit manually, and scroll to the conflict block.

6. In the header for that file, select **Edit inline** to open the editor. In this
example, the conflict block begins at line 1350 and ends at line 1356:

![Merge conflict editor](https://docs.gitlab.com/user/project/merge_requests/img/merge_conflict_editor_v16_7.png)

7. After you resolve the conflict, enter a **Commit message**.

8. Select **Commit to source branch**.


## Rebase [Permalink](https://docs.gitlab.com/user/project/merge_requests/conflicts/\#rebase "Permalink")

If your merge request is stuck with a `Checking ability to merge automatically`
message, you can:

- In a comment in the merge request, run the [`/rebase` quick action](https://docs.gitlab.com/user/project/quick_actions/#rebase).
- In the merge widget, select **Rebase source branch**.
- [Rebase with Git](https://docs.gitlab.com/topics/git/git_rebase/#rebase).

To troubleshoot CI/CD pipeline issues, see [debugging CI/CD pipelines](https://docs.gitlab.com/ci/debugging/).

For projects that use the semi-linear or fast-forward merge method, you can also
turn on [automatic rebase before merge](https://docs.gitlab.com/user/project/merge_requests/methods/#automatic-rebase-before-merge)
to skip the manual rebase step.

### Rebase in the GitLab UI [Permalink](https://docs.gitlab.com/user/project/merge_requests/conflicts/\#rebase-in-the-gitlab-ui "Permalink")

To trigger a rebase from the GitLab UI, use the [`/rebase` quick action](https://docs.gitlab.com/user/project/quick_actions/#rebase), or the
rebase option in the merge request widget.

Prerequisites:

- No merge conflicts exist.
- You must have at least the [Developer role](https://docs.gitlab.com/user/permissions/) for the source project.
- If the merge request is in a fork, the fork must allow commits
[from members of the upstream project](https://docs.gitlab.com/user/project/merge_requests/allow_collaboration/).

To rebase a merge request’s branch from the GitLab UI:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Code** \> **Merge requests** and find the merge request.
3. Either:
   - On the **Overview** tab, scroll to the merge request widget and select **Rebase source branch**.
   - In a comment, enter `/rebase` and select **Comment**.

GitLab schedules, then runs, a rebase of the branch against the default branch.
GitLab shows the completed rebase as a system note.

If you have configured commit signing for commits made
through the GitLab UI, web commits lose their commit signatures
[when rebased through the UI](https://docs.gitlab.com/user/project/repository/signed_commits/web_commits/#web-commits-become-unsigned-after-rebase).

## Related topics [Permalink](https://docs.gitlab.com/user/project/merge_requests/conflicts/\#related-topics "Permalink")

- [Rebase and resolve conflicts](https://docs.gitlab.com/topics/git/git_rebase/)
- [Introduction to Git rebase and force-push](https://docs.gitlab.com/topics/git/git_rebase/)
- [Git applications for visualizing the Git workflow](https://git-scm.com/downloads/guis)
- [Automatic conflict resolution with `git rerere`](https://git-scm.com/book/en/v2/Git-Tools-Rerere)

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**