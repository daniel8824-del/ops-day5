<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth-login -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Filter by keyword

- [acli](https://developer.atlassian.com/cloud/acli/reference/commands/)
- [admin](https://developer.atlassian.com/cloud/acli/reference/commands/admin/)

[admin auth](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth/)

[admin user](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user/)

- [feedback](https://developer.atlassian.com/cloud/acli/reference/commands/feedback/)
- [jira](https://developer.atlassian.com/cloud/acli/reference/commands/jira/)

[jira auth](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth/)

- [login](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth-login/)
- [logout](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth-logout/)
- [status](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth-status/)
- [switch](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth-switch/)

[jira board](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board/)

[jira dashboard](https://developer.atlassian.com/cloud/acli/reference/commands/jira-dashboard/)

[jira field](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field/)

[jira filter](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter/)

[jira project](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project/)

[jira sprint](https://developer.atlassian.com/cloud/acli/reference/commands/jira-sprint/)

[jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem/)

- [rovodev](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev/)

[rovodev auth](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev-auth/)

Last updated Oct 3, 2024

On This Page

- [acli jira auth login](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth-login/#acli-jira-auth-login)


## acli jira auth login

Authenticate with an Atlassian host.

```
Copy
1
acli jira auth login [flags]
```

### Examples

```
Copy
1
2
3
4
5
6
7
8
9
10
# Authenticate using web browser (OAuth)
$ acli jira auth login --web

# Authenticate with your email, site name and API token without scopes
$ acli jira auth login --site "mysite.atlassian.net" --email "user@atlassian.com" --token < token.txt
OR
$ echo <token> | acli jira auth login --site "mysite.atlassian.net" --email "user@atlassian.com" --token

# Authenticate with your email, site name and API token without scopes on Windows
$ Get-Content token.txt | .\acli.exe jira auth login --site "mysite.atlassian.net" --email "user@atlassian.com" --token
```

### Options

```
Copy
1
2
3
4
5
  -e, --email string   User email is required for authentication
  -h, --help           Show help for command
  -s, --site string    Site of the Atlassian instance is required for authentication
      --token          Read token from standard input
  -w, --web            Authenticate using web browser
```

### SEE ALSO

- [acli jira auth](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth) \- Authenticate to use Atlassian CLI.

Rate this page:

Unusable

Poor

Okay

Good

Excellent