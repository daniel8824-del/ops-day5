<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-create -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Filter by keyword

- [acli](https://developer.atlassian.com/cloud/acli/reference/commands/)
- [admin](https://developer.atlassian.com/cloud/acli/reference/commands/admin/)

[admin auth](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth/)

[admin user](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user/)

- [feedback](https://developer.atlassian.com/cloud/acli/reference/commands/feedback/)
- [jira](https://developer.atlassian.com/cloud/acli/reference/commands/jira/)

[jira auth](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth/)

[jira board](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board/)

[jira dashboard](https://developer.atlassian.com/cloud/acli/reference/commands/jira-dashboard/)

[jira field](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field/)

[jira filter](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter/)

[jira project](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project/)

[jira sprint](https://developer.atlassian.com/cloud/acli/reference/commands/jira-sprint/)

[jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem/)

- [archive](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-archive/)
- [assign](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-assign/)
- [attachment-delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-attachment-delete/)
- [attachment-list](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-attachment-list/)
- [clone](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-clone/)
- [comment-create](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-create/)
- [comment-delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-delete/)
- [comment-list](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-list/)
- [comment-update](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-update/)
- [comment-visibility](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-visibility/)
- [create](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-create/)
- [create-bulk](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-create-bulk/)
- [delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-delete/)
- [edit](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-edit/)
- [link](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-link/)
- [search](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-search/)
- [transition](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-transition/)
- [unarchive](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-unarchive/)
- [view](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-view/)
- [watcher-remove](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-watcher-remove/)

- [rovodev](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev/)

[rovodev auth](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev-auth/)

Last updated Oct 3, 2024

On This Page

- [acli jira workitem create](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-create/#acli-jira-workitem-create)


## acli jira workitem create

Create a Jira work item.

### Synopsis

Create a Jira work item to track individual pieces of work that must be completed.

```
Copy
1
acli jira workitem create [flags]
```

### Examples

```
Copy
1
2
3
4
5
6
7
8
9
10
11
# Create work item by supplying a summary, project name and work item type
$ acli jira workitem create --summary "New Task" --project "TEAM" --type "Task"

# Create work item from file and supplying all work item details
$ acli jira workitem create --from-file "workitem.txt" --project "PROJ" --type "Bug" --assignee "user@atlassian.com" --label "bug,cli"

# Generate a JSON file that could be used for workitem creation via --from-json flag
$ acli jira workitem create --generate-json

# Create work item from a JSON file
$ acli jira workitem create --from-json "workitem.json"
```

### Options

```
Copy
1
2
3
4
5
6
7
8
9
10
11
12
13
14
  -a, --assignee string           Assign people by their email or account ID. Use '@me' to self-assign, 'default' to assign to the project's default assignee
  -d, --description string        Supply a description in plain text or Atlassian Document Format (ADF)
      --description-file string   Read the description in plain text or Atlassian Document Format (ADF) from the file
  -e, --editor                    Open a text editor to specify the summary and description
  -f, --from-file string          Read the work item summary, description from a file
      --from-json string          Read the work item definition from a JSON file
      --generate-json             Generates a JSON file that could be used for work item creation
  -h, --help                      Show help for command
      --json                      Output in JSON
  -l, --label strings             Add labels by name and comma-separated
      --parent string             Parent work item ID
  -p, --project string            Add the work item to projects by project key
  -s, --summary string            Supply a summary for the work item
  -t, --type string               Defines the work item type of the created work item. For example, Epic, Story, Task, Bug
```

### SEE ALSO

- [acli jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem) \- Jira work item commands.

Rate this page:

Unusable

Poor

Okay

Good

Excellent