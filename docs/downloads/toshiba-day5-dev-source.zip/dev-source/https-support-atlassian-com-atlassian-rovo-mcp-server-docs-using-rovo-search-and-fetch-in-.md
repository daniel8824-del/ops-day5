<!-- source: https://support.atlassian.com/atlassian-rovo-mcp-server/docs/using-rovo-search-and-fetch-in-the-atlassian-remote-mcp-server -->

[Skip to main content](https://support.atlassian.com/atlassian-rovo-mcp-server/docs/using-rovo-search-and-fetch-in-the-atlassian-remote-mcp-server#maincontent)

# Using Rovo search and fetch in the Atlassian Rovo MCP Server

Rovo’s `search` and `fetch` features for Atlassian Rovo MCP Server help you quickly find and retrieve information from Jira and Confluence, right from your supported client. This page explains how to use these features and provides example prompts to get you started.

## What are Rovo `search` and `fetch`?

- **Rovo search:** Use natural language to look up issues, pages, and other content across Jira and Confluence. Rovo interprets your intent and finds relevant results without requiring special syntax.

- **Rovo fetch:** Retrieve specific details or content from Jira or Confluence, such as the description of an issue or the contents of a Confluence page, using a simple prompt.


## How to use Rovo `search` and `fetch`

You can invoke Rovo Search and Fetch by entering commands or prompts in your supported client (such as Claude, Cursor, or other chat interface).

**To**`search` **:**

- Enter a natural language prompt describing what you want to find.


**To**`fetch` **:**

- Ask for specific details or content from an issue or page, providing enough information for Rovo to identify the item (such as the issue key or page title).


**Tip:** For best results, make your prompts as specific as possible. If you don’t get the expected result, try rephrasing your prompt or including more details.

### Example prompts

**Rovo search (natural language):**

- `Find all Jira issues assigned to me that are due this week.`

- `Show Confluence pages about quarterly planning.`

- `Search for Jira tickets with the label "customer-feedback".`

- `Are there any issues related to the mobile application’s bugs?`


**Rovo fetch (natural language):**

- `Fetch the description of Jira work item MCP-123.`

- `Get the contents of the Confluence page "MCP Release Notes".`

- `Show comments on Jira work item MCP-456.`


When your prompt includes “ [JQL](https://support.atlassian.com/jira-software-cloud/docs/what-is-advanced-search-in-jira-cloud/ "https://support.atlassian.com/jira-software-cloud/docs/what-is-advanced-search-in-jira-cloud/")” or “ [CQL](https://confluence.atlassian.com/conf100/_cql-1627456241.html "https://confluence.atlassian.com/conf100/_cql-1627456241.html"),” the system may use the advanced search tools instead of Rovo search.

## Tips and troubleshooting

- Make your prompts as specific as possible for the best results.

- If you don’t get the expected result, try rephrasing your prompt or including more details (such as project name or issue key).


* * *

## Disclaimer

MCP clients can perform actions in Jira, Confluence, and Compass with your existing permissions. Use least privilege, review high‑impact changes before confirming, and monitor audit logs for unusual activity.

Learn more: [MCP Clients - Understanding the potential security risks](https://www.atlassian.com/blog/artificial-intelligence/mcp-risk-awareness "https://www.atlassian.com/blog/artificial-intelligence/mcp-risk-awareness")

* * *

Need help? [Contact Atlassian Support](http://support.atlassian.com/ "http://support.atlassian.com/") or visit the [getting started guide](https://support.atlassian.com/rovo/docs/getting-started-with-the-atlassian-remote-mcp-server/ "https://support.atlassian.com/rovo/docs/getting-started-with-the-atlassian-remote-mcp-server/").

Was this helpful?

Yes

No

It wasn't accurateIt wasn't clearIt wasn't relevant

Provide feedback about this article

## Still need help?

The Atlassian Community is here for you.

[Ask the Community](https://community.atlassian.com/t5/custom/page/page-id/create-post-step-1?add-tags=atlassian-rovo-mcp-server,Cloud)