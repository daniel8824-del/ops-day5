<!-- source: https://docs.gitlab.com/user/project/merge_requests/reviews -->

/

* * *

# Merge request reviews

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

The merge request review process ensures that subject matter experts review your proposed changes
before they are merged. Reviewers add review comments to merge requests, and [suggest changes](https://docs.gitlab.com/user/project/merge_requests/reviews/suggestions/)
the author can apply directly from the GitLab UI.

Reviewers can use any of these tools to review a merge request:

- The GitLab interface.
- Visual Studio Code, with the
[GitLab for VS Code extension](https://docs.gitlab.com/editor_extensions/visual_studio_code/).
- A terminal window, with the [GitLab CLI](https://docs.gitlab.com/editor_extensions/gitlab_cli/).

Approvals are one of several merge checks that ensure your merge request merges only when it’s truly
ready. Depending on your project configuration, reviewers can also block a merge request
from merging by setting **Request changes**.

GitLab Premium and Ultimate provide an **Assign reviewers** drawer with more information to help you
find reviewers [who fulfill approval rules](https://docs.gitlab.com/user/project/merge_requests/reviews/#find-reviewers-who-fulfill-approval-rules):

![This merge request requires four approvals, and three of the approval requirements are not met.](https://docs.gitlab.com/user/project/merge_requests/reviews/img/reviewer_drawer_v18_2.png)

By following the [defined review flow](https://docs.gitlab.com/user/project/merge_requests/reviews/#start-a-review), each reviewer decides whether to accept or reject a merge request.
The right sidebar shows the list of reviewers, and (if they follow the review flow) their review status:

![Examples of reviewers in various states of review.](https://docs.gitlab.com/user/project/merge_requests/reviews/img/reviewer_list_v18_2.png)

- dash-circleReview not yet started.
- status\_runningReview is in progress.
- check-circleReviewed and approved.
- comment-linesReviewed, requested changes, and
[blocked this merge request](https://docs.gitlab.com/user/project/merge_requests/reviews/#prevent-merge-when-you-request-changes) until changes are made.
This block [can be bypassed](https://docs.gitlab.com/user/project/merge_requests/reviews/#prevent-merge-when-you-request-changes).

For an overview, see the [merge request review](https://www.youtube.com/watch?v=2MayfXKpU08&list=PLFGfElNsQthYDx0A_FaNNfUm9NHsK6zED&index=183) video.

## Find merge requests to review [Permalink](https://docs.gitlab.com/user/project/merge_requests/reviews/\#find-merge-requests-to-review "Permalink")

Your [merge request homepage](https://docs.gitlab.com/user/project/merge_requests/homepage/) shows your merge requests in progress, and merge requests
awaiting review from you. The merge requests you need to review are in the **Review requested** category.
To see all merge requests that need your attention, use one of these methods:

- Press the `Shift` + `m` [keyboard shortcut](https://docs.gitlab.com/user/shortcuts/).
- In the left sidebar, select **Merge requests** (merge-request).
- In the top bar, select **Search or go to**, then, from the dropdown list, select **Merge requests I’m working on**.

## View the review status of a merge request [Permalink](https://docs.gitlab.com/user/project/merge_requests/reviews/\#view-the-review-status-of-a-merge-request "Permalink")

To do this:

1. In the top bar, select **Search or go to** and find your project.

2. In the left sidebar, select **Code** \> **Merge requests** and find your merge request.

3. Select the title of the merge request to view it.

4. Scroll to the [merge request widget](https://docs.gitlab.com/user/project/merge_requests/widgets/) to see the mergeability and
approval status for the merge request. For example, the lack of required approvals blocks this merge request:

![The merge request widget displays ‘All required approvals must be given’.](https://docs.gitlab.com/user/project/merge_requests/reviews/img/reviews_missing_v17_3.png)


## Request a review [Permalink](https://docs.gitlab.com/user/project/merge_requests/reviews/\#request-a-review "Permalink")

History

- **Assign reviewers** drawer [introduced](https://gitlab.com/groups/gitlab-org/-/epics/12878) in GitLab 17.5 [with a flag](https://docs.gitlab.com/administration/feature_flags/) named `reviewer_assign_drawer`.
- Drawer [enabled](https://gitlab.com/gitlab-org/gitlab/-/issues/467205) on GitLab.com and GitLab Self-Managed in GitLab 17.5.
- [Feature flag](https://gitlab.com/gitlab-org/gitlab/-/issues/467205)`reviewer_assign_drawer` removed in GitLab 17.8.

When you’ve finished preparing your changes, it’s time to request a review. To assign a reviewer to
your merge request, either use the
[`/assign_reviewer` quick action](https://docs.gitlab.com/user/project/quick_actions/#assign_reviewer) in any text field, or:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Code** \> **Merge requests** and find your merge request.
3. Select the title of the merge request to view it.
4. To find a reviewer by name: in the right sidebar, in the **Reviewers** section, select **Edit**.
5. To find a reviewer who fulfills an approval rule in GitLab Premium and Ultimate:
1. In the right sidebar, in the **Reviewers** section, select **Assign** to open the **Assign reviewers** drawer.
2. For each approval rule, select **Edit** to find a reviewer who fulfills that approval rule.

GitLab adds the merge request to the user’s review requests.

### Find reviewers who fulfill approval rules [Permalink](https://docs.gitlab.com/user/project/merge_requests/reviews/\#find-reviewers-who-fulfill-approval-rules "Permalink")

- Tier: Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

GitLab Premium and Ultimate help you more quickly find the best reviewers for your merge request.
Use the **Assign reviewers** drawer to filter lists of reviewers. See the Code Owners for the files
changed in your merge request, and the users who satisfy your project’s approval rules.

In this example, the merge request requires 3 Code Owner approvals, but has none so far:

![The Assign Reviewers drawer for a merge request that requires 3 Code Owner approvals, but has none. It shows one line per Code Owner rule, and one line per approval rule. Select reviewers for each rule.](https://docs.gitlab.com/user/project/merge_requests/reviews/img/select_good_reviewers_v17_5.png)

To assign eligible approvers in a merge request:

1. In the **Reviewers** section, select **Assign**.
2. To see optional approval rules or Code Owners, select **Optional approval rules** (chevron-lg-up) to show them.
3. Next to the reviewer type you need, select **Edit**:
   - **Code Owners** shows only the Code Owners for that file type.
   - **Approval rules** shows only users who fulfill that approval rule.
4. Select your desired reviewer. (GitLab Premium and Ultimate enable you to select more than one reviewer.)
5. Repeat for each required **Code Owner** and **Approval rule** item.
6. When you’ve selected your reviewers, in the upper right, select **Close** (close)
to hide the **Assign reviewers** drawer.

### Re-request a review [Permalink](https://docs.gitlab.com/user/project/merge_requests/reviews/\#re-request-a-review "Permalink")

After a reviewer completes their [merge request reviews](https://docs.gitlab.com/user/discussions/),
the author of the merge request can request a new review from the reviewer.
To do this, either use the `/request_review @user` quick action in any text field on the merge request, or:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Code** \> **Merge requests** and find your merge request.
3. Select the title of the merge request to view it.
4. If you have collapsed the right sidebar in the merge request, select the
chevron-double-lg-left**Expand Sidebar** to expand it.
5. In the **Reviewers** section, select the **Re-request a review** icon (redo)
next to the reviewer’s name.

GitLab creates a new [to-do item](https://docs.gitlab.com/user/todos/) for the reviewer, and sends
them a notification email.

## Start a review [Permalink](https://docs.gitlab.com/user/project/merge_requests/reviews/\#start-a-review "Permalink")

History

- **Assign reviewers** drawer [introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/185795) in GitLab 17.11 [with a flag](https://docs.gitlab.com/administration/feature_flags/) named `improved_review_experience`. Disabled by default.
- **Assign reviewers** drawer [enabled by default](https://gitlab.com/gitlab-org/gitlab/-/issues/535461) in GitLab 18.1.

When reviewing a merge request, follow the review process instead of leaving individual
comments. When you select **Start a review**, the **Reviewers** section of the right sidebar updates
your status from **Awaiting review** (dash-circle) to
**Reviewer started review** (comment-dots)

To start your review of a merge request:

1. Either:

   - Press `Shift` + `r` to go to your **Merge requests** page.
   - In the upper-right corner, select **Merge requests** (merge-request).
2. Find your merge request, and select the title of the merge request to view it.

3. Read the merge request description and comments to learn about the merge request.

4. Select **Changes** to view the diff of the proposed changes. To learn more about
the **Changes** page, see [changes in merge requests](https://docs.gitlab.com/user/project/merge_requests/changes/).

5. [Suggest multi-line or single-line changes](https://docs.gitlab.com/user/project/merge_requests/reviews/suggestions/) as needed. When ready to save your
first review comment, select **Start a review** to:


   - Update your status in the right sidebar to **Reviewer started review** (comment-dots).

   - Save your review comment, but leave it unpublished, like this:

     ![An unpublished multi-line review comment shown as ‘Pending’.](https://docs.gitlab.com/user/project/merge_requests/reviews/img/pending_state_v18_1.png)


If you select **Add comment now** instead of **Start a review**, GitLab publishes your comment immediately.

6. Continue writing review comments on the **Changes** tab or the **Overview** tab.
Selecting **Add to review** keeps them unpublished until you submit your review:

![New thread](https://docs.gitlab.com/user/project/merge_requests/reviews/img/mr_review_new_comment_v16_6.png)


Next, submit your review.

### Resolve or reopen thread with a comment [Permalink](https://docs.gitlab.com/user/project/merge_requests/reviews/\#resolve-or-reopen-thread-with-a-comment "Permalink")

Comments can also resolve or reopen comment threads.
To resolve or reopen a thread when replying to a comment:

1. In the comment text area, write your comment.
2. Select or clear **Resolve thread** or **Reopen thread**.
3. Select **Add comment now** or **Add to review**.

Pending comments display information about delayed actions.
These actions will execute when you submit a review.

## Submit a review [Permalink](https://docs.gitlab.com/user/project/merge_requests/reviews/\#submit-a-review "Permalink")

History

- Using **Approve** to submit pending review comments [introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/562579) in GitLab 18.6.

When you submit a review, GitLab:

- Publishes the comments in your review.
- Sends a single email to every notifiable user of the merge request, with your
review comments attached. Replying to this email creates a new comment on the merge request.
- Performs any quick actions you added to your review comments.
- Shows the outcome of your review.

To submit your review of a merge request quickly:

- Go to the merge request widget and select **Approve**. The merge request is also approved by you.
- Use the [`/submit_review` quick action](https://docs.gitlab.com/user/project/quick_actions/#submit_review) in the text of a non-review comment.

To read through and edit your review comments when you submit your review:

1. On the top right, select **Your review** to show details about your review:

![The review drawer, showing a review in progress. It contains a single-line review comment, and a comment spanning two lines of code.](https://docs.gitlab.com/user/project/merge_requests/reviews/img/review_drawer_v18_3.png)

2. Review your pending comments. Edit them as needed.

3. Select the outcome of your review.

   - **Approve**: Leave feedback and approve the changes.
   - **Comment**: Leave general feedback without an explicit approval or change request.
   - **Request changes**: Block the merge request from merging until the author
     addresses your feedback.
4. Optional. Write a summary of your review. GitLab Premium and Ultimate users can select
**Add summary** (tanuki-ai) to create a summary for you. Include any
quick actions you want performed.


### Discard your pending review [Permalink](https://docs.gitlab.com/user/project/merge_requests/reviews/\#discard-your-pending-review "Permalink")

When you discard a review, your unpublished comments are deleted and you cannot restore them.
To do this:

1. In the upper right, select **Your review** to show details about your review:

![The review drawer, showing a review in progress. It contains a single-line review comment, and a comment spanning two lines of code.](https://docs.gitlab.com/user/project/merge_requests/reviews/img/review_drawer_v18_3.png)

2. Select **Discard review**.


### Prevent merge when you request changes [Permalink](https://docs.gitlab.com/user/project/merge_requests/reviews/\#prevent-merge-when-you-request-changes "Permalink")

- Tier: Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/430728) in GitLab 16.11 [with a flag](https://docs.gitlab.com/administration/feature_flags/) named `mr_reviewer_requests_changes`. Disabled by default.
- Enabled by default [on GitLab.com](https://gitlab.com/gitlab-org/gitlab/-/issues/451211) and [GitLab Self-Managed](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/158226) in GitLab 17.2.
- [Feature flag removed](https://gitlab.com/gitlab-org/gitlab/-/issues/451211) in GitLab 17.3.

A reviewer [requesting changes](https://docs.gitlab.com/user/project/merge_requests/reviews/#submit-a-review) blocks a merge request from merging.
When this happens, the merge request reports area shows the message
**Change requests must be approved by the requesting user**. To unblock the merge request,
the reviewer who requested changes should [re-review and approve](https://docs.gitlab.com/user/project/merge_requests/reviews/#re-request-a-review) the merge request.

### Remove a change request [Permalink](https://docs.gitlab.com/user/project/merge_requests/reviews/\#remove-a-change-request "Permalink")

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/480412) in GitLab 17.8.

If you previously requested changes, you can remove your change request. You might need to do this
if both of the following are true:

- You can no longer approve the merge request.
- You want to cancel your change request, but don’t want to submit a new review.

To remove your change request without submitting a new review:

1. In the top bar, select **Search or go to** and find your project.

2. In the left sidebar, select **Code** \> **Merge requests** and find your merge request.

3. Select the title of the merge request to view it.

4. On the merge request **Overview**, scroll to the merge request reports area.

5. Next to **Change requests must be approved by the requesting user**, select **Remove**:

![A merge request that is blocked because a user requested changes](https://docs.gitlab.com/user/project/merge_requests/reviews/img/remove_v17_8.png)


### Bypass a request for changes [Permalink](https://docs.gitlab.com/user/project/merge_requests/reviews/\#bypass-a-request-for-changes "Permalink")

If the user who requested changes is unavailable to re-review or approve,
another user with permission to merge the merge request can override this check:

1. In the top bar, select **Search or go to** and find your project.

2. In the left sidebar, select **Code** \> **Merge requests** and find your merge request.

3. Select the title of the merge request to view it.

4. On the merge request **Overview**, scroll to the merge request reports area.

5. Next to **Change requests must be approved by the requesting user**, select **Bypass**:

![A merge request that is blocked because a user requested changes](https://docs.gitlab.com/user/project/merge_requests/reviews/img/bypass_v17_2.png)

6. The merge reports area shows `Merge with caution: Override added`. To see which check a user
bypassed, select **Expand merge checks** (chevron-lg-down) and find the
check that contains a warning (status\_warning) icon. In this example, the
author bypassed **Change requests must be approved by the requesting user**:

![This merge request contains a bypassed check, and should be merged with caution.](https://docs.gitlab.com/user/project/merge_requests/reviews/img/status_warning_v17_4.png)


## Download merge request changes [Permalink](https://docs.gitlab.com/user/project/merge_requests/reviews/\#download-merge-request-changes "Permalink")

You can [download the changes from a merge request](https://docs.gitlab.com/user/project/merge_requests/changes/#download-merge-request-changes)
as a diff or patch file.

## Associated features [Permalink](https://docs.gitlab.com/user/project/merge_requests/reviews/\#associated-features "Permalink")

Merge requests are related to these features:

- [Cherry-pick changes](https://docs.gitlab.com/user/project/merge_requests/cherry_pick_changes/):
In the GitLab UI, select **Cherry-pick** in a merged merge request or a commit to cherry-pick it.
- [Compare changes](https://docs.gitlab.com/user/project/merge_requests/changes/):
View and download the diff of changes included in a merge request.
- [Fast-forward merge requests](https://docs.gitlab.com/user/project/merge_requests/methods/#fast-forward-merge):
For a linear Git history and a way to accept merge requests without creating merge commits
- [Find the merge request that introduced a change](https://docs.gitlab.com/user/project/merge_requests/versions/):
When viewing the commit details page, GitLab links to the merge requests containing that commit.
- [Merge requests versions](https://docs.gitlab.com/user/project/merge_requests/versions/):
Select and compare the different versions of merge request diffs
- [Resolve conflicts](https://docs.gitlab.com/user/project/merge_requests/conflicts/):
GitLab can provide the option to resolve certain merge request conflicts in the GitLab UI.
- [Revert changes](https://docs.gitlab.com/user/project/merge_requests/revert_changes/):
Revert changes from any commit from a merge request.
- [Keyboard shortcuts](https://docs.gitlab.com/user/shortcuts/#merge-requests):
Access and change specific parts of a merge request with keyboard commands.
- [Value stream analytics](https://docs.gitlab.com/user/group/value_stream_analytics/): Track key merge request steps (such as `reviewed` and `approved`) to identify where your team spends the most time in the software development lifecycle. This information helps uncover actionable insights to optimize merge request workflows for groups and projects, and improve developer productivity. Read more about [how we reduced MR review time with value stream analytics](https://about.gitlab.com/blog/how-we-reduced-mr-review-time-with-value-stream-management/) in the blog post.

## Related topics [Permalink](https://docs.gitlab.com/user/project/merge_requests/reviews/\#related-topics "Permalink")

- [Compare changes in merge requests](https://docs.gitlab.com/user/project/merge_requests/changes/)
- [Compare revisions](https://docs.gitlab.com/user/project/repository/compare_revisions/)
- [Merge methods](https://docs.gitlab.com/user/project/merge_requests/methods/)
- [Draft Notes API](https://docs.gitlab.com/api/draft_notes/)

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**