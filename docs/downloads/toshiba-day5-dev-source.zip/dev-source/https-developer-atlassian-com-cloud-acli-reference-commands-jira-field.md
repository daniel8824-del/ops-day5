<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/jira-field -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Filter by keyword

- [acli](https://developer.atlassian.com/cloud/acli/reference/commands/)
- [admin](https://developer.atlassian.com/cloud/acli/reference/commands/admin/)

[admin auth](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth/)

[admin user](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user/)

- [feedback](https://developer.atlassian.com/cloud/acli/reference/commands/feedback/)
- [jira](https://developer.atlassian.com/cloud/acli/reference/commands/jira/)

[jira auth](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth/)

[jira board](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board/)

[jira dashboard](https://developer.atlassian.com/cloud/acli/reference/commands/jira-dashboard/)

[jira field](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field/)

- [jira-field-cancel-delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field-cancel-delete/)
- [create](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field-create/)
- [delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field-delete/)

[jira filter](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter/)

[jira project](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project/)

[jira sprint](https://developer.atlassian.com/cloud/acli/reference/commands/jira-sprint/)

[jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem/)

- [rovodev](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev/)

[rovodev auth](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev-auth/)

Last updated Oct 3, 2024

On This Page

- [acli jira field](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field/#acli-jira-field)


## acli jira field

Jira field commands.

### Options

```
Copy
1
  -h, --help   Show help for command
```

### SEE ALSO

- [acli jira](https://developer.atlassian.com/cloud/acli/reference/commands/jira) \- Jira Cloud commands.
- [acli jira field cancel-delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field-cancel-delete) \- Restores the field from the trash.
- [acli jira field create](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field-create) \- Create a custom field in Jira.
- [acli jira field delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field-delete) \- Moves a custom field to trash.

Rate this page:

Unusable

Poor

Okay

Good

Excellent