<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-update -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Filter by keyword

- [acli](https://developer.atlassian.com/cloud/acli/reference/commands/)
- [admin](https://developer.atlassian.com/cloud/acli/reference/commands/admin/)

[admin auth](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth/)

[admin user](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user/)

- [feedback](https://developer.atlassian.com/cloud/acli/reference/commands/feedback/)
- [jira](https://developer.atlassian.com/cloud/acli/reference/commands/jira/)

[jira auth](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth/)

[jira board](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board/)

[jira dashboard](https://developer.atlassian.com/cloud/acli/reference/commands/jira-dashboard/)

[jira field](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field/)

[jira filter](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter/)

[jira project](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project/)

- [archive](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-archive/)
- [create](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-create/)
- [delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-delete/)
- [list](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-list/)
- [restore](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-restore/)
- [update](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-update/)
- [view](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-view/)

[jira sprint](https://developer.atlassian.com/cloud/acli/reference/commands/jira-sprint/)

[jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem/)

- [rovodev](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev/)

[rovodev auth](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev-auth/)

Last updated Oct 3, 2024

On This Page

- [acli jira project update](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-update/#acli-jira-project-update)


## acli jira project update

Update a Jira project.

```
Copy
1
acli jira project update [flags]
```

### Examples

```
Copy
1
2
3
4
5
6
7
8
# Update project key and name
$ acli jira project update --project-key "TEAM1" --key "TEAM" --name "New Name"

# Generate a JSON file that could be used for project update via --from-json flag
$ acli jira project update --generate-json

# Update project from a JSON file
$ acli jira project update --project-key "TEAM1" --from-json "project.json"
```

### Options

```
Copy
1
2
3
4
5
6
7
8
9
  -d, --description string   New description of the project
  -j, --from-json string     Read updated project details from a json file
  -g, --generate-json        Generates a JSON file that could be used for project update
  -h, --help                 Show help for command
  -k, --key string           New key of the project
  -l, --lead-email string    New lead account user email
  -n, --name string          New name of the project
  -p, --project-key string   Key of the project to be updated
  -u, --url string           New URL of the project
```

### SEE ALSO

- [acli jira project](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project) \- Jira project commands.

Rate this page:

Unusable

Poor

Okay

Good

Excellent