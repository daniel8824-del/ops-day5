<!-- source: https://docs.gitlab.com/user/project/merge_requests/drafts -->

/

* * *

# Draft merge requests

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

If a merge request isn’t ready to merge, you can block it from merging until you
[mark it as ready](https://docs.gitlab.com/user/project/merge_requests/drafts/#mark-merge-requests-as-ready). Merge requests marked as **Draft**
cannot merge until you remove the **Draft** flag, even if they meet all other merge criteria:

![merge blocked](https://docs.gitlab.com/user/project/merge_requests/img/merge_request_draft_blocked_v16_0.png)

## Mark merge requests as drafts [Permalink](https://docs.gitlab.com/user/project/merge_requests/drafts/\#mark-merge-requests-as-drafts "Permalink")

You can flag a merge request as a draft in several ways:

- Viewing a merge request: In the upper-right corner of the merge request,
select **Merge request actions** (ellipsis\_v), then **Mark as draft**.
- Creating or editing a merge request: You can do either of the following:
  - Add `[Draft]`, `Draft:` or `(Draft)` to the beginning of the merge request’s title.
  - Select **Mark as draft** below the **Title** field
- Commenting in an existing merge request: Add the
[`/draft` quick action](https://docs.gitlab.com/user/project/quick_actions/#draft)
in a comment. To mark a merge request as ready, use the [`/ready`](https://docs.gitlab.com/user/project/quick_actions/#ready) quick action.
- Creating a commit: Add `draft:`, `Draft:`, `fixup!`, or `Fixup!` to the
beginning of a commit message targeting the merge request’s source branch. This
method is not a toggle. Adding this text again in a later commit doesn’t mark the
merge request as ready.

## Mark merge requests as ready [Permalink](https://docs.gitlab.com/user/project/merge_requests/drafts/\#mark-merge-requests-as-ready "Permalink")

When a merge request is ready to merge, you can remove the `Draft` flag in several ways:

- Viewing a merge request: In the upper-right corner of the merge request, select **Mark as ready**.
Users with the Developer, Maintainer, or Owner role can also scroll to the bottom of the merge request
description and select **Mark as ready**.
- Editing an existing merge request: Remove `[Draft]`, `Draft:` or `(Draft)`
from the beginning of the title, or clear **Mark as draft** below the **Title** field.
- Commenting in an existing merge request: Add the [`/ready` quick action](https://docs.gitlab.com/user/project/quick_actions/#ready)
in a comment in the merge request.

When you mark a merge request as ready, GitLab notifies
[merge request participants and watchers](https://docs.gitlab.com/user/profile/notifications/#issue-merge-request-and-epic-events).

## Include or exclude drafts when searching [Permalink](https://docs.gitlab.com/user/project/merge_requests/drafts/\#include-or-exclude-drafts-when-searching "Permalink")

When you view or search in your project’s merge requests list, to include or exclude
draft merge requests:

1. In the top bar, select **Search or go to** and find your project.

2. In the left sidebar, select **Code** \> **Merge requests**.

3. To filter by merge request status, select **Open**, **Merged**, **Closed**,
or **All** in the navigation bar.

4. Select the search box to display a list of filters and select **Draft**, or
enter the word `draft`.

5. Select `=`.

6. Select **Yes** to include drafts, or **No** to exclude, and press **Return**
to update the list of merge requests:

![Filter draft merge requests](https://docs.gitlab.com/user/project/merge_requests/img/filter_draft_merge_requests_v16_0.png)


## Pipelines for drafts [Permalink](https://docs.gitlab.com/user/project/merge_requests/drafts/\#pipelines-for-drafts "Permalink")

Draft merge requests run the same pipelines as merge requests marked as ready.

To skip a pipeline for a draft merge request, see [skip pipelines for draft merge requests](https://docs.gitlab.com/ci/yaml/workflow/#skip-pipelines-for-draft-merge-requests).

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**