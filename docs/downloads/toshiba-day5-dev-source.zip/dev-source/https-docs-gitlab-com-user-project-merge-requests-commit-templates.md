<!-- source: https://docs.gitlab.com/user/project/merge_requests/commit_templates -->

/

* * *

# Commit message templates

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

GitLab uses commit templates to create default messages for specific types of
commits. These templates encourage commit messages to follow a particular format,
or contain specific information. Users can override these templates when merging
a merge request.

The commit template syntax is like the syntax for
[review suggestions](https://docs.gitlab.com/user/project/merge_requests/reviews/suggestions/#configure-the-commit-message-for-applied-suggestions).

GitLab Duo can also help you generate [merge commit messages](https://docs.gitlab.com/user/project/merge_requests/duo_in_merge_requests/#generate-a-merge-commit-message)
even if you don’t configure templates.

## Configure commit templates [Permalink](https://docs.gitlab.com/user/project/merge_requests/commit_templates/\#configure-commit-templates "Permalink")

Change the commit templates for your project if the default templates don’t
contain the information you need.

Prerequisites:

- You must have the Maintainer or Owner role for a project.

To do this:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Settings** \> **Merge requests**.
3. Depending on the template type you want to create, scroll to either
[**Merge commit message template**](https://docs.gitlab.com/user/project/merge_requests/commit_templates/#default-template-for-merge-commits) or
[**Squash commit message template**](https://docs.gitlab.com/user/project/merge_requests/commit_templates/#default-template-for-squash-commits).
4. For your desired commit type, enter your default message. You can use both static
text and [variables](https://docs.gitlab.com/user/project/merge_requests/commit_templates/#supported-variables-in-commit-templates). Each template
is limited to 500 characters, though after replacing the templates
with data, the final message might be longer.
5. Select **Save changes**.

## Default template for merge commits [Permalink](https://docs.gitlab.com/user/project/merge_requests/commit_templates/\#default-template-for-merge-commits "Permalink")

The default template for merge commit messages is:

```plaintext
Merge branch '%{source_branch}' into '%{target_branch}'

%{title}

%{issues}

See merge request %{reference}
```

## Default template for squash commits [Permalink](https://docs.gitlab.com/user/project/merge_requests/commit_templates/\#default-template-for-squash-commits "Permalink")

If you have configured your project to [squash commits on merge](https://docs.gitlab.com/user/project/merge_requests/squash_and_merge/),
GitLab creates a squash commit message with this template:

```plaintext
%{title}
```

## Supported variables in commit templates [Permalink](https://docs.gitlab.com/user/project/merge_requests/commit_templates/\#supported-variables-in-commit-templates "Permalink")

History

- `local_reference` variable [introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/199823) in GitLab 16.1.
- `source_project_id` variables [introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/128553) in GitLab 16.3.
- `merge_request_author` variable [introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/152510) in GitLab 17.1.

Commit message templates support these variables:

| Variable | Description | Output example |
| --- | --- | --- |
| `%{source_branch}` | The name of the branch to merge. | `my-feature-branch` |
| `%{target_branch}` | The name of the branch to apply the changes to. | `main` |
| `%{title}` | Title of the merge request. | `Fix tests and translations` |
| `%{issues}` | String with phrase `Closes <issue numbers>`. Contains all issues mentioned in the merge request description that match [issue closing patterns](https://docs.gitlab.com/user/project/issues/managing_issues/#closing-issues-automatically). Empty if no issues are mentioned. | `Closes #465, #190 and #400` |
| `%{description}` | Description of the merge request. | `Merge request description.`<br>`Can be multiline.` |
| `%{reference}` | Reference to the merge request. | `group-name/project-name!72359` |
| `%{local_reference}` | Local reference to the merge request. | `!72359` |
| `%{source_project_id}` | ID of the merge request’s source project. | `123` |
| `%{first_commit}` | Full message of the first commit in merge request diff. | `Update README.md` |
| `%{first_multiline_commit}` | Full message of the first commit that’s not a merge commit and has more than one line in message body. Merge request title if all commits aren’t multiline. | `Update README.md`<br>`Improved project description in readme file.` |
| `%{first_multiline_commit_description}` | Description (without the first line/title) of the first commit that’s not a merge commit and has more than one line in message body. | `Improved project description in readme file.` |
| `%{url}` | Full URL to the merge request. | `https://gitlab.com/gitlab-org/gitlab/-/merge_requests/1` |
| `%{reviewed_by}` | Line-separated list of the merge request reviewers, based on users who submit a review by using batch comments, in a `Reviewed-by` Git commit trailer format. | `Reviewed-by: Sidney Jones <sjones@example.com>`<br>`Reviewed-by: Zhang Wei <zwei@example.com>` |
| `%{approved_by}` | Line-separated list of the merge request approvers in a `Approved-by` Git commit trailer format. | `Approved-by: Sidney Jones <sjones@example.com>`<br>`Approved-by: Zhang Wei <zwei@example.com>` |
| `%{merged_by}` | User who merged the merge request. | `Alex Garcia <agarcia@example.com>` |
| `%{merge_request_author}` | Name and email of the merge request author. | `Zane Doe <zdoe@example.com>` |
| `%{co_authored_by}` | Names and emails of commit authors in a `Co-authored-by` Git commit trailer format. Limited to authors of 100 most recent commits in merge request. | `Co-authored-by: Zane Doe <zdoe@example.com>`<br>`Co-authored-by: Blake Smith <bsmith@example.com>` |
| `%{all_commits}` | Messages from all commits in the merge request. Limited to 100 most recent commits. Skips commit bodies exceeding 100 KiB and merge commit messages. | `* Feature introduced`<br>`This commit implements feature`<br>`Changelog:added`<br>`* Bug fixed`<br>`* Documentation improved`<br>`This commit introduced better docs.` |

Any line containing only an empty variable is removed. If the removed line is both
preceded and followed by an empty line, the preceding empty line is also removed.

After you edit a commit message on an open merge request, GitLab
automatically updates the commit message again.
To restore the commit message to the project template, reload the page.

## Related topics [Permalink](https://docs.gitlab.com/user/project/merge_requests/commit_templates/\#related-topics "Permalink")

- [Merge request title templates](https://docs.gitlab.com/user/project/merge_requests/title_templates/)
- [Squash and merge](https://docs.gitlab.com/user/project/merge_requests/squash_and_merge/)

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**

| Variable | Description | Output example |
| --- | --- | --- |