<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-link-list -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Last updated Oct 3, 2024

On This Page

- [acli jira workitem link list](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-link-list/#acli-jira-workitem-link-list)


## acli jira workitem link list

List all the links of a workitem.

```
Copy
1
acli jira workitem link list [flags]
```

### Examples

```
Copy
1
2
3
# List work item links
$ acli jira workitem link list --key TEST-123
```

### Options

```
Copy
1
2
3
  -h, --help         Show help for command
      --json         Output in JSON format
      --key string   Workitem key to list the links for
```

### SEE ALSO

- [acli jira workitem link](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-link) \- Link work items commands.

Rate this page:

Unusable

Poor

Okay

Good

Excellent