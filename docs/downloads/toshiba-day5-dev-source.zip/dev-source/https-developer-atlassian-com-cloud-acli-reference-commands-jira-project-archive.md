<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-archive -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Filter by keyword

- [acli](https://developer.atlassian.com/cloud/acli/reference/commands/)
- [admin](https://developer.atlassian.com/cloud/acli/reference/commands/admin/)

[admin auth](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth/)

[admin user](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user/)

- [feedback](https://developer.atlassian.com/cloud/acli/reference/commands/feedback/)
- [jira](https://developer.atlassian.com/cloud/acli/reference/commands/jira/)

[jira auth](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth/)

[jira board](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board/)

[jira dashboard](https://developer.atlassian.com/cloud/acli/reference/commands/jira-dashboard/)

[jira field](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field/)

[jira filter](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter/)

[jira project](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project/)

- [archive](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-archive/)
- [create](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-create/)
- [delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-delete/)
- [list](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-list/)
- [restore](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-restore/)
- [update](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-update/)
- [view](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-view/)

[jira sprint](https://developer.atlassian.com/cloud/acli/reference/commands/jira-sprint/)

[jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem/)

- [rovodev](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev/)

[rovodev auth](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev-auth/)

Last updated Oct 3, 2024

On This Page

- [acli jira project archive](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-archive/#acli-jira-project-archive)


## acli jira project archive

Archives a Jira project.

```
Copy
1
acli jira project archive [flags]
```

### Examples

```
Copy
1
$ acli jira project archive --key "TEAM"
```

### Options

```
Copy
1
2
  -h, --help         Show help for command
      --key string   Key of the project to be archived
```

### SEE ALSO

- [acli jira project](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project) \- Jira project commands.

Rate this page:

Unusable

Poor

Okay

Good

Excellent