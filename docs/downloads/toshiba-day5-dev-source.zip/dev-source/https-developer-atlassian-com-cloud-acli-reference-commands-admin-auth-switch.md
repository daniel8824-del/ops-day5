<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth-switch -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Filter by keyword

- [acli](https://developer.atlassian.com/cloud/acli/reference/commands/)
- [admin](https://developer.atlassian.com/cloud/acli/reference/commands/admin/)

[admin auth](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth/)

- [login](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth-login/)
- [logout](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth-logout/)
- [status](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth-status/)
- [switch](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth-switch/)

[admin user](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user/)

- [feedback](https://developer.atlassian.com/cloud/acli/reference/commands/feedback/)
- [jira](https://developer.atlassian.com/cloud/acli/reference/commands/jira/)

[jira auth](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth/)

[jira board](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board/)

[jira dashboard](https://developer.atlassian.com/cloud/acli/reference/commands/jira-dashboard/)

[jira field](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field/)

[jira filter](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter/)

[jira project](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project/)

[jira sprint](https://developer.atlassian.com/cloud/acli/reference/commands/jira-sprint/)

[jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem/)

- [rovodev](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev/)

[rovodev auth](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev-auth/)

Last updated Oct 3, 2024

On This Page

- [acli admin auth switch](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth-switch/#acli-admin-auth-switch)


## acli admin auth switch

Switch between Atlassian organization admin accounts.

```
Copy
1
acli admin auth switch [flags]
```

### Examples

```
Copy
1
$ acli admin auth switch --org myorgname
```

### Options

```
Copy
1
2
  -h, --help         Show help for command
  -o, --org string   Org of the admin account from which to switch
```

### SEE ALSO

- [acli admin auth](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth) \- Authenticate to use Atlassian CLI for organization admin tasks.

Rate this page:

Unusable

Poor

Okay

Good

Excellent