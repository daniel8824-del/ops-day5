<!-- source: https://docs.gitlab.com/ci/testing/code_coverage -->

/

* * *

# Code coverage

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

Configure code coverage to track and visualize how much of your source code is covered by tests. You can:

- Track overall coverage metrics and trends using the `coverage` keyword.
- Visualize line-by-line coverage using the `artifacts:reports:coverage_report` keyword.

## Configure coverage reporting [Permalink](https://docs.gitlab.com/ci/testing/code_coverage/\#configure-coverage-reporting "Permalink")

Use the [`coverage`](https://docs.gitlab.com/ci/yaml/#coverage) keyword to monitor your test coverage and enforce coverage requirements in merge requests.

With coverage reporting, you can:

- Display the overall coverage percentage in merge requests.
- Aggregate coverage from multiple test jobs.
- Add coverage check approval rules.
- Track coverage trends over time.

To configure coverage reporting:

1. Add the `coverage` keyword to your pipeline configuration:





yaml







```yaml
test-unit:
     script:
    - coverage run unit/
coverage: '/TOTAL.+ ([0-9]{1,3}%)/'

test-integration:
script:
    - coverage run integration/
coverage: '/TOTAL.+ ([0-9]{1,3}%)/'
```

2. Configure the regular expression (regex) to match your test output format.
See [coverage regex patterns](https://docs.gitlab.com/ci/testing/code_coverage/#coverage-regex-patterns) for common patterns.

3. To aggregate coverage from multiple jobs, add the `coverage` keyword to each job you want to include.

4. Optional. [Add a coverage check approval rule](https://docs.gitlab.com/ci/testing/code_coverage/#add-a-coverage-check-approval-rule).


### Coverage regex patterns [Permalink](https://docs.gitlab.com/ci/testing/code_coverage/\#coverage-regex-patterns "Permalink")

The following sample regex patterns were designed to parse coverage output from common test coverage tools.

Test the regex patterns carefully. Tool output formats can change over time, and these patterns might no longer work as expected.

- [Python and Ruby](https://docs.gitlab.com/ci/testing/code_coverage/#)
- [C/C++ and Rust](https://docs.gitlab.com/ci/testing/code_coverage/#)
- [Java and JVM](https://docs.gitlab.com/ci/testing/code_coverage/#)
- [Node.js](https://docs.gitlab.com/ci/testing/code_coverage/#)
- [PHP](https://docs.gitlab.com/ci/testing/code_coverage/#)
- [Go](https://docs.gitlab.com/ci/testing/code_coverage/#)
- [.NET and PowerShell](https://docs.gitlab.com/ci/testing/code_coverage/#)
- [Elixir](https://docs.gitlab.com/ci/testing/code_coverage/#)

| Tool | Language | Command | Regex pattern |
| --- | --- | --- | --- |
| pytest-cov | Python | `pytest --cov` | `/TOTAL.*? (100(?:\.0+)?\%|[1-9]?\d(?:\.\d+)?\%)$/` |
| Simplecov-html | Ruby | `rspec spec` | `/Line\sCoverage:\s\d+\.\d+%/` |

| Tool | Language | Command | Regex pattern |
| --- | --- | --- | --- |
| gcovr | C/C++ | `gcovr` | `/^TOTAL.*\s+(\d+\%)$/` |
| tarpaulin | Rust | `cargo tarpaulin` | `/^\d+.\d+% coverage/` |

| Tool | Language | Command | Regex pattern |
| --- | --- | --- | --- |
| JaCoCo | Java/Kotlin | `./gradlew test jacocoTestReport` | `/Total.*?([0-9]{1,3})%/` |
| Scoverage | Scala | `sbt coverage test coverageReport` | `/(?i)total.*? (100(?:\.0+)?\%|[1-9]?\d(?:\.\d+)?\%)$/` |

| Tool | Command | Regex pattern |
| --- | --- | --- |
| tap | `tap --coverage-report=text-summary` | `/^Statements\s*:\s*([^%]+)/` |
| nyc | `nyc npm test` | `/All files[^|]*\|[^|]*\s+([\d\.]+)/` |
| jest | `jest --ci --coverage` | `/All files[^|]*\|[^|]*\s+([\d\.]+)/` |
| node:test | `node --experimental-test-coverage --test` | `/all files[^|]*\|[^|]*\s+([\d\.]+)/` |

| Tool | Command | Regex pattern |
| --- | --- | --- |
| pest | `pest --coverage --colors=never` | `/Statement coverage[A-Za-z\.*]\s*:\s*([^%]+)/` |
| phpunit | `phpunit --coverage-text --colors=never` | `/^\s*Lines:\s*\d+.\d+\%/` |

| Tool | Command | Regex pattern |
| --- | --- | --- |
| go test (single) | `go test -cover` | `/coverage: \d+.\d+% of statements/` |
| go test (project) | `go test -coverprofile=cover.profile && go tool cover -func cover.profile` | `/total:\s+\(statements\)\s+\d+.\d+%/` |

| Tool | Language | Command | Regex pattern |
| --- | --- | --- | --- |
| OpenCover | .NET | None | `/(Visited Points).*\((.*)\)/` |
| dotnet test ( [MSBuild](https://github.com/coverlet-coverage/coverlet/blob/master/Documentation/MSBuildIntegration.md)) | .NET | `dotnet test` | `/Total\s*\|*\s(\d+(?:\.\d+)?)/` |
| Pester | PowerShell | None | `/Covered (\d{1,3}(\.|,)?\d{0,2}%)/` |

| Tool | Command | Regex pattern |
| --- | --- | --- |
| excoveralls | None | `/\[TOTAL\]\s+(\d+\.\d+)%/` |
| mix | `mix test --cover` | `/\d+.\d+\%\s+|\s+Total/` |

## Coverage visualization [Permalink](https://docs.gitlab.com/ci/testing/code_coverage/\#coverage-visualization "Permalink")

Use the [`artifacts:reports:coverage_report`](https://docs.gitlab.com/ci/yaml/artifacts_reports/#artifactsreportscoverage_report)
keyword to view which specific lines of code are covered by tests in merge requests.

You can generate coverage reports in these formats:

- Cobertura: For multiple languages including Java, JavaScript, Python, and Ruby.
- JaCoCo: For Java projects only.

Coverage visualization uses [artifacts reports](https://docs.gitlab.com/ci/yaml/#artifactsreports) to:

1. Collect one or more coverage reports, including from wildcard paths.
2. Combine the coverage information from all reports.
3. Display the combined results in merge request diffs.

Coverage files are parsed in a background job, so there might be a delay between
pipeline completion and the visualization appearing in the merge request.

By default, coverage visualization data expires one week after creation.

### Configure coverage visualization [Permalink](https://docs.gitlab.com/ci/testing/code_coverage/\#configure-coverage-visualization "Permalink")

To configure coverage visualization:

1. Configure your test tool to generate a coverage report.

2. Add the `artifacts:reports:coverage_report` configuration to your pipeline:





yaml







```yaml
test:
     script:
    - run tests with coverage
artifacts:
    reports:
      coverage_report:
        coverage_format: cobertura  # or jacoco
        path: coverage/coverage.xml
```

For language-specific configuration details see:

- [Cobertura coverage report](https://docs.gitlab.com/ci/testing/code_coverage/cobertura/)
- [JaCoCo coverage report](https://docs.gitlab.com/ci/testing/code_coverage/jacoco/)

### Coverage reports for child pipelines [Permalink](https://docs.gitlab.com/ci/testing/code_coverage/\#coverage-reports-for-child-pipelines "Permalink")

Coverage reports for child pipelines appear in merge request diff annotations.
However, parent pipelines cannot access these coverage reports for use in their own jobs.

Support for parent pipelines to fetch coverage reports for child pipelines is proposed in
[issue 285100](https://gitlab.com/gitlab-org/gitlab/-/issues/285100).

## Add a coverage check approval rule [Permalink](https://docs.gitlab.com/ci/testing/code_coverage/\#add-a-coverage-check-approval-rule "Permalink")

- Tier: Premium, Ultimate

You can require specific users or a group to approve merge requests that reduce the project’s test coverage.

Prerequisites:

- [Configure coverage reporting](https://docs.gitlab.com/ci/testing/code_coverage/#configure-coverage-reporting).

To add a `Coverage-Check` approval rule:

1. Go to your project and select **Settings** \> **Merge requests**.
2. Under **Merge request approvals**, do one of the following:
   - Next to the `Coverage-Check` approval rule, select **Enable**.
   - For manual setup, select **Add approval rule**, then enter `Coverage-Check` as the **Rule name**.
3. Select a **Target branch**.
4. Set the number of **Required number of approvals**.
5. Select the **Users** or **Groups** to provide approval.
6. Select **Save changes**.

The `Coverage-Check` approval rule requires approval when the merge base pipeline contains no coverage data, even if the merge request improves overall coverage.

## View coverage results [Permalink](https://docs.gitlab.com/ci/testing/code_coverage/\#view-coverage-results "Permalink")

After a pipeline runs successfully, you can view code coverage results in:

- Merge request widget: See the coverage percentage and changes compared to the target branch.

![Merge request widget showing code coverage percentage](https://docs.gitlab.com/ci/testing/code_coverage/img/pipelines_test_coverage_mr_widget_v17_3.png)

- Merge request diff: Review which lines are covered by tests. Available with Cobertura and JaCoCo reports.

- Pipeline jobs: Monitor coverage results for individual jobs.


## View coverage history [Permalink](https://docs.gitlab.com/ci/testing/code_coverage/\#view-coverage-history "Permalink")

You can track the evolution of code coverage for your project or group over time.

### For a project [Permalink](https://docs.gitlab.com/ci/testing/code_coverage/\#for-a-project "Permalink")

To view the code coverage history for a project:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Analyze** \> **Repository analytics**.
3. From the dropdown list, select the job you want to view historical data for.
4. Optional. To view a CSV file of the data, select **Download raw data (.csv)**.

### For a group [Permalink](https://docs.gitlab.com/ci/testing/code_coverage/\#for-a-group "Permalink")

- Tier: Premium, Ultimate

To view the code coverage history for all projects in a group:

1. In the top bar, select **Search or go to** and find your group.
2. In the left sidebar, select **Analyze** \> **Repository analytics**.
3. Optional. To view a CSV file of the data, select **Download historic test coverage data (.csv)**.

## Display coverage badges [Permalink](https://docs.gitlab.com/ci/testing/code_coverage/\#display-coverage-badges "Permalink")

Share your project’s code coverage status using pipeline badges.

To add a coverage badge to your project, see [test coverage report badges](https://docs.gitlab.com/user/project/badges/#test-coverage-report-badges).

## Troubleshooting [Permalink](https://docs.gitlab.com/ci/testing/code_coverage/\#troubleshooting "Permalink")

### Remove color codes from code coverage [Permalink](https://docs.gitlab.com/ci/testing/code_coverage/\#remove-color-codes-from-code-coverage "Permalink")

Some test coverage tools output with ANSI color codes that aren’t
parsed correctly by the regular expression. This causes coverage
parsing to fail.

Some coverage tools do not provide an option to disable color
codes in the output. If so, pipe the output of the coverage tool through a one-line script that strips the color codes.

For example:

shell

```shell
lein cloverage | perl -pe 's/\e\[?.*?[\@-~]//g'\
```\
\
Was this page helpful?YesNo\
\
reCAPTCHA\
\
Recaptcha requires verification.\
\
protected by **reCAPTCHA**\
\
| Tool | Language | Command | Regex pattern |\
| --- | --- | --- | --- |\
\
| Tool | Language | Command | Regex pattern |\
| --- | --- | --- | --- |\
\
| Tool | Language | Command | Regex pattern |\
| --- | --- | --- | --- |\
\
| Tool | Command | Regex pattern |\
| --- | --- | --- |\
\
| Tool | Command | Regex pattern |\
| --- | --- | --- |\
\
| Tool | Command | Regex pattern |\
| --- | --- | --- |\
\
| Tool | Language | Command | Regex pattern |\
| --- | --- | --- | --- |\
\
| Tool | Command | Regex pattern |\
| --- | --- | --- |