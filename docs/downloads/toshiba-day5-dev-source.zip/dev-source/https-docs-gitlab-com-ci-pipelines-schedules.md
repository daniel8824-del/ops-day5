<!-- source: https://docs.gitlab.com/ci/pipelines/schedules -->

/

* * *

# Scheduled pipelines

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

Create pipeline schedules to run pipelines at regular intervals based on cron patterns.
Use pipeline schedules for tasks that need to run on a time-based schedule rather than triggered by code changes.

Unlike pipelines triggered by commits or merge requests, scheduled pipelines run independently of code changes.
This makes them suitable for tasks that need to happen regardless of development activity,
such as keeping deployments current or running periodic maintenance.

Scheduled pipelines stop running when a project or group is marked for deletion.

## Create a pipeline schedule [Permalink](https://docs.gitlab.com/ci/pipelines/schedules/\#create-a-pipeline-schedule "Permalink")

History

- Inputs option [introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/525504) in GitLab 17.11.

When you create a pipeline schedule, you become the schedule owner.
The pipeline runs with your permissions and can access [protected environments](https://docs.gitlab.com/ci/environments/protected_environments/)
and use the [CI/CD job token](https://docs.gitlab.com/ci/jobs/ci_job_token/) based on your access level.

Prerequisites:

- You must have the Developer, Maintainer, or Owner role for the project.
- Your primary email address must be verified.
- For schedules that target [protected branches](https://docs.gitlab.com/user/project/repository/branches/protected/#protect-a-branch),
you must have merge permissions for the target branch.
- Your `.gitlab-ci.yml` file must have valid syntax. You can [validate your configuration](https://docs.gitlab.com/ci/yaml/lint/) before scheduling.

To create a pipeline schedule:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Build** \> **Pipeline schedules**.
3. Select **New schedule**.
4. Complete the fields.
   - **Interval Pattern**: Select one of the preconfigured intervals, or enter a custom
     interval in [cron notation](https://docs.gitlab.com/topics/cron/). You can use any cron value,
     but scheduled pipelines cannot run more frequently than the instance’s
     [maximum scheduled pipeline frequency](https://docs.gitlab.com/administration/cicd/#change-maximum-scheduled-pipeline-frequency).
   - **Target branch or tag**: Select the branch or tag for the pipeline.
   - **Inputs**: Set values for any [inputs](https://docs.gitlab.com/ci/inputs/) defined in your pipeline’s `spec:inputs` section.
     These input values are used every time the scheduled pipeline runs. A schedule can have a maximum of 20 inputs.
   - **Variables**: Add any number of [CI/CD variables](https://docs.gitlab.com/ci/variables/) to the schedule.
     These variables are available only when the scheduled pipeline runs,
     and not in any other pipeline run. Inputs are recommended for pipeline configuration instead of variables
     because they offer improved security and flexibility.

If the project has reached the [maximum number of pipeline schedules](https://docs.gitlab.com/administration/instance_limits/#number-of-pipeline-schedules),
delete unused schedules before adding another.

## Edit a pipeline schedule [Permalink](https://docs.gitlab.com/ci/pipelines/schedules/\#edit-a-pipeline-schedule "Permalink")

Prerequisites:

- You must be the schedule owner or take ownership of the schedule.
- You must have the Developer, Maintainer, or Owner role for the project.
- For schedules that target [protected branches](https://docs.gitlab.com/user/project/repository/branches/protected/#protect-a-branch),
you must have merge permissions for the target branch.
- For schedules that run on [protected tags](https://docs.gitlab.com/user/project/protected_tags/#configure-protected-tags),
you must be allowed to create protected tags.

To edit a pipeline schedule:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Build** \> **Pipeline schedules**.
3. Next to the schedule, select **Edit** (pencil).
4. Make your changes, then select **Save changes**.

## Run manually [Permalink](https://docs.gitlab.com/ci/pipelines/schedules/\#run-manually "Permalink")

You can manually run scheduled pipelines once per minute.
When you run a scheduled pipeline manually, it uses your permissions instead of the schedule owner’s permissions.

To trigger a pipeline schedule immediately instead of waiting for the next scheduled time:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Build** \> **Pipeline schedules**.
3. Next to the schedule, select **Run** (play).

## Take ownership [Permalink](https://docs.gitlab.com/ci/pipelines/schedules/\#take-ownership "Permalink")

If a pipeline schedule becomes inactive because the original owner is unavailable, you can take ownership.

Scheduled pipelines execute with the permissions of the user who owns the schedule.

Prerequisites:

- You must have the Maintainer or Owner role for the project.

To take ownership of a schedule:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Build** \> **Pipeline schedules**.
3. Next to the schedule, select **Take ownership**.

## View your scheduled pipelines [Permalink](https://docs.gitlab.com/ci/pipelines/schedules/\#view-your-scheduled-pipelines "Permalink")

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/558979) in GitLab 18.4.

To view the active pipeline schedules that you own across all your projects:

1. In the upper-right corner, select your avatar.
2. Select **Edit profile**.
3. Select **Account**.
4. Scroll to **Scheduled pipelines you own**.

## Related topics [Permalink](https://docs.gitlab.com/ci/pipelines/schedules/\#related-topics "Permalink")

- [CI/CD pipelines](https://docs.gitlab.com/ci/pipelines/)
- [Run jobs for scheduled pipelines](https://docs.gitlab.com/ci/jobs/job_rules/#run-jobs-for-scheduled-pipelines)
- [Pipeline schedules API](https://docs.gitlab.com/api/pipeline_schedules/)
- [Pipeline efficiency](https://docs.gitlab.com/ci/pipelines/pipeline_efficiency/#reduce-how-often-jobs-run)

## Troubleshooting [Permalink](https://docs.gitlab.com/ci/pipelines/schedules/\#troubleshooting "Permalink")

When working with pipeline schedules, you might encounter the following issues.

### Scheduled pipeline becomes inactive [Permalink](https://docs.gitlab.com/ci/pipelines/schedules/\#scheduled-pipeline-becomes-inactive "Permalink")

If a scheduled pipeline status changes to `Inactive` unexpectedly,
the schedule owner might have been blocked or removed from the project.

Take ownership of the schedule to reactivate it.

### Distribute pipeline schedules to prevent system load [Permalink](https://docs.gitlab.com/ci/pipelines/schedules/\#distribute-pipeline-schedules-to-prevent-system-load "Permalink")

To prevent excessive load from too many pipelines starting simultaneously,
review and distribute your pipeline schedules:

1. Run this command to extract and format schedule data:





shell







```shell
outfile=/tmp/gitlab_ci_schedules.tsv
sudo gitlab-psql --command "
    COPY (SELECT
        ci_pipeline_schedules.cron,
        ci_pipeline_schedules.cron_timezone,
        namespaces.path AS group,
        projects.path   AS project,
        users.email
    FROM ci_pipeline_schedules
    JOIN projects ON projects.id = ci_pipeline_schedules.project_id
    JOIN namespaces ON namespaces.id = projects.namespace_id
    JOIN users    ON users.id    = ci_pipeline_schedules.owner_id
    WHERE ci_pipeline_schedules.active = 't'
    ) TO '$outfile' CSV HEADER DELIMITER E'\t' ;"
sort  "$outfile" | uniq -c | sort -n
```

2. Review the output to identify popular `cron` patterns.
For example, many schedules might run at the start of every hour (`0 * * * *`).

3. Adjust the schedules to create a staggered [`cron` pattern](https://docs.gitlab.com/topics/cron/#cron-syntax), especially for large repositories.
For example, instead of multiple schedules running at the start of every hour,
distribute them throughout the hour (`5 * * * *`, `15 * * * *`, `25 * * * *`).


Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**