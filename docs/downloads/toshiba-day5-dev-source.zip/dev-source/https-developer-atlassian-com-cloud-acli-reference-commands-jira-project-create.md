<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-create -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Filter by keyword

- [acli](https://developer.atlassian.com/cloud/acli/reference/commands/)
- [admin](https://developer.atlassian.com/cloud/acli/reference/commands/admin/)

[admin auth](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth/)

[admin user](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user/)

- [feedback](https://developer.atlassian.com/cloud/acli/reference/commands/feedback/)
- [jira](https://developer.atlassian.com/cloud/acli/reference/commands/jira/)

[jira auth](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth/)

[jira board](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board/)

[jira dashboard](https://developer.atlassian.com/cloud/acli/reference/commands/jira-dashboard/)

[jira field](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field/)

[jira filter](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter/)

[jira project](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project/)

- [archive](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-archive/)
- [create](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-create/)
- [delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-delete/)
- [list](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-list/)
- [restore](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-restore/)
- [update](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-update/)
- [view](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-view/)

[jira sprint](https://developer.atlassian.com/cloud/acli/reference/commands/jira-sprint/)

[jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem/)

- [rovodev](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev/)

[rovodev auth](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev-auth/)

Last updated Oct 3, 2024

On This Page

- [acli jira project create](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project-create/#acli-jira-project-create)


## acli jira project create

Create a Jira project – a collection of work items.

### Synopsis

Create a Jira project which is a collection of work items (stories, bugs, tasks, etc). You would typically use a project to represent the development work for a product, project, or service in Jira.

```
Copy
1
acli jira project create [flags]
```

### Examples

```
Copy
1
2
3
4
5
6
7
8
9
10
11
# Create a project from an existing project
$ acli jira project create --from-project "TEAM" --key "NEWTEAM" --name "New Project"

# Provide optional fields in --from-project
$ acli jira project create --from-project "TEAM" --key "NEWTEAM" --name "New Project" --description "New project description" --url "https://example.com" --lead-email "user@atlassian.com"

# Generate a JSON file that could be used for project creation via --from-json flag
$ acli jira project create --generate-json

# Create a project from a JSON file
$ acli jira project create --from-json "project.json"
```

### Options

```
Copy
1
2
3
4
5
6
7
8
9
  -d, --description string    Supply a description for the project
  -j, --from-json string      Read project details from a JSON file
  -f, --from-project string   Create a project from an existing project. Only company managed projects can be used to clone a new project.
  -g, --generate-json         Generates a JSON file that could be used for project creation
  -h, --help                  Show help for command
  -k, --key string            Key of the project to be created
  -l, --lead-email string     Lead account user email (If not provided, the lead will be same as that of parent project)
  -n, --name string           Name of the project to be created
  -u, --url string            URL of the project
```

### SEE ALSO

- [acli jira project](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project) \- Jira project commands.

Rate this page:

Unusable

Poor

Okay

Good

Excellent