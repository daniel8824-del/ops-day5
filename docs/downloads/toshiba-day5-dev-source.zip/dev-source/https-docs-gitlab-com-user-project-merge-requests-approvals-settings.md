<!-- source: https://docs.gitlab.com/user/project/merge_requests/approvals/settings -->

/

* * *

# Merge request approval settings

- Tier: Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

You can configure the settings for [merge request approvals](https://docs.gitlab.com/user/project/merge_requests/approvals/) to
ensure the approval rules meet your use case. You can also configure
[approval rules](https://docs.gitlab.com/user/project/merge_requests/approvals/rules/), which define the number and type of users who must
approve work before it’s merged. Merge request approval settings define how
to apply those rules as a merge request moves toward completion.

Use any combination of these settings to configure approval limits for merge requests:

- [**Prevent approval by merge request creator**](https://docs.gitlab.com/user/project/merge_requests/approvals/settings/#prevent-approval-by-merge-request-creator):
Prevents the author of a merge request from approving it.
- [**Prevent approvals by users who add commits**](https://docs.gitlab.com/user/project/merge_requests/approvals/settings/#prevent-approvals-by-users-who-add-commits):
Prevents users who add commits to a merge request from also approving it.
- [**Prevent editing approval rules in merge requests**](https://docs.gitlab.com/user/project/merge_requests/approvals/settings/#prevent-editing-approval-rules-in-merge-requests):
Prevents users from overriding project approval rules on merge requests.
- [**Require user re-authentication (password or SAML) to approve**](https://docs.gitlab.com/user/project/merge_requests/approvals/settings/#require-user-re-authentication-to-approve):
Force potential approvers to first authenticate with either a password or with SAML.
- Code Owner approval removals: Define what happens to existing approvals when
commits are added to the merge request.
  - **Keep approvals**: Do not remove any approvals.
  - [**Remove all approvals**](https://docs.gitlab.com/user/project/merge_requests/approvals/settings/#remove-all-approvals-when-commits-are-added-to-the-source-branch):
    Remove all existing approvals.
  - [**Remove approvals by Code Owners if their files changed**](https://docs.gitlab.com/user/project/merge_requests/approvals/settings/#remove-approvals-by-code-owners-if-their-files-changed):
    If a Code Owner approves a merge request, and a later commit changes files
    they are a Code Owner for, their approval is removed.

## Edit merge request approval settings [Permalink](https://docs.gitlab.com/user/project/merge_requests/approvals/settings/\#edit-merge-request-approval-settings "Permalink")

To view or edit merge request approval settings for a single project:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Settings** \> **Merge requests**.
3. Expand **Approvals**.

### Cascade settings from the instance or top-level group [Permalink](https://docs.gitlab.com/user/project/merge_requests/approvals/settings/\#cascade-settings-from-the-instance-or-top-level-group "Permalink")

To simplify the management of approval rule settings, configure them as broadly as possible.
Settings configured:

- [For your instance](https://docs.gitlab.com/administration/merge_requests_approvals/) apply to all groups
and projects on the instance.
- For a [top-level group](https://docs.gitlab.com/user/group/manage/#group-merge-request-approval-settings) apply to
its subgroups and projects.

How a setting cascades depends on where it’s configured:

- A setting configured for your instance locks the equivalent setting for all groups and projects.
You cannot change the inherited setting in a group or project.
- A setting configured for a top-level group cascades to its subgroups and projects:
  - When a prevention setting is enabled for a group, the equivalent project setting is
    locked. Project Maintainers cannot change it.
  - When a prevention setting is disabled for a group, project Maintainers can configure it
    for individual projects.

## Prevent approval by merge request creator [Permalink](https://docs.gitlab.com/user/project/merge_requests/approvals/settings/\#prevent-approval-by-merge-request-creator "Permalink")

By default, the creator of a merge request (author) cannot approve it. To change this setting:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Settings** \> **Merge requests**.
3. In the **Merge request approvals** section, scroll to **Approval settings** and
clear the **Prevent approval by merge request creator (author)** checkbox.
4. Select **Save changes**.

Merge request creators can edit the approval rule in an individual merge request and override
this setting, unless you configure one of these options:

- [Prevent overrides of default approvals](https://docs.gitlab.com/user/project/merge_requests/approvals/settings/#prevent-editing-approval-rules-in-merge-requests) for your project.
- _(GitLab Self-Managed instances only)_ Prevent overrides of default approvals
[for your instance](https://docs.gitlab.com/administration/merge_requests_approvals/). When configured
for your instance, you can’t edit this setting on projects or individual
merge requests.

## Prevent approvals by users who add commits [Permalink](https://docs.gitlab.com/user/project/merge_requests/approvals/settings/\#prevent-approvals-by-users-who-add-commits "Permalink")

History

- [Feature flag `keep_merge_commits_for_approvals`](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/127744) added in GitLab 16.3 to also include merge commits in this check.
- [Feature flag `keep_merge_commits_for_approvals`](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/131778) removed in GitLab 16.5. This check now includes merge commits.

By default, users who commit to a merge request (the committers) can still approve it. To prevent
committers in your project (or your instance) from approving merge requests that are partially
their own:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Settings** \> **Merge requests**.
3. In the **Merge request approvals** section, scroll to **Approval settings** and
select **Prevent approvals by users who add commits**.
If this checkbox is cleared, an administrator has disabled it
[for your instance](https://docs.gitlab.com/administration/merge_requests_approvals/), and
you can’t change it for your project.
4. Select **Save changes**.

[Code owners](https://docs.gitlab.com/user/project/codeowners/) who commit to a merge request cannot approve it,
if the merge request affects files they own.

For more information, see the [official Git documentation](https://git-scm.com/book/en/v2/Git-Basics-Viewing-the-Commit-History).

If a merge request is rebased by someone other than the user who originally committed the changes,
the commit history is rewritten with a new committer. This might enable users who
previously committed changes in a merge request to now approve changes in it, as they are
no longer a committer.

See also [approving after rebase](https://docs.gitlab.com/topics/git/git_rebase/#approving-after-rebase)

## Prevent editing approval rules in merge requests [Permalink](https://docs.gitlab.com/user/project/merge_requests/approvals/settings/\#prevent-editing-approval-rules-in-merge-requests "Permalink")

By default, users can override the approval rules you [create for a project](https://docs.gitlab.com/user/project/merge_requests/approvals/rules/)
on a per-merge-request basis. If you don’t want users to change approval rules
on merge requests, you can disable this setting:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Settings** \> **Merge requests**.
3. In the **Merge request approvals** section, scroll to **Approval settings** and
select **Prevent editing approval rules in merge requests**.
4. Select **Save changes**.

This setting has a different scope at each level. For a project or group, it prevents approval
rule overrides per merge request. The approval rules list in project settings remains editable.
To also prevent project Maintainers from editing the approval rules list, an administrator must
enable
[**Prevent editing approval rules in projects and merge requests**](https://docs.gitlab.com/administration/merge_requests_approvals/)
for your instance.
When you change this field, it can affect all open merge requests depending on the setting:

- If users could edit approval rules previously, and you disable this behavior,
GitLab updates all open merge requests to enforce the approval rules.
- If users could not edit approval rules previously, and you enable approval rule
editing, open merge requests remain unchanged. This preserves any changes already
made to approval rules in those merge requests.

## Require user re-authentication to approve [Permalink](https://docs.gitlab.com/user/project/merge_requests/approvals/settings/\#require-user-re-authentication-to-approve "Permalink")

History

- Requiring re-authentication by using SAML authentication for GitLab.com groups [introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/5981) in GitLab 16.6 [with a flag](https://docs.gitlab.com/administration/feature_flags/) named `ff_require_saml_auth_to_approve`. Disabled by default.
- Requiring re-authentication by using SAML authentication for GitLab Self-Managed instances [introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/431415) in GitLab 16.7 [with a flag](https://docs.gitlab.com/administration/feature_flags/) named `ff_require_saml_auth_to_approve`. Disabled by default.
- [Enabled `ff_require_saml_auth_to_approve` by default](https://gitlab.com/gitlab-org/gitlab/-/issues/431714) in GitLab 16.8 for GitLab.com and GitLab Self-Managed instances.
- Feature flag removed in GitLab 18.3

On GitLab Self-Managed, by default requiring re-authentication by using SAML authentication is available. To hide the feature, an administrator can
[disable the feature flag](https://docs.gitlab.com/administration/feature_flags/) named `ff_require_saml_auth_to_approve`. On GitLab.com and GitLab Dedicated, this feature is available.

You can force potential approvers to first authenticate with SAML or a password.
This permission enables an electronic signature for approvals, such as the one defined by
[Code of Federal Regulations (CFR) Part 11](https://www.accessdata.fda.gov/scripts/cdrh/cfdocs/cfcfr/CFRSearch.cfm?CFRPart=11&showFR=1&subpartNode=21:1.0.1.1.8.3).

Prerequisites:

- This setting is only available on top-level groups.

1. In the top bar, select **Search or go to** and find your project.
2. Enable password authentication and SAML authentication. For more information on:
   - Password authentication, see
     [sign-in restrictions documentation](https://docs.gitlab.com/administration/settings/sign_in_restrictions/#password-and-passkey-authentication).
   - SAML authentication for GitLab.com groups, see
     [SAML SSO for GitLab.com groups documentation](https://docs.gitlab.com/user/group/saml_sso/).
   - SAML authentication for GitLab Self-Managed instances, see
     [SAML SSO for GitLab Self-Managed](https://docs.gitlab.com/integration/saml/).
3. In the left sidebar, select **Settings** \> **Merge requests**.
4. In the **Merge request approvals** section, scroll to **Approval settings** and
select **Require user re-authentication (password or SAML) to approve**.
5. Select **Save changes**.

## Remove all approvals when commits are added to the source branch [Permalink](https://docs.gitlab.com/user/project/merge_requests/approvals/settings/\#remove-all-approvals-when-commits-are-added-to-the-source-branch "Permalink")

- Tier: Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

By default, an approval on a merge request is removed when you add more changes
after the approval.

GitLab uses [`git patch-id`](https://git-scm.com/docs/git-patch-id) to identify diffs
in merge requests. This value is a reasonably stable and unique identifier, and it enables
smarter decisions about resetting approvals inside a merge request. When you push new changes
to a merge request, the `patch-id` is evaluated against the previous `patch-id` to determine
if the approvals should be reset. This enables GitLab to make better reset decisions when
you perform commands like `git rebase` or `git merge <target>` on a feature branch.

To keep existing approvals after more changes are added to a merge request:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Settings** \> **Merge requests**.
3. In the **Merge request approvals** section, scroll to **Approval settings** and
clear the **Remove all approvals** checkbox.
4. Select **Save changes**.

If you automate the creation and approval of merge requests, build in logic to ensure commits are
processed fully before approving the merge request. This prevents an unintentional approval reset.
For more information, see [handle timing issues with automated approvals](https://docs.gitlab.com/api/merge_request_approvals/#prevent-approval-resets-in-automated-merge-requests).

## Remove approvals by Code Owners if their files changed [Permalink](https://docs.gitlab.com/user/project/merge_requests/approvals/settings/\#remove-approvals-by-code-owners-if-their-files-changed "Permalink")

To remove approvals only from Code Owners whose files change in a new commit:

Prerequisites:

- You must have the Maintainer or Owner role for a project.

To do this:

1. In the top bar, select **Search or go to** and find your project.
2. In the left sidebar, select **Settings** \> **Merge requests**.
3. In the **Merge request approvals** section, scroll to **Approval settings** and
select **Remove approvals by Code Owners if their files changed**.
4. Select **Save changes**.

## Related topics [Permalink](https://docs.gitlab.com/user/project/merge_requests/approvals/settings/\#related-topics "Permalink")

- [Merge request approval settings for your instance](https://docs.gitlab.com/administration/merge_requests_approvals/)
- [Compliance center](https://docs.gitlab.com/user/compliance/compliance_center/)
- [Merge request approvals API](https://docs.gitlab.com/api/merge_request_approvals/)
- [Merge request approval settings API](https://docs.gitlab.com/api/merge_request_approval_settings/)

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**