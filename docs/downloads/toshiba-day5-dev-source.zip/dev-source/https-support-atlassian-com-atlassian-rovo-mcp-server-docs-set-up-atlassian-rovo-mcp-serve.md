<!-- source: https://support.atlassian.com/atlassian-rovo-mcp-server/docs/set-up-atlassian-rovo-mcp-server -->

[Skip to main content](https://support.atlassian.com/atlassian-rovo-mcp-server/docs/set-up-atlassian-rovo-mcp-server#maincontent)

# Set up Atlassian Rovo MCP Server

- [Learn how Atlassian's Remote MCP Server connects AI tools to Jira & Confluence for streamlined workflows. \\
\\
View topics](https://support.atlassian.com/atlassian-rovo-mcp-server/docs/use-atlassian-rovo-mcp-server/)