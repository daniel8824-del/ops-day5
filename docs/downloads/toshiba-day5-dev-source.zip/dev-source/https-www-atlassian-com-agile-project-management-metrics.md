<!-- source: https://www.atlassian.com/agile/project-management/metrics -->

Get it free

Search

Sign in

# Five agile KPI metrics you won't hate

Stats and charts are powerful tools. Use them for good, dear agilists... use them for good.

![](https://images.ctfassets.net/xjcz23wx147q/2uNEtaB8azod7exGiL9Obf/b34e5b81e9176b0dfc38880a173994e0/Dan_Radigan_200x200.png)

By Dan Radigan, Atlassian Head of Technical Product Marketing

Agile has had a huge impact on me both professionally and personally as I've learned the best experiences are agile, both in code and in life. You'll often find me at the intersection of technology, photography, and motorcycling.

Get the free project reporting template

Streamline your project reporting with consistent, comprehensive reports for a complete overview of your projects.

[Use template](https://www.atlassian.com/software/jira/templates/project-reporting)

**Key Takeaways**

- Agile metrics like sprint burndown, velocity, cycle time, and cumulative flow diagrams help teams track progress and optimize delivery.

- These metrics provide insights into team performance, bottlenecks, and forecasting for future sprints.

- Regularly reviewing metrics supports continuous improvement and data-driven decision-making.

- Incorporate Agile metrics into retrospectives to identify trends and refine your team’s workflow for better outcomes.


Metrics are a touchy subject.

On the one hand, we've all been on a project where no data of any kind was tracked, and it was hard to tell whether we're on track for release or getting more efficient as we go along. On the other hand, many of us have had the misfortune of being on a projects where stats were used as a weapon, pitting one team against another or justifying mandatory weekend work. So it's no surprise that most teams have a love/hate relationship with metrics.

But it doesn't have to be this way. Tracking and sharing sound agile metrics can reduce confusion and shine a light on the team's progress (and setbacks) throughout the development cycle. Here's how.

## What are Agile metrics?

Agile metrics are quantitative measures used to track the progress, quality, and effectiveness of agile teams and projects. Common metrics include [velocity](https://www.atlassian.com/agile/project-management/velocity-scrum), lead time, cycle time, [burndown charts](https://www.atlassian.com/agile/tutorials/burndown-charts), and [cumulative flow diagrams](https://support.atlassian.com/jira-software-cloud/docs/view-and-understand-the-cumulative-flow-diagram/).

These metrics help teams identify bottlenecks, forecast delivery, and drive continuous improvement. For example, tracking velocity allows teams to predict how much work they can complete in future sprints, while monitoring cycle time highlights areas for process optimization.

### What is a KPI in Agile?

A [KPI (Key Performance Indicator)](https://www.atlassian.com/work-management/project-management/project-planning/kpi) in Agile is a specific metric used to measure the success of a team or project against defined goals. KPIs might include customer satisfaction, defect rates, or time to market, depending on what’s most important to the organization.

Selecting the right KPIs ensures that teams stay focused on delivering value and achieving strategic objectives. For example, a team might track the number of critical bugs resolved per sprint as a KPI to improve product quality and customer experience.

## How to use agile KPI metrics to optimize your delivery

"Done" only tells half the story. It's about building the right product, at the right time, for the right market. Staying on track throughout the program means collecting and analyzing relevant data along the way. In any agile program, it's important to track both business metrics and agile metrics. Business metrics focus on whether the solution is meeting the market need, and agile metrics measure aspects of the development process.

> A program's business metrics should be rooted in its roadmap.

For each initiative on the roadmap, include several key performance indicators (KPIs) that map to the program's goals. In addition, include success criteria for each product [requirement](https://www.atlassian.com/agile/product-management/requirements) such as adoption rate by end users or percentage of code covered by automated tests. These success criteria feed into the program's agile metrics. And the more teams learn, the better they can adapt and evolve.

### Sprint burndown

Scrum teams organize development into time-boxed [sprints](https://www.atlassian.com/agile/project-management/epics-stories-themes). At the outset of the sprint, the team forecasts how much work they can complete during a sprint. A sprint burndown report then tracks the completion of work throughout the sprint. The x-axis represents time, and the y-axis refers to the amount of work left to complete, measured in either story points or hours. The goal is to have all the forecasted work completed by the end of the sprint.

A team that consistently meets its forecast is a compelling advertisement for agile in their organization. But don't let that tempt you to fudge the numbers by declaring an item complete before it really is. It may look good in the short term, but in the long run, it only hampers learning and improvement.

[Learn how to use burndown charts in Jira](https://www.atlassian.com/agile/tutorials/burndown-charts)

![Burndown chart](https://dam-cdn.atl.orangelogic.com/AssetLink/kwru26n88v2sx36423o574bw5p36ypd3.svg)

Anti-patterns to watch for

- The team finishes early sprint after sprint because they aren't committing to enough work.

- The team misses their forecast sprint after sprint because they're committing to too much work.

- The burndown line makes steep drops rather than a more gradual burndown because the work hasn't been broken down into granular pieces.

- The product owner adds or changes the scope mid-sprint.


### Epic and release burndown

[Epic and release](https://www.atlassian.com/agile/project-management/epics-stories-themes) (or version) burndown charts track the progress of development over a larger body of work than the sprint burndown, and guide development for both scrum and kanban teams. Since a sprint (for scrum teams) may contain work from several epics and versions, it's important to track both the progress of individual sprints as well as epics and versions.

"Scope creep" is the injection of more requirements into a previously-defined project. For example, if the team is delivering a new website for the company, scope creep would be asking for new features after the initial [requirements](https://www.atlassian.com/agile/product-management/requirements) had been sketched out. While tolerating scope creep during a sprint is bad practice, scope change within epics and versions is a natural consequence of agile development. As the team moves through the project, the product owner may decide to take on or remove work based on what they're learning. The epic and release burn down charts keep everyone aware of the ebb and flow of work inside the epic and version.

![Epic Burndown chart](https://dam-cdn.atl.orangelogic.com/AssetLink/g2vv366r0v4np04747y78o1w378i3u6d.svg)

Anti-patterns to watch for

- The team finishes early sprint after sprint because they aren't committing to enough work.

- The team misses their forecast sprint after sprint because they're committing to too much work.

- The burndown line makes steep drops rather than a more gradual burndown because the work hasn't been broken down into granular pieces.

- The product owner adds or changes the scope mid-sprint.


### Velocity

Velocity is the average amount of work a scrum team completes during a sprint, measured in either story points or hours, and is very useful for forecasting. The product owner can use velocity to predict how quickly a team can work through the backlog, because the report tracks the forecasted and completed work over several iterations–the more iterations, the more accurate the forecast.

Let's say the product owner wants to complete 500 story points in the backlog. We know that the development team generally completes 50 story points per iteration. The product owner can reasonably assume the team will need 10 iterations (give or take) to complete the required work.

It's important to monitor how velocity evolves over time. New teams can expect to see an increase in velocity as the team optimizes relationships and the work process. Existing teams can track their velocity to ensure consistent performance over time, and can confirm that a particular process change made improvements or not. A decrease in average velocity is usually a sign that some part of the team's development process has become inefficient and should be brought up at the next retrospective.

![Velocity chart](https://dam-cdn.atl.orangelogic.com/AssetLink/47at541gh5m35jun5x1m3055568k25i6.svg)

Anti-patterns to watch for

- The team finishes early sprint after sprint because they aren't committing to enough work.

- The team misses their forecast sprint after sprint because they're committing to too much work.

- The burndown line makes steep drops rather than a more gradual burndown because the work hasn't been broken down into granular pieces.

- The product owner adds or changes the scope mid-sprint.


Each team’s velocity is unique. If team A has a velocity of 50 and team B has a velocity of 75, it doesn't mean that team B has higher throughput. Since each team's [estimation](https://www.atlassian.com/agile/project-management/estimation) culture is unique, their velocity will be as well. Resist the temptation to compare velocity across teams. Measure the level of effort and output of work based on each team's unique interpretation of story points.

### Control chart

Control charts focus on the cycle time of individual issues–the total time from "in progress" to "done". Teams with shorter cycle times are likely to have higher throughput, and teams with consistent cycle times across many issues are more predictable in delivering work. While cycle time is a primary metric for kanban teams, scrum teams can benefit from optimized cycle time as well.

Measuring cycle time is an efficient and flexible way to improve a team's processes because the results of changes are discernable almost immediately, allowing them to make any further adjustments right away. The end goal is to have a consistent and short cycle time, regardless of the type of work (new feature, [technical debt](https://www.atlassian.com/agile/software-development/technical-debt), etc.).

![Control chart](https://dam-cdn.atl.orangelogic.com/AssetLink/3s546370gfna7u8kr0b035lj05u4h7x0.svg)

Anti-patterns to watch for

- The team finishes early sprint after sprint because they aren't committing to enough work.

- The team misses their forecast sprint after sprint because they're committing to too much work.

- The burndown line makes steep drops rather than a more gradual burndown because the work hasn't been broken down into granular pieces.

- The product owner adds or changes the scope mid-sprint.


### Cumulative flow diagram

The cumulative flow diagram should look smooth(ish) from left to right. Bubbles or gaps in any one color indicate shortages and bottlenecks, so when you see one, look for ways to smooth out color bands across the chart.

![Cumulative flow diagram](https://dam-cdn.atl.orangelogic.com/AssetLink/76b022276676y1iwb2114swm8wj7n7lq.svg)

Anti-patterns to watch for

- The team finishes early sprint after sprint because they aren't committing to enough work.

- The team misses their forecast sprint after sprint because they're committing to too much work.

- The burndown line makes steep drops rather than a more gradual burndown because the work hasn't been broken down into granular pieces.

- The product owner adds or changes the scope mid-sprint.


### More Agile metrics

Good metrics aren't limited to the reports discussed above. For example, quality is an important metric for agile teams and there are a number of traditional metrics that can be applied to agile development:

- How many defects are found:

  - during development?

  - after release to customers?

  - by people outside of the team?
- How many defects are deferred to a future release?

- How many customer support requests are coming in?

- What is the percentage of automated test coverage?


Agile teams should also look at release frequency and delivery speed. At the end of each sprint, the team should release software out to production. How often is that actually happening? Are most release builds getting shipped? In the same vein, how long does it take for the team to release an emergency fix out to production? Is release easy for the team or does it require heroics?

### Find insights in context

Insights are a great tool for teams to access metrics when they need them: during sprint planning, checking in at the daily standup, or optimizing delivery. You can find insights in the upper right-hand corner of the board, backlog, and deployments view of Jira.

Insights give a visual snapshot of the following metrics:

- Sprint progress

- Issue type breakdown

- Sprint commitment

- Deployment frequency

- Cycle time


Use these metrics to continuously optimize team performance. [Learn more about insights](https://www.atlassian.com/software/jira/features/reports).

## How do you measure the success of an Agile project?

The success of an [Agile](https://www.atlassian.com/agile) project is measured by evaluating both quantitative metrics and qualitative outcomes, such as delivering value to customers, meeting business goals, and fostering team collaboration. Key indicators include on-time delivery, stakeholder satisfaction, and the ability to adapt to change.

Teams often use a combination of metrics like [velocity](https://www.atlassian.com/agile/project-management/velocity-scrum), customer feedback, and business impact to assess performance. For example, a project that delivers a high-quality product on schedule and receives positive user feedback would be considered successful in an Agile context.

## In conclusion...

Agile metrics and kpi's are just one part of building a team's culture. They give quantitative insight into the team's performance and provide measurable goals for the team. While they're important, don't get obsessed. Listening to the team's feedback during [retrospectives](https://www.atlassian.com/agile/scrum/ceremonies) is equally important in growing trust across the team, quality in the product, and development speed through the release process. Use both quantitative and qualitative feedback to drive change.

### Related resources

- [Project Management Resources](https://www.atlassian.com/project-management)

  - [Resources for Project Managers](https://www.atlassian.com/project-management/project-managers)

## Recommended for you

### Ready-made Jira templates

Browse our library of custom Jira templates for various teams, departments, and workflows.

[Go to Jira templates](https://www.atlassian.com/software/jira/templates)

### A comprehensive introduction to Jira

Use this step-by-step guide to discover essential features and the best practices to maximize your productivity.

[Go to Jira Product guide](https://www.atlassian.com/software/jira/guides/getting-started/introduction#what-is-jira-software)

### Understanding the Basics of Git

From beginners to advanced experts, use this guide to Git to learn the basics with helpful tutorials and tips.

[Learn more](https://www.atlassian.com/git)

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**