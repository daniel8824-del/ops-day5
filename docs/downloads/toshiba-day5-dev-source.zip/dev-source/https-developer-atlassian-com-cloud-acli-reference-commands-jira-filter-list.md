<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter-list -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Filter by keyword

- [acli](https://developer.atlassian.com/cloud/acli/reference/commands/)
- [admin](https://developer.atlassian.com/cloud/acli/reference/commands/admin/)

[admin auth](https://developer.atlassian.com/cloud/acli/reference/commands/admin-auth/)

[admin user](https://developer.atlassian.com/cloud/acli/reference/commands/admin-user/)

- [feedback](https://developer.atlassian.com/cloud/acli/reference/commands/feedback/)
- [jira](https://developer.atlassian.com/cloud/acli/reference/commands/jira/)

[jira auth](https://developer.atlassian.com/cloud/acli/reference/commands/jira-auth/)

[jira board](https://developer.atlassian.com/cloud/acli/reference/commands/jira-board/)

[jira dashboard](https://developer.atlassian.com/cloud/acli/reference/commands/jira-dashboard/)

[jira field](https://developer.atlassian.com/cloud/acli/reference/commands/jira-field/)

[jira filter](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter/)

- [add-favourite](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter-add-favourite/)
- [change-owner](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter-change-owner/)
- [list](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter-list/)
- [search](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter-search/)

[jira project](https://developer.atlassian.com/cloud/acli/reference/commands/jira-project/)

[jira sprint](https://developer.atlassian.com/cloud/acli/reference/commands/jira-sprint/)

[jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem/)

- [rovodev](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev/)

[rovodev auth](https://developer.atlassian.com/cloud/acli/reference/commands/rovodev-auth/)

Last updated Oct 3, 2024

On This Page

- [acli jira filter list](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter-list/#acli-jira-filter-list)


## acli jira filter list

List filter that are either my or favourite.

```
Copy
1
acli jira filter list [flags]
```

### Examples

```
Copy
1
2
3
4
5
6
# List my filters
$ acli jira filter list --my

# List my favourite filters
$ acli jira filter list --favourite
```

### Options

```
Copy
1
2
3
4
      --favourite   List my favourite filters
  -h, --help        Show help for command
      --json        Output in JSON format
      --my          List my filters
```

### SEE ALSO

- [acli jira filter](https://developer.atlassian.com/cloud/acli/reference/commands/jira-filter) \- Jira filter commands.

Rate this page:

Unusable

Poor

Okay

Good

Excellent