<!-- source: https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment -->

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

Documentation

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Get Support](https://developer.atlassian.com/support)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

[Atlassian home](https://www.atlassian.com/)

[Developer](https://developer.atlassian.com/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

DOCUMENTATION

Cloud

Data Center

Resources

[News and Updates](https://developer.atlassian.com/news-and-updates/)

[Get support](https://developer.atlassian.com/support/)

[Sign in](https://developer.atlassian.com/account/login?returnTo=)

Last updated Oct 3, 2024

On This Page

- [acli jira workitem comment](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment/#acli-jira-workitem-comment)


## acli jira workitem comment

Work item comments commands.

### Options

```
Copy
1
  -h, --help   Show help for command
```

### SEE ALSO

- [acli jira workitem](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem) \- Jira work item commands.
- [acli jira workitem comment create](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-create) \- Create a comment on work items
- [acli jira workitem comment delete](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-delete) \- Delete a comment for a given workitem
- [acli jira workitem comment list](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-list) \- List comments for a work item.
- [acli jira workitem comment update](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-update) \- Update a comment on a work item.
- [acli jira workitem comment visibility](https://developer.atlassian.com/cloud/acli/reference/commands/jira-workitem-comment-visibility) \- Get visibility options for work item comments.

Rate this page:

Unusable

Poor

Okay

Good

Excellent