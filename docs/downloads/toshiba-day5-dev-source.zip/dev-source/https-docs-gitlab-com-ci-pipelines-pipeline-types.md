<!-- source: https://docs.gitlab.com/ci/pipelines/pipeline_types -->

/

* * *

# Types of pipelines

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

Multiple types of pipelines can run in a project, including:

- Branch pipelines
- Tag pipelines
- Merge request pipelines
- Merged results pipelines
- Merge trains
- Workload pipelines (for the GitLab Duo Agent Platform only)

These types of pipelines all appear on the **Pipelines** tab of a merge request.

## Branch pipeline [Permalink](https://docs.gitlab.com/ci/pipelines/pipeline_types/\#branch-pipeline "Permalink")

Your pipeline can run every time you commit changes to a branch.

This type of pipeline is called a _branch pipeline_.
They display a `branch` label in pipeline lists.

This pipeline runs by default. No configuration is required.

Branch pipelines:

- Run when you push a new commit to a branch.
- Have access to [some predefined variables](https://docs.gitlab.com/ci/variables/predefined_variables/).
- Have access to [protected variables](https://docs.gitlab.com/ci/variables/#protect-a-cicd-variable)
and [protected runners](https://docs.gitlab.com/ci/runners/configure_runners/#prevent-runners-from-revealing-sensitive-information)
when the branch is a [protected branch](https://docs.gitlab.com/user/project/repository/branches/protected/).

## Tag pipeline [Permalink](https://docs.gitlab.com/ci/pipelines/pipeline_types/\#tag-pipeline "Permalink")

A pipeline can run every time you create or push a new [tag](https://docs.gitlab.com/user/project/repository/tags/).

This type of pipeline is called a _tag pipeline_.
They display a `tag` label in pipeline lists.

This pipeline runs by default. No configuration is required.

Tag pipelines:

- Run when you create/push a new tag to your repository.
- Have access to [some predefined variables](https://docs.gitlab.com/ci/variables/predefined_variables/).
- Have access to [protected variables](https://docs.gitlab.com/ci/variables/#protect-a-cicd-variable)
and [protected runners](https://docs.gitlab.com/ci/runners/configure_runners/#prevent-runners-from-revealing-sensitive-information)
when the tag is a [protected tag](https://docs.gitlab.com/user/project/protected_tags/).

## Merge request pipeline [Permalink](https://docs.gitlab.com/ci/pipelines/pipeline_types/\#merge-request-pipeline "Permalink")

Instead of a branch pipeline, you can configure your pipeline to run every time you make changes to the
source branch in a merge request.

This type of pipeline is called a _merge request pipeline_.
They display a `merge request` label in pipeline lists.

Merge request pipelines do not run by default. You must configure
the jobs in the `.gitlab-ci.yml` file to run as merge request pipelines.

For more information, see [merge request pipelines](https://docs.gitlab.com/ci/pipelines/merge_request_pipelines/).

## Merged results pipeline [Permalink](https://docs.gitlab.com/ci/pipelines/pipeline_types/\#merged-results-pipeline "Permalink")

History

- The `merged results` label was [introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/132975) in GitLab 16.5.

A _merged results pipeline_ runs on the result of the source and target branches merged together.
It’s a type of merge request pipeline.

These pipelines do not run by default. You must configure the jobs in the `.gitlab-ci.yml` file
to run as a merge request pipeline, and enable merged results pipelines.

These pipelines display a `merged results` label in pipeline lists.

For more information, see [merged results pipeline](https://docs.gitlab.com/ci/pipelines/merged_results_pipelines/).

## Merge trains [Permalink](https://docs.gitlab.com/ci/pipelines/pipeline_types/\#merge-trains "Permalink")

In projects with frequent merges to the default branch, changes in different merge requests
might conflict with each other. Use _merge trains_ to put merge requests in a queue.
Each merge request is compared to the other, earlier merge requests, to ensure they all work together.

Merge trains differ from merged results pipelines, because merged results pipelines
ensure the changes work with the content in the default branch,
but not content that others are merging at the same time.

These pipelines do not run by default. You must configure the jobs in the `.gitlab-ci.yml` file
to run as a merge request pipeline, enable merged results pipelines, and enable merge trains.

These pipelines display a `merge train` label in pipeline lists.

For more information, see [merge trains](https://docs.gitlab.com/ci/pipelines/merge_trains/).

## Workload pipeline [Permalink](https://docs.gitlab.com/ci/pipelines/pipeline_types/\#workload-pipeline "Permalink")

Workload pipelines are the execution environment for GitLab Duo Agent Platform workloads.

Workload pipelines:

- Run on ephemeral Git references which follow this naming convention: `refs/workloads/<identifier>`.
- Have the source `duo_workflow` in pipeline lists.
- Workload refs are automatically removed when the pipeline job finishes or fails.

A link to the workload pipeline is available from the agent or platform session.

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**