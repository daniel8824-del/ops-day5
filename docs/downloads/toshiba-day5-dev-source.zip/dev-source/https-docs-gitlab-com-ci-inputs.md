<!-- source: https://docs.gitlab.com/ci/inputs -->

/

* * *

# CI/CD inputs

- Tier: Free, Premium, Ultimate
- Offering: GitLab.com, GitLab Self-Managed, GitLab Dedicated

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/391331) in GitLab 15.11 as a beta feature.
- [Made generally available](https://gitlab.com/gitlab-com/www-gitlab-com/-/merge_requests/134062) in GitLab 17.0.

Use CI/CD inputs to increase the flexibility of CI/CD configuration. Inputs and [CI/CD variables](https://docs.gitlab.com/ci/variables/)
can be used in similar ways, but have different benefits:

- Inputs provide typed parameters for reusable templates with built-in validation at pipeline creation time.
To define specific values when the pipeline runs, use inputs instead of CI/CD variables.
- CI/CD variables offer flexible values that can be defined at multiple levels, but can be modified
throughout pipeline execution. Use variables for values that need to be accessible in the job’s runtime environment.
You can also use [predefined variables](https://docs.gitlab.com/ci/variables/predefined_variables/) with `rules`
for dynamic pipeline configuration.

## CI/CD Inputs and variables comparison [Permalink](https://docs.gitlab.com/ci/inputs/\#cicd-inputs-and-variables-comparison "Permalink")

Inputs:

- **Purpose**: Defined in CI configurations (templates, components or `.gitlab-ci.yml`) and assigned values
when a pipeline is triggered, allowing consumers to customize reusable CI configurations.
- **Modification**: Once passed at pipeline initialization, input values are interpolated in the CI/CD
configuration and remain fixed for the entire pipeline run.
- **Scope**: Available only in the file they are defined, whether in the `.gitlab-ci.yml` or a file
being `include`d. You can pass them explicitly to other files - using `include:inputs` \- or pipeline
using `trigger:inputs`.
- **Validation**: Provide robust validation capabilities including type checking, regex patterns,
predefined option lists, and helpful descriptions for users.

CI/CD Variables:

- **Purpose**: Values that can be set as environment variables during job execution and in various parts
of the pipeline for passing data between jobs.
- **Modification**: Can be dynamically generated or modified during pipeline execution through dotenv artifacts,
conditional rules, or directly in job scripts.
- **Scope**: Can be defined globally (affecting all jobs), at the job level (affecting only specific jobs),
or for the entire project or group through the GitLab UI.
- **Validation**: Simple key-value pairs with minimal built-in validation, though you can add some controls through
the GitLab UI for project variables.

## Define input parameters with `spec:inputs` [Permalink](https://docs.gitlab.com/ci/inputs/\#define-input-parameters-with-specinputs "Permalink")

Use `spec:inputs` in the CI/CD configuration [header](https://docs.gitlab.com/ci/yaml/#header-keywords) to define input parameters that
can be passed to the configuration file.

Use the `$[[ inputs.input-id ]]` interpolation format outside the header section to declare where to use
the inputs.

For example:

yaml

```yaml
spec:
  inputs:
    job-stage:
      default: test
    environment:
      default: production
---
scan-website:
  stage: $[[ inputs.job-stage ]]
  script: ./scan-website $[[ inputs.environment ]]
```

In this example, the inputs are `job-stage` and `environment`.

You can only use inputs values in the file with the `spec` section.
To use an input value from a different file added with `include`,
[pass it to the included file explicitly](https://docs.gitlab.com/ci/inputs/#for-configuration-added-with-include).

With `spec:inputs`:

- Inputs are mandatory if `default` is not specified.
- Inputs are evaluated and populated when the configuration is fetched during pipeline creation.
- A string containing an input must be less than 1 MB.
- A string inside an input must be less than 1 KB.
- Inputs can use CI/CD variables, but have the same [variable limitations as the `include` keyword](https://docs.gitlab.com/ci/yaml/includes/#use-variables-with-include).
- If the file that defines `spec:inputs` also contains job definitions, add a YAML document
separator (`---`) after the header.

Then you set the values for the inputs when you:

- [Run a new pipeline](https://docs.gitlab.com/ci/inputs/#for-a-pipeline) using this configuration file.
You should always set default values when using inputs to configure new pipelines
with any method other than `include`. Otherwise the pipeline could fail to start
if a new pipeline triggers automatically, including in:
  - Merge request pipelines
  - Branch pipelines
  - Tag pipelines
- [Include the configuration](https://docs.gitlab.com/ci/inputs/#for-configuration-added-with-include) in your pipeline.
Any inputs that are mandatory must be added to the `include:inputs` section, and are used
every time the configuration is included.

### Input configuration [Permalink](https://docs.gitlab.com/ci/inputs/\#input-configuration "Permalink")

To configure inputs, use:

- [`spec:inputs:default`](https://docs.gitlab.com/ci/yaml/#specinputsdefault) to define default values for inputs
when not specified. When you specify a default, the inputs are no longer mandatory.
- [`spec:inputs:description`](https://docs.gitlab.com/ci/yaml/#specinputsdescription) to give a description to
a specific input. The description does not affect the input, but can help people
understand the input details or expected values.
- [`spec:inputs:options`](https://docs.gitlab.com/ci/yaml/#specinputsoptions) to specify a list of allowed values
for an input.
- [`spec:inputs:regex`](https://docs.gitlab.com/ci/yaml/#specinputsregex) to specify a regular expression
that the input must match.
- [`spec:inputs:type`](https://docs.gitlab.com/ci/yaml/#specinputstype) to force a specific input type, which
can be `string` (default when not specified), `array`, `number`, or `boolean`.
- [`spec:inputs:rules`](https://docs.gitlab.com/ci/yaml/#specinputsrules) to define conditional `options`
and `default` values based on the values of other inputs.

You can define multiple inputs per CI/CD configuration file, and each input can have
multiple configuration parameters.

For example, in a file named `scan-website-job.yml`:

yaml

```yaml
spec:
  inputs:
    job-prefix:     # Mandatory string input
      description: "Define a prefix for the job name"
    job-stage:      # Optional string input with a default value when not provided
      default: test
    environment:    # Mandatory input that must match one of the options
      options: ['test', 'staging', 'production']
    concurrency:
      type: number  # Optional numeric input with a default value when not provided
      default: 1
    version:        # Mandatory string input that must match the regular expression
      type: string
      regex: ^v\d\.\d+(\.\d+)$
    export_results: # Optional boolean input with a default value when not provided
      type: boolean
      default: true
---

"$[[ inputs.job-prefix ]]-scan-website":
  stage: $[[ inputs.job-stage ]]
  script:
    - echo "scanning website -e $[[ inputs.environment ]] -c $[[ inputs.concurrency ]] -v $[[ inputs.version ]]"
    - if $[[ inputs.export_results ]]; then echo "export results"; fi
```

In this example:

- `job-prefix` is a mandatory string input and must be defined.
- `job-stage` is optional. If not defined, the value is `test`.
- `environment` is a mandatory string input that must match one of the defined options.
- `concurrency` is an optional numeric input. When not specified, it defaults to `1`.
- `version` is a mandatory string input that must match the specified regular expression.
- `export_results` is an optional boolean input. When not specified, it defaults to `true`.

### Input types [Permalink](https://docs.gitlab.com/ci/inputs/\#input-types "Permalink")

You can specify that an input must use a specific type with the optional `spec:inputs:type` keyword.

The input types are:

- [`array`](https://docs.gitlab.com/ci/inputs/#array-type)
- `boolean`
- `number`
- `string` (default when not specified)

When an input replaces an entire YAML value in the CI/CD configuration, it is interpolated
into the configuration as its specified type. For example:

yaml

```yaml
spec:
  inputs:
    array_input:
      type: array
    boolean_input:
      type: boolean
    number_input:
      type: number
    string_input:
      type: string
---

test_job:
  allow_failure: $[[ inputs.boolean_input ]]
  needs: $[[ inputs.array_input ]]
  parallel: $[[ inputs.number_input ]]
  script: $[[ inputs.string_input ]]
```

When an input is inserted into a YAML value as part of a larger string, the input
is always interpolated as a string. For example:

yaml

```yaml
spec:
  inputs:
    port:
      type: number
---

test_job:
  script: curl "https://gitlab.com:$[[ inputs.port ]]"
```

#### Array type [Permalink](https://docs.gitlab.com/ci/inputs/\#array-type "Permalink")

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/407176) in GitLab 16.11.

The content of the items in an array type can be any valid YAML map, sequence, or scalar. More complex YAML features
like [`!reference`](https://docs.gitlab.com/ci/yaml/yaml_optimization/#reference-tags) cannot be used. When using the value of an array
input in a string (for example `echo "My rules: $[[ inputs.rules-config ]]"` in your `script:` section), you might
see unexpected results. The array input is converted to its string representation, which might not match your
expectations for complex YAML structures such as maps.

yaml

```yaml
spec:
  inputs:
    rules-config:
      type: array
      default:
        - if: $CI_PIPELINE_SOURCE == "merge_request_event"
          when: manual
        - if: $CI_PIPELINE_SOURCE == "schedule"
---

test_job:
  rules: $[[ inputs.rules-config ]]
  script: ls
```

Array inputs must be formatted as JSON, for example `["array-input-1", "array-input-2"]`,
when manually passing inputs for:

- [Manually run pipelines](https://docs.gitlab.com/ci/pipelines/#run-a-pipeline-manually).
- The [pipeline triggers API](https://docs.gitlab.com/api/pipeline_triggers/#trigger-a-pipeline-with-a-token).
- The [pipelines API](https://docs.gitlab.com/api/pipelines/#create-a-new-pipeline).
- Git [push options](https://docs.gitlab.com/topics/git/commit/#push-options-for-gitlab-cicd)
- [Pipeline schedules](https://docs.gitlab.com/ci/pipelines/schedules/#create-a-pipeline-schedule)

##### Array inputs with options [Permalink](https://docs.gitlab.com/ci/inputs/\#array-inputs-with-options "Permalink")

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/566155) in GitLab 19.0.

You can define a list of options to restrict the allowed values for array inputs.
When you run a pipeline manually, the UI displays a multi-select dropdown
instead of a text field. For example:

yaml

```yaml
spec:
  inputs:
    runner_tags:
      type: array
      default: ["docker"]
      options:
        - docker
        - linux
        - gpu
        - macos
---

test:
  script:
    - run_tests.sh
  tags: $[[ inputs.runner_tags ]]
```

The pipeline fails to start if any value in the array input does not match a listed option.

##### Access individual array elements [Permalink](https://docs.gitlab.com/ci/inputs/\#access-individual-array-elements "Permalink")

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/work_items/587657) in GitLab 18.10 [with a flag](https://docs.gitlab.com/administration/feature_flags/) named `ci_inputs_array_index_operator`. Disabled by default.
- [Generally available](https://gitlab.com/gitlab-org/gitlab/-/work_items/587657) in GitLab 18.11. Feature flag `ci_inputs_array_index_operator` removed.

Use bracket notation with an index number to access individual elements of an array input.
Array items are indexed in the order they are defined in the YAML array,
with positive numbers, and the `[0]` index item is the first item in the array.

For example:

yaml

```yaml
spec:
  inputs:
    supported_versions:
      type: array
      default:
        - '2.0'
        - '1.0'
        - '0.1'
---

job:
  script:
    # Outputs: 'Latest version is 2.0'
    - echo 'Latest version is $[[ inputs.supported_versions[0] ]]'
```

You can chain array indexing with dot notation to access nested values:

yaml

```yaml
spec:
  inputs:
    servers:
      type: array
      default:
        - host: server1.example.com
          port: 8080
---

job:
  script:
    - curl "https://$[[ inputs.servers[0].host ]]:$[[ inputs.servers[0].port ]]"
```

For multi-dimensional arrays, use multiple indices in a row. For example, you can use `[0][1]` for a 2-dimensional array:

yaml

```yaml
spec:
  inputs:
    matrix:
      type: array
      default:
        - ['a', 'b']
        - ['c', 'd']
---

job:
  script:
    # Outputs: 'b'
    - echo $[[ inputs.matrix[0][1] ]]
```

You can chain together a maximum of 5 indices per segment, for example `arr[0][1][2][3][4]`.

#### Multi-line input string values [Permalink](https://docs.gitlab.com/ci/inputs/\#multi-line-input-string-values "Permalink")

Inputs support different value types. You can pass multi-string values using the following format:

yaml

```yaml
spec:
  inputs:
    closed_message:
      description: Message to announce when an issue is closed.
      default: 'Hi {{author}} :wave:,

        Based on the policy for inactive issues, this is now being closed.

        If this issue requires further attention, reopen this issue.'
---
```

### Define conditional input options with `spec:inputs:rules` [Permalink](https://docs.gitlab.com/ci/inputs/\#define-conditional-input-options-with-specinputsrules "Permalink")

History

- [Introduced](https://gitlab.com/groups/gitlab-org/-/epics/18546) in GitLab 18.7.

Use [`spec:inputs:rules`](https://docs.gitlab.com/ci/yaml/#specinputsrules) to define different `options` and `default` values for an input
based on the values of other inputs. You can use this configuration when one input should have different
allowed values depending on the context provided by other inputs.

Each rule in the `rules` list can have:

- `if`: An expression that checks the values of one or more inputs to determine when this rule applies. Uses the same syntax as
[`$[[ inputs.input-id ]]` interpolation](https://docs.gitlab.com/ci/inputs/#define-input-parameters-with-specinputs).
- `options`: A list of allowed values for the input when this rule matches.
- `default`: The default value to use when this rule matches.

Rules are evaluated in order. The first rule with a matching `if` condition is used.
The last rule without an `if` condition acts as a fallback when no other rules match.

For example, to define instance types that vary based on cloud provider and environment:

yaml

```yaml
spec:
  inputs:
    cloud_provider:
      options: ['aws', 'gcp', 'azure']
      default: 'aws'
      description: 'Cloud provider'

    environment:
      options: ['development', 'staging', 'production']
      default: 'development'
      description: 'Target environment'

    instance_type:
      description: 'VM instance type'
      rules:
        - if: $[[ inputs.cloud_provider ]] == 'aws' && $[[ inputs.environment ]] == 'development'
          options: ['t3.micro', 't3.small']
          default: 't3.micro'
        - if: $[[ inputs.cloud_provider ]] == 'aws' && $[[ inputs.environment ]] == 'production'
          options: ['t3.xlarge', 't3.2xlarge', 'm5.xlarge']
          default: 't3.xlarge'
        - if: $[[ inputs.cloud_provider ]] == 'gcp'
          options: ['e2-micro', 'e2-small', 'e2-standard-4']
          default: 'e2-micro'
        - if: $[[ inputs.cloud_provider ]] == 'azure'
          options: ['Standard_B1s', 'Standard_B2s', 'Standard_D2s_v3']
          default: 'Standard_B1s'
        - options: ['small', 'medium', 'large']  # Fallback for any other case
          default: 'small'
---

deploy:
  script: |
    echo "Deploying to $[[ inputs.cloud_provider ]]"
    echo "Environment: $[[ inputs.environment ]]"
    echo "Instance: $[[ inputs.instance_type ]]"
```

In this example:

- When `cloud_provider` is `aws` and `environment` is `development`, the user can select
from `t3.micro` or `t3.small` instance types, with `t3.micro` as the default.
- When `cloud_provider` is `aws` and `environment` is `production`, different instance
types are available (`t3.xlarge`, `t3.2xlarge`, `m5.xlarge`).
- When `cloud_provider` is `gcp`, GCP-specific instance types are available regardless
of the environment.
- If none of the conditions match, the fallback rule provides generic size options.

You can also use the `||` (OR) operator to match multiple conditions. For example:

yaml

```yaml
spec:
  inputs:
    deployment_type:
      options: ['canary', 'blue-green', 'rolling', 'recreate']
      default: 'rolling'

    requires_approval:
      description: 'Whether deployment requires manual approval'
      rules:
        - if: $[[ inputs.deployment_type ]] == 'canary' || $[[ inputs.deployment_type ]] == 'blue-green'
          options: ['true']
          default: 'true'
        - options: ['true', 'false']
          default: 'false'
---

deploy:
  script: echo "Deploying with $[[ inputs.deployment_type ]] strategy"
```

In this example, the `requires_approval` input is set to `true` when `deployment_type` is either
`canary` or `blue-green`. In all other cases, the default is `false` and both `true` or `false` are allowed options.

### Allow user-entered values with `default: null` [Permalink](https://docs.gitlab.com/ci/inputs/\#allow-user-entered-values-with-default-null "Permalink")

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/218804) in GitLab 18.9.

Use `spec:inputs:rules` with `default: null` and without `options` to allow users to enter
their own value for an input. This is useful for workflow-specific values like environment names
or test configurations.

For example:

yaml

```yaml
spec:
  inputs:
    deployment_type:
      options: ['standard', 'custom']
      default: 'standard'

    custom_config:
      description: 'Custom configuration value'
      rules:
        - if: $[[ inputs.deployment_type ]] == 'custom'
          default: null
---

deploy:
  script: echo "Config: $[[ inputs.custom_config ]]"
```

In this example, when `deployment_type` is `custom`, the `custom_config` input is listed on the run pipeline page
and users must enter a value for the input.

### Use boolean inputs with `spec:inputs:rules` [Permalink](https://docs.gitlab.com/ci/inputs/\#use-boolean-inputs-with-specinputsrules "Permalink")

You can use boolean inputs in rule conditions. Boolean values can be compared using boolean literals (`true`/`false`):

yaml

```yaml
spec:
  inputs:
    publish:
      type: boolean
      default: true

    publish_stage:
      rules:
        - if: $[[ inputs.publish ]] == true
          default: 'publish'
        - if: $[[ inputs.publish ]] == false
          default: 'test'
---

job:
  stage: $[[ inputs.publish_stage ]]
  script: echo "Publishing is $[[ inputs.publish ]]"
```

In this example, when `publish` is `true`, `publish_stage` defaults to `publish`. When `publish` is `false`,
it defaults to `test`.

## Set input values [Permalink](https://docs.gitlab.com/ci/inputs/\#set-input-values "Permalink")

You can set input values in your pipeline configuration or when you trigger a pipeline.

After the pipeline starts, you cannot fetch any used input values. If a value is safe to expose,
you can output the value in a job log for future reference, or save it in an artifact.

### For configuration added with `include` [Permalink](https://docs.gitlab.com/ci/inputs/\#for-configuration-added-with-include "Permalink")

History

- `include:with` [renamed to `include:inputs`](https://gitlab.com/gitlab-org/gitlab/-/issues/406780) in GitLab 16.0.

Use [`include:inputs`](https://docs.gitlab.com/ci/yaml/#includeinputs) to set the values for inputs
when the included configuration is added to the pipeline, including for:

- [CI/CD components](https://docs.gitlab.com/ci/components/)
- Any other configuration added with `include`.

For example, to include and set the input values for `scan-website-job.yml` from the
[input configuration example](https://docs.gitlab.com/ci/inputs/#input-configuration):

yaml

```yaml
include:
  - local: 'scan-website-job.yml'
    inputs:
      job-prefix: 'some-service-'
      environment: 'staging'
      concurrency: 2
      version: 'v1.3.2'
      export_results: false
```

In this example, the inputs for the included configuration are:

| Input | Value | Details |
| --- | --- | --- |
| `job-prefix` | `some-service-` | Must be explicitly defined. |
| `job-stage` | `test` | Not defined in `include:inputs`, so the value comes from `spec:inputs:default` in the included configuration. |
| `environment` | `staging` | Must be explicitly defined, and must match one of the values in `spec:inputs:options` in the included configuration. |
| `concurrency` | `2` | Must be a numeric value to match the `spec:inputs:type` set to `number` in the included configuration. Overrides the default value. |
| `version` | `v1.3.2` | Must be explicitly defined, and must match the regular expression in the `spec:inputs:regex` in the included configuration. |
| `export_results` | `false` | Must be either `true` or `false` to match the `spec:inputs:type` set to `boolean` in the included configuration. Overrides the default value. |

Input values are only available in the same file as the `spec` section defining them.
A file added with `include` cannot access inputs defined in other files, or the including file.
To use a value from an included file, pass it explicitly with `include:inputs`.

#### With multiple `include` entries [Permalink](https://docs.gitlab.com/ci/inputs/\#with-multiple-include-entries "Permalink")

Inputs must be specified separately for each include entry. For example:

yaml

```yaml
include:
  - component: $CI_SERVER_FQDN/the-namespace/the-project/the-component@1.0
    inputs:
      stage: my-stage
  - local: path/to/file.yml
    inputs:
      stage: my-stage
```

### For a pipeline [Permalink](https://docs.gitlab.com/ci/inputs/\#for-a-pipeline "Permalink")

History

- [Introduced](https://gitlab.com/groups/gitlab-org/-/epics/16321) in GitLab 17.11.

Inputs provide advantages over variables including type checking, validation and a clear contract.
Unexpected inputs are rejected.
Inputs for pipelines must be defined in the [`spec:inputs` header](https://docs.gitlab.com/ci/inputs/#define-input-parameters-with-specinputs)
of the main `.gitlab-ci.yml` file. You cannot use inputs defined in included files for pipeline-level configuration.

In [GitLab 17.7](https://docs.gitlab.com/update/deprecations/#increased-default-security-for-use-of-pipeline-variables)
and later, pipeline inputs are recommended over passing [pipeline variables](https://docs.gitlab.com/ci/variables/#use-pipeline-variables).
For enhanced security, you should [disable pipeline variables](https://docs.gitlab.com/ci/variables/#restrict-pipeline-variables) when using inputs.

You should always set default values when defining inputs for pipelines.
If any input is missing a default, the pipeline fails when it triggers automatically.
For example, merge request pipelines can trigger for changes to a merge request’s source branch.
You cannot manually set inputs for merge request pipelines, so if any input is missing a default,
the pipeline fails. This can also happen for branch pipelines, tag pipelines,
and other automatically triggered pipelines.

You can set input values with:

- [Downstream pipelines](https://docs.gitlab.com/ci/pipelines/downstream_pipelines/#pass-inputs-to-a-downstream-pipeline)
- [Manually run pipelines](https://docs.gitlab.com/ci/pipelines/#run-a-pipeline-manually).
- The [pipeline triggers API](https://docs.gitlab.com/api/pipeline_triggers/#trigger-a-pipeline-with-a-token)
- The [pipelines API](https://docs.gitlab.com/api/pipelines/#create-a-new-pipeline)
- Git [push options](https://docs.gitlab.com/topics/git/commit/#push-options-for-gitlab-cicd)
- [Pipeline schedules](https://docs.gitlab.com/ci/pipelines/schedules/#create-a-pipeline-schedule)
- The [`trigger` keyword](https://docs.gitlab.com/ci/pipelines/downstream_pipelines/#pass-inputs-to-a-downstream-pipeline)

A pipeline can take up to 20 inputs.

Feedback is welcome on [this issue](https://gitlab.com/gitlab-org/gitlab/-/issues/533802).

You can pass inputs to [downstream pipelines](https://docs.gitlab.com/ci/pipelines/downstream_pipelines/),
if the downstream pipeline’s configuration file uses [`spec:inputs`](https://docs.gitlab.com/ci/inputs/#define-input-parameters-with-specinputs).

For example, with [`trigger:inputs`](https://docs.gitlab.com/ci/yaml/#triggerinputs):

- [Parent-child pipeline](https://docs.gitlab.com/ci/inputs/#)
- [Multi-project pipeline](https://docs.gitlab.com/ci/inputs/#)

yaml

```yaml
trigger-job:
  trigger:
    strategy: mirror
    include:
      - local: path/to/child-pipeline.yml
        inputs:
          job-name: "defined"
  rules:
    - if: $CI_PIPELINE_SOURCE == 'merge_request_event'
```

yaml

```yaml
trigger-job:
  trigger:
    strategy: mirror
    project: project-group/my-downstream-project
    inputs:
      job-name: "defined"
  rules:
    - if: $CI_PIPELINE_SOURCE == 'merge_request_event'
```

#### Define pipeline inputs in external files [Permalink](https://docs.gitlab.com/ci/inputs/\#define-pipeline-inputs-in-external-files "Permalink")

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/merge_requests/206931) in GitLab 18.6 [with a flag](https://docs.gitlab.com/administration/feature_flags/) named `ci_file_inputs`. Disabled by default.
- [Generally available](https://gitlab.com/gitlab-org/gitlab/-/issues/579240) in GitLab 18.9. Feature flag `ci_file_inputs` removed.

You can reuse pipeline input definitions across multiple CI/CD configurations by defining them in
external files and including them a project’s pipeline configuration with [`spec:include`](https://docs.gitlab.com/ci/yaml/#specinclude).

Create a file with input definitions, for example in a file named `shared-inputs.yml`:

yaml

```yaml
inputs:
  environment:
    description: "Deployment environment"
    options: ['staging', 'production']
  region:
    default: 'us-east-1'
```

Then you can include the external inputs in your `.gitlab-ci.yml` with `local`:

yaml

```yaml
spec:
  include:
    - local: /shared-inputs.yml
---

deploy:
  script: echo "Deploying to $[[ inputs.environment ]] in $[[ inputs.region ]]"
```

If the file is stored outside your project, you can use:

- `project` for files in another GitLab project. Use the full project path and define the filename with `file`.
You can optionally also define the `ref` to fetch the file from.
- `remote` for file on another server. Use the full URL to the file.

You can also include multiple input files at the same time, for example:

yaml

```yaml
spec:
  include:
    - local: /shared-inputs.yml
    - project: 'my-group/shared-configs'
      ref: main
      file: '/ci/common-inputs.yml'
    - remote: 'https://example.com/ci/shared-inputs.yml'
---
```

You cannot use `spec:include` for [CI/CD component](https://docs.gitlab.com/ci/components/#component-spec-section) inputs.

#### Override inputs from an external file [Permalink](https://docs.gitlab.com/ci/inputs/\#override-inputs-from-an-external-file "Permalink")

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/557867) in GitLab 18.9.

Input keys must be unique across all included files and inline specifications.
If you define an input with the same key in multiple included files, or in both
an included file and the `inputs:` section in the `.gitlab-ci.yml` configuration,
the following error is returned:

```plaintext
Duplicate input keys found: environment. Input keys must be unique across all included files and inline specifications.
```

To fix this error, ensure each input key is defined only once, either in an included
file or in the inline `inputs:` section, but not both.

## Specify functions to manipulate input values [Permalink](https://docs.gitlab.com/ci/inputs/\#specify-functions-to-manipulate-input-values "Permalink")

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/409462) in GitLab 16.3.

You can specify predefined functions in the interpolation block to manipulate the input value.
The format supported is the following:

yaml

```yaml
$[[ input.input-id | <function1> | <function2> | ... <functionN> ]]
```

With functions:

- Only [predefined interpolation functions](https://docs.gitlab.com/ci/inputs/#predefined-interpolation-functions) are permitted.
- A maximum of 3 functions may be specified in a single interpolation block.
- The functions are executed in the sequence they are specified.

yaml

```yaml
spec:
  inputs:
    test:
      default: 'test $MY_VAR'
---

test-job:
  script: echo $[[ inputs.test | expand_vars | truncate(5,8) ]]
```

In this example, assuming the input uses the default value and `$MY_VAR` is an unmasked project variable with value `my value`:

1. First, the function [`expand_vars`](https://docs.gitlab.com/ci/inputs/#expand_vars) expands the value to `test my value`.
2. Then [`truncate`](https://docs.gitlab.com/ci/inputs/#truncate) applies to `test my value` with a character offset of `5` and length `8`.
3. The output of `script` would be `echo my value`.

### Predefined interpolation functions [Permalink](https://docs.gitlab.com/ci/inputs/\#predefined-interpolation-functions "Permalink")

#### `expand_vars` [Permalink](https://docs.gitlab.com/ci/inputs/\#expand_vars "Permalink")

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/387632) in GitLab 16.5.

Use `expand_vars` to expand [CI/CD variables](https://docs.gitlab.com/ci/variables/) in the input value.

Only variables you can [use with the `include` keyword](https://docs.gitlab.com/ci/yaml/includes/#use-variables-with-include) and which are
**not** [masked](https://docs.gitlab.com/ci/variables/#mask-a-cicd-variable) can be expanded.
[Nested variable expansion](https://docs.gitlab.com/ci/variables/where_variables_can_be_used/#nested-variable-expansion) is not supported.

Example:

yaml

```yaml
spec:
  inputs:
    test:
      default: 'test $MY_VAR'
---

test-job:
  script: echo $[[ inputs.test | expand_vars ]]
```

In this example, if `$MY_VAR` is unmasked (exposed in job logs) with a value of `my value`, then the input
would expand to `test my value`.

#### `truncate` [Permalink](https://docs.gitlab.com/ci/inputs/\#truncate "Permalink")

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/409462) in GitLab 16.3.

Use `truncate` to shorten the interpolated value. For example:

- `truncate(<offset>,<length>)`

| Name | Type | Description |
| --- | --- | --- |
| `offset` | Integer | Number of characters to offset by. |
| `length` | Integer | Number of characters to return after the offset. |

Example:

yaml

```yaml
$[[ inputs.test | truncate(3,5) ]]
```

Assuming the value of `inputs.test` is `0123456789`, then the output would be `34567`.

#### `posix_escape` [Permalink](https://docs.gitlab.com/ci/inputs/\#posix_escape "Permalink")

History

- [Introduced](https://gitlab.com/gitlab-org/gitlab/-/issues/568289) in GitLab 18.6.

Use `posix_escape` to escape any POSIX _Bourne shell_ control or meta characters in input values.
`posix_escape` escapes the characters by inserting `\` before relevant characters in the input.

Example:

yaml

```yaml
spec:
  inputs:
    test:
      default: |
        A string with single ' and double " quotes and   blanks
---

test-job:
  script: printf '%s\n' $[[ inputs.test | posix_escape ]]
```

In this example, `posix_escape` escapes characters that could be shell control or metadata characters:

console

```console
$ printf '%s\n' A\ string\ with\ single\ \'\ and\ double\ \"\ quotes\ and\ \ \ blanks
A string with single ' and double " quotes and   blanks
```

The escaped input preserves special characters and spacing as provided.

Do not rely on `posix_escape` for security purposes with untrusted input values.

`posix_escape` makes a best-effort attempt to preserve the input value exactly, but some
character combinations could still cause undesired results. Even when using `posix_escape`, it is possible that:

- Shell code included in the string might be executed.
- Single or double quotes might be used to escape any surrounding quoting.
- Variable references could be used to access protected variables.
- Input or output redirection might be used to read or write to local files.
- Unescaped spaces are used by shells to split a string into multiple arguments.

For security purposes you should ensure that your inputs are trusted. You can use:

- The [`spec:input:type`](https://docs.gitlab.com/ci/yaml/#specinputstype)`number` or `boolean`, which cannot contain problematic characters.
- The [`spec:input:regex`](https://docs.gitlab.com/ci/yaml/#specinputsregex) keyword to prevent problematic inputs.
- The [`spec:input:options`](https://docs.gitlab.com/ci/yaml/#specinputsoptions) keyword to define a predefined list of input options.

If you combine `posix_escape` with `expand_vars`, you must set `expand_vars` first.
Otherwise `posix_escape` would escape the `$` in the variable, preventing expansion.
For example:

yaml

```yaml
test-job:
  script: echo $[[ inputs.test | expand_vars | posix_escape ]]
```

## Troubleshooting [Permalink](https://docs.gitlab.com/ci/inputs/\#troubleshooting "Permalink")

### YAML syntax errors when using `inputs` in `rules` [Permalink](https://docs.gitlab.com/ci/inputs/\#yaml-syntax-errors-when-using-inputs-in-rules "Permalink")

When you use input to modify `rules:if` expressions, you might get one of
[a variety of syntax errors](https://docs.gitlab.com/ci/jobs/job_troubleshooting/#this-gitlab-ci-configuration-is-invalid-for-variable-expressions).

These errors are often related to how strings are handled in [CI/CD variable expressions](https://docs.gitlab.com/ci/jobs/job_rules/#cicd-variable-expressions).
Expressions in `rules:if` expect a CI/CD variable compared to a quoted string (`'` or `"`) or another variable.
When input values are inserted into the `rules` configuration at pipeline runtime,
the resulting value might not be a quoted string or variable, which causes the error.

For example, in the configuration to include:

yaml

```yaml
spec:
  inputs:
    branch:
      default: $CI_DEFAULT_BRANCH
    branch2:
      default: $CI_DEFAULT_BRANCH
---

job-name:
  rules:
    - if: $CI_COMMIT_REF_NAME == $[[ inputs.branch ]]
    - if: $CI_COMMIT_REF_NAME == $[[ inputs.branch2 ]]
```

Then, in the main configuration file:

yaml

```yaml
include:
  inputs:
    branch: $CI_DEFAULT_BRANCH  # Valid
    branch2: main               # Invalid
```

In this example:

- Using `branch: $CI_DEFAULT_BRANCH` is valid. The `if:` clause evaluates to
`if: $CI_COMMIT_REF_NAME == $CI_DEFAULT_BRANCH`, which is a valid variable expression.
The variable does not need to be quoted.
- Using `branch2: main` is invalid. The `if:` clause evaluates to
`if: $CI_COMMIT_REF_NAME == main`, which is invalid because `main` is a string but is not quoted.

To resolve this issue, make sure expressions remain properly formatted after input values
are inserted into the configuration. This might require additional quote characters.
For example, add quotes to the rules that use string values:

yaml

```yaml
rules:
  if: $CI_COMMIT_REF_NAME == "$[[ inputs.branch2 ]]"
```

For interpolation functions like [`expand_vars`](https://docs.gitlab.com/ci/inputs/#expand_vars),
you might also need to quote the entire `if:` expression. For example:

yaml

```yaml
spec:
  inputs:
    environment:
      default: "$ENVIRONMENT"
---

$[[ inputs.environment | expand_vars ]] job:
  script: echo
  rules:
    - if: '"$[[ inputs.environment | expand_vars ]]" == "production"'
```

In this example, quoting both the input and the entire `if:` expression ensures valid
syntax after the input is evaluated. When quotes are nested, use `"` for the inner
quotes and `'` for the outer quotes, or the inverse.

Jobs names do not need to be quoted.

Was this page helpful?YesNo

reCAPTCHA

Recaptcha requires verification.

protected by **reCAPTCHA**

| Input | Value | Details |
| --- | --- | --- |

| Name | Type | Description |
| --- | --- | --- |